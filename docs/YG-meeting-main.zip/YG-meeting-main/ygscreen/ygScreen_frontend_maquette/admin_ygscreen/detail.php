<?php
/**
 * File: detail.php
 * Version: 1.1.3
 * Description: Maquette PHP complète de la page Détail compte avec toutes les popups supplémentaires.
 */

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<title>Activ'screen - Détail du compte avec popups étendues</title>
<style>
    /* Styles de base identiques */
    body {
        font-family: Arial, sans-serif;
        background: #000;
        color: #eee;
        margin: 0; padding: 0;
    }
    .header {
        background: linear-gradient(to bottom, #3a3a3a 0%, #1c1c1c 100%);
        color: #eee;
        padding: 10px 20px;
        box-shadow: inset 0 -2px 5px rgba(0,0,0,0.7);
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        user-select: none;
    }
    .logo {
        font-weight: bold;
        font-size: 26px;
        color: white;
        text-shadow: 0 2px 3px rgba(0,0,0,0.8);
        font-family: 'Trebuchet MS', Arial, sans-serif;
        position: relative;
    }
    .logo::after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 0;
        width: 100%;
        height: 15px;
        background: linear-gradient(transparent, rgba(255,255,255,0.25));
        opacity: 0.3;
        pointer-events: none;
        filter: blur(3px);
    }
    .user-info {
        text-align: right;
        line-height: 1.2;
    }
    .user-info .logout {
        color: #f44336;
        cursor: pointer;
        font-weight: bold;
    }
    nav {
        background-color: #222;
        border-top: 3px solid #600000;
        box-shadow: 0 3px 5px rgba(0,0,0,0.5);
        user-select: none;
    }
    nav ul {
        list-style: none;
        margin: 0; padding: 0 15px;
        display: flex;
        height: 38px;
        align-items: center;
    }
    nav ul li {
        position: relative;
        margin-right: 8px;
    }
    nav ul li a, nav ul li button {
        background-color: #444;
        border: none;
        padding: 8px 16px;
        color: #ccc;
        font-size: 14px;
        cursor: pointer;
        text-decoration: none;
        display: block;
        border-radius: 3px 3px 0 0;
        transition: background-color 0.3s ease, color 0.3s ease;
        user-select: none;
    }
    nav ul li a:hover, nav ul li button:hover {
        background-color: #5a5a5a;
        color: #fff;
    }
    nav ul li.active > button, nav ul li.active > a {
        background-color: #600000;
        color: white;
        font-weight: bold;
        cursor: default;
    }
    nav ul li ul.dropdown {
        position: absolute;
        top: 38px;
        left: 0;
        background-color: #fff;
        box-shadow: 0 5px 8px rgba(0,0,0,0.3);
        padding: 0;
        margin: 0;
        list-style: none;
        min-width: 180px;
        border-radius: 0 0 5px 5px;
        display: none;
        z-index: 1000;
    }
    nav ul li:hover ul.dropdown {
        display: block;
    }
    nav ul li ul.dropdown li {
        margin: 0;
    }
    nav ul li ul.dropdown li a {
        padding: 10px 16px;
        color: #222;
        font-weight: normal;
        border-bottom: 1px solid #ddd;
        border-radius: 0;
    }
    nav ul li ul.dropdown li a:hover {
        background-color: #f4f4f4;
        color: #600000;
        font-weight: bold;
    }
    main {
        background-color: #eee;
        color: #333;
        padding: 20px 30px;
        margin-top: 2px;
        user-select: none;
        max-width: 1100px;
        margin-left: auto;
        margin-right: auto;
    }
    .section-box {
        border: 1px solid #a23333;
        background-color: #fff;
        border-radius: 5px;
        margin-bottom: 20px;
        padding: 15px;
    }
    .section-box h3 {
        background-color: #a23333;
        color: #fff;
        padding: 5px 10px;
        margin: -15px -15px 15px -15px;
        font-size: 16px;
        border-radius: 5px 5px 0 0;
        user-select: none;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
        margin-bottom: 10px;
    }
    thead {
        background-color: #a23333;
        color: white;
        user-select: none;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 5px 8px;
        vertical-align: middle;
        text-align: left;
    }
    tbody tr:nth-child(odd) {
        background-color: #ffe5e5;
    }
    tbody tr:nth-child(even) {
        background-color: #fff;
    }
    .actions {
        text-align: center;
        user-select: none;
        width: 100px;
    }
    .actions img, .actions button {
        cursor: pointer;
        margin: 0 4px;
        vertical-align: middle;
        width: 16px;
        height: 16px;
        background: none;
        border: none;
        padding: 0;
    }
    .btn-small {
        background-color: #888;
        border: none;
        color: #ddd;
        padding: 5px 12px;
        margin-bottom: 8px;
        cursor: pointer;
        border-radius: 3px;
        font-weight: bold;
        margin-right: 8px;
    }
    .btn-small:hover {
        background-color: #666;
    }
    .info-green {
        color: green;
        font-weight: bold;
    }
    .info-red {
        color: red;
        font-weight: bold;
    }
    .link-red {
        color: #a23333;
        font-style: italic;
        text-decoration: underline;
        cursor: pointer;
    }
    .input-textarea {
        width: 100%;
        min-height: 60px;
        font-family: Arial, sans-serif;
        font-size: 14px;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        resize: vertical;
    }
    .form-section {
        margin-bottom: 15px;
    }
    .form-label {
        font-weight: bold;
        display: block;
        margin-bottom: 5px;
    }
    .form-inline {
        display: flex;
        gap: 20px;
    }
    .form-inline > div {
        flex: 1;
    }
    .green-arrow {
        color: green;
        font-weight: bold;
        cursor: pointer;
        margin-right: 10px;
    }
    .red-button {
        background-color: #a23333;
        border: none;
        color: white;
        padding: 6px 14px;
        cursor: pointer;
        border-radius: 3px;
        font-weight: bold;
    }
    .red-button:hover {
        background-color: #7b1f1f;
    }

    /* Popup modal commun */
    .modal-bg {
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.6);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 10000;
    }
    .modal {
        background: #fff;
        width: 450px;
        border-radius: 6px;
        box-shadow: 0 0 15px rgba(0,0,0,0.5);
        padding: 15px 20px 20px 20px;
        position: relative;
        user-select: text;
        max-height: 80vh;
        overflow-y: auto;
    }
    .modal h2 {
        margin: 0 0 15px 0;
        padding-bottom: 5px;
        border-bottom: 2px solid #a23333;
        color: #a23333;
        font-size: 18px;
    }
    .modal label {
        display: block;
        margin: 10px 0 3px 0;
        font-weight: bold;
    }
    .modal textarea, .modal select, .modal input[type="text"] {
        width: 100%;
        font-family: Arial, sans-serif;
        font-size: 14px;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        box-sizing: border-box;
    }
    .modal textarea {
        min-height: 60px;
        resize: vertical;
    }
    .modal .close-btn {
        position: absolute;
        top: 10px; right: 10px;
        background: #f44336;
        color: white;
        width: 22px;
        height: 22px;
        text-align: center;
        line-height: 22px;
        font-weight: bold;
        border-radius: 50%;
        cursor: pointer;
        user-select: none;
    }
    .modal .update-btn, .modal .ok-btn {
        margin-top: 15px;
        background-color: #a23333;
        border: none;
        color: white;
        padding: 7px 18px;
        cursor: pointer;
        border-radius: 3px;
        float: right;
        font-weight: bold;
    }
    .modal .update-btn:hover, .modal .ok-btn:hover {
        background-color: #7b1f1f;
    }
    .modal .info-text {
        font-size: 12px;
        margin-top: 10px;
        color: #555;
    }
</style>
<script>
    function showModal(id) {
        document.getElementById('modal-' + id).style.display = 'flex';
    }
    function closeModal(id) {
        document.getElementById('modal-' + id).style.display = 'none';
    }
</script>
</head>
<body>
<div class="header">
    <div class="logo">Activ'screen</div>
    <div class="user-info">
        Bienvenue Yann Gantner - <span class="logout">Me déconnecter</span><br>
        <?php echo date('H:i (l, F d)'); ?>
    </div>
</div>
<nav>
    <ul>
        <li><button type="button">Yks/Queries</button></li>
        <li><button type="button">Contenu</button></li>
        <li class="active"><button type="button">Clients</button></li>
    </ul>
</nav>
<main>
    <div class="section-box">
        <h3>Détail du compte [18314]</h3>

        <h4>Shops</h4>
        <button class="btn-small">Add new shop</button>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>City</th>
                    <th>Nb Streams</th>
                    <th>Nb Players</th>
                    <th>Nb Hosts</th>
                    <th>Hosts</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>19380</td>
                    <td class="link-red">FOTO OTTICA RB</td>
                    <td>VIA CARNIA 7/9</td>
                    <td>33054 LIGNANO SABBIADORO</td>
                    <td>2</td>
                    <td>0</td>
                    <td>1</td>
                    <td><a href="#" class="link-red" title="Host details">64457DCA75106221E5D9E18E6F1001F0</a> - V3-S01-007794</td>
                    <td><a href="#" class="link-red">Coordonnées</a> - <a href="#" class="link-red">Trash shop</a></td>
                </tr>
            </tbody>
        </table>

        <div class="form-inline">
            <div>
                <h4>Account details</h4>
                <p><strong>account name</strong><br>FOTO OTTICA RB</p>
                <p><strong>Creation</strong><br>Vendredi 30 Mai 2025</p>
                <p><strong>Release level</strong><br>stable</p>
                <p><strong>Login</strong><br>1026712</p>
                <p><strong>Password</strong><br>••••••••</p>
                <p><strong>Distributor</strong><br>Essilor Italy</p>
                <p><strong>Personnal brand</strong><br>20689</p>
                <p><strong>Languages</strong><br>it-it</p>
                <button class="btn-small" onclick="showModal('account')">Modifier cet account</button>
            </div>

            <div>
                <h4>Migrate elements to this account</h4>
                <textarea rows="8" style="width: 100%;" placeholder="Old account IDs (one per line)"></textarea>
                <button class="btn-small" style="margin-top: 5px;">Choose elements</button>
            </div>

            <div>
                <h4>My activscreen</h4>
                <p><span class="green-arrow">&#x27A4;</span> Connectez vous sur my-activscreen.com</p>
            </div>
        </div>
    </div>

    <div class="section-box">
        <h3>Liste des playlists</h3>
        <button class="btn-small" onclick="showModal('playlist')">Ajouter une playlist</button>
        <table>
            <thead>
                <tr>
                    <th>Playlist</th>
                    <th>Playlist name</th>
                    <th>Duration</th>
                    <th>Last modification</th>
                    <th>Nb of video</th>
                    <th>Ratio</th>
                    <th>Display in</th>
                    <th>Preview</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="9" style="text-align:center; color:#a23333;">Aucune playlist</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="section-box">
        <h3>Licenses</h3>
        <table>
            <thead>
                <tr>
                    <th>License</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>Expires</th>
                    <th><input type="checkbox" title="toggle non-interactive"/></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Bouquet Optique</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td><input type="checkbox"/></td>
                </tr>
                <tr>
                    <td>Bouquet Infos</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td><input type="checkbox"/></td>
                </tr>
                <tr>
                    <td>Bouquet Evasion</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td><input type="checkbox"/></td>
                </tr>
                <tr>
                    <td>Bouquet Audition</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td><input type="checkbox"/></td>
                </tr>
                <tr>
                    <td>Onglet Créactiv’</td>
                    <td>2025-05-30 16:26:35 +0200</td>
                    <td>2028-05-29 16:26:45 +0200</td>
                    <td>in 3 years 13 days</td>
                    <td><input type="checkbox"/></td>
                </tr>
                <tr>
                    <td>Onglet Programmation</td>
                    <td>2025-05-30 16:26:35 +0200</td>
                    <td>2028-05-29 16:26:45 +0200</td>
                    <td>in 3 years 13 days</td>
                    <td><input type="checkbox"/></td>
                </tr>
                <tr>
                    <td>Onglet Activ’screen Interactive</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td><input type="checkbox"/></td>
                </tr>
                <tr class="summary-row">
                    <td colspan="3">7 licenses</td>
                    <td colspan="2" style="text-align:right;">next event: 3 years 13 days</td>
                </tr>
            </tbody>
        </table>
        <div style="margin-top:10px;">
            <label for="subscribe_for">For current selection :</label>
            <select id="subscribe_for" name="subscribe_for" onchange="updateSubscribeLabel()">
                <option value="" disabled selected>-- choose a duration --</option>
                <option value="1 month">1 month</option>
                <option value="6 months">6 months</option>
                <option value="1 year">1 year</option>
                <option value="2 years">2 years</option>
                <option value="3 years">3 years</option>
                <option value="4 years">4 years</option>
                <option value="5 years">5 years</option>
                <option value="manual">-- manual dates --</option>
            </select>
            <button class="btn-small">Subscribe</button>
            or: <button class="btn-small red-button">Revoke</button>
        </div>
    </div>

    <div class="section-box">
        <h3>Medias management</h3>
        <p><button class="btn-small" onclick="showModal('brands')">View Brands requests</button>
        <button class="btn-small" onclick="showModal('videos')">View client's videos</button></p>
    </div>

    <div class="section-box">
        <h3>Liste des plannings</h3>
        <p>Aucun planning</p>
    </div>

    <div class="section-box">
        <h3>Channels</h3>
        <button class="btn-small" onclick="showModal('channel')">Create a channel from this account</button>
        <table>
            <thead>
                <tr>
                    <th>Channel #</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Ratio</th>
                    <th>Selectivity</th>
                    <th>Show on Distrib</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr><td colspan="7" style="color:#a23333; text-align:center;">No channel here</td></tr>
            </tbody>
        </table>
    </div>

    <div class="section-box">
        <h3>Carousels</h3>
        <button class="btn-small" onclick="showModal('carousel')">Add a carousel</button>
        <p style="background-color:#f8d7da; color:#721c24; padding:5px; border-radius:3px;">&#10006; No touch applications</p>
    </div>

    <div class="section-box">
        <h3>Web manifests</h3>
        <button class="btn-small" onclick="showModal('webmanifest')">Add a web manifest</button>
        <table>
            <thead>
                <tr>
                    <th>web_id</th><th>web_name</th><th>manifest_id</th><th>Build time</th><th>Locales updated</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr><td colspan="6" style="color:#a23333; text-align:center;">No web manifests</td></tr>
            </tbody>
        </table>
    </div>

    <div class="section-box">
        <h3>Operations</h3>
        <button class="red-button">Delete this account</button>
    </div>

</main>

<!-- Popup Modifier cet account -->
<div id="modal-account" class="modal-bg" onclick="if(event.target==this) closeModal('account');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-account-title">
        <div class="close-btn" onclick="closeModal('account')" title="Fermer">&times;</div>
        <h2 id="modal-account-title">account management [18314]</h2>
        <form>
            <label for="account_name">Nom :</label>
            <input id="account_name" name="account_name" type="text" value="FOTO OTTICA RB" />
            <label for="login">Login :</label>
            <input id="login" name="login" type="text" value="1026712" />
            <label for="password">Password :</label>
            <input id="password" name="password" type="text" value="Lmy9w3sG" />
            <label for="distributor">Distributeur :</label>
            <select id="distributor" name="distributor">
                <option selected>Essilor Italy</option>
                <option>Essilor Brasil</option>
                <option>Essilor Chile - Megalux</option>
            </select>
            <label for="release_level">Release level :</label>
            <select id="release_level" name="release_level">
                <option>Stable</option>
                <option>Beta</option>
                <option>Dev</option>
            </select>
            <label for="languages">Languages :</label>
            <select id="languages" name="languages" multiple size="4">
                <option>hu-hu</option>
                <option>id-id</option>
                <option>it-ch</option>
                <option selected>it-it</option>
            </select>
            <p><strong>Languages used: it-it</strong></p>
            <button type="submit" class="update-btn">Enregistrer l'account</button>
        </form>
    </div>
</div>

<!-- Popup Ajouter une playlist -->
<div id="modal-playlist" class="modal-bg" onclick="if(event.target==this) closeModal('playlist');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-playlist-title">
        <div class="close-btn" onclick="closeModal('playlist')" title="Fermer">&times;</div>
        <h2 id="modal-playlist-title">Add a playlist</h2>
        <form>
            <label for="playlist_name">Playlist Name :</label>
            <input id="playlist_name" name="playlist_name" type="text" />
            <button type="submit" class="ok-btn">Add playlist</button>
        </form>
    </div>
</div>

<!-- Popup Subscribe for (licences) -->
<div id="modal-subscribe" class="modal-bg" onclick="if(event.target==this) closeModal('subscribe');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-subscribe-title">
        <div class="close-btn" onclick="closeModal('subscribe')" title="Fermer">&times;</div>
        <h2 id="modal-subscribe-title">Subscribe for</h2>
        <form>
            <label for="duration_select">Duration :</label>
            <select id="duration_select" name="duration_select">
                <option>-- choose a duration --</option>
                <option>1 month</option>
                <option>6 months</option>
                <option>1 year</option>
                <option>2 years</option>
                <option>3 years</option>
                <option>4 years</option>
                <option>5 years</option>
                <option>-- manual dates --</option>
            </select>
            <button type="submit" class="ok-btn">Ok</button>
        </form>
    </div>
</div>

<!-- Popup Create a Channel -->
<div id="modal-channel" class="modal-bg" onclick="if(event.target==this) closeModal('channel');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-channel-title">
        <div class="close-btn" onclick="closeModal('channel')" title="Fermer">&times;</div>
        <h2 id="modal-channel-title">channel management [ Nouvelle chaine ]</h2>
        <form>
            <label for="channel_weight">Channel weight :</label>
            <input id="channel_weight" name="channel_weight" type="text" />
            <label for="merge_algorithm">Merge Algorithm :</label>
            <select id="merge_algorithm" name="merge_algorithm">
                <option>Ponderation (default)</option>
                <option>Other</option>
            </select>
            <label><input type="checkbox" name="apply_selectivity" /> Apply selectivity :</label>
            <label><input type="checkbox" name="show_on_distrib" checked /> Show on Distrib :</label>
            <label><input type="checkbox" name="is_global" /> Is global :</label>

            <fieldset style="margin-top:15px; padding:10px; border:1px solid #ccc;">
                <legend><strong>Compte</strong></legend>
                <label for="flux">Flux :</label>
                <select id="flux" name="flux">
                    <option>-- Sélectionner --</option>
                    <option>Flux 1</option>
                    <option>Flux 2</option>
                </select>
            </fieldset>

            <button type="submit" class="update-btn" style="margin-top:10px;">Enregistrer la chaîne</button>
        </form>
    </div>
</div>

<!-- Popup Add a Carousel -->
<div id="modal-carousel" class="modal-bg" onclick="if(event.target==this) closeModal('carousel');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-carousel-title">
        <div class="close-btn" onclick="closeModal('carousel')" title="Fermer">&times;</div>
        <h2 id="modal-carousel-title">Add a carousel</h2>
        <form>
            <label for="source">Application source :</label>
            <select id="source" name="source">
                <option>-- Sélectionner --</option>
                <option>ConnectedStore</option>
                <option>Nikon studio connecté (interactive)</option>
                <option>Phygital (contenu des socles 2019)</option>
            </select>
            <label for="copy_mode" style="margin-top:10px;">Mode de copie :</label>
            <select id="copy_mode" name="copy_mode">
                <option>-- Sélectionner --</option>
                <option>Slave</option>
                <option>Full copy</option>
            </select>
            <label for="name" style="margin-top:10px;">Nom :</label>
            <input id="name" name="name" type="text" />
            <button type="submit" class="ok-btn">Ok</button>
        </form>
    </div>
</div>

<!-- Popup Add a Web Manifest -->
<div id="modal-webmanifest" class="modal-bg" onclick="if(event.target==this) closeModal('webmanifest');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-webmanifest-title">
        <div class="close-btn" onclick="closeModal('webmanifest')" title="Fermer">&times;</div>
        <h2 id="modal-webmanifest-title">Add a web manifest</h2>
        <form>
            <label for="webmanifest_source">Application source :</label>
            <select id="webmanifest_source" name="webmanifest_source">
                <option>-- Sélectionner --</option>
                <option>ConnectedStore</option>
                <option>Nikon studio connecté (interactive)</option>
                <option>Phygital (contenu des socles 2019)</option>
            </select>
            <label for="webmanifest_name" style="margin-top:10px;">Name :</label>
            <input id="webmanifest_name" name="webmanifest_name" type="text" />
            <button type="submit" class="ok-btn">Save</button>
        </form>
    </div>
</div>

<!-- Popup Brands Requests -->
<div id="modal-brands" class="modal-bg" onclick="if(event.target==this) closeModal('brands');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-brands-title">
        <div class="close-btn" onclick="closeModal('brands')" title="Fermer">&times;</div>
        <h2 id="modal-brands-title">Brands requests</h2>
        <div style="display:flex; gap: 10px;">
            <select size="15" style="width:48%;">
                <option>Jeux kids &gt; Anglais</option>
                <option>Jeux kids &gt; Francais</option>
                <option>Jeux kids &gt; Italien</option>
                <option>&gt; Blue UV Capture</option>
                <option>&gt; Blue UV Capture extended</option>
                <option>&gt; COMFORT MAX</option>
                <option>&gt; CRIZAL EUROPE</option>
                <option>&gt; Comfort Max extended</option>
                <option>&gt; Crizal extended</option>
                <option>&gt; EPS</option>
                <option>&gt; EPS extended</option>
                <option>&gt; EYECODE</option>
                <option>&gt; Eyecode extended</option>
                <option>&gt; Eyezen 2023</option>
                <option>&gt; Eyezen 2023 extended</option>
                <option>&gt; LENS COMPARATOR XR 2023</option>
                <option>&gt; LENS COMPARATOR XR 2023 extended</option>
                <option>&gt; Transitions Gen S</option>
            </select>
            <div style="width:4%; display:flex; flex-direction: column; justify-content: center; gap: 10px;">
                <button title="Add">&rarr;</button>
                <button title="Remove">&larr;</button>
            </div>
            <select size="15" style="width:48%;"></select>
        </div>
        <table style="width:100%; margin-top:10px; font-size:12px;">
            <thead>
                <tr style="background:#a23333; color:white;">
                    <th>Brand</th><th>Date</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr><td colspan="3" style="color:#f00; text-align:center;">No requests for this account.</td></tr>
            </tbody>
        </table>
    </div>
</div>

<!-- Popup Client's Videos -->
<div id="modal-videos" class="modal-bg" onclick="if(event.target==this) closeModal('videos');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-videos-title">
        <div class="close-btn" onclick="closeModal('videos')" title="Fermer">&times;</div>
        <h2 id="modal-videos-title">Client's videos</h2>
        <div class="pagination" style="margin-bottom:10px;">
            [1] 2 3 ...2615 2616 2617 2618 2619 (1-42/109992)
        </div>
        <div style="margin-bottom:10px;">
            <a href="#" style="color: #4CAF50; text-decoration: none; font-weight: bold;">
                &#x2B07; Upload a new video
            </a>
        </div>
        <table>
            <thead>
                <tr>
                    <th>#</th><th>Image</th><th>Name</th><th>Internal name</th><th>Brand</th><th>Category</th>
                    <th>Active</th><th>Start date</th><th>End Date</th><th>Actions</th><th><input type="checkbox"/></th>
                </tr>
            </thead>
            <tbody>
                <tr style="background-color: #ffe5e5;">
                    <td>967944</td>
                    <td><img src="movie.png" alt="movie" style="width: 60px; height: 40px;" /></td>
                    <td>Promotion</td>
                    <td>No comment</td>
                    <td><a href="#" style="color:#a23333;">Animations Persos [#5961]</a></td>
                    <td><a href="#" style="color:#a23333;">CréActiv' [#9]</a></td>
                    <td style="text-align:center; color: red; font-weight:bold; font-size:18px;">&#9940;</td>
                    <td style="color: green;">2025-05-31</td>
                    <td>2037-01-01</td>
                    <td><input type="checkbox" /></td>
                </tr>
                <tr>
                    <td>967943</td>
                    <td><img src="logo.png" alt="logo" style="width: 60px; height: 40px;" /></td>
                    <td>Logo</td>
                    <td>No comment</td>
                    <td><a href="#" style="color:#a23333;">Animations Persos [#9321]</a></td>
                    <td><a href="#" style="color:#a23333;">CréActiv' [#9]</a></td>
                    <td style="text-align:center; color: green; font-weight:bold; font-size:18px;">&#9989;</td>
                    <td style="color: green;">2025-05-31</td>
                    <td>2037-01-01</td>
                    <td><input type="checkbox" /></td>
                </tr>
            </tbody>
        </table>
        <div class="summary-row">
            shown: 42 movies &nbsp;&nbsp; 18 brands &nbsp;&nbsp; 1 categories &nbsp;&nbsp; 28 active &nbsp;&nbsp; last event: 2025-05-31 &nbsp;&nbsp; next event: 2025-05-30
        </div>
        <form class="action-buttons" method="post" action="#">
            <label for="set_start_date">For current selection :</label><br />
            <input type="date" id="set_start_date" name="set_start_date" />
            <label for="set_end_date">Set end date to</label>
            <input type="date" id="set_end_date" name="set_end_date" />
            <button type="submit" class="update" disabled>Update</button>
            <button type="submit" class="delete">Delete</button>
        </form>
    </div>
</div>

</body>
</html>
