<?php
// File: /var/www/html/api/config.php
// Version: 1.2.0
// Date: 2025-05-31
// Author: Meeting Server Team
// Description: Configuration centralisée pour Meeting API (aucun objet PDO, juste les paramètres !)

return [
    // === Connexion à la base de données MySQL/MariaDB ===
    // Hôte (adresse IP ou DNS) de la base de données
    'db_host'    => getenv('DB_HOST')    ?: '127.0.0.1',
    // Nom de la base de données utilisée par le projet
    'db_name'    => getenv('DB_NAME')    ?: 'devices_db',
    // Nom d’utilisateur SQL utilisé pour la connexion
    'db_user'    => getenv('DB_USER')    ?: 'meeting_db',
    // Mot de passe SQL utilisé pour la connexion
    'db_pass'    => getenv('DB_PASS')    ?: '2cmorh2x',
    // Jeu de caractères pour la connexion PDO
    'db_charset' => getenv('DB_CHARSET') ?: 'utf8mb4',

    // === Authentification SSH API (clé pour authorized_keys, sécurité agent SSH) ===
    // Token secret pour l’endpoint SSH authorized_keys (doit correspondre côté serveur SSH)
    'ssh_authorized_keys_token' => getenv('SSH_AUTHORIZED_KEYS_TOKEN')
        ?: 'bd26cb67351f871891315b3592fc23fe31f9d744e338f44c98c7662de20a201c',

    // === Administration : compte d’accès temporaire à l’interface admin Meeting ===
    // Nom d’utilisateur pour le panneau d’admin (temporaire)
    'admin_user' => getenv('ADMIN_USER') ?: 'sn8k',
    // Mot de passe pour le panneau d’admin (temporaire)
    'admin_pass' => getenv('ADMIN_PASS') ?: 'Luka2013B!!!!',

    // === Timeout de heartbeat pour la disponibilité des devices (en secondes) ===
    // Durée maximale (en secondes) sans heartbeat avant qu’un device soit considéré "offline"
    'device_heartbeat_timeout' => getenv('DEVICE_HEARTBEAT_TIMEOUT') ?: 60,

    // === Répertoire et paramètres pour la stack reverse tunnel (TunnelController et forcecommand) ===
    // Dossier où sont déposés les fichiers de demande de tunnel
    'tunnel_requests_dir' => getenv('TUNNEL_REQUESTS_DIR') ?: '/var/www/html/api/tunnel_requests',
    // Dossier où sont stockés les fichiers de statut de tunnel
    'tunnel_status_dir'   => getenv('TUNNEL_STATUS_DIR')   ?: '/var/www/html/api/tunnel_status',
    // Fichier de log dédié à la gestion des tunnels reverse
    'tunnel_logfile'      => getenv('TUNNEL_LOGFILE')      ?: '/var/www/html/api/logs/tunnel_api.log',
    // Nom d’hôte (FQDN ou IP) utilisé pour générer les URLs de tunnel (HTTP/VNC/SSH)
    'tunnel_host'         => getenv('TUNNEL_HOST')         ?: 'clusterTO83.meeting.ygsoft.fr',
    // Chemin cible par défaut pour les commandes SCP (tunnel scp)
    'scp_default_path'    => getenv('SCP_DEFAULT_PATH')    ?: '/path',

    // === Journaux (logs) pour les statuts devices ===
    // Fichier log pour les statuts devices (StatusController)
    'status_logfile'   => getenv('STATUS_LOGFILE')   ?: '/var/www/html/api/logs/status_api.log',
    // Nombre maximum de logs "connection" conservés par device (purge au-delà)
    'status_max_logs'  => getenv('STATUS_MAX_LOGS')  ?: 25,

    // === Logs et token pour gestion des clés SSH (SshKeysController) ===
    // Fichier log dédié aux opérations sur les clés SSH devices
    'ssh_keys_logfile' => getenv('SSH_KEYS_LOGFILE') ?: '/var/www/html/api/logs/ssh_keys_api.log',
    // Token utilisé pour authentifier l’API des clés SSH (doit matcher côté forcecommand/serveur SSH)
    'ssh_api_token'    => getenv('SSH_API_TOKEN')    ?: 'REPLACE_ME',

    // === Logs système et API pour les métriques systèmes (MetricsController) ===
    // Fichier de logs des appels et stats de l’API de metrics système
    'metrics_logfile' => getenv('METRICS_LOGFILE') ?: '/var/www/html/api/logs/metrics_api.log',

    // === Paramètres pour la gestion des ports SSH reverse (ForceCommandController) ===
    // Premier port utilisable pour l’attribution de tunnels dynamiques
    'forcecommand_port_min'             => getenv('FORCECOMMAND_PORT_MIN') ?: 9050,
    // Dernier port utilisable pour l’attribution de tunnels dynamiques
    'forcecommand_port_max'             => getenv('FORCECOMMAND_PORT_MAX') ?: 9130,
    // Délai maximal (en secondes) entre deux heartbeats pour valider un device (forcecommand)
    'forcecommand_max_last_seen'        => getenv('FORCECOMMAND_MAX_LAST_SEEN') ?: 120,
    // Durée (en secondes) de réservation d’un port de tunnel (avant expiration)
    'forcecommand_reservation_duration' => getenv('FORCECOMMAND_RESERVATION_DURATION') ?: 300,

    // === Répertoire racine de stockage des firmwares/distributions binaires devices (FlashController, DeviceController) ===
    // Chemin absolu du dossier de stockage des fichiers de flash/distrib (firmwares, updates…)
    'flash_storage_root'    => getenv('FLASH_STORAGE_ROOT') ?: '/var/www/html/storage',

    // === Paramètres DeviceController : logs, stockage, scripts, tunnels, debug ===
    // Fichier de log principal pour toutes les opérations de DeviceController
    'device_logfile'         => getenv('DEVICE_LOGFILE') ?: '/var/www/html/api/logs/device_service.log',
    // Fichier de log pour la modification des notes device
    'device_note_logfile'    => getenv('DEVICE_NOTE_LOGFILE') ?: '/var/www/html/api/logs/device_notes.log',
    // Chemin général du stockage (utilisé pour lister types/distributions/devices)
    'storage_path'           => getenv('STORAGE_PATH') ?: '/var/www/html/storage',
    // Chemin du script de synchronisation des clés SSH (appelé automatiquement)
    'key_sync_script'        => getenv('KEY_SYNC_SCRIPT') ?: '/usr/local/bin/ygs-KeysSync.sh',
    // Fichier de log pour debug détaillé des workflows tunnel
    'tunnel_debug_logfile'   => getenv('TUNNEL_DEBUG_LOGFILE') ?: '/tmp/tunnel_debug.log',
    // Délai d’attente maximal (en secondes) pour l’établissement d’un tunnel dynamique device
    'tunnel_timeout'         => getenv('TUNNEL_TIMEOUT') ?: 30,

    // === Clé publique SSH du serveur et métadonnées ===
    // Clé publique du serveur utilisée par les devices pour l’authentification SSH (format OpenSSH)
    'server_pubkey' => getenv('SERVER_PUBKEY') ?: 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCdMOCKKEY... admin@meeting',
    // Empreinte SHA256 de la clé publique serveur (pour vérification côté device/admin)
    'server_pubkey_fingerprint' => getenv('SERVER_PUBKEY_FINGERPRINT') ?: 'SHA256:FAKEFINGERPRINT1234567890',
    // Date de génération de la clé publique serveur
    'server_pubkey_date' => getenv('SERVER_PUBKEY_DATE') ?: '2025-05-25 18:12:00',
    // Date du dernier déploiement (push) de la clé serveur sur les devices
    'server_key_last_deploy' => getenv('SERVER_KEY_LAST_DEPLOY') ?: '2025-05-27 13:55:41',

    // === Endpoints et logs pour MetricsController/Admin ===
    // Chemin relatif ou absolu vers l’API metrics (frontend admin)
    'metrics_api_url' => getenv('METRICS_API_URL') ?: '/api/metrics',
    // Chemin absolu du fichier log Metrics (utilisé si affichage côté PHP natif)
    'metrics_logfile' => getenv('METRICS_LOGFILE') ?: '/var/www/html/api/logs/metrics_api.log',

];
