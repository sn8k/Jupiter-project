<?php
/**
 * File: channel_details.php
 * Version: 1.0.0
 * Description: Maquette complète de la page détail d'une chaîne avec gestion, listes, popups et menus déroulants.
 */

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<title>Activ'screen - Detail de la chaîne</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #000;
        color: #eee;
        margin: 0; padding: 0;
    }
    .header {
        background: linear-gradient(to bottom, #3a3a3a 0%, #1c1c1c 100%);
        color: #eee;
        padding: 10px 20px;
        box-shadow: inset 0 -2px 5px rgba(0,0,0,0.7);
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        user-select: none;
    }
    .logo {
        font-weight: bold;
        font-size: 26px;
        color: white;
        text-shadow: 0 2px 3px rgba(0,0,0,0.8);
        font-family: 'Trebuchet MS', Arial, sans-serif;
        position: relative;
    }
    .logo::after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 0;
        width: 100%;
        height: 15px;
        background: linear-gradient(transparent, rgba(255,255,255,0.25));
        opacity: 0.3;
        pointer-events: none;
        filter: blur(3px);
    }
    .user-info {
        text-align: right;
        line-height: 1.2;
    }
    .user-info .logout {
        color: #f44336;
        cursor: pointer;
        font-weight: bold;
    }
    nav {
        background-color: #222;
        border-top: 3px solid #600000;
        box-shadow: 0 3px 5px rgba(0,0,0,0.5);
        user-select: none;
    }
    nav ul {
        list-style: none;
        margin: 0; padding: 0 15px;
        display: flex;
        height: 38px;
        align-items: center;
    }
    nav ul li {
        position: relative;
        margin-right: 8px;
    }
    nav ul li a, nav ul li button {
        background-color: #444;
        border: none;
        padding: 8px 16px;
        color: #ccc;
        font-size: 14px;
        cursor: pointer;
        text-decoration: none;
        display: block;
        border-radius: 3px 3px 0 0;
        transition: background-color 0.3s ease, color 0.3s ease;
        user-select: none;
    }
    nav ul li a:hover, nav ul li button:hover {
        background-color: #5a5a5a;
        color: #fff;
    }
    nav ul li.active > button, nav ul li.active > a {
        background-color: #600000;
        color: white;
        font-weight: bold;
        cursor: default;
    }
    nav ul li ul.dropdown {
        position: absolute;
        top: 38px;
        left: 0;
        background-color: #fff;
        box-shadow: 0 5px 8px rgba(0,0,0,0.3);
        padding: 0;
        margin: 0;
        list-style: none;
        min-width: 180px;
        border-radius: 0 0 5px 5px;
        display: none;
        z-index: 1000;
    }
    nav ul li:hover ul.dropdown {
        display: block;
    }
    nav ul li ul.dropdown li {
        margin: 0;
    }
    nav ul li ul.dropdown li a {
        padding: 10px 16px;
        color: #222;
        font-weight: normal;
        border-bottom: 1px solid #ddd;
        border-radius: 0;
    }
    nav ul li ul.dropdown li a:hover {
        background-color: #f4f4f4;
        color: #600000;
        font-weight: bold;
    }
    main {
        background-color: #eee;
        color: #333;
        padding: 20px 30px;
        margin-top: 2px;
        user-select: none;
        max-width: 1100px;
        margin-left: auto;
        margin-right: auto;
    }
    .section-box {
        border: 1px solid #a23333;
        background-color: #fff;
        border-radius: 5px;
        margin-bottom: 20px;
        padding: 15px;
    }
    .section-box h3 {
        background-color: #a23333;
        color: #fff;
        padding: 5px 10px;
        margin: -15px -15px 15px -15px;
        font-size: 16px;
        user-select: none;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
        margin-bottom: 10px;
    }
    thead {
        background-color: #a23333;
        color: white;
        user-select: none;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 5px 8px;
        vertical-align: middle;
        text-align: left;
    }
    tbody tr:nth-child(odd) {
        background-color: #ffe5e5;
    }
    tbody tr:nth-child(even) {
        background-color: #fff;
    }
    .actions {
        text-align: center;
        user-select: none;
        width: 100px;
    }
    .actions img, .actions button {
        cursor: pointer;
        margin: 0 4px;
        vertical-align: middle;
        width: 16px;
        height: 16px;
        background: none;
        border: none;
        padding: 0;
    }
    .btn-small {
        background-color: #888;
        border: none;
        color: #ddd;
        padding: 5px 12px;
        margin-bottom: 8px;
        cursor: pointer;
        border-radius: 3px;
        font-weight: bold;
        margin-right: 8px;
    }
    .btn-small:hover {
        background-color: #666;
    }
    .green-arrow {
        color: green;
        font-weight: bold;
        cursor: pointer;
        margin-right: 10px;
    }
    .red-button {
        background-color: #a23333;
        border: none;
        color: white;
        padding: 6px 14px;
        cursor: pointer;
        border-radius: 3px;
        font-weight: bold;
    }
    .red-button:hover {
        background-color: #7b1f1f;
    }
    .link-red {
        color: #a23333;
        text-decoration: underline;
        cursor: pointer;
        user-select: text;
    }
    .link-red:hover {
        color: #600000;
    }
    /* Popup modal commun */
    .modal-bg {
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.6);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 10000;
    }
    .modal {
        background: #fff;
        width: 350px;
        border-radius: 6px;
        box-shadow: 0 0 15px rgba(0,0,0,0.5);
        padding: 15px 20px 20px 20px;
        position: relative;
        user-select: text;
        max-height: 80vh;
        overflow-y: auto;
    }
    .modal h2 {
        margin: 0 0 15px 0;
        padding-bottom: 5px;
        border-bottom: 2px solid #a23333;
        color: #a23333;
        font-size: 18px;
    }
    .modal label {
        display: block;
        margin: 10px 0 3px 0;
        font-weight: bold;
    }
    .modal input[type="text"], .modal select {
        width: 100%;
        font-family: Arial, sans-serif;
        font-size: 14px;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        box-sizing: border-box;
    }
    .modal .close-btn {
        position: absolute;
        top: 10px; right: 10px;
        background: #f44336;
        color: white;
        width: 22px;
        height: 22px;
        text-align: center;
        line-height: 22px;
        font-weight: bold;
        border-radius: 50%;
        cursor: pointer;
        user-select: none;
    }
    .modal .add-btn {
        margin-top: 15px;
        background-color: #a23333;
        border: none;
        color: white;
        padding: 7px 18px;
        cursor: pointer;
        border-radius: 3px;
        float: right;
        font-weight: bold;
    }
    .modal .add-btn:hover {
        background-color: #7b1f1f;
    }
</style>
<script>
    function showModal(id) {
        document.getElementById('modal-' + id).style.display = 'flex';
    }
    function closeModal(id) {
        document.getElementById('modal-' + id).style.display = 'none';
    }
</script>
</head>
<body>
<div class="header">
    <div class="logo">Activ'screen</div>
    <div class="user-info">
        Bienvenue Yann Gantner - <span class="logout">Me déconnecter</span><br>
        <?php echo date('H:i (l, F d)'); ?>
    </div>
</div>
<nav>
    <ul>
        <li><button type="button">Yks/Queries</button></li>
        <li><button type="button">Contenu</button></li>
        <li class="active"><button type="button">Clients</button></li>
    </ul>
</nav>

<main>
    <h2>Detail de la chaîne [894]</h2>

    <div class="section-box" style="max-width: 30%; float: left; margin-right: 2%;">
        <h3>Channel details</h3>
        <table>
            <tbody>
                <tr><td>Name</td><td><em>Menu verre activisu</em></td></tr>
                <tr><td>Channel weight</td><td>1</td></tr>
                <tr><td>Selective</td><td>no</td></tr>
                <tr><td>Show on Distrib</td><td>no</td></tr>
                <tr><td><strong>Is global</strong></td><td>yes</td></tr>
                <tr><td>Creation</td><td>Vendredi 14 Septembre 2012</td></tr>
                <tr><td>Login</td><td>activisusilmo</td></tr>
                <tr><td>Password</td><td>••••••••</td></tr>
                <tr><td>Distributor</td><td><em>Démo Salon</em></td></tr>
            </tbody>
        </table>
        <button class="btn-small" onclick="showModal('channel')">Modifier ce channel</button>
    </div>

    <div class="section-box" style="max-width: 30%; float: left; margin-right: 2%;">
        <h3>Stream details</h3>
        <table>
            <tbody>
                <tr><td>#</td><td>13393</td></tr>
                <tr><td>Name</td><td>Flux VO3</td></tr>
                <tr><td>Contents</td><td>VO3</td></tr>
                <tr><td>Type</td><td>astouch</td></tr>
                <tr><td>Media type</td><td>astouch</td></tr>
                <tr><td>Playlist</td><td></td></tr>
            </tbody>
        </table>
        <button class="btn-small" onclick="showModal('stream')">Modifier ce stream</button>
    </div>

    <div class="section-box" style="max-width: 30%; float: left;">
        <h3>Subscription movie</h3>
        <button class="btn-small">Créer la vidéo d'inscription</button>
    </div>

    <div style="clear: both;"></div>

    <div class="section-box">
        <div style="color: #a23333; font-weight: bold; margin-bottom: 10px;">No contents in the stream: Please select a playlist !</div>
        <h3>Liste des flux</h3>
        <table>
            <thead>
                <tr>
                    <th>#</th><th>Name</th><th>Shop #</th><th>Shop Name</th><th>Distrib</th><th>Frequency</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="color:#a23333;">33045</td>
                    <td>demo_screen_a8master</td>
                    <td>17185</td>
                    <td>51406_Precisão Relojoaria e Otica Ltda</td>
                    <td>Essilor Brasil</td>
                    <td>100 %</td>
                    <td>
                        <a href="#">Edit</a> - <a href="#">Delete</a>
                    </td>
                </tr>
                <tr>
                    <td style="color:#a23333;">6177</td>
                    <td>demo_screen_a8master</td>
                    <td>15264</td>
                    <td>461243_BEATRIZ MARIA PEREIRA DA FONSECA VIEIRA 11260469654</td>
                    <td>Essilor Brasil</td>
                    <td>100 %</td>
                    <td>
                        <a href="#">Edit</a> - <a href="#">Delete</a>
                    </td>
                </tr>
                <tr>
                    <td style="color:#a23333;">30377</td>
                    <td>demo_screen_a8master</td>
                    <td>13615</td>
                    <td>022545_Ostsee Optik</td>
                    <td>Essilor Germany</td>
                    <td>100 %</td>
                    <td>
                        <a href="#">Edit</a> - <a href="#">Delete</a>
                    </td>
                </tr>
                <tr>
                    <td style="color:#a23333;">27491</td>
                    <td>demo_screen_a8master</td>
                    <td>12453</td>
                    <td>Bruce Too Eyewear</td>
                    <td>Essilor Canada</td>
                    <td>100 %</td>
                    <td>
                        <a href="#">Edit</a> - <a href="#">Delete</a>
                    </td>
                </tr>
                <tr>
                    <td style="color:#a23333;">22021</td>
                    <td>demo_screen_a8master</td>
                    <td>15265</td>
                    <td>498405_JOSE EDCARLOS DE SOUZA CARDOSO</td>
                    <td>Essilor Brasil</td>
                    <td>100 %</td>
                    <td>
                        <a href="#">Edit</a> - <a href="#">Delete</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</main>

<!-- Popup Channel management -->
<div id="modal-channel" class="modal-bg" onclick="if(event.target==this) closeModal('channel');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-channel-title">
        <div class="close-btn" onclick="closeModal('channel')" title="Fermer">&times;</div>
        <h2 id="modal-channel-title">Channel management [894]</h2>
        <form>
            <label for="channel_weight">Channel weight :</label>
            <input type="text" id="channel_weight" name="channel_weight" value="1" />
            <label for="merge_algorithm">Merge Algorithm :</label>
            <select id="merge_algorithm" name="merge_algorithm">
                <option value="ponderation" selected>Ponderation (default)</option>
                <option value="follow">Follow (notaires, ...)</option>
            </select>
            <label><input type="checkbox" id="apply_selectivity" name="apply_selectivity" /> Apply selectivity :</label>
            <label><input type="checkbox" id="show_on_distrib" name="show_on_distrib" /> Show on Distrib :</label>
            <label><input type="checkbox" id="is_global" name="is_global" disabled checked /> Is global :</label>
            <label for="account_flux">Flux :</label>
            <select id="account_flux" name="account_flux">
                <option value="">-- Sélectionner --</option>
                <option value="VO3_HTML5">VO3 (HTML5) - Flux VO3</option>
                <option value="VO3_HTML5_TEST">VO3 (HTML5) - FLUX VO3 test</option>
                <option value="MENU_VERR_ACTIVISU">Menu verre activisu - Flux meyefit</option>
                <option value="MENU_VERR_ACTIVISU_TABLETTE">Menu verre activisu - flux tablette interactive</option>
                <option value="MENU_VERR_ACTIVISU_VISAUDIO">Menu verre activisu - Flux Visaudio</option>
                <option value="MENU_VERR_ACTIVISU_VO2COPYPHYCOMFORT">Menu verre activisu - VO2CopyPhyComfort</option>
                <option value="MENU_VERR_ACTIVISU_VO2COPYPHYSIO">Menu verre activisu - VO2CopyPhysio</option>
                <option value="MENU_VERR_ACTIVISU_WIZFIT_US">Menu verre activisu - Flux Wizfit_US</option>
                <option value="SILMO2016_EXPERT4_ACTIVSTORE">Menu verre activisu - Silmo2016Expert4Activstore</option>
                <option value="SILMO2016_EXPERT4_COLONNE">Menu verre activisu - Silmo2016Expert4Colonne</option>
                <option value="SILMO2016_EYE_PARTNER">Menu verre activisu - Silmo2016EyePartner</option>
                <option value="MENU_VERR_ACTIVISU_CONNECTEDSTORE">Menu verre activisu - ConnectedStore</option>
                <option value="MENU_VERR_ACTIVISU_VISUALHEALTH">Menu verre activisu - Visual Health</option>
                <option value="MENU_VERR_ACTIVISU_CONNECTEDSTORE_ARBO">Menu verre activisu - ConnectedStore_ARBO</option>
                <option value="MENU_VERR_ACTIVISU_SANTE_VISUELLE">Menu verre activisu - Santé Visuelle</option>
                <option value="SWING4">Swing4 - Flux Swing4</option>
                <option value="EXPERT4_HTML5">Expert 4 (HTML5) - Flux Silmo_Expert4</option>
                <option value="EYECODE_HTML5">Eyecode (HTML5) - Flux Silmo_Eyecode</option>
                <option value="VO2_HTML5">VO2 (HTML5) - Flux Silmo_VO2</option>
            </select>
            <button class="add-btn" type="submit">Enregistrer la chaine</button>
        </form>
    </div>
</div>

</body>
</html>
