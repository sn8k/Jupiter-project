<?php
/**
 * File: ephemerides.php
 * Version: 1.1.0
 * Description: Maquette PHP de la page Ephemerides avec tableaux par mois, style Activ'screen, et popup édition intégrée.
 */

header('Content-Type: text/html; charset=utf-8');

// Liste des mois et nombre de jours pour simplifier (sans gestion années bissextiles)
$months = [
    'Janvier' => 31,
    'Février' => 28,
    'Mars' => 31,
    'Avril' => 30,
    'Mai' => 31,
    'Juin' => 30,
    'Juillet' => 31,
    'Août' => 31,
    'Septembre' => 30,
    'Octobre' => 31,
    'Novembre' => 30,
    'Décembre' => 31
];

// Fonction pour générer un texte lorem simple
function lorem($length = 60) {
    $lorem = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ";
    return substr(str_repeat($lorem, 5), 0, $length) . '...';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<title>Activ'screen - Ephémérides</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #000;
        color: #eee;
        margin: 0; padding: 0;
    }
    .header {
        background: linear-gradient(to bottom, #3a3a3a 0%, #1c1c1c 100%);
        color: #eee;
        padding: 10px 20px;
        box-shadow: inset 0 -2px 5px rgba(0,0,0,0.7);
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        user-select: none;
    }
    .logo {
        font-weight: bold;
        font-size: 26px;
        color: white;
        text-shadow: 0 2px 3px rgba(0,0,0,0.8);
        font-family: 'Trebuchet MS', Arial, sans-serif;
        position: relative;
    }
    .logo::after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 0;
        width: 100%;
        height: 15px;
        background: linear-gradient(transparent, rgba(255,255,255,0.25));
        opacity: 0.3;
        pointer-events: none;
        filter: blur(3px);
    }
    .user-info {
        text-align: right;
        line-height: 1.2;
    }
    .user-info .logout {
        color: #f44336;
        cursor: pointer;
        font-weight: bold;
    }
    nav {
        background-color: #222;
        border-top: 3px solid #600000;
        box-shadow: 0 3px 5px rgba(0,0,0,0.5);
        user-select: none;
    }
    nav ul {
        list-style: none;
        margin: 0; padding: 0 15px;
        display: flex;
        height: 38px;
        align-items: center;
    }
    nav ul li {
        position: relative;
        margin-right: 8px;
    }
    nav ul li a, nav ul li button {
        background-color: #444;
        border: none;
        padding: 8px 16px;
        color: #ccc;
        font-size: 14px;
        cursor: pointer;
        text-decoration: none;
        display: block;
        border-radius: 3px 3px 0 0;
        transition: background-color 0.3s ease, color 0.3s ease;
        user-select: none;
    }
    nav ul li a:hover, nav ul li button:hover {
        background-color: #5a5a5a;
        color: #fff;
    }
    nav ul li.active > button, nav ul li.active > a {
        background-color: #600000;
        color: white;
        font-weight: bold;
        cursor: default;
    }
    nav ul li ul.dropdown {
        position: absolute;
        top: 38px;
        left: 0;
        background-color: #fff;
        box-shadow: 0 5px 8px rgba(0,0,0,0.3);
        padding: 0;
        margin: 0;
        list-style: none;
        min-width: 180px;
        border-radius: 0 0 5px 5px;
        display: none;
        z-index: 1000;
    }
    nav ul li:hover ul.dropdown {
        display: block;
    }
    nav ul li ul.dropdown li {
        margin: 0;
    }
    nav ul li ul.dropdown li a {
        padding: 10px 16px;
        color: #222;
        font-weight: normal;
        border-bottom: 1px solid #ddd;
        border-radius: 0;
    }
    nav ul li ul.dropdown li a:hover {
        background-color: #f4f4f4;
        color: #600000;
        font-weight: bold;
    }
    main {
        background-color: #eee;
        color: #333;
        padding: 20px 30px;
        margin-top: 2px;
        user-select: none;
        max-width: 1000px;
        margin-left: auto;
        margin-right: auto;
    }
    h2.month-title {
        color: #a23333;
        margin-top: 40px;
        margin-bottom: 10px;
        border-bottom: 1px solid #a23333;
        padding-bottom: 3px;
        user-select: text;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
        margin-bottom: 20px;
    }
    thead {
        background-color: #a23333;
        color: white;
        user-select: none;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 5px 8px;
        vertical-align: top;
        text-align: left;
    }
    tbody tr:nth-child(odd) {
        background-color: #ffe5e5;
    }
    tbody tr:nth-child(even) {
        background-color: #fff;
    }
    tbody td.actions {
        text-align: right;
        user-select: none;
    }
    tbody td.actions a {
        color: #a23333;
        text-decoration: none;
        font-weight: bold;
        cursor: pointer;
    }
    tbody td.actions a:hover {
        text-decoration: underline;
    }

    /* Popup modal styles */
    .modal-bg {
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.6);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 10000;
    }
    .modal {
        background: #fff;
        width: 400px;
        border-radius: 6px;
        box-shadow: 0 0 15px rgba(0,0,0,0.5);
        padding: 15px 20px 20px 20px;
        position: relative;
        user-select: text;
    }
    .modal h2 {
        margin: 0 0 15px 0;
        padding-bottom: 5px;
        border-bottom: 2px solid #a23333;
        color: #a23333;
        font-size: 18px;
    }
    .modal label {
        display: block;
        margin: 10px 0 3px 0;
        font-weight: bold;
    }
    .modal textarea {
        width: 100%;
        height: 70px;
        resize: vertical;
        font-family: Arial, sans-serif;
        font-size: 14px;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
    }
    .modal .close-btn {
        position: absolute;
        top: 10px; right: 10px;
        background: #f44336;
        color: white;
        width: 22px;
        height: 22px;
        text-align: center;
        line-height: 22px;
        font-weight: bold;
        border-radius: 50%;
        cursor: pointer;
        user-select: none;
    }
    .modal .update-btn {
        margin-top: 15px;
        background-color: #a23333;
        border: none;
        color: white;
        padding: 7px 18px;
        cursor: pointer;
        border-radius: 3px;
        float: right;
        font-weight: bold;
    }
    .modal .update-btn:hover {
        background-color: #7b1f1f;
    }
</style>
<script>
    // Ouvre la popup et remplit les champs avec les données de la ligne cliquée
    function openModal(day, saint, anniversaires, evenement, citation) {
        document.getElementById('modal-bg').style.display = 'flex';
        document.getElementById('modal-title').textContent = 'Jour ' + day;
        document.getElementById('saint').value = saint;
        document.getElementById('anniversaires').value = anniversaires;
        document.getElementById('evenement').value = evenement;
        document.getElementById('citation').value = citation;
    }
    function closeModal() {
        document.getElementById('modal-bg').style.display = 'none';
    }
</script>
</head>
<body>
<div class="header">
    <div class="logo">Activ'screen</div>
    <div class="user-info">
        Bienvenue Yann Gantner - <span class="logout">Me déconnecter</span><br>
        <?php echo date('H:i (l, F d)'); ?>
    </div>
</div>
<nav>
    <ul>
        <li><button type="button">Yks/Queries</button></li>
        <li><button type="button">Contenu</button></li>
        <li><button type="button">Clients</button></li>
    </ul>
</nav>
<main>
<?php foreach ($months as $month => $days): ?>
    <h2 class="month-title"><?= htmlspecialchars($month) ?></h2>
    <table>
        <thead>
            <tr>
                <th>Jour</th>
                <th>Saint</th>
                <th>Anniversaires</th>
                <th>Evènement</th>
                <th>Citation</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php for ($day=1; $day <= $days; $day++):
                // Exemple de données simplifiées pour la popup
                $saint = "Saint Exemple";
                $anniversaires = "Lorem ipsum, Dolor sit (19XX)";
                $evenement = "Lorem ipsum dolor sit amet, consectetur.";
                $citation = "Lorem ipsum dolor sit amet, citation example.";
            ?>
                <tr>
                    <td><?= $day ?></td>
                    <td><?= $saint ?></td>
                    <td><?= $anniversaires ?></td>
                    <td><?= $evenement ?></td>
                    <td><?= $citation ?></td>
                    <td class="actions">
                        <a href="javascript:void(0);" onclick="openModal(<?= $day ?>, '<?= htmlspecialchars($saint, ENT_QUOTES) ?>', '<?= htmlspecialchars($anniversaires, ENT_QUOTES) ?>', '<?= htmlspecialchars($evenement, ENT_QUOTES) ?>', '<?= htmlspecialchars($citation, ENT_QUOTES) ?>')">Edit</a>
                    </td>
                </tr>
            <?php endfor; ?>
        </tbody>
    </table>
<?php endforeach; ?>
</main>

<!-- Popup modale -->
<div id="modal-bg" class="modal-bg" onclick="if(event.target==this) closeModal();">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <div class="close-btn" onclick="closeModal()" title="Fermer">&times;</div>
        <h2 id="modal-title">Jour X</h2>
        <form>
            <label for="saint">Saint :</label>
            <textarea id="saint" name="saint"></textarea>

            <label for="evenement">Evènement :</label>
            <textarea id="evenement" name="evenement"></textarea>

            <label for="citation">Citation :</label>
            <textarea id="citation" name="citation"></textarea>

            <label for="anniversaires">Anniversaires :</label>
            <textarea id="anniversaires" name="anniversaires"></textarea>

            <p>Séparés par des virgules.</p>

            <button type="submit" class="update-btn">Update</button>
        </form>
    </div>
</div>

</body>
</html>
