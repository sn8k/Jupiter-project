<?php
session_start();
if (empty($_SESSION['ygscreen_logged_in']) || !isset($_SESSION['ygscreen_username'])) {
    header('Location: index.php');
    exit;
}
$username = $_SESSION['ygscreen_display_name'] ?? $_SESSION['ygscreen_username'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<title>YGScreen - Supervision des vidéos</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        font-family: Arial, sans-serif;
        background: #000;
        color: #eee;
        margin: 0; padding: 0;
    }
    .header {
        background: linear-gradient(to bottom, #3a3a3a 0%, #1c1c1c 100%);
        color: #eee;
        height: 70px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 14px;
        padding: 0 28px;
        box-shadow: inset 0 -2px 5px rgba(0,0,0,0.7);
    }
    .logo {
        font-weight: bold;
        font-size: 26px;
        color: white;
        text-shadow: 0 2px 3px rgba(0,0,0,0.8);
        position: relative;
        user-select: none;
        font-family: 'Trebuchet MS', Arial, sans-serif;
        letter-spacing: 0.5px;
    }
    .logo::after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 0;
        width: 100%;
        height: 15px;
        background: linear-gradient(transparent, rgba(255,255,255,0.25));
        opacity: 0.3;
        pointer-events: none;
        filter: blur(3px);
    }
    .logo a { color: inherit; text-decoration: none; }
    .logo a:hover { color: #a23333; text-decoration: underline; }
    .user-info { text-align: right; line-height: 1.2; color:#eee;}
    .user-info .logout { color: #f44336; font-weight: bold; text-decoration:none; margin-left:10px; }
    .user-info .logout:hover { color: #fff; text-decoration: underline; }
    nav { background-color: #222; border-top: 3px solid #600000; box-shadow: 0 3px 5px rgba(0,0,0,0.5); user-select: none; padding: 0; }
    .navbar-nav .nav-link { color: #ccc !important; font-size: 15px; padding: 8px 18px !important; border-radius: 3px 3px 0 0; transition: background 0.2s, color 0.2s; margin-right: 5px; }
    .navbar-nav .nav-link.active, .navbar-nav .show > .nav-link { background-color: #600000 !important; color: #fff !important; font-weight: bold; }
    .navbar-nav .nav-link:hover { background-color: #5a5a5a !important; color: #fff !important; }
    .dropdown-menu { background: #fff; border-radius: 0 0 6px 6px; box-shadow: 0 5px 14px rgba(0,0,0,0.18); border: none; margin-top: 1px; min-width: 200px; z-index: 2000; }
    .dropdown-item { color: #333 !important; font-size: 15px; padding: 10px 18px; border-bottom: 1px solid #eee; transition: background 0.2s, color 0.2s; }
    .dropdown-item:last-child { border-bottom: none; }
    .dropdown-item:hover { background: #f4f4f4; color: #a23333 !important; font-weight: bold; }
    main { background-color: #eee; color: #333; padding: 28px 36px 24px 36px; margin-top: 2px; user-select: none; border-radius: 0 0 15px 15px; max-width: 1100px; margin-left: auto; margin-right: auto; min-height: 330px; }
    .filter-box {
        border: 1px solid #a23333;
        padding: 15px;
        background-color: #fff;
        color: #333;
        max-width: 700px;
        margin-bottom: 28px;
        border-radius: 7px;
    }
    .filter-box h3 {
        background-color: #a23333;
        color: #fff;
        padding: 7px 14px;
        margin: -15px -15px 15px -15px;
        font-size: 18px;
        border-radius: 7px 7px 0 0;
    }
    .filter-section label { font-weight: bold; font-size: 14px; margin-right: 4px;}
    .filter-section select, .filter-section input[type="text"], .filter-section input[type="date"] {
        margin-left: 10px; padding: 3px 6px; font-size: 13px;
    }
    .filter-links { font-size: 12px; margin-top: 5px; color: #a23333; cursor: pointer; }
    .filter-links a { color: #a23333; text-decoration: underline; margin-right: 10px; }
    .filter-buttons { text-align: right; margin-top: 10px; }
    .filter-buttons button { background-color: #a23333; color: #fff; border: none; padding: 7px 16px; margin-left: 7px; cursor: pointer; border-radius: 3px; font-weight: bold; }
    .filter-buttons button:hover { background-color: #7b1f1f; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 20px; }
    table thead { background-color: #a23333; color: white; user-select: none; }
    table th, table td { border: 1px solid #ddd; padding: 6px 8px; text-align: left; vertical-align: middle; }
    table tbody tr:nth-child(odd) { background-color: #ffe5e5; }
    table tbody tr:nth-child(even) { background-color: #fff; }
    table tbody tr td a { color: #a23333; text-decoration: none; }
    table tbody tr td a:hover { text-decoration: underline; }
    .icon-active { color: green; font-weight: bold; font-size: 18px; text-align: center; }
    .icon-inactive { color: red; font-weight: bold; font-size: 18px; text-align: center; }
    .pagination { background-color: #a23333; padding: 5px 10px; color: white; font-size: 13px; margin-bottom: 10px; border-radius: 5px; user-select: none; }
    .pagination a { color: white; text-decoration: none; margin: 0 3px; cursor: pointer; }
    .pagination a:hover { text-decoration: underline; }
    .summary { font-size: 12px; color: #444; margin-top: -10px; margin-bottom: 10px; }
    .action-buttons { margin-top: 15px; }
    .action-buttons input[type="text"], .action-buttons input[type="date"] {
        padding: 4px 8px; font-size: 13px; width: 150px; margin-right: 10px; border: 1px solid #ccc; border-radius: 3px;
    }
    .action-buttons button { padding: 6px 12px; font-weight: bold; border-radius: 3px; border: 1px solid #a23333; cursor: pointer; }
    .action-buttons button.update { background-color: #ccc; color: #666; border-color: #ccc; cursor: not-allowed; }
    .action-buttons button.delete { background-color: #a23333; color: white; border-color: #a23333; }
    .action-buttons button.delete:hover { background-color: #7b1f1f; border-color: #7b1f1f; }
    @media (max-width: 991px) { .header{flex-direction:column;align-items:flex-start;height:auto;padding:8px 12px;} main{padding:20px 6vw;} }
</style>
</head>
<body>
<div class="header">
    <div class="logo">
        <a href="home.php" style="color:inherit;text-decoration:none;">YGScreen</a>
    </div>
    <div class="user-info">
        Bienvenue <?= htmlspecialchars($username) ?> -
        <a class="logout" href="logout.php" title="Se déconnecter">Me déconnecter</a><br>
        <?= date('H:i (l, F d)'); ?>
    </div>
</div>
<nav class="navbar navbar-expand-lg py-0" style="background:#222;">
    <div class="container-fluid" style="padding:0;">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 flex-row" style="width:100%;">
            <li class="nav-item">
                <a class="nav-link" href="home.php">Yks/Queries</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="contenuDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Contenu</a>
                <ul class="dropdown-menu" aria-labelledby="contenuDropdown">
                    <li><a class="dropdown-item" href="#">Allocine</a></li>
                    <li><a class="dropdown-item" href="#">Categories</a></li>
                    <li><a class="dropdown-item" href="#">Arbre des distributeurs</a></li>
                    <li><a class="dropdown-item" href="./ephemerides.php">Ephemeride</a></li>
                    <li><a class="dropdown-item active" href="./videos.php">Videos</a></li>
                </ul>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="search.php" id="clientsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Clients</a>
                <ul class="dropdown-menu" aria-labelledby="clientsDropdown">
                    <li><a class="dropdown-item" href="#">Tableau de bord</a></li>
                    <li><a class="dropdown-item" href="#">Fin de licenses</a></li>
                    <li><a class="dropdown-item" href="#">Pending brand requests</a></li>
                    <li><a class="dropdown-item" href="#">Brand Requests mails</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>
<main>
    <div class="filter-box">
        <h3>Supervision des vidéos : Définition des filtres</h3>
        <form method="get" action="#">
            <fieldset class="filter-section">
                <legend><strong>Recherche Classique</strong></legend>
                <label for="categorie">Categorie/Bouquet :</label>
                <select id="categorie" name="categorie">
                    <option>--Tous--</option>
                </select><br /><br />
                <label for="groupe">Groupe :</label>
                <select id="groupe" name="groupe">
                    <option>--Tous--</option>
                </select><br /><br />
                <label for="marque">Marque :</label>
                <select id="marque" name="marque">
                    <option>--Tous--</option>
                </select><br />
                <div class="filter-links">
                    <a href="#">Recherche créactiv - Recherche classique</a>
                </div>
            </fieldset>
            <fieldset class="filter-section">
                <legend><strong>Critères de recherche</strong></legend>
                <label for="active">Active</label>
                <select id="active" name="active">
                    <option>-- Sélectionner --</option>
                </select>
                &nbsp;&nbsp;
                <label for="periodique">Periodique</label>
                <select id="periodique" name="periodique">
                    <option>-- Sélectionner --</option>
                </select><br /><br />
                <label for="ratio_4_3">4:3</label>
                <select id="ratio_4_3" name="ratio_4_3">
                    <option>-- Sélectionner --</option>
                </select>
                &nbsp;&nbsp;
                <label for="ratio_16_9">16:9</label>
                <select id="ratio_16_9" name="ratio_16_9">
                    <option>-- Sélectionner --</option>
                </select>
                &nbsp;&nbsp;
                <label for="ratio_9_16">9:16</label>
                <select id="ratio_9_16" name="ratio_9_16">
                    <option>-- Sélectionner --</option>
                </select><br /><br />
                <label for="date_debut">Date debut</label>
                <input type="date" id="date_debut" name="date_debut" />
                &nbsp;&nbsp;
                <label for="date_fin">Date fin</label>
                <input type="date" id="date_fin" name="date_fin" /><br /><br />
                <label for="search_text">Recherche (#Id, Nom, Internal Name...)</label>
                <input type="text" id="search_text" name="search_text" style="width: 100%;" /><br /><br />
                <label for="sortby">Sort by :</label>
                <select id="sortby" name="sortby">
                    <option>Creation date</option>
                </select>
                <select id="sortdir" name="sortdir">
                    <option>Desc</option>
                </select>
            </fieldset>
            <div class="filter-buttons">
                <button type="reset">Reset filters</button>
                <button type="submit">Filtrer</button>
            </div>
        </form>
    </div>

    <div class="pagination">
        [1] 2 3 ...2615 2616 2617 2618 2619 (1-42/109992)
    </div>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Image</th>
                <th>Name</th>
                <th>Internal name</th>
                <th>Brand</th>
                <th>Category</th>
                <th>Active</th>
                <th>Start date</th>
                <th>End Date</th>
                <th>Actions</th>
                <th><input type="checkbox" /></th>
            </tr>
        </thead>
        <tbody>
            <!-- À remplir dynamiquement (backend) -->
        </tbody>
    </table>

    <div class="summary">
        <!-- À remplir dynamiquement (backend) -->
    </div>

    <form class="action-buttons" method="post" action="#">
        <label for="set_start_date">For current selection :</label><br />
        <input type="date" id="set_start_date" name="set_start_date" />
        <label for="set_end_date">Set end date to</label>
        <input type="date" id="set_end_date" name="set_end_date" />
        <button type="submit" class="update" disabled>Update</button>
        <button type="submit" class="delete">Delete</button>
    </form>

    <div class="pagination">
        [1] 2 3 ...2615 2616 2617 2618 2619 (1-42/109992)
    </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Fix UX : “Clients” clique = search.php (hors sous-menu)
document.addEventListener("DOMContentLoaded", function() {
    var clientsDropdown = document.getElementById("clientsDropdown");
    if (clientsDropdown) {
        clientsDropdown.addEventListener("click", function(e) {
            if (!e.target.closest('.dropdown-menu')) {
                window.location.href = 'search.php';
            }
        });
    }
});
</script>
</body>
</html>
