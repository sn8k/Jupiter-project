<?php
/**
 * File: home.php
 * Version: 2.0.0
 * Description: Page d'accueil YGScreen avec Bootstrap 5, menu déroulant fluide, user dynamique et logout sécurisé.
 */
session_start();
if (empty($_SESSION['ygscreen_logged_in']) || !isset($_SESSION['ygscreen_username'])) {
    header('Location: login.php');
    exit;
}
$username = $_SESSION['ygscreen_display_name'] ?? $_SESSION['ygscreen_username'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>YGScreen interarea - yks/Queries</title>
<!-- Bootstrap 5 CSS (CDN) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        margin: 0;
        padding: 0;
        background-color: #000;
        font-family: Arial, sans-serif;
        color: #eee;
    }
    .header {
        background: linear-gradient(to bottom, #3a3a3a 0%, #1c1c1c 100%);
        height: 70px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 28px;
        box-shadow: inset 0 -2px 5px rgba(0,0,0,0.7);
        color: #eee;
        font-size: 14px;
    }
    .logo {
        font-weight: bold;
        font-size: 26px;
        color: white;
        text-shadow: 0 2px 3px rgba(0,0,0,0.8);
        position: relative;
        user-select: none;
        font-family: 'Trebuchet MS', Arial, sans-serif;
        letter-spacing: 0.5px;
    }
    .logo::after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 0;
        width: 100%;
        height: 15px;
        background: linear-gradient(transparent, rgba(255,255,255,0.25));
        opacity: 0.3;
        pointer-events: none;
        filter: blur(3px);
    }
    .user-info {
        text-align: right;
        line-height: 1.2;
        color: #eee;
        font-size: 14px;
    }
    .user-info .logout {
        color: #f44336;
        font-weight: bold;
        text-decoration: none;
        margin-left: 10px;
    }
    .user-info .logout:hover {
        color: #fff;
        text-decoration: underline;
    }
    nav {
        background-color: #222;
        border-top: 3px solid #600000;
        box-shadow: 0 3px 5px rgba(0,0,0,0.5);
        user-select: none;
        padding: 0 0 0 0;
    }
    .navbar-nav .nav-link {
        color: #ccc !important;
        font-size: 15px;
        padding: 8px 18px !important;
        border-radius: 3px 3px 0 0;
        transition: background 0.2s, color 0.2s;
        margin-right: 5px;
    }
    .navbar-nav .nav-link.active,
    .navbar-nav .show > .nav-link {
        background-color: #600000 !important;
        color: #fff !important;
        font-weight: bold;
    }
    .navbar-nav .nav-link:hover {
        background-color: #5a5a5a !important;
        color: #fff !important;
    }
    .dropdown-menu {
        background: #fff;
        border-radius: 0 0 6px 6px;
        box-shadow: 0 5px 14px rgba(0,0,0,0.18);
        border: none;
        margin-top: 1px;
        min-width: 200px;
        z-index: 2000;
    }
    .dropdown-item {
        color: #333 !important;
        font-size: 15px;
        padding: 10px 18px;
        border-bottom: 1px solid #eee;
        transition: background 0.2s, color 0.2s;
    }
    .dropdown-item:last-child { border-bottom: none; }
    .dropdown-item:hover {
        background: #f4f4f4;
        color: #a23333 !important;
        font-weight: bold;
    }
    main {
        background-color: #eee;
        color: #333;
        padding: 28px 36px 24px 36px;
        margin-top: 2px;
        user-select: none;
        border-radius: 0 0 15px 15px;
        min-height: 330px;
    }
    @media (max-width: 991px) {
        .header { flex-direction: column; align-items: flex-start; height: auto; padding: 8px 12px; }
        main { padding: 20px 6vw; }
    }
</style>
</head>
<body>
<div class="header">
    <div class="logo">YGScreen</div>
    <div class="user-info">
        Bienvenue <?= htmlspecialchars($username) ?> -
        <a class="logout" href="logout.php" title="Se déconnecter">Me déconnecter</a><br>
        <?= date('H:i (l, F d)'); ?>
    </div>
</div>

<nav class="navbar navbar-expand-lg py-0" style="background:#222;">
    <div class="container-fluid" style="padding:0;">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 flex-row" style="width:100%;">
            <li class="nav-item">
                <a class="nav-link active" href="#" tabindex="-1">Yks/Queries</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="contenuDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Contenu
                </a>
                <ul class="dropdown-menu" aria-labelledby="contenuDropdown">
                    <li><a class="dropdown-item" href="#">Allocine</a></li>
                    <li><a class="dropdown-item" href="#">Categories</a></li>
                    <li><a class="dropdown-item" href="#">Arbre des distributeurs</a></li>
                    <li><a class="dropdown-item" href="./ephemerides.php">Ephemeride</a></li>
                    <li><a class="dropdown-item" href="./videos.php">Videos</a></li>
                </ul>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="clientsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Clients
                </a>
                <ul class="dropdown-menu" aria-labelledby="clientsDropdown">
                    <li><a class="dropdown-item" href="#">Tableau de bord</a></li>
                    <li><a class="dropdown-item" href="#">Fin de licenses</a></li>
                    <li><a class="dropdown-item" href="#">Pending brand requests</a></li>
                    <li><a class="dropdown-item" href="#">Brand Requests mails</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>

<main>
    <h2>YGScreen Admin</h2>
    <p>Bienvenue sur une zone réservée</p>
</main>

<!-- Bootstrap 5 JS (pour dropdowns fluides) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Corrige la fermeture trop rapide des dropdowns Bootstrap natifs :
    // "hover" ET "click" + garde ouverte tant qu'on est sur le menu/sous-menu
    document.querySelectorAll('.navbar-nav .dropdown').forEach(function(drop){
        drop.addEventListener('mouseenter', function(){
            let link = drop.querySelector('.dropdown-toggle');
            let menu = drop.querySelector('.dropdown-menu');
            let bsDropdown = bootstrap.Dropdown.getOrCreateInstance(link);
            bsDropdown.show();
        });
        drop.addEventListener('mouseleave', function(){
            let link = drop.querySelector('.dropdown-toggle');
            let bsDropdown = bootstrap.Dropdown.getOrCreateInstance(link);
            setTimeout(function() {
                // On ne ferme que si la souris n'est pas sur le menu !
                if (!drop.matches(':hover') && !drop.querySelector('.dropdown-menu:hover')) {
                    bsDropdown.hide();
                }
            }, 150);
        });
        // Permet d’ouvrir aussi au clic sur mobile/tablette
        drop.querySelector('.dropdown-toggle').addEventListener('click', function(e){
            let bsDropdown = bootstrap.Dropdown.getOrCreateInstance(this);
            bsDropdown.toggle();
        });
    });
</script>
</body>
</html>
