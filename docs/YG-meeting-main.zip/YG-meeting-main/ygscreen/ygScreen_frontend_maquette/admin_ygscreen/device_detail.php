<?php
/**
 * File: device_detail.php
 * Version: 1.3.0
 * Description: Maquette complète de la page devicekey avec recherche, détails magasin, abonnements, players, liens et popups.
 */

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<title>Activ'screen - Détail devicekey</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #000;
        color: #eee;
        margin: 0; padding: 0;
    }
    .header {
        background: linear-gradient(to bottom, #3a3a3a 0%, #1c1c1c 100%);
        color: #eee;
        padding: 10px 20px;
        box-shadow: inset 0 -2px 5px rgba(0,0,0,0.7);
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        user-select: none;
    }
    .logo {
        font-weight: bold;
        font-size: 26px;
        color: white;
        text-shadow: 0 2px 3px rgba(0,0,0,0.8);
        font-family: 'Trebuchet MS', Arial, sans-serif;
        position: relative;
    }
    .logo::after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 0;
        width: 100%;
        height: 15px;
        background: linear-gradient(transparent, rgba(255,255,255,0.25));
        opacity: 0.3;
        pointer-events: none;
        filter: blur(3px);
    }
    .user-info {
        text-align: right;
        line-height: 1.2;
    }
    .user-info .logout {
        color: #f44336;
        cursor: pointer;
        font-weight: bold;
    }
    nav {
        background-color: #222;
        border-top: 3px solid #600000;
        box-shadow: 0 3px 5px rgba(0,0,0,0.5);
        user-select: none;
    }
    nav ul {
        list-style: none;
        margin: 0; padding: 0 15px;
        display: flex;
        height: 38px;
        align-items: center;
    }
    nav ul li {
        position: relative;
        margin-right: 8px;
    }
    nav ul li a, nav ul li button {
        background-color: #444;
        border: none;
        padding: 8px 16px;
        color: #ccc;
        font-size: 14px;
        cursor: pointer;
        text-decoration: none;
        display: block;
        border-radius: 3px 3px 0 0;
        transition: background-color 0.3s ease, color 0.3s ease;
        user-select: none;
    }
    nav ul li a:hover, nav ul li button:hover {
        background-color: #5a5a5a;
        color: #fff;
    }
    nav ul li.active > button, nav ul li.active > a {
        background-color: #600000;
        color: white;
        font-weight: bold;
        cursor: default;
    }
    nav ul li ul.dropdown {
        position: absolute;
        top: 38px;
        left: 0;
        background-color: #fff;
        box-shadow: 0 5px 8px rgba(0,0,0,0.3);
        padding: 0;
        margin: 0;
        list-style: none;
        min-width: 180px;
        border-radius: 0 0 5px 5px;
        display: none;
        z-index: 1000;
    }
    nav ul li:hover ul.dropdown {
        display: block;
    }
    nav ul li ul.dropdown li {
        margin: 0;
    }
    nav ul li ul.dropdown li a {
        padding: 10px 16px;
        color: #222;
        font-weight: normal;
        border-bottom: 1px solid #ddd;
        border-radius: 0;
    }
    nav ul li ul.dropdown li a:hover {
        background-color: #f4f4f4;
        color: #600000;
        font-weight: bold;
    }
    main {
        background-color: #eee;
        color: #333;
        padding: 20px 30px;
        margin-top: 2px;
        user-select: none;
        max-width: 1100px;
        margin-left: auto;
        margin-right: auto;
    }
    .section-box {
        border: 1px solid #a23333;
        background-color: #fff;
        border-radius: 5px;
        margin-bottom: 20px;
        padding: 15px;
    }
    .section-box h3 {
        background-color: #a23333;
        color: #fff;
        padding: 5px 10px;
        margin: -15px -15px 15px -15px;
        font-size: 16px;
        border-radius: 5px 5px 0 0;
        user-select: none;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
        margin-bottom: 10px;
    }
    thead {
        background-color: #a23333;
        color: white;
        user-select: none;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 5px 8px;
        vertical-align: middle;
        text-align: left;
    }
    tbody tr:nth-child(odd) {
        background-color: #ffe5e5;
    }
    tbody tr:nth-child(even) {
        background-color: #fff;
    }
    .actions {
        text-align: center;
        user-select: none;
        width: 100px;
    }
    .actions img, .actions button {
        cursor: pointer;
        margin: 0 4px;
        vertical-align: middle;
        width: 16px;
        height: 16px;
        background: none;
        border: none;
        padding: 0;
    }
    .btn-small {
        background-color: #888;
        border: none;
        color: #ddd;
        padding: 5px 12px;
        margin-bottom: 8px;
        cursor: pointer;
        border-radius: 3px;
        font-weight: bold;
        margin-right: 8px;
    }
    .btn-small:hover {
        background-color: #666;
    }
    .green-arrow {
        color: green;
        font-weight: bold;
        cursor: pointer;
        margin-right: 10px;
    }
    .red-button {
        background-color: #a23333;
        border: none;
        color: white;
        padding: 6px 14px;
        cursor: pointer;
        border-radius: 3px;
        font-weight: bold;
    }
    .red-button:hover {
        background-color: #7b1f1f;
    }
    .link-red {
        color: #a23333;
        text-decoration: underline;
        cursor: pointer;
        user-select: text;
    }
    .link-red:hover {
        color: #600000;
    }

    /* Popup modal commun */
    .modal-bg {
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: rgba(0,0,0,0.6);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 10000;
    }
    .modal {
        background: #fff;
        width: 400px;
        border-radius: 6px;
        box-shadow: 0 0 15px rgba(0,0,0,0.5);
        padding: 15px 20px 20px 20px;
        position: relative;
        user-select: text;
        max-height: 80vh;
        overflow-y: auto;
    }
    .modal h2 {
        margin: 0 0 15px 0;
        padding-bottom: 5px;
        border-bottom: 2px solid #a23333;
        color: #a23333;
        font-size: 18px;
    }
    .modal label {
        display: block;
        margin: 10px 0 3px 0;
        font-weight: bold;
    }
    .modal input[type="text"], .modal select {
        width: 100%;
        font-family: Arial, sans-serif;
        font-size: 14px;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 3px;
        box-sizing: border-box;
    }
    .modal .close-btn {
        position: absolute;
        top: 10px; right: 10px;
        background: #f44336;
        color: white;
        width: 22px;
        height: 22px;
        text-align: center;
        line-height: 22px;
        font-weight: bold;
        border-radius: 50%;
        cursor: pointer;
        user-select: none;
    }
    .modal .add-btn {
        margin-top: 15px;
        background-color: #a23333;
        border: none;
        color: white;
        padding: 7px 18px;
        cursor: pointer;
        border-radius: 3px;
        float: right;
        font-weight: bold;
    }
    .modal .add-btn:hover {
        background-color: #7b1f1f;
    }
    /* For subscribe manual dates inputs */
    #manual_dates_inputs {
        display: none;
        margin-top: 10px;
    }
</style>
<script>
    function showModal(id) {
        document.getElementById('modal-' + id).style.display = 'flex';
    }
    function closeModal(id) {
        document.getElementById('modal-' + id).style.display = 'none';
    }

    function onSubscribeChange(select) {
        const manualDiv = document.getElementById('manual_dates_inputs');
        if (select.value === 'manual') {
            manualDiv.style.display = 'block';
        } else {
            manualDiv.style.display = 'none';
        }
    }

    function onStreamTypeChange() {
        const type = document.getElementById('stream_type').value;
        // Cacher tous les champs spécifiques d'abord
        document.getElementById('stream_ratio_container').style.display = 'none';
        document.getElementById('stream_carousel_container').style.display = 'none';
        document.getElementById('stream_application_container').style.display = 'none';

        if(type === 'Web') {
            document.getElementById('stream_ratio_container').style.display = 'block';
            document.getElementById('stream_application_container').style.display = 'block';
        } else if(type === 'Interactive') {
            document.getElementById('stream_ratio_container').style.display = 'block';
            // Pas d'application ici
        } else if(type === 'Playlists' || type === 'Audio') {
            // Pas de champs supplémentaires
        }
    }

    window.addEventListener('DOMContentLoaded', (event) => {
        onStreamTypeChange(); // Appliquer l'état initial des champs
    });
</script>
</head>
<body>
<div class="header">
    <div class="logo">Activ'screen</div>
    <div class="user-info">
        Bienvenue Yann Gantner - <span class="logout">Me déconnecter</span><br>
        <?php echo date('H:i (l, F d)'); ?>
    </div>
</div>
<nav>
    <ul>
        <li><button type="button">Yks/Queries</button></li>
        <li><button type="button">Contenu</button></li>
        <li class="active"><button type="button">Clients</button></li>
    </ul>
</nav>

<main>
    <!-- Search box -->
    <div class="section-box">
        <h3>Rechercher des comptes</h3>
        <form>
            <select multiple size="7" style="width: 40%; float: left; margin-right: 20px;">
                <option>Réseaux Export IVS</option>
                <option>Global Business</option>
                <option>ACUITIS Italy</option>
                <option>IVS Switzerland VISILAB</option>
                <option>BBGR Nikon Europe</option>
                <option>Reize Optik</option>
                <option>NIKA Nikon</option>
                <option>Omega Optix - Czech Republic</option>
            </select>
            <div style="overflow: hidden;">
                <label>Account name, login, device key... (complex query)</label>
                <input type="text" style="width: 60%;" />
                <label><input type="checkbox" /> ShopIDs</label>

                <label>Product serial</label>
                <input type="text" style="width: 40%;" />
                <label>Release level :</label>
                <select>
                    <option>-- Sélectionner --</option>
                    <option>Stable</option>
                    <option>Beta</option>
                    <option>Dev</option>
                </select>

                <label>Sort by :</label>
                <select>
                    <option>Creation date</option>
                    <option>Name</option>
                    <option>Release level</option>
                    <option>Login</option>
                </select>

                <label>Desc / Asc :</label>
                <select>
                    <option>Desc</option>
                    <option>Asc</option>
                </select>

                <label>Display :</label>
                <select>
                    <option>10</option>
                    <option selected>20</option>
                    <option>50</option>
                    <option>100</option>
                </select>

                <button class="btn-small" style="float: right; margin-top: 10px;">Search</button>
            </div>
            <div style="clear: both;"></div>
        </form>
    </div>

    <!-- Shop details -->
    <div class="section-box">
        <h3>Détails du magasin [19380]</h3>
        <button class="btn-small">&larr; Back to account "FOTO OTTICA RB"</button>
        <table>
            <tbody>
                <tr><td><strong>Shop name</strong></td><td>FOTO OTTICA RB</td></tr>
                <tr><td><strong>Shop contact</strong></td><td>Valter PARISOTTO</td></tr>
                <tr><td><strong>Mail</strong></td><td>info@ottica.it</td></tr>
                <tr><td><strong>Addresse</strong></td><td>VIA CARNIA 7/9 , 33054 LIGNANO SABBIADORO</td></tr>
                <tr><td><strong>Phone</strong></td><td></td></tr>
                <tr><td><strong>Shop create</strong></td><td>Vendredi 30 Mai 2025</td></tr>
                <tr><td><strong>Nb stream</strong></td><td>2</td></tr>
                <tr><td><strong>Nb players</strong></td><td>0</td></tr>
                <tr><td><strong>Nb products</strong></td><td>0</td></tr>
                <tr><td><strong>Code client</strong></td><td>-</td></tr>
            </tbody>
        </table>
        <button class="btn-small" onclick="showModal('shop')">Modifier ce magasin</button>
        <button class="btn-small">Détails du magasin</button>
    </div>

    <!-- Flux list -->
    <div class="section-box">
        <h3>Liste des flux</h3>
        <button class="btn-small" onclick="showModal('stream')">Ajouter un flux</button>
        <table>
            <thead>
                <tr>
                    <th>Stream</th><th>Stream Name</th><th>My acs</th><th>Wtmrk</th><th>Stream contents</th><th>Stream category</th><th>Stream media type</th><th>Stream usage</th><th>Channels</th><th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="color:#a23333;">37586</td>
                    <td><a href="#" class="link-red" title="Edit Stream" onclick="showModal('stream')">a8master_web</a></td>
                    <td>--</td>
                    <td>off</td>
                    <td>App Interactive V03 (stable manifest #460)</td>
                    <td>Web</td>
                    <td>--</td>
                    <td>--</td>
                    <td>Flux V03 (100%)</td>
                    <td class="actions">
                        <button title="Edit" onclick="showModal('stream')">&#9998;</button>
                        <button title="Delete">&#10006;</button>
                    </td>
                </tr>
                <tr>
                    <td style="color:#a23333;">37587</td>
                    <td><a href="#" class="link-red" title="Edit Stream" onclick="showModal('stream')">demo_screen_a8master</a></td>
                    <td>--</td>
                    <td>off</td>
                    <td>Aucun contenu</td>
                    <td>Interactive</td>
                    <td>--</td>
                    <td>--</td>
                    <td>--</td>
                    <td class="actions">
                        <button title="Edit" onclick="showModal('stream')">&#9998;</button>
                        <button title="Delete">&#10006;</button>
                    </td>
                </tr>
            </tbody>
            <tfoot>
                <tr style="background:#eee; font-weight:bold; color:#333;">
                    <td colspan="3">shown: 2</td>
                    <td>0x</td>
                    <td>0 cat.</td>
                    <td>2 media types</td>
                    <td>0 usages</td>
                    <td>1 channels</td>
                    <td></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>

        <div style="margin-top: 10px;">
            <label for="subscribe_duration">For current selection :</label>
            <select id="subscribe_duration" onchange="onSubscribeChange(this)">
                <option value="1m">1 month</option>
                <option value="6m">6 months</option>
                <option value="1y">1 year</option>
                <option value="2y">2 years</option>
                <option value="3y">3 years</option>
                <option value="4y">4 years</option>
                <option value="5y" selected>5 years</option>
                <option value="manual">-- manual dates --</option>
            </select>
            <button class="btn-small">Subscribe</button>
            <span>or:</span>
            <button class="red-button">Revoke</button>

            <div id="manual_dates_inputs" style="display:none; margin-top:10px;">
                <label for="manual_start">from</label>
                <input type="text" id="manual_start" placeholder="jj/mm/aaaa" />
                <label for="manual_end">until</label>
                <input type="text" id="manual_end" placeholder="jj/mm/aaaa" />
            </div>
        </div>
    </div>

    <!-- Hosts list -->
    <div class="section-box">
        <h3>Liste des hosts</h3>
        <button class="btn-small" onclick="showModal('host')">Add a host</button>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Host name</th>
                    <th>Key</th>
                    <th>Last tick</th>
                    <th>Software</th>
                    <th>Installation</th>
                    <th>Auto player</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>51795</td>
                    <td><a href="https://meeting.ygsoft.fr/devices" class="link-red" title="Host details">V3-S01-007794</a></td>
                    <td style="color:#a23333;">64457DCA75106221E5D9E18E6F1001F0</td>
                    <td> - </td>
                    <td>Activscreen Linux</td>
                    <td>30/05/25 16:26</td>
                    <td>-</td>
                    <td class="actions">
                        <button title="Info" onclick="showModal('host_info')">&#8505;</button>
                        <button title="Delete">&#10006;</button>
                        <button title="Add Auto Player" onclick="showModal('player')">&#x271A;</button>
                        <button title="Clear Cache">&#x1F527;</button>
                        <button title="Add Screenset">&#x25A1;</button>
                    </td>
                </tr>
            </tbody>
            <tfoot>
                <tr style="background:#eee; font-weight:bold; color:#333;">
                    <td colspan="2">shown: 1</td>
                    <td colspan="2">1 softwares</td>
                    <td colspan="3">latest: 30/05/25</td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <!-- Players list -->
    <div class="section-box">
        <h3>Liste des players</h3>
        <button class="btn-small" onclick="showModal('player')">Add a player</button>
        <table>
            <thead>
                <tr>
                    <th>Player #</th>
                    <th>Serial</th>
                    <th>Stream</th>
                    <th>Model</th>
                    <th>Type</th>
                    <th>Install</th>
                    <th>Last availability</th>
                    <th>Ip Address</th>
                    <th>Device key</th>
                    <th>Token</th>
                    <th>Host</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr><td colspan="12" style="text-align:center; color:#a23333;">No players</td></tr>
            </tbody>
        </table>
    </div>

    <!-- Products list -->
    <div class="section-box">
        <h3>Liste des products</h3>
        <button class="btn-small" onclick="showModal('product')">Add a product</button>
        <table>
            <thead>
                <tr>
                    <th>Serial #</th>
                    <th>Type</th>
                    <th>Model</th>
                    <th>Install</th>
                    <th>Ip Address</th>
                    <th>Last status</th>
                    <th>Host</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr><td colspan="8" style="text-align:center; color:#a23333;">No products</td></tr>
            </tbody>
        </table>
    </div>

    <!-- Schedule -->
    <div class="section-box">
        <h3>Jours / Horaires</h3>
        <table>
            <thead>
                <tr><th>Day</th><th>Hours</th></tr>
            </thead>
            <tbody>
                <tr><td>Lundi</td><td><span style="background:#c00; color:#fff;">00:00 - 08:30</span> <span style="background:#0c0; color:#000;">08:30 - 12:30</span> <span style="background:#c00; color:#fff;">12:30 - 14:00</span> <span style="background:#0c0; color:#000;">14:00 - 19:00</span> <span style="background:#c00; color:#fff;">19:00 - 23:59</span></td></tr>
                <tr><td>Mardi</td><td><span style="background:#c00; color:#fff;">00:00 - 08:30</span> <span style="background:#0c0; color:#000;">08:30 - 12:30</span> <span style="background:#c00; color:#fff;">12:30 - 14:00</span> <span style="background:#0c0; color:#000;">14:00 - 19:00</span> <span style="background:#c00; color:#fff;">19:00 - 23:59</span></td></tr>
                <tr><td>Mercredi</td><td><span style="background:#c00; color:#fff;">00:00 - 08:30</span> <span style="background:#0c0; color:#000;">08:30 - 12:30</span> <span style="background:#c00; color:#fff;">12:30 - 14:00</span> <span style="background:#0c0; color:#000;">14:00 - 19:00</span> <span style="background:#c00; color:#fff;">19:00 - 23:59</span></td></tr>
                <tr><td>Jeudi</td><td><span style="background:#c00; color:#fff;">00:00 - 08:30</span> <span style="background:#0c0; color:#000;">08:30 - 12:30</span> <span style="background:#c00; color:#fff;">12:30 - 14:00</span> <span style="background:#0c0; color:#000;">14:00 - 19:00</span> <span style="background:#c00; color:#fff;">19:00 - 23:59</span></td></tr>
                <tr><td>Vendredi</td><td><span style="background:#c00; color:#fff;">00:00 - 08:30</span> <span style="background:#0c0; color:#000;">08:30 - 12:30</span> <span style="background:#c00; color:#fff;">12:30 - 14:00</span> <span style="background:#0c0; color:#000;">14:00 - 19:00</span> <span style="background:#c00; color:#fff;">19:00 - 23:59</span></td></tr>
                <tr><td>Samedi</td><td><span style="background:#c00; color:#fff;">00:00 - 08:30</span> <span style="background:#0c0; color:#000;">08:30 - 12:30</span> <span style="background:#c00; color:#fff;">12:30 - 14:00</span> <span style="background:#0c0; color:#000;">14:00 - 19:00</span> <span style="background:#c00; color:#fff;">19:00 - 23:59</span></td></tr>
                <tr><td>Dimanche</td><td><span style="background:#c00; color:#fff;">00:00 - 23:59</span></td></tr>
            </tbody>
        </table>
        <div style="margin-top:10px;">
            <select>
                <option>Racine - 9:00 - 19:00 lundi - samedi</option>
            </select>
            <button class="btn-small">Utiliser</button>
        </div>
    </div>
</main>

<!-- Popup Shop management -->
<div id="modal-shop" class="modal-bg" onclick="if(event.target==this) closeModal('shop');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-shop-title">
        <div class="close-btn" onclick="closeModal('shop')" title="Fermer">&times;</div>
        <h2 id="modal-shop-title">Shop management [19380]</h2>
        <form>
            <label>Shop Name :</label>
            <input type="text" value="FOTO OTTICA RB" />
            <label>First Name :</label>
            <input type="text" value="Valter" />
            <label>Last Name :</label>
            <input type="text" value="PARISOTTO" />
            <label>Address (1) :</label>
            <input type="text" value="VIA CARNIA 7/9" />
            <label>Address (2) :</label>
            <input type="text" />
            <label>Zip code :</label>
            <input type="text" value="33054" />
            <label>City :</label>
            <input type="text" value="LIGNANO SABBIADORO" />
            <label>Mail :</label>
            <input type="text" value="info@ottica.it" />
            <label>Phone :</label>
            <input type="text" />
            <label>Fax :</label>
            <input type="text" />
            <label>Code Client :</label>
            <input type="text" />
            <label>Time Zone * :</label>
            <select>
                <option>UTC+1, Europe/Paris</option>
                <option>UTC+0, GMT</option>
                <option>UTC+2, Europe/Berlin</option>
            </select>
            <label>Country :</label>
            <select>
                <option>Italy</option>
                <option>France</option>
                <option>Germany</option>
            </select>
            <button class="add-btn" type="submit">Enregistrer le magasin (shop_update)</button>
        </form>
    </div>
</div>

<!-- Popup Add a Product -->
<div id="modal-product" class="modal-bg" onclick="if(event.target==this) closeModal('product');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-product-title">
        <div class="close-btn" onclick="closeModal('product')" title="Fermer">&times;</div>
        <h2 id="modal-product-title">Add a product</h2>
        <form>
            <label for="product_type">Product type :</label>
            <select id="product_type" name="product_type">
                <option>-- Sélectionner --</option>
                <option>Type 1</option>
                <option>Type 2</option>
                <option>Type 3</option>
            </select>
            <label for="serial">Serial :</label>
            <select id="serial" name="serial">
                <option>-- Sélectionner --</option>
                <option>Serial 1</option>
                <option>Serial 2</option>
                <option>Serial 3</option>
            </select>
            <button type="submit" class="add-btn">Add</button>
        </form>
    </div>
</div>

<!-- Popup Add a Host -->
<div id="modal-host" class="modal-bg" onclick="if(event.target==this) closeModal('host');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-host-title">
        <div class="close-btn" onclick="closeModal('host')" title="Fermer">&times;</div>
        <h2 id="modal-host-title">Add a host</h2>
        <form>
            <label for="device_key">Device key :</label>
            <input id="device_key" name="device_key" type="text" />
            <button type="submit" class="add-btn">Add</button>
        </form>
    </div>
</div>

<!-- Popup Add a Player -->
<div id="modal-player" class="modal-bg" onclick="if(event.target==this) closeModal('player');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-player-title">
        <div class="close-btn" onclick="closeModal('player')" title="Fermer">&times;</div>
        <h2 id="modal-player-title">Add a player</h2>
        <form>
            <label for="player_type">Player type :</label>
            <select id="player_type" name="player_type">
                <option>-- Sélectionner --</option>
                <option>Type A</option>
                <option>Type B</option>
                <option>Type C</option>
            </select>
            <label for="player_model">Model :</label>
            <select id="player_model" name="player_model">
                <option>-- Sélectionner --</option>
                <option>Model 1</option>
                <option>Model 2</option>
                <option>Model 3</option>
            </select>
            <label for="player_install">Install :</label>
            <select id="player_install" name="player_install">
                <option>-- Sélectionner --</option>
                <option>Install 1</option>
                <option>Install 2</option>
                <option>Install 3</option>
            </select>
            <button type="submit" class="add-btn">Add</button>
        </form>
    </div>
</div>

<!-- Popup Manage Stream -->
<div id="modal-stream" class="modal-bg" onclick="if(event.target==this) closeModal('stream');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-stream-title">
        <div class="close-btn" onclick="closeModal('stream')" title="Fermer">&times;</div>
        <h2 id="modal-stream-title">Manage stream</h2>
        <form>
            <label for="stream_name">Nom du flux :</label>
            <input type="text" id="stream_name" name="stream_name" value="" />
            <label for="stream_type">Type de flux :</label>
            <select id="stream_type" name="stream_type" onchange="onStreamTypeChange()">
                <option value="">-- Sélectionner --</option>
                <option value="Playlists">Playlists</option>
                <option value="Audio">Audio</option>
                <option value="Interactive">Interactive</option>
                <option value="Web">Web</option>
            </select>
            <label for="stream_usage">Utilisation du flux :</label>
            <select id="stream_usage" name="stream_usage">
                <option value="">-- Sélectionner --</option>
                <option value="a8master_web">a8master_web</option>
                <option value="bridge2_web">bridge2_web</option>
                <option value="demo_screen">demo_screen</option>
                <option value="demo_screen_a8master">demo_screen_a8master</option>
                <option value="demo_screen_bridge2">demo_screen_bridge2</option>
                <option value="demo_screen_sdl">demo_screen_sdl</option>
                <option value="stream_interactive_nfc">stream_interactive_nfc</option>
                <option value="stream_screensaver_nfc">stream_screensaver_nfc</option>
                <option value="vox_screensaver">vox_screensaver</option>
                <option value="vox_web">vox_web</option>
            </select>
            <label><input type="checkbox" id="stream_visibility" name="stream_visibility" /> Visibilité (my-activscreen) du flux :</label>
            <label><input type="checkbox" id="stream_watermark" name="stream_watermark" /> Watermark activé :</label>

            <div id="stream_ratio_container" style="display:none;">
                <label for="stream_ratio">Ratio du flux :</label>
                <select id="stream_ratio" name="stream_ratio">
                    <option value="16:9">16:9</option>
                    <option value="4:3">4:3</option>
                    <option value="9:16">9:16</option>
                </select>
            </div>

            <div id="stream_application_container" style="display:none;">
                <label for="stream_application">Carousel Application :</label>
                <select id="stream_application" name="stream_application">
                    <option value="">-- Sélectionner --</option>
                    <option value="App Interactive V03 (stable manifest #460)">App Interactive V03 (stable manifest #460)</option>
                    <option value="App Interactive V04 (dev manifest #470)">App Interactive V04 (dev manifest #470)</option>
                </select>
            </div>

            <button type="submit" class="add-btn">Enregistrer le flux</button>

            <h3>Stats</h3>
            <table>
                <tbody>
                    <tr><td>Nombre de fichiers</td><td>0</td></tr>
                    <tr><td>Poids des fichiers</td><td>0 octets</td></tr>
                </tbody>
            </table>

            <h3>Channels</h3>
            <table>
                <thead>
                    <tr><th>#</th><th>Name</th><th>Frequency</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <tr><td colspan="4" style="text-align:center; color:#a23333;">No channels found.</td></tr>
                </tbody>
            </table>

            <label for="channel_select">Add a channel:</label>
            <select id="channel_select" name="channel_select">
                <option value="">-- Sélectionner --</option>
                <option value="ch1">Channel 1</option>
                <option value="ch2">Channel 2</option>
                <option value="ch3">Channel 3</option>
            </select>
            <label for="channel_frequency">Frequency :</label>
            <input type="text" id="channel_frequency" name="channel_frequency" value="1.0" />
            <button type="submit" class="add-btn">Add a channel</button>
        </form>
    </div>
</div>

<!-- Popup Host Info -->
<div id="modal-host_info" class="modal-bg" onclick="if(event.target==this) closeModal('host_info');">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-host_info-title">
        <div class="close-btn" onclick="closeModal('host_info')" title="Fermer">&times;</div>
        <h2 id="modal-host_info-title">Host Information</h2>
        <p><strong>Product Serial:</strong> VOX-S01-006169</p>
        <p><strong>Dernier tick:</strong> Date indéfinie</p>
        <p><strong>Version:</strong> 4.3.46-17</p>
        <h3>Préférences</h3>
        <form>
            <label>Bandwidth throttle limit :</label>
            <input type="text" />
            <label>Default Carousel :</label>
            <select>
                <option>No carousel</option>
                <option>Carousel 1</option>
                <option>Carousel 2</option>
            </select>
            <label>Encrypt media :</label>
            <input type="checkbox" />
            <label>Disable time bomb :</label>
            <input type="checkbox" />
            <label>Preview monitor mode :</label>
            <select>
                <option>Mode 1</option>
                <option>Mode 2</option>
                <option>Mode 3</option>
            </select>
            <label><input type="checkbox" /> Auto Start Streaming</label>
            <label><input type="checkbox" /> Enable HTTP</label>
            <label><input type="checkbox" checked /> Enable Streaming</label>
            <label><input type="checkbox" checked /> Activer l'upload FTP</label>
            <label><input type="checkbox" checked /> Activer dans le mail & tableau de bord</label>
            <button class="add-btn" type="submit">Sauvegarder</button>
        </form>
    </div>
</div>

</body>
</html>
