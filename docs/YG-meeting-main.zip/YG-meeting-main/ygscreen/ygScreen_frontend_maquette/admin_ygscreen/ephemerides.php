<?php
/**
 * File: ephemerides.php
 * Version: 3.0.0
 * Description: Page Éphémérides YGScreen, design Bootstrap, inline edit, BDD, menu UX à jour.
 */
session_start();
if (empty($_SESSION['ygscreen_logged_in']) || !isset($_SESSION['ygscreen_username'])) {
    header('Location: index.php');
    exit;
}
$username = $_SESSION['ygscreen_display_name'] ?? $_SESSION['ygscreen_username'];

// Connexion PDO
require_once __DIR__ . '/db.php'; // $pdo

// --- Gestion AJAX update d'une cellule
if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['month'], $_POST['day'], $_POST['field'], $_POST['value'])
    && in_array($_POST['field'], ['saint','anniversaires','evenement','citation'], true)
) {
    $month = $_POST['month'];
    $day = (int)$_POST['day'];
    $field = $_POST['field'];
    $value = trim($_POST['value']);

    // Sécurisation
    $months = [
        'Janvier'=>31,'Février'=>28,'Mars'=>31,'Avril'=>30,'Mai'=>31,'Juin'=>30,
        'Juillet'=>31,'Août'=>31,'Septembre'=>30,'Octobre'=>31,'Novembre'=>30,'Décembre'=>31
    ];
    if (!isset($months[$month]) || $day<1 || $day>$months[$month]) {
        http_response_code(400); echo json_encode(['ok'=>false,'err'=>'Date invalide']); exit;
    }
    // Upsert SQL
    $stmt = $pdo->prepare("INSERT INTO ephemerides (month, day, $field) VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE $field=VALUES($field)");
    $ok = $stmt->execute([$month, $day, $value]);
    echo json_encode(['ok'=>$ok, 'field'=>$field, 'value'=>$value]);
    exit;
}

// --- Lecture pour affichage complet
$months = [
    'Janvier'=>31,'Février'=>28,'Mars'=>31,'Avril'=>30,'Mai'=>31,'Juin'=>30,
    'Juillet'=>31,'Août'=>31,'Septembre'=>30,'Octobre'=>31,'Novembre'=>30,'Décembre'=>31
];
$data = [];
$stmt = $pdo->query("SELECT * FROM ephemerides");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $m = $row['month']; $d = $row['day'];
    $data[$m][$d] = [
        'saint' => $row['saint'] ?? '',
        'anniversaires' => $row['anniversaires'] ?? '',
        'evenement' => $row['evenement'] ?? '',
        'citation' => $row['citation'] ?? ''
    ];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<title>YGScreen - Ephémérides</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body { font-family: Arial,sans-serif; background: #000; color:#eee; margin:0; padding:0; }
    .header { background: linear-gradient(to bottom,#3a3a3a 0%,#1c1c1c 100%);
        color: #eee; height: 70px; padding:0 28px; box-shadow: inset 0 -2px 5px rgba(0,0,0,0.7);
        display: flex; justify-content: space-between; align-items: center; font-size:14px; }
    .logo { font-weight:bold; font-size:26px; color:#fff; text-shadow:0 2px 3px rgba(0,0,0,0.8);
        position:relative; user-select:none; font-family:'Trebuchet MS',Arial,sans-serif; letter-spacing:0.5px;}
    .logo::after { content:'';position:absolute;bottom:-8px;left:0;width:100%;height:15px;
        background:linear-gradient(transparent,rgba(255,255,255,0.25));opacity:0.3;pointer-events:none;filter:blur(3px);}
    .user-info { text-align:right; line-height:1.2; color:#eee; font-size:14px;}
    .user-info .logout { color:#f44336;font-weight:bold;text-decoration:none;margin-left:10px;}
    .user-info .logout:hover { color:#fff; text-decoration:underline;}
    nav { background-color:#222;border-top:3px solid #600000;box-shadow:0 3px 5px rgba(0,0,0,0.5);user-select:none;padding:0;}
    .navbar-nav .nav-link { color:#ccc !important; font-size:15px; padding:8px 18px !important;
        border-radius:3px 3px 0 0;transition:background 0.2s,color 0.2s;margin-right:5px;}
    .navbar-nav .nav-link.active, .navbar-nav .show > .nav-link {background-color:#600000 !important;color:#fff !important;font-weight:bold;}
    .navbar-nav .nav-link:hover { background-color:#5a5a5a !important; color:#fff !important;}
    .dropdown-menu { background:#fff; border-radius:0 0 6px 6px; box-shadow:0 5px 14px rgba(0,0,0,0.18); border:none; margin-top:1px; min-width:200px;z-index:2000;}
    .dropdown-item { color:#333 !important; font-size:15px; padding:10px 18px; border-bottom:1px solid #eee; transition:background 0.2s,color 0.2s;}
    .dropdown-item:last-child { border-bottom:none; }
    .dropdown-item:hover { background:#f4f4f4; color:#a23333 !important; font-weight:bold;}
    main { background-color:#eee; color:#333; padding:28px 36px 24px 36px; margin-top:2px; user-select:none; border-radius:0 0 15px 15px; max-width:1100px; margin-left:auto; margin-right:auto; min-height:330px;}
    h2.month-title { color:#a23333; margin-top:40px; margin-bottom:10px; border-bottom:1px solid #a23333; padding-bottom:3px; user-select:text;}
    table { width:100%; border-collapse:collapse; font-size:13px; margin-bottom:20px;}
    thead { background-color:#a23333; color:white; user-select:none;}
    th,td { border:1px solid #ddd; padding:5px 8px; vertical-align:top; text-align:left;}
    tbody tr:nth-child(odd) { background-color:#ffe5e5;}
    tbody tr:nth-child(even) { background-color:#fff;}
    td.editable-cell { cursor:pointer; position:relative; }
    td.editable-cell .edit-pen { color:#a23333; cursor:pointer; font-size:14px; margin-left:4px; }
    td.editable-cell input, td.editable-cell textarea {
        width:100%; font-size:13px; border:1px solid #a23333; border-radius:3px; background:#f4f4f4; color:#333; margin:0; padding:2px 4px;
    }
    td.editable-cell .save-edit, td.editable-cell .cancel-edit {
        background:none; border:none; font-size:15px; cursor:pointer; margin-left:4px;
    }
    td.editable-cell .save-edit { color:#2d7f2d;}
    td.editable-cell .cancel-edit { color:#ba1818;}
    @media (max-width: 991px) { .header{flex-direction:column;align-items:flex-start;height:auto;padding:8px 12px;} main{padding:20px 6vw;} }
</style>
</head>
<body>
<div class="header">
    <div class="logo">
        <a href="home.php" style="text-decoration:none; color:inherit;">YGScreen</a>
    </div>
    <div class="user-info">
        Bienvenue <?= htmlspecialchars($username) ?> -
        <a class="logout" href="logout.php" title="Se déconnecter">Me déconnecter</a><br>
        <?= date('H:i (l, F d)'); ?>
    </div>
</div>

<nav class="navbar navbar-expand-lg py-0" style="background:#222;">
    <div class="container-fluid" style="padding:0;">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 flex-row" style="width:100%;">
            <li class="nav-item">
                <a class="nav-link" href="home.php">Yks/Queries</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle active" href="#" id="contenuDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Contenu</a>
                <ul class="dropdown-menu" aria-labelledby="contenuDropdown">
                    <li><a class="dropdown-item" href="#">Allocine</a></li>
                    <li><a class="dropdown-item" href="#">Categories</a></li>
                    <li><a class="dropdown-item" href="#">Arbre des distributeurs</a></li>
                    <li><a class="dropdown-item active" href="./ephemerides.php">Ephemeride</a></li>
                    <li><a class="dropdown-item" href="./videos.php">Videos</a></li>
                </ul>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="search.php" id="clientsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Clients</a>
                <ul class="dropdown-menu" aria-labelledby="clientsDropdown">
                    <li><a class="dropdown-item" href="#">Tableau de bord</a></li>
                    <li><a class="dropdown-item" href="#">Fin de licenses</a></li>
                    <li><a class="dropdown-item" href="#">Pending brand requests</a></li>
                    <li><a class="dropdown-item" href="#">Brand Requests mails</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>
<main>
<?php foreach ($months as $month => $days): ?>
    <h2 class="month-title"><?= htmlspecialchars($month) ?></h2>
    <table>
        <thead>
            <tr>
                <th>Jour</th>
                <th>Saint</th>
                <th>Anniversaires</th>
                <th>Evènement</th>
                <th>Citation</th>
            </tr>
        </thead>
        <tbody>
        <?php for ($day=1; $day <= $days; $day++):
            $d = $data[$month][$day] ?? ['saint'=>'', 'anniversaires'=>'', 'evenement'=>'', 'citation'=>''];
        ?>
            <tr>
                <td><?= $day ?></td>
                <?php foreach(['saint','anniversaires','evenement','citation'] as $field): ?>
                    <td class="editable-cell" data-month="<?=htmlspecialchars($month)?>" data-day="<?=$day?>" data-field="<?=$field?>">
                        <span class="cell-value"><?= htmlspecialchars($d[$field]) ?></span>
                        <span class="edit-pen" title="Éditer">&#9998;</span>
                    </td>
                <?php endforeach; ?>
            </tr>
        <?php endfor; ?>
        </tbody>
    </table>
<?php endforeach; ?>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// --- Menu hover/click
document.querySelectorAll('.navbar-nav .dropdown').forEach(function(drop){
    drop.addEventListener('mouseenter', function(){
        let link = drop.querySelector('.dropdown-toggle');
        let bsDropdown = bootstrap.Dropdown.getOrCreateInstance(link);
        bsDropdown.show();
    });
    drop.addEventListener('mouseleave', function(){
        let link = drop.querySelector('.dropdown-toggle');
        let bsDropdown = bootstrap.Dropdown.getOrCreateInstance(link);
        setTimeout(function() {
            if (!drop.matches(':hover') && !drop.querySelector('.dropdown-menu:hover')) {
                bsDropdown.hide();
            }
        }, 150);
    });
    drop.querySelector('.dropdown-toggle').addEventListener('click', function(e){
        let bsDropdown = bootstrap.Dropdown.getOrCreateInstance(this);
        bsDropdown.toggle();
    });
});

// --- Inline edit éphémérides
document.querySelectorAll('.editable-cell').forEach(function(cell){
    cell.querySelector('.edit-pen').addEventListener('click', function(e){
        e.stopPropagation();
        let td = cell;
        if (td.querySelector('input,textarea')) return; // already editing

        let oldVal = td.querySelector('.cell-value').textContent;
        let field = td.getAttribute('data-field');
        let input = field === 'evenement' || field === 'citation'
            ? document.createElement('textarea')
            : document.createElement('input');
        input.value = oldVal;
        input.className = "form-control";
        input.style.margin = "0";
        input.style.display = "inline-block";
        input.style.width = "80%";

        let saveBtn = document.createElement('button');
        saveBtn.className = "save-edit";
        saveBtn.type = "button";
        saveBtn.innerHTML = "&#10003;";
        let cancelBtn = document.createElement('button');
        cancelBtn.className = "cancel-edit";
        cancelBtn.type = "button";
        cancelBtn.innerHTML = "&#10007;";

        let container = document.createElement('span');
        container.style.display = "inline-flex";
        container.appendChild(input);
        container.appendChild(saveBtn);
        container.appendChild(cancelBtn);

        let cellValueSpan = td.querySelector('.cell-value');
        cellValueSpan.style.display = "none";
        let pen = td.querySelector('.edit-pen');
        pen.style.display = "none";
        td.appendChild(container);
        input.focus();

        // Annule
        cancelBtn.onclick = function(){
            cellValueSpan.style.display = "";
            pen.style.display = "";
            container.remove();
        };
        // Sauve
        saveBtn.onclick = function(){
            let val = input.value.trim();
            fetch(window.location.href, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'month=' + encodeURIComponent(td.getAttribute('data-month')) +
                      '&day=' + encodeURIComponent(td.getAttribute('data-day')) +
                      '&field=' + encodeURIComponent(field) +
                      '&value=' + encodeURIComponent(val)
            })
            .then(r => r.json())
            .then(res => {
                if(res.ok) {
                    cellValueSpan.textContent = val;
                }
                cellValueSpan.style.display = "";
                pen.style.display = "";
                container.remove();
            });
        };
        input.addEventListener('keydown', function(e){
            if (e.key === 'Enter' && field!=='evenement' && field!=='citation') saveBtn.onclick();
            if (e.key === 'Escape') cancelBtn.onclick();
        });
    });
});

// Redirige sur search.php quand on clique sur le bouton principal Clients (hors dropdown)
document.querySelector('a[href="search.php"]').addEventListener('click', function(e){
    if (!e.target.closest('.dropdown-menu')) {
        window.location.href = 'search.php';
    }
});
</script>
</body>
</html>
