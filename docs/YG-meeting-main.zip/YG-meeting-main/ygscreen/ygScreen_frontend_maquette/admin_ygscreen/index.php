<?php
/**
 * File: index.php
 * Version: 2.2.0
 * Description: Page de login YGScreen (multi-user), création premier admin, look unifié avec home.php.
 */
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/db.php'; // Fournit $pdo

// Teste si la table users est vide
$stmt = $pdo->query("SELECT COUNT(*) FROM users");
$users_count = (int)$stmt->fetchColumn();

$error = '';
// Gestion du login POST classique
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['password'])) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['ygscreen_logged_in'] = true;
        $_SESSION['ygscreen_user_id'] = $user['id'];
        $_SESSION['ygscreen_username'] = $user['username'];
        $_SESSION['ygscreen_display_name'] = $user['display_name'] ?? $user['username'];
        $_SESSION['ygscreen_is_admin'] = !empty($user['is_admin']);
        header('Location: home.php');
        exit;
    } else {
        $error = "Identifiants invalides.";
    }
}

// Gestion de la création du tout premier user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_user'])) {
    $username = trim($_POST['new_username'] ?? '');
    $password = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';
    $display = trim($_POST['display_name'] ?? '');

    // Vérif basique
    if (!$username || !$password || !$confirm) {
        $error = "Merci de remplir tous les champs.";
    } elseif ($password !== $confirm) {
        $error = "Les mots de passe ne correspondent pas.";
    } elseif (!preg_match('/^[a-zA-Z0-9_\-.]{3,30}$/', $username)) {
        $error = "Le nom d'utilisateur n'est pas valide.";
    } else {
        // Check again (race condition - si user créé entre temps)
        $count = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
        if ($count > 0) {
            $error = "Un utilisateur a déjà été créé. Veuillez vous connecter.";
        } else {
            $pass_hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, display_name, is_admin) VALUES (?, ?, ?, 1)");
            $ok = $stmt->execute([$username, $pass_hash, $display ?: $username]);
            if ($ok) {
                header('Location: index.php?created=1'); // Correction ici !
                exit;
            } else {
                $error = "Erreur lors de la création du compte.";
            }
        }
    }
}

$show_create = ($users_count === 0);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<title>YGScreen - Connexion</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    body {
        font-family: Arial, sans-serif;
        background: #000;
        color: #eee;
        margin: 0; padding: 0;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }
    .header {
        background: linear-gradient(to bottom, #3a3a3a 0%, #1c1c1c 100%);
        color: #eee;
        padding: 0 20px;
        height: 70px;
        box-shadow: inset 0 -2px 5px rgba(0,0,0,0.7);
        display: flex;
        align-items: center;
    }
    .logo {
        font-weight: bold;
        font-size: 26px;
        color: white;
        text-shadow: 0 2px 3px rgba(0,0,0,0.8);
        font-family: 'Trebuchet MS', Arial, sans-serif;
        user-select: none;
        letter-spacing: 1px;
        position: relative;
    }
    .logo::after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 0;
        width: 100%;
        height: 15px;
        background: linear-gradient(transparent, rgba(255,255,255,0.25));
        opacity: 0.3;
        pointer-events: none;
        filter: blur(3px);
    }
    .login-container {
        margin: 60px auto 0 auto;
        background: #1c1c1c;
        border-radius: 12px;
        box-shadow: 0 6px 32px rgba(0,0,0,0.4);
        max-width: 340px;
        padding: 36px 30px 28px 30px;
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    .login-container h2 {
        margin-top: 0;
        margin-bottom: 25px;
        color: #a23333;
        font-size: 22px;
        font-weight: bold;
        letter-spacing: 1px;
        text-align: center;
        border-bottom: 1px solid #a23333;
        padding-bottom: 8px;
        width: 100%;
    }
    .login-container label {
        font-size: 15px;
        color: #eee;
        font-weight: normal;
        margin-bottom: 3px;
        margin-top: 12px;
        display: block;
        letter-spacing: 0.5px;
    }
    .login-container input[type="text"],
    .login-container input[type="password"] {
        width: 100%;
        padding: 9px 12px;
        border-radius: 4px;
        border: 1px solid #444;
        background: #222;
        color: #eee;
        font-size: 15px;
        margin-bottom: 8px;
        box-sizing: border-box;
        transition: border 0.2s;
    }
    .login-container input[type="text"]:focus,
    .login-container input[type="password"]:focus {
        border-color: #a23333;
        outline: none;
        background: #191919;
    }
    .login-container button {
        background: #a23333;
        color: #fff;
        border: none;
        font-weight: bold;
        font-size: 16px;
        border-radius: 4px;
        padding: 11px 0;
        margin-top: 18px;
        width: 100%;
        cursor: pointer;
        box-shadow: 0 2px 6px rgba(0,0,0,0.18);
        transition: background 0.15s;
    }
    .login-container button:hover {
        background: #600000;
    }
    .login-container .error-msg {
        background: #4e1e1e;
        color: #ffc1c1;
        padding: 9px 0;
        width: 100%;
        text-align: center;
        border-radius: 3px;
        margin-bottom: 13px;
        font-size: 15px;
        border: 1px solid #a23333;
        font-weight: bold;
    }
    .info-msg {
        background: #222;
        color: #a23333;
        text-align: center;
        font-size: 15px;
        padding: 6px 0;
        border-radius: 3px;
        margin-bottom: 18px;
    }
    @media (max-width: 500px) {
        .login-container { padding: 20px 5vw; max-width: 98vw; }
        .header { padding: 0 7vw; }
    }
</style>
</head>
<body>
    <div class="header">
        <div class="logo">YGScreen</div>
    </div>
    <div class="login-container">
        <?php if (isset($_GET['created'])): ?>
            <div class="info-msg">Utilisateur créé avec succès, vous pouvez vous connecter.</div>
        <?php endif; ?>

        <?php if ($show_create): ?>
            <h2>Créer le premier utilisateur</h2>
            <?php if ($error): ?>
                <div class="error-msg"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="post" autocomplete="off">
                <label for="new_username">Nom d'utilisateur :</label>
                <input type="text" id="new_username" name="new_username" required autocomplete="off" maxlength="30">

                <label for="display_name">Nom à afficher (optionnel) :</label>
                <input type="text" id="display_name" name="display_name" maxlength="100" autocomplete="off">

                <label for="new_password">Mot de passe :</label>
                <input type="password" id="new_password" name="new_password" required minlength="6" autocomplete="new-password">

                <label for="confirm_password">Confirmer le mot de passe :</label>
                <input type="password" id="confirm_password" name="confirm_password" required minlength="6" autocomplete="new-password">

                <button type="submit" name="create_user" value="1">Créer l'utilisateur admin</button>
            </form>
        <?php else: ?>
            <h2>Login</h2>
            <?php if ($error): ?>
                <div class="error-msg"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="post" autocomplete="off">
                <label for="username">Nom d'utilisateur :</label>
                <input type="text" id="username" name="username" autocomplete="username" required>

                <label for="password">Mot de passe :</label>
                <input type="password" id="password" name="password" autocomplete="current-password" required>

                <button type="submit">Se connecter</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
