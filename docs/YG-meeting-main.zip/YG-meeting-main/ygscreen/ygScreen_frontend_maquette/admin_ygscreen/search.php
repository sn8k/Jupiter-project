<?php
/**
 * File: clients.php
 * Version: 1.1.0
 * Description: Maquette PHP de la page Clients avec tableau pré-rempli exemples.
 */

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8" />
<title>Activ'screen - Recherche Clients</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background: #000;
        color: #eee;
        margin: 0; padding: 0;
    }
    .header {
        background: linear-gradient(to bottom, #3a3a3a 0%, #1c1c1c 100%);
        color: #eee;
        padding: 10px 20px;
        box-shadow: inset 0 -2px 5px rgba(0,0,0,0.7);
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 13px;
        user-select: none;
    }
    .logo {
        font-weight: bold;
        font-size: 26px;
        color: white;
        text-shadow: 0 2px 3px rgba(0,0,0,0.8);
        font-family: 'Trebuchet MS', Arial, sans-serif;
        position: relative;
    }
    .logo::after {
        content: '';
        position: absolute;
        bottom: -8px;
        left: 0;
        width: 100%;
        height: 15px;
        background: linear-gradient(transparent, rgba(255,255,255,0.25));
        opacity: 0.3;
        pointer-events: none;
        filter: blur(3px);
    }
    .user-info {
        text-align: right;
        line-height: 1.2;
    }
    .user-info .logout {
        color: #f44336;
        cursor: pointer;
        font-weight: bold;
    }
    nav {
        background-color: #222;
        border-top: 3px solid #600000;
        box-shadow: 0 3px 5px rgba(0,0,0,0.5);
        user-select: none;
    }
    nav ul {
        list-style: none;
        margin: 0; padding: 0 15px;
        display: flex;
        height: 38px;
        align-items: center;
    }
    nav ul li {
        position: relative;
        margin-right: 8px;
    }
    nav ul li a, nav ul li button {
        background-color: #444;
        border: none;
        padding: 8px 16px;
        color: #ccc;
        font-size: 14px;
        cursor: pointer;
        text-decoration: none;
        display: block;
        border-radius: 3px 3px 0 0;
        transition: background-color 0.3s ease, color 0.3s ease;
        user-select: none;
    }
    nav ul li a:hover, nav ul li button:hover {
        background-color: #5a5a5a;
        color: #fff;
    }
    nav ul li.active > button, nav ul li.active > a {
        background-color: #600000;
        color: white;
        font-weight: bold;
        cursor: default;
    }
    nav ul li ul.dropdown {
        position: absolute;
        top: 38px;
        left: 0;
        background-color: #fff;
        box-shadow: 0 5px 8px rgba(0,0,0,0.3);
        padding: 0;
        margin: 0;
        list-style: none;
        min-width: 180px;
        border-radius: 0 0 5px 5px;
        display: none;
        z-index: 1000;
    }
    nav ul li:hover ul.dropdown {
        display: block;
    }
    nav ul li ul.dropdown li {
        margin: 0;
    }
    nav ul li ul.dropdown li a {
        padding: 10px 16px;
        color: #222;
        font-weight: normal;
        border-bottom: 1px solid #ddd;
        border-radius: 0;
    }
    nav ul li ul.dropdown li a:hover {
        background-color: #f4f4f4;
        color: #600000;
        font-weight: bold;
    }
    main {
        background-color: #eee;
        color: #333;
        padding: 20px 30px;
        margin-top: 2px;
        user-select: none;
        max-width: 1100px;
        margin-left: auto;
        margin-right: auto;
    }
    .filter-box, .list-box {
        border: 1px solid #a23333;
        background-color: #fff;
        padding: 15px;
        border-radius: 5px;
        margin-bottom: 20px;
    }
    .filter-box h3, .list-box h3 {
        background-color: #a23333;
        color: #fff;
        padding: 5px 10px;
        margin: -15px -15px 15px -15px;
        font-size: 16px;
        border-radius: 5px 5px 0 0;
        user-select: none;
    }
    .filter-left {
        float: left;
        width: 200px;
        height: 140px;
        border: 1px solid #ccc;
        overflow-y: auto;
        font-size: 13px;
        padding: 5px;
        background-color: #fff;
        color: #000;
        user-select: text;
    }
    .filter-right {
        margin-left: 210px;
        font-size: 14px;
        user-select: text;
    }
    .filter-right label {
        margin-right: 5px;
    }
    .filter-right input[type="text"], .filter-right select {
        margin-right: 15px;
        padding: 4px 6px;
        font-size: 13px;
    }
    .filter-right input[type="checkbox"] {
        vertical-align: middle;
        margin-left: 5px;
        margin-right: 20px;
    }
    .filter-right button {
        float: right;
        background-color: #a23333;
        color: #fff;
        border: none;
        padding: 5px 15px;
        cursor: pointer;
        border-radius: 3px;
        font-weight: bold;
    }
    .filter-right button:hover {
        background-color: #7b1f1f;
    }
    .clearfix::after {
        content: \"\";
        clear: both;
        display: table;
    }
    .list-buttons {
        margin-bottom: 8px;
    }
    .list-buttons button {
        background-color: #888;
        border: none;
        color: #ddd;
        padding: 5px 12px;
        margin-right: 8px;
        cursor: pointer;
        border-radius: 3px;
        font-weight: bold;
    }
    .list-buttons button:hover {
        background-color: #666;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
    }
    thead {
        background-color: #a23333;
        color: white;
        user-select: none;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 5px 8px;
        vertical-align: middle;
        text-align: left;
    }
    tbody tr:nth-child(odd) {
        background-color: #ffe5e5;
    }
    tbody tr:nth-child(even) {
        background-color: #fff;
    }
    tbody td.actions {
        text-align: center;
        user-select: none;
    }
    tbody td.actions img {
        cursor: pointer;
        margin: 0 3px;
        vertical-align: middle;
        width: 16px;
        height: 16px;
    }
    .pagination {
        background-color: #a23333;
        padding: 5px 10px;
        color: white;
        font-size: 13px;
        margin-top: 8px;
        border-radius: 5px;
        user-select: none;
    }
    .pagination a {
        color: white;
        text-decoration: none;
        margin: 0 3px;
        cursor: pointer;
    }
    .pagination a:hover {
        text-decoration: underline;
    }
    .summary-row {
        background-color: #ccc;
        font-size: 13px;
        font-weight: bold;
        color: #222;
    }
</style>
</head>
<body>
<div class="header">
    <div class="logo">Activ'screen</div>
    <div class="user-info">
        Bienvenue Yann Gantner - <span class="logout">Me déconnecter</span><br>
        <?php echo date('H:i (l, F d)'); ?>
    </div>
</div>
<nav>
    <ul>
        <li><button type="button">Yks/Queries</button></li>
        <li><button type="button">Contenu</button></li>
        <li class="active"><button type="button">Clients</button></li>
    </ul>
</nav>
<main>
    <div class="filter-box clearfix">
        <h3>Rechercher des comptes</h3>
        <div class="filter-left" tabindex="0" role="listbox" aria-label="Liste des groupes">
            Réseaux Export IVS<br>
            Global Business<br>
            ACUITIS Italy<br>
            IVS Switzerland VISILAB<br>
            BBGR Nikon Europe<br>
            &nbsp;&nbsp;Reize Optik<br>
            &nbsp;&nbsp;NIKA Nikon<br>
            &nbsp;&nbsp;Omega Optix - Czech Republic
        </div>
        <div class="filter-right">
            <label for="account">Account name, login, device key... (complex query)</label>
            <input id="account" type="text" name="account" />
            <label><input type="checkbox" name="shopids" /> ShopIDs</label><br><br>
            <label for="product_serial">Product serial</label>
            <input id="product_serial" type="text" name="product_serial" />
            <label for="release_level">Release level :</label>
            <select id="release_level" name="release_level">
                <option>-- Sélectionner --</option>
            </select><br><br>
            <label for="sort_by">Sort by :</label>
            <select id="sort_by" name="sort_by">
                <option>Creation date</option>
            </select>
            <select id="sort_dir" name="sort_dir">
                <option>Desc</option>
            </select>
            <label for="display_count">Display :</label>
            <select id="display_count" name="display_count">
                <option>20</option>
            </select>
            <button type="submit">Search</button>
        </div>
    </div>

    <div class="list-box">
        <h3>Liste des comptes</h3>
        <div class="list-buttons">
            <button>Create an account</button>
            <button>Export Excel</button>
            <button>Show usernames</button>
        </div>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Shops list</th>
                    <th>License end</th>
                    <th>Distributor</th>
                    <th>Release level</th>
                    <th>Created on</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="color:#a23333;">18314</td>
                    <td>FOTO OTTICA RB</td>
                    <td><a href="#" style="color:#a23333;">Shop #19380 FOTO OTTICA RB - 33054 LIGNANO SABBIADORO</a></td>
                    <td>2028-06-05</td>
                    <td>Essilor Italy</td>
                    <td>stable</td>
                    <td>2025-05-30</td>
                    <td class="actions">
                        <img src="info_icon.png" alt="Info" title="Info" />
                        <img src="delete_icon.png" alt="Delete" title="Delete" />
                    </td>
                </tr>
                <tr>
                    <td style="color:#a23333;">18313</td>
                    <td>17665_LUZES RELOJOARIA E OTICA LTDA</td>
                    <td><a href="#" style="color:#a23333;">Shop #19379 17665_LUZES RELOJOARIA E OTICA LTDA - 90610000 PORTO ALEGRE-RS</a></td>
                    <td>2028-06-19</td>
                    <td>Essilor Brasil</td>
                    <td>stable</td>
                    <td>2025-05-30</td>
                    <td class="actions">
                        <img src="info_icon.png" alt="Info" title="Info" />
                        <img src="delete_icon.png" alt="Delete" title="Delete" />
                    </td>
                </tr>
                <tr>
                    <td style="color:#a23333;">18312</td>
                    <td>17206_LUZES RELOJOARIA E OTICA LTDA</td>
                    <td><a href="#" style="color:#a23333;">Shop #19378 17206_LUZES RELOJOARIA E OTICA LTDA - 90110001 PORTO ALEGRE-RS</a></td>
                    <td>2028-06-19</td>
                    <td>Essilor Brasil</td>
                    <td>stable</td>
                    <td>2025-05-30</td>
                    <td class="actions">
                        <img src="info_icon.png" alt="Info" title="Info" />
                        <img src="delete_icon.png" alt="Delete" title="Delete" />
                    </td>
                </tr>
            </tbody>
        </table>
        <div class="summary-row">
            Shown: 3 accounts &nbsp;&nbsp; 3 shops &nbsp;&nbsp; 3 distributors &nbsp;&nbsp; 3 releases
        </div>
        <div class="pagination">
            [1] 2 3 ...819 820 821 822 823
        </div>
    </div>
</main>
</body>
</html>
