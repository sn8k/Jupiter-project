// File: backend/api.js
// Version: 1.4.1 (2025-06-25)
// - Imposition stricte des médias 'imposed_medias' à chaque appel playlist
// - 'default' toujours en tête et en random dans la playlist
// - Logs verbeux/debug pour toutes les étapes

const API_VERSION = "1.4.1 (2025-06-25)";

const express   = require('express');
const multer    = require('multer');
const fs        = require('fs');
const path      = require('path');
const crypto    = require('crypto');
const ffmpeg    = require('./ffmpeg_worker');
const config    = require('./config.json');
const imposedMediaDir = config.imposed_media_dir ||
    path.resolve(__dirname, '..', '..', 'medias_library', 'imposed_medias');
const logFile = config.log_file;

function log(msg) {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log(line);
    if (logFile) {
        fs.appendFile(logFile, line + '\n', () => {});
    }
}

log(`=== YGScreen API version ${API_VERSION} démarrée ===`);
console.log(`=== YGScreen API version ${API_VERSION} démarrée ===`);

const app     = express();
const upload  = multer({ dest: config.tmp_dir });

app.use(express.json());

app.post('/api/player/upload', upload.single('video'), async (req, res) => {
    try {
        log(`[UPLOAD] POST /api/player/upload - Params: ${JSON.stringify(req.body)}`);
        if (!req.file || !req.body.device_key) {
            log(`[UPLOAD][ERROR] missing parameters`);
            res.status(400).json({ error: 'missing parameters' });
            return;
        }
        log(`[UPLOAD] Request from device ${req.body.device_key} file ${req.file.originalname}`);
        const { device_key, mode = 'landscape', order, title = '' } = req.body;
        const tmpPath = req.file.path;
        const fileBuffer = fs.readFileSync(tmpPath);
        const hash = crypto.createHash('sha1').update(fileBuffer).digest('hex');
        const dir = hash.substring(0, 2);
        const deviceDir = path.join(config.media_storage, device_key, dir);
        fs.mkdirSync(deviceDir, { recursive: true });
        const destPath = path.join(deviceDir, hash);
        log(`[UPLOAD] Converting with ffmpeg (${tmpPath} -> ${destPath}) mode=${mode}`);
        await ffmpeg.convert(tmpPath, destPath, mode, log);
        fs.unlinkSync(tmpPath);
        log(`[UPLOAD] Conversion done for ${device_key}`);

        const playlistPath = path.join(config.media_storage, device_key, 'playlist.json');
        let playlist = { mode, playlist: [] };
        if (fs.existsSync(playlistPath)) {
            playlist = JSON.parse(fs.readFileSync(playlistPath));
            if (!playlist.playlist) playlist.playlist = [];
        }
        playlist.mode = mode;
        playlist.playlist.push({ dir, file: hash, order: Number(order) || playlist.playlist.length + 1, title: title || req.file.originalname });
        fs.writeFileSync(playlistPath, JSON.stringify(playlist, null, 2));
        log(`[UPLOAD] Playlist updated for ${device_key}`);

        res.json({ ok: true, hash });
        log(`[UPLOAD] Uploaded ${hash} for ${device_key}`);
    } catch (e) {
        console.error(`[UPLOAD][FATAL] ${e.stack}`);
        log(`[UPLOAD][FATAL] ${e.stack}`);
        res.status(500).json({ error: 'conversion failed' });
    }
});

// -------- NOUVELLE VERSION /api/player/playlist/:device_key --------
app.get('/api/player/playlist/:device_key', (req, res) => {
    log(`[PLAYLIST] GET /api/player/playlist/${req.params.device_key}`);
    try {
        const deviceDir = path.join(config.media_storage, req.params.device_key);
        const playlistPath = path.join(deviceDir, 'playlist.json');
        let playlist = { mode: 'landscape', playlist: [] };

        if (!fs.existsSync(deviceDir)) {
            log(`[PLAYLIST][INFO] Création dossier device: ${deviceDir}`);
            fs.mkdirSync(deviceDir, { recursive: true });
        }

        // 1. Charger la playlist utilisateur si elle existe
        if (fs.existsSync(playlistPath)) {
            try {
                playlist = JSON.parse(fs.readFileSync(playlistPath));
                if (!playlist.playlist) playlist.playlist = [];
                log(`[PLAYLIST][INFO] Playlist existante lue, ${playlist.playlist.length} vidéos`);
            } catch (e) {
                log(`[PLAYLIST][WARN] Erreur lecture playlist existante: ${e}`);
                playlist = { mode: 'landscape', playlist: [] };
            }
        } else {
            log(`[PLAYLIST][INFO] Aucune playlist existante`);
        }

        // 2. Charger les médias imposés
        let imposed = [];
        let imposedDefault = null;
        if (fs.existsSync(imposedMediaDir)) {
            const files = fs.readdirSync(imposedMediaDir);
            log(`[PLAYLIST][INFO] ${files.length} fichiers trouvés dans imposed_medias`);
            for (const f of files) {
                const filePath = path.join(imposedMediaDir, f);
                if (!fs.statSync(filePath).isFile()) continue;
                const data = fs.readFileSync(filePath);
                const hash = crypto.createHash('sha1').update(data).digest('hex');
                const dir = hash.substring(0, 2);
                const targetDir = path.join(deviceDir, dir);
                fs.mkdirSync(targetDir, { recursive: true });
                const dest = path.join(targetDir, hash);
                if (!fs.existsSync(dest)) fs.writeFileSync(dest, data);
                const entry = { dir, file: hash, title: f };
                if (f.toLowerCase().startsWith('default')) {
                    imposedDefault = entry;
                    log(`[PLAYLIST][INFO] Vidéo 'default' trouvée: ${f} (hash: ${hash})`);
                } else {
                    imposed.push(entry);
                    log(`[PLAYLIST][INFO] Vidéo imposée trouvée: ${f} (hash: ${hash})`);
                }
            }
        } else {
            log(`[PLAYLIST][WARN] imposedMediaDir inexistant: ${imposedMediaDir}`);
        }

        // 3. Fusion playlist finale
        let finalPlaylist = [];
        let order = 1;

        if (imposedDefault) {
            finalPlaylist.push({ ...imposedDefault, order: order++ });
            log(`[PLAYLIST][INFO] 'default' insérée en position 1`);
        }

        // Ajout vidéos utilisateur
        for (const item of playlist.playlist || []) {
            if (imposedDefault && item.file === imposedDefault.file) {
                log(`[PLAYLIST][INFO] Doublon 'default' évité dans playlist user`);
                continue;
            }
            finalPlaylist.push({ ...item, order: order++ });
            log(`[PLAYLIST][INFO] Ajout vidéo user: ${item.title || item.file}`);
        }

        // Ajout des autres imposés (sans doublon)
        for (const imp of imposed) {
            if (finalPlaylist.some(e => e.file === imp.file)) {
                log(`[PLAYLIST][INFO] Vidéo imposée déjà présente, non ajoutée: ${imp.title}`);
                continue;
            }
            finalPlaylist.push({ ...imp, order: order++ });
            log(`[PLAYLIST][INFO] Ajout vidéo imposée: ${imp.title}`);
        }

        // Insérer default en random (hors début) si playlist longue
        if (imposedDefault && finalPlaylist.length > 2) {
            const randPos = Math.floor(Math.random() * (finalPlaylist.length - 1)) + 1;
            finalPlaylist.splice(randPos, 0, { ...imposedDefault, order: randPos + 1, title: imposedDefault.title + " (random)" });
            for (let i = 0; i < finalPlaylist.length; i++) finalPlaylist[i].order = i + 1;
            log(`[PLAYLIST][INFO] 'default' réinsérée en position random: ${randPos + 1}`);
        }

        playlist.playlist = finalPlaylist;

        // Sauvegarde la playlist (toujours à jour)
        fs.writeFileSync(playlistPath, JSON.stringify(playlist, null, 2));

        log(`[PLAYLIST][DEBUG] Playlist finale (${finalPlaylist.length} vidéos):\n${JSON.stringify(finalPlaylist, null, 2)}`);

        res.sendFile(playlistPath);
        log(`[PLAYLIST][INFO] Playlist servie pour device ${req.params.device_key}`);
    } catch (e) {
        console.error(`[PLAYLIST][FATAL] ${e.stack}`);
        log(`[PLAYLIST][FATAL] ${e.stack}`);
        res.status(500).json({ error: 'read error' });
    }
});

app.get('/api/player/media/:device_key/:dir/:file', (req, res) => {
    const file = path.join(config.media_storage, req.params.device_key, req.params.dir, req.params.file);
    log(`[MEDIA] GET /api/player/media/${req.params.device_key}/${req.params.dir}/${req.params.file} (${file})`);
    if (!fs.existsSync(file)) {
        log(`[MEDIA][ERROR] Fichier non trouvé: ${file}`);
        return res.status(404).json({ error: 'file not found' });
    }
    res.sendFile(file);
    log(`[MEDIA][INFO] Fichier media servi: ${file}`);
});

app.post('/api/player/clear-cache/:device_key', (req, res) => {
    try {
        const devicePath = path.join(config.media_storage, req.params.device_key);
        log(`[CLEAR-CACHE] POST /api/player/clear-cache/${req.params.device_key}`);
        if (!fs.existsSync(devicePath)) {
            log(`[CLEAR-CACHE][ERROR] devicePath introuvable: ${devicePath}`);
            return res.status(404).json({ error: 'device not found' });
        }
        for (const entry of fs.readdirSync(devicePath)) {
            if (entry === 'playlist.json' || entry === 'default') continue;
            fs.rmSync(path.join(devicePath, entry), { recursive: true, force: true });
            log(`[CLEAR-CACHE][INFO] Suppression: ${entry}`);
        }
        res.json({ ok: true });
        log(`[CLEAR-CACHE][INFO] Cache vidé pour ${req.params.device_key}`);
    } catch (e) {
        console.error(`[CLEAR-CACHE][FATAL] ${e.stack}`);
        log(`[CLEAR-CACHE][FATAL] ${e.stack}`);
        res.status(500).json({ error: 'clear failed' });
    }
});

app.listen(8500, '0.0.0.0', () => {
    log(`YGScreen backend version ${API_VERSION} started on 0.0.0.0:8500`);
    console.log(`API Backend YGS-Player version ${API_VERSION} sur 0.0.0.0:8500`);
});
