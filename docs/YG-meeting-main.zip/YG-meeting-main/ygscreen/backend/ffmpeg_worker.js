// File: backend/ffmpeg_worker.js
// Version: 1.1.2 (2025-06-25)

const { spawn } = require('child_process');
const config = require('./config.json');

/**
 * Convertit une vidéo vers le format mp4 H264.
 * @param {string} input - Chemin du fichier source
 * @param {string} output - Chemin du fichier destination (sans extension)
 * @param {string} mode - "landscape" ou "portrait" (optionnel)
 * @returns {Promise<void>}
 */
exports.convert = (input, output, mode = 'landscape', logger = () => {}) => {
  return new Promise((resolve, reject) => {
    const args = ['-y', '-i', input];

    // Simple preset; le mode peut être utilisé pour adapter la résolution
    if (mode === 'portrait') {
      args.push('-vf', 'transpose=1');
    }

    args.push('-c:v', 'libx264', '-preset', 'veryfast', '-movflags', '+faststart', '-f', 'mp4', output);

    logger(`ffmpeg command: ${config.conversion_bin} ${args.join(' ')}`);

    const proc = spawn(config.conversion_bin, args);

    proc.stderr.on('data', d => {
      process.stderr.write(d);
      logger(`ffmpeg stderr: ${d.toString()}`.trim());
    });
    proc.on('error', err => {
      logger(`ffmpeg error: ${err.message}`);
      reject(err);
    });
    proc.on('close', code => {
      logger(`ffmpeg exited with code ${code}`);
      if (code === 0) resolve();
      else reject(new Error('ffmpeg exited with code ' + code));
    });
  });
};
