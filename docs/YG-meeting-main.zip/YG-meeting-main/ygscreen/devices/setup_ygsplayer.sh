#!/usr/bin/env bash
# File: setup_ygsplayer.sh
# Version: 1.0.0 (2025-06-25)
# Description: Installe toutes les dépendances nécessaires à ygs-player,
#   puis déploie le service via install_ygs_player.sh.

set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "[INFO] Relance avec sudo..."
  exec sudo -E "$0" "$@"
fi

install_deps() {
  echo "[1/2] Installation des dépendances (curl, jq, mpv, Node.js)…"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y || true
  apt-get install -y curl jq mpv || true
  if ! command -v node >/dev/null 2>&1; then
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash - || echo "[WARN] setup NodeSource échoué"
    apt-get install -y nodejs || echo "[WARN] installation nodejs échouée"
  fi
}

install_player() {
  "$(dirname "$0")/../../tools/setup-files/install_ygs_player.sh"
}

install_deps
install_player

echo "[OK] setup ygs-player terminé"
