#!/usr/bin/env node
// File: devices/ygs-player.js
// Version: 1.2.2 (2025-06-25)
// Description: YGScreen media player agent for RPi, URL du backend API dynamique (host, port, protocole séparés).

import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import https from 'node:https';
import { spawn } from 'node:child_process';

const VERSION = '1.2.2';
const CFG_FILE = new URL('./player_config.json', import.meta.url).pathname;
const AGENT_CFG_FILE = '/usr/local/bin/config.json';
const DEVICE_INFO_FILE = '/etc/meeting/device_info.json';
const LOG_FILE = '/var/log/ygs-player.log';
const TMP_PLAYLIST = '/tmp/ygs-player.m3u';

// -------------------
// Config par défaut :
// -------------------
const DEFAULT_CFG = {
  deviceKey: 'ChangeMe',
  mediaRoot: '/var/cache/ygscreen/medias',
  mpvBin: '/usr/bin/mpv',
  refreshMs: 60000,
  ygsApiProtocol: 'http',               // <-- Par défaut "https"
  ygsApiHost: 'meeting.ygsoft.fr',       // <-- Host distant par défaut
  ygsApiPort: 8500                       // <-- Port backend API YGScreen
};

// Logging simple + fichier
function log(...msg) {
  const line = new Date().toISOString() + ' ' + msg.join(' ');
  console.log(line);
  try { fs.appendFileSync(LOG_FILE, line + '\n'); } catch {}
}

function readJson(file) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return null; }
}

// Construit l'URL du backend à partir de la config, toujours dynamique
function makeApiBase(cfg) {
  const proto = cfg.ygsApiProtocol || 'https';
  const host = cfg.ygsApiHost || 'meeting.ygsoft.fr';
  const port = cfg.ygsApiPort ? `:${cfg.ygsApiPort}` : '';
  return `${proto}://${host}${port}`;
}

function loadCfg() {
  const cfg = { ...DEFAULT_CFG, ...(readJson(CFG_FILE) || {}) };

  // Permet la surcharge par config centrale si voulu
  const agent = readJson(AGENT_CFG_FILE);
  if (agent) {
    if (agent.ygsApiProtocol) cfg.ygsApiProtocol = agent.ygsApiProtocol;
    if (agent.ygsApiHost)     cfg.ygsApiHost     = agent.ygsApiHost;
    if (agent.ygsApiPort)     cfg.ygsApiPort     = agent.ygsApiPort;
  }

  // Device info : clé unique
  const info = readJson(DEVICE_INFO_FILE);
  if (info && info.device_key) cfg.deviceKey = info.device_key;

  // On compose dynamiquement les URLs
  const base = makeApiBase(cfg);
  cfg.playlistUrl = `${base}/api/player/playlist`;
  cfg.mediaUrl    = `${base}/api/player/media`;

  return cfg;
}

function saveCfg(cfg) {
  try { fs.writeFileSync(CFG_FILE, JSON.stringify(cfg, null, 2)); } catch {}
}

function httpGet(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    client.get(url, res => {
      if (res.statusCode && res.statusCode >= 400) {
        reject(new Error('status ' + res.statusCode));
      } else {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve(Buffer.concat(chunks)));
      }
    }).on('error', reject);
  });
}

async function fetchPlaylist(cfg) {
  const url = `${cfg.playlistUrl}/${cfg.deviceKey}`;
  log('Fetching playlist', url);
  const buf = await httpGet(url);
  return JSON.parse(buf.toString());
}

async function downloadMedia(cfg, dir, file, dest) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const url = `${cfg.mediaUrl}/${cfg.deviceKey}/${dir}/${file}`;
  log('Downloading', url);
  const data = await httpGet(url);
  fs.writeFileSync(dest, data);
}

function clearCache(cfg) {
  const deviceDir = path.join(cfg.mediaRoot, cfg.deviceKey);
  if (!fs.existsSync(deviceDir)) return;
  for (const entry of fs.readdirSync(deviceDir)) {
    if (entry === 'playlist.json' || entry === 'default') continue;
    fs.rmSync(path.join(deviceDir, entry), { recursive: true, force: true });
  }
  log('Cache cleared');
}

async function syncMedias(cfg) {
  let playlist;
  const deviceDir = path.join(cfg.mediaRoot, cfg.deviceKey);
  fs.mkdirSync(deviceDir, { recursive: true });
  const localPlaylistFile = path.join(deviceDir, 'playlist.json');

  try {
    playlist = await fetchPlaylist(cfg);
    fs.writeFileSync(localPlaylistFile, JSON.stringify(playlist, null, 2));
  } catch (e) {
    log('Failed to fetch playlist:', e.message);
    if (fs.existsSync(localPlaylistFile)) {
      playlist = JSON.parse(fs.readFileSync(localPlaylistFile));
    } else {
      log('No playlist available');
      return null;
    }
  }

  const expected = new Set();
  for (const item of playlist.playlist || []) {
    const target = path.join(deviceDir, item.dir, item.file);
    expected.add(path.relative(deviceDir, target));
    if (!fs.existsSync(target)) {
      try { await downloadMedia(cfg, item.dir, item.file, target); }
      catch (err) { log('Download error', item.file, err.message); }
    }
  }

  for (const entry of fs.readdirSync(deviceDir)) {
    if (entry === 'playlist.json' || entry === 'default') continue;
    const full = path.join(deviceDir, entry);
    if (fs.lstatSync(full).isDirectory()) {
      for (const f of fs.readdirSync(full)) {
        const rel = path.join(entry, f);
        if (!expected.has(rel)) fs.rmSync(path.join(full, f), { force: true });
      }
      if (fs.readdirSync(full).length === 0) fs.rmdirSync(full);
    } else if (!expected.has(entry)) {
      fs.rmSync(full, { force: true });
    }
  }

  const ordered = [...(playlist.playlist || [])]
    .sort((a,b) => (a.order||0)-(b.order||0))
    .map(it => path.join(deviceDir, it.dir, it.file));

  fs.writeFileSync(TMP_PLAYLIST, ordered.join('\n'));
  return TMP_PLAYLIST;
}

async function main() {
  const cfg = loadCfg();
  if (!fs.existsSync(CFG_FILE)) saveCfg(cfg);
  const arg = process.argv[2];
  if (arg === '--clear-cache') { clearCache(cfg); return; }
  log(`=== ygs-player ${VERSION} ===`);
  while (true) {
    const m3u = await syncMedias(cfg);
    if (m3u) {
      log('Starting mpv');
      const mpv = spawn(cfg.mpvBin, ['--fs', '--no-terminal', '--playlist=' + m3u], { stdio: 'inherit' });
      await new Promise(r => mpv.on('close', r));
    } else {
      await new Promise(r => setTimeout(r, cfg.refreshMs));
    }
  }
}

main().catch(e => { log('Fatal', e.message); process.exit(1); });
