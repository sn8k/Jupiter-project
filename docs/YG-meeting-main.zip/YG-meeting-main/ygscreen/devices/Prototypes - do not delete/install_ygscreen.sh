#!/bin/bash
#
# install_ygscreen.sh - Installe mpv, configure l'autoplay HDMI sur Raspberry Pi sans Desktop
# Version: 1.1 - 2024-05-25 (patch boot clean, tty1, login, service systemd)
# Auteur: ChatGPT
#

set -e

SERVICE_NAME="ygscreen"
MEDIA_DIR="/var/cache/YGScreen/medias"
DEFAULT_VIDEO="$MEDIA_DIR/default.mp4"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
MPV_BIN=$(which mpv || true)
PLAYER_SCRIPT="/usr/local/bin/ygscreen_player.sh"

echo "== Installation automatique YGScreen (BOOT CLEAN) =="

# 0. Patch boot pour "no logs" (boot noir)
BOOTFIRM="/boot/firmware"
[ -d "$BOOTFIRM" ] || BOOTFIRM="/boot"
CMDLINE="$BOOTFIRM/cmdline.txt"
CONFIGTXT="$BOOTFIRM/config.txt"

echo "[BOOT] Patch $CONFIGTXT (disable splash/logo/overscan)"
sudo grep -q "^disable_splash=1" $CONFIGTXT || echo "disable_splash=1" | sudo tee -a $CONFIGTXT
sudo grep -q "^disable_overscan=1" $CONFIGTXT || echo "disable_overscan=1" | sudo tee -a $CONFIGTXT
sudo grep -q "^disable_logo=1" $CONFIGTXT || echo "disable_logo=1" | sudo tee -a $CONFIGTXT

echo "[BOOT] Patch $CMDLINE (console sur tty3, quiet, loglevel=3)"
sudo cp "$CMDLINE" "$CMDLINE.bak.$(date +%Y%m%d-%H%M%S)"
NEWCMD=$(cat $CMDLINE | sed -E 's/console=tty[0-9]+/ /g')
NEWCMD=$(echo $NEWCMD | sed 's/  */ /g')
NEWCMD="$NEWCMD console=tty3 quiet loglevel=3 vt.global_cursor_default=0"
echo "$NEWCMD" | sudo tee $CMDLINE >/dev/null

echo "[BOOT] Désactive le getty (login prompt) sur tty1"
sudo systemctl mask getty@tty1

# 1. Installer mpv si nécessaire
if [ -z "$MPV_BIN" ]; then
    echo "Installation de mpv..."
    sudo apt update
    sudo apt install -y mpv
    MPV_BIN=$(which mpv)
else
    echo "mpv déjà installé."
fi

# 2. Créer le dossier médias si absent
if [ ! -d "$MEDIA_DIR" ]; then
    echo "Création du dossier $MEDIA_DIR"
    sudo mkdir -p "$MEDIA_DIR"
    sudo chown $(whoami):$(whoami) "$MEDIA_DIR"
else
    echo "Le dossier $MEDIA_DIR existe déjà."
fi

# 3. Télécharger la vidéo par défaut si manquante
if [ ! -f "$DEFAULT_VIDEO" ]; then
    echo "Téléchargement de la vidéo par défaut..."
    wget -O "$DEFAULT_VIDEO" "https://meeting.ygsoft.fr/default.mp4"
else
    echo "La vidéo par défaut existe déjà."
fi

# 4. Créer le script de lecture automatique (avec clear écran noir)
cat <<'EOF' | sudo tee "$PLAYER_SCRIPT" > /dev/null
#!/bin/bash
MEDIA_DIR="/var/cache/YGScreen/medias"
DEFAULT="$MEDIA_DIR/default.mp4"

# Écran noir avant toute chose (assure le fond noir)
setterm --background black --foreground black --clear all > /dev/tty1

while true; do
    if [ -d "$MEDIA_DIR" ]; then
        SUBFOLDERS=$(find "$MEDIA_DIR" -mindepth 1 -type d)
        if [ -n "$SUBFOLDERS" ]; then
            for folder in $SUBFOLDERS; do
                for vid in "$folder"/*.{mp4,mkv,avi,webm}; do
                    [ -f "$vid" ] || continue
                    mpv --fs --no-terminal --really-quiet "$vid"
                done
            done
        else
            if [ -f "$DEFAULT" ]; then
                mpv --fs --no-terminal --loop=inf --really-quiet "$DEFAULT"
            else
                sleep 5
            fi
        fi
    else
        sleep 5
    fi
done
EOF
sudo chmod +x "$PLAYER_SCRIPT"

# 5. Créer le service systemd (sur tty1, fond noir garanti, boot "clean")
cat <<EOF | sudo tee "$SERVICE_FILE" > /dev/null
[Unit]
Description=Lecture vidéos HDMI au démarrage (YGScreen/mpv)
After=multi-user.target

[Service]
Type=simple
StandardInput=tty
TTYPath=/dev/tty1
TTYReset=yes
TTYVHangup=yes
ExecStartPre=/usr/bin/setterm --background black --foreground black --clear all > /dev/tty1
ExecStart=$PLAYER_SCRIPT
RemainAfterExit=yes
User=$(whoami)
Group=$(whoami)

[Install]
WantedBy=multi-user.target
EOF

# 6. Activer et démarrer le service
echo "Activation et démarrage du service systemd..."
sudo systemctl daemon-reload
sudo systemctl enable "$SERVICE_NAME"
sudo systemctl restart "$SERVICE_NAME"

echo "== Installation terminée (YGScreen v1.1) ! =="
echo "Le boot sera désormais noir (propre), sans texte, et la lecture vidéo HDMI auto sur tty1."
echo "Pour annuler : systemctl disable $SERVICE_NAME ; systemctl unmask getty@tty1 ; supprimer $SERVICE_FILE"
echo "Les vidéos : place-les dans des sous-dossiers de $MEDIA_DIR (par défaut default.mp4)."
echo "Si tu veux changer la vidéo principale : édite $PLAYER_SCRIPT."

exit 0
