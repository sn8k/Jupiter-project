#!/bin/bash
#
# install_ysplash.sh — Camouflage du boot et splash personnalisé pour Raspberry Pi (Debian 12 Lite)
# Version: 1.0 — 2024-05-23
# Auteur: ChatGPT
#

set -e

echo "=== [YScreen] Masquage du démarrage et installation du splash ==="

# 1. Editer /boot/cmdline.txt pour masquer le boot log
CMDLINE="/boot/cmdline.txt"
if [ ! -f "$CMDLINE" ]; then
    echo "ERREUR : $CMDLINE introuvable. Exécuter sur un Raspberry Pi avec /boot monté."
    exit 1
fi

# Sauvegarder l'original
sudo cp "$CMDLINE" "${CMDLINE}.bak"

# Supprimer les anciennes options si présentes
NEW_CMDLINE=$(cat "$CMDLINE" | \
    sed -e 's/console=tty[0-9]\+//g' \
        -e 's/quiet//g' \
        -e 's/loglevel=[0-9]\+//g' \
        -e 's/logo\.nologo//g' \
        -e 's/vt\.global_cursor_default=0//g' \
        -e 's/splash//g')

# Ajouter nos options en tête
NEW_CMDLINE="console=tty3 quiet loglevel=0 logo.nologo vt.global_cursor_default=0 splash $NEW_CMDLINE"

# Nettoyer espaces superflus
NEW_CMDLINE=$(echo "$NEW_CMDLINE" | tr -s ' ')

# Ecrire en une seule ligne !
echo "$NEW_CMDLINE" | sudo tee "$CMDLINE" > /dev/null

echo "→ /boot/cmdline.txt mis à jour."

# 2. Installer Plymouth et thème spinner
echo "Installation de Plymouth et du thème spinner..."
sudo apt update
sudo apt install -y plymouth plymouth-themes

# 3. Choisir le thème "spinner"
echo "Configuration du splash spinner..."
sudo plymouth-set-default-theme spinner

# 4. Ajouter notre texte custom à spinner

# Localiser le fichier .script du thème
THEME_PATH="/usr/share/plymouth/themes/spinner"
SCRIPT_FILE="$THEME_PATH/spinner.script"
BACKUP_FILE="$THEME_PATH/spinner.script.bak"

if [ -f "$SCRIPT_FILE" ]; then
    # Sauvegarder si pas déjà fait
    [ -f "$BACKUP_FILE" ] || sudo cp "$SCRIPT_FILE" "$BACKUP_FILE"

    # Modifier le script pour ajouter notre texte custom
    # On ajoute une ligne de texte centrée ("YScreen by YGS / Starting") sous le spinner
    if ! grep -q "YScreen by YGS" "$SCRIPT_FILE"; then
        sudo sed -i '/Window.SetBackgroundTopColor/ a \
        my_message = "YScreen by YGS /  Starting";\
        ' "$SCRIPT_FILE"

        # Ajouter l'affichage du texte à chaque frame du spinner
        sudo sed -i '/plymouth.SetBootProgressFunction/ a \
    # Affichage message custom\
    if my_message != ""\
        screen_width = Window.GetWidth();\
        screen_height = Window.GetHeight();\
        message_width = Plymouth.MeasureText(my_message);\
        Plymouth.DrawText(screen_width/2-message_width/2, screen_height/2+40, my_message);\
    end if\
' "$SCRIPT_FILE"
    fi
    echo "→ Texte splash personnalisé inséré dans le thème spinner."
else
    echo "Erreur : thème spinner introuvable, texte custom non inséré."
fi

# 5. Masquer le prompt de login tty1 (pour éviter toute intrusion avant mpv)
echo "Désactivation du prompt login sur tty1..."
sudo systemctl mask getty@tty1.service

# 6. Mise à jour des images/initramfs pour plymouth
echo "Mise à jour du splash Plymouth..."
sudo update-initramfs -u

echo ""
echo "=== Fini ! ==="
echo "→ Redémarre le Raspberry Pi pour voir le résultat !"
echo "• Le démarrage sera propre, sans texte."
echo "• Splash spinner + 'YScreen by YGS /  Starting'"
echo "• Pas de prompt login sur HDMI, ta vidéo pourra démarrer sans perturbation visuelle."
