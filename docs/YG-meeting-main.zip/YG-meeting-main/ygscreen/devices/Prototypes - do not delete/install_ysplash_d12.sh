#!/bin/bash
#
# install_ysplash_debian12_rpi.sh — Boot clean + splash spinner personnalisé pour Debian 12 Raspberry Pi
# Version: 1.2 — 2024-05-23
# Auteur: ChatGPT
#

set -e

# ----- 1. Modifier /boot/firmware/cmdline.txt -----
CMDLINE="/boot/firmware/cmdline.txt"
if [ ! -f "$CMDLINE" ]; then
    echo "ERREUR : $CMDLINE introuvable."
    exit 1
fi

echo "Sauvegarde de $CMDLINE → $CMDLINE.bak"
sudo cp "$CMDLINE" "$CMDLINE.bak"

# Nettoyer puis ajouter les options nécessaires
NEW_CMDLINE=$(cat "$CMDLINE" | \
    sed -e 's/console=tty[0-9]\+//g' \
        -e 's/quiet//g' \
        -e 's/loglevel=[0-9]\+//g' \
        -e 's/logo\.nologo//g' \
        -e 's/vt\.global_cursor_default=0//g' \
        -e 's/splash//g')

NEW_CMDLINE="console=tty3 quiet loglevel=0 logo.nologo vt.global_cursor_default=0 splash $NEW_CMDLINE"
NEW_CMDLINE=$(echo "$NEW_CMDLINE" | tr -s ' ')

echo "$NEW_CMDLINE" | sudo tee "$CMDLINE" > /dev/null
echo "→ $CMDLINE mis à jour."

# ----- 2. Installer Plymouth et thèmes -----
echo "Installation de plymouth et des thèmes…"
sudo apt update
sudo apt install -y plymouth plymouth-themes

# ----- 3. Activer le thème spinner -----
echo "Activation du splash spinner…"
sudo plymouth-set-default-theme spinner

# ----- 4. Patch du spinner pour texte custom -----
SPINNER_PATH="/usr/share/plymouth/themes/spinner"
SCRIPT_FILE="$SPINNER_PATH/spinner.script"
BACKUP_FILE="$SPINNER_PATH/spinner.script.bak"

if [ -f "$SCRIPT_FILE" ]; then
    # Sauvegarde si pas déjà fait
    if [ ! -f "$BACKUP_FILE" ]; then
        sudo cp "$SCRIPT_FILE" "$BACKUP_FILE"
    fi

    # Vérifier si notre texte est déjà présent
    if ! grep -q "YScreen by YGS" "$SCRIPT_FILE"; then
        # Injecter la variable après les définitions de couleurs
        sudo sed -i '/Window.SetBackgroundTopColor/ a \
my_message = "YScreen by YGS / Starting";\
' "$SCRIPT_FILE"

        # Injecter l'affichage du texte dans le handler principal du spinner
        sudo sed -i '/plymouth.SetBootProgressFunction/ a \
    # Affichage message custom\
    if my_message != ""\
        screen_width = Window.GetWidth();\
        screen_height = Window.GetHeight();\
        message_width = Plymouth.MeasureText(my_message);\
        Plymouth.DrawText(screen_width/2-message_width/2, screen_height/2+40, my_message);\
    end if\
' "$SCRIPT_FILE"

        echo "→ Texte personnalisé injecté dans le spinner."
    else
        echo "Le texte personnalisé est déjà présent dans le spinner."
    fi
else
    echo "Erreur : $SCRIPT_FILE introuvable, impossible de personnaliser le texte spinner."
fi

# ----- 5. Masquer le prompt login tty1 -----
echo "Masquage du prompt login sur tty1…"
sudo systemctl mask getty@tty1.service

# ----- 6. Mise à jour initramfs -----
echo "Mise à jour du splash Plymouth…"
sudo update-initramfs -u

echo ""
echo "=== Terminé ! ==="
echo "→ Redémarre le Raspberry Pi pour voir le résultat !"
echo "• Le démarrage sera propre, sans texte."
echo "• Splash spinner + 'YScreen by YGS / Starting'"
echo "• Pas de prompt login sur HDMI, ta vidéo pourra démarrer sans perturbation visuelle."
echo ""
echo "Pour revenir en arrière :"
echo " - Restaurer $CMDLINE à partir de $CMDLINE.bak"
echo " - sudo systemctl unmask getty@tty1.service"
