#!/bin/bash
#
# File: ygs-player.sh
# Location: /usr/local/bin/ygs-player.sh
# Version: 1.6.1
# Date: 2024-05-25
# Author: CreativeMind (ChatGPT)
# Description:
#   YGScreen HDMI Player (Meeting-ready) - mode interactif SSH
#   - default.mp4 instantané au boot (loop en bg), playlist Meeting ou offline
#   - Pan/scan, logging, menu SSH, debug avancé.
#
# Force écran noir sur tty1
setterm --background black --foreground black --clear all > /dev/tty1


MEDIA_DIR="/var/cache/ygscreen/medias"
DEFAULT="$MEDIA_DIR/default.mp4"
LOG_DIR="/var/log/ygs"
LOG_FILE="$LOG_DIR/player.log"
PLAYER_NAME="ygs-player.sh"
VERSION="1.6.1"

PANSCAN_OPTS="--fs --no-terminal --really-quiet --video-aspect-override=16:9 --panscan=1"
TMP_PLAYLIST="/tmp/ygscreen_playlist.m3u"
MEETING_PLAYLIST_URL="https://meeting.ygsoft.fr/api/device/playlist" # <--- Placeholder
CURL_TIMEOUT=5
SERVICE_NAME="ygscreen"

### LOGGING ###
log() {
    local msg="$1"
    local now
    now="$(date '+%Y-%m-%d %H:%M:%S')"
    sudo mkdir -p "$LOG_DIR" 2>/dev/null
    sudo touch "$LOG_FILE"
    sudo chmod 664 "$LOG_FILE"
    echo "[$now] $msg" | sudo tee -a "$LOG_FILE" >/dev/null
}

### PLAYLIST ###
fetch_playlist_from_meeting() {
    log "Tentative de téléchargement de la playlist Meeting : $MEETING_PLAYLIST_URL"
    HTTP_CODE=$(curl -sSL --max-time $CURL_TIMEOUT -w "%{http_code}" -o "$TMP_PLAYLIST" "$MEETING_PLAYLIST_URL")
    if [[ "$HTTP_CODE" =~ ^2 ]]; then
        log "Playlist Meeting récupérée avec succès ($HTTP_CODE)."
        return 0
    else
        log "Echec du téléchargement playlist Meeting (code $HTTP_CODE). Fallback local."
        rm -f "$TMP_PLAYLIST"
        return 1
    fi
}

generate_local_playlist() {
    log "Génération d'une playlist locale (offline mode)."
    > "$TMP_PLAYLIST"
    if [ -f "$DEFAULT" ]; then
        echo "$DEFAULT" >> "$TMP_PLAYLIST"
        log "Ajout (inconditionnel) en tête : $DEFAULT"
    fi
    mapfile -t ALL_VIDEOS < <(find "$MEDIA_DIR" -type f \( -iname '*.mp4' -o -iname '*.mkv' -o -iname '*.avi' -o -iname '*.webm' \) ! -name 'default.mp4' | sort)
    COUNT=0
    for VID in "${ALL_VIDEOS[@]}"; do
        [ -f "$VID" ] || continue
        echo "$VID" >> "$TMP_PLAYLIST"
        log "Ajout local: $VID"
        ((COUNT++))
        if (( COUNT % 3 == 0 )); then
            if [ -f "$DEFAULT" ]; then
                echo "$DEFAULT" >> "$TMP_PLAYLIST"
                log "Ajout de default.mp4 après $COUNT vidéos"
            fi
        fi
    done
    if [ ${#ALL_VIDEOS[@]} -eq 0 ] && [ -f "$DEFAULT" ]; then
        log "Aucune autre vidéo trouvée, fallback sur default.mp4"
        echo "$DEFAULT" >> "$TMP_PLAYLIST"
    elif [ ! -s "$TMP_PLAYLIST" ]; then
        log "Aucune vidéo disponible, playlist vide."
    fi
}

### MODE INTERACTIF ###
show_menu() {
    cat <<EOM

=========================================
 YGS-PLAYER $VERSION - MODE INTERACTIF
=========================================
restart      - Restart ygs-player (service)
reinstall    - Reinstall ygs-player systemd service
downPlaylist - Download playlist from meeting & restart service
clearCache   - Delete all subfolders in $MEDIA_DIR (except default.mp4)
downMedia    - (Re)download medias from meeting (placeholder)
next         - Play next media
previous     - Play previous media
help         - Show all commands
quit         - Quit interactive mode
=========================================
EOM
}

do_restart() {
    log "[INTERACTIF] Redémarrage du service $SERVICE_NAME..."
    sudo systemctl restart "$SERVICE_NAME"
    echo "Service $SERVICE_NAME redémarré."
}

do_reinstall() {
    log "[INTERACTIF] Réinstallation du service $SERVICE_NAME..."
    sudo systemctl disable "$SERVICE_NAME"
    sudo systemctl daemon-reload
    sudo systemctl enable "$SERVICE_NAME"
    sudo systemctl restart "$SERVICE_NAME"
    echo "Service $SERVICE_NAME réinstallé et relancé."
}

do_downPlaylist() {
    log "[INTERACTIF] Force redownload de la playlist Meeting..."
    if fetch_playlist_from_meeting; then
        sudo systemctl restart "$SERVICE_NAME"
        echo "Playlist Meeting rapatriée et service relancé."
    else
        echo "Erreur lors du téléchargement de la playlist Meeting."
    fi
}

do_clearCache() {
    log "[INTERACTIF] Suppression du cache média (sous-dossiers de $MEDIA_DIR)..."
    find "$MEDIA_DIR" -mindepth 1 -maxdepth 1 -type d -exec sudo rm -rf {} +
    find "$MEDIA_DIR" -mindepth 1 -maxdepth 1 -type f ! -name "default.mp4" -exec sudo rm -f {} +
    echo "Cache vidé, seul default.mp4 conservé."
}

do_downMedia() {
    log "[INTERACTIF] downMedia appelé (fonction à compléter plus tard Meeting)"
    echo "TODO: Download des médias Meeting non implémenté pour l'instant."
}

do_next() {
    log "[INTERACTIF] Demande next à mpv."
    pkill -USR1 mpv && echo "Commande next envoyée à mpv (si actif)."
}

do_previous() {
    log "[INTERACTIF] Demande previous à mpv."
    pkill -USR2 mpv && echo "Commande previous envoyée à mpv (si actif)."
}

is_interactive() {
    # --- DEBUG PATCH ---
    log "DEBUG: ENV - SSH_CONNECTION='$SSH_CONNECTION', INVOCATION_ID='$INVOCATION_ID', tty='$(tty 2>/dev/null)'"
    # SSH ? = interactif
    if [[ -n "$SSH_CONNECTION" ]]; then
        log "DEBUG: Mode interactif détecté (SSH_CONNECTION)"
        return 0
    fi
    # TTY != /dev/tty1 => interactif
    local TTY
    TTY=$(tty 2>/dev/null)
    log "DEBUG: tty=$TTY"
    if [[ "$TTY" != "/dev/tty1" && "$TTY" != "not a tty" ]]; then
        log "DEBUG: Mode interactif détecté (tty=$TTY)"
        return 0
    fi
    # Systemd INVOCATION_ID = mode service
    if [[ -n "$INVOCATION_ID" ]]; then
        log "DEBUG: Mode service détecté (INVOCATION_ID=$INVOCATION_ID)"
        return 1
    fi
    # Fallback
    log "DEBUG: Fallback mode service (aucun critère interactif)"
    return 1
}

### LANCEMENT ###
if [[ "$1" == "--help" ]]; then
    cat <<EOF
$PLAYER_NAME v$VERSION
Usage: $PLAYER_NAME [--help]
En service (autoplay HDMI), ou interactif si lancé en SSH/terminal.
EOF
    exit 0
fi

log "=== [$PLAYER_NAME] START v$VERSION ==="
log "Media folder: $MEDIA_DIR"
log "Default video: $DEFAULT"

if is_interactive; then
    log "DEBUG: Mode INTERACTIF sélectionné (menu SSH/terminal)"
    show_menu
    while true; do
        echo -n "YGS> "
        read -r cmd
        case "$cmd" in
            restart)    do_restart;;
            reinstall)  do_reinstall;;
            downPlaylist) do_downPlaylist;;
            clearCache) do_clearCache;;
            downMedia)  do_downMedia;;
            next)       do_next;;
            previous)   do_previous;;
            help)       show_menu;;
            quit|exit)  log "[INTERACTIF] Sortie du mode interactif"; exit 0;;
            *)          echo "Commande inconnue. Tapez 'help'."
        esac
    done
    exit 0
else
    log "DEBUG: Mode PLAYER (service) sélectionné"
fi

### MODE PLAYER (SERVICE) ###
while true; do
    if [ ! -d "$MEDIA_DIR" ]; then
        log "Dossier $MEDIA_DIR introuvable, attente 5s"
        sleep 5
        continue
    fi

    # --- Démarrage immédiat de default.mp4 en boucle (fond) ---
    DEFAULT_LOOP_PID=""
    if [ -f "$DEFAULT" ]; then
        log "Démarrage instantané de default.mp4 en boucle (attente playlist)..."
        mpv $PANSCAN_OPTS --loop=inf "$DEFAULT" &
        DEFAULT_LOOP_PID=$!
    fi

    # --- Récupération/Génération de la playlist ---
    if curl -s --head --request GET --max-time $CURL_TIMEOUT "https://meeting.ygsoft.fr" | grep "200 OK" > /dev/null; then
        if fetch_playlist_from_meeting; then
            log "Lecture playlist Meeting"
        else
            generate_local_playlist
            log "Lecture playlist locale"
        fi
    else
        log "Pas d'accès Meeting (offline), playlist locale"
        generate_local_playlist
    fi

    # --- Arrêt du loop default.mp4 dès que la playlist est prête ---
    if [ -n "$DEFAULT_LOOP_PID" ] && kill -0 "$DEFAULT_LOOP_PID" 2>/dev/null; then
        log "Arrêt de la boucle default.mp4 (PID $DEFAULT_LOOP_PID)"
        kill "$DEFAULT_LOOP_PID"
        wait "$DEFAULT_LOOP_PID" 2>/dev/null
    fi

    if [ ! -s "$TMP_PLAYLIST" ]; then
        log "Playlist vide, attente 5s"
        sleep 5
        continue
    fi

    log "Démarrage mpv (playlist: $TMP_PLAYLIST)"
    mpv $PANSCAN_OPTS --playlist="$TMP_PLAYLIST"
    log "mpv a quitté (nouvelle boucle dans 3s)"
    sleep 3
done
