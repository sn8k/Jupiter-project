#!/bin/bash

# Change et personnalise le splash sur RPi Debian 12 pour affichage texte custom

set -e

echo "== [YScreen] Splash personnalisé (thème script) =="

# 1. Active le thème script
sudo plymouth-set-default-theme script

# 2. Patch script.script
SCRIPT_FILE="/usr/share/plymouth/themes/script/script.script"
BACKUP_FILE="/usr/share/plymouth/themes/script/script.script.bak"

if [ -f "$SCRIPT_FILE" ]; then
    if [ ! -f "$BACKUP_FILE" ]; then
        sudo cp "$SCRIPT_FILE" "$BACKUP_FILE"
    fi

    # Ajoute la variable custom et force l'affichage
    sudo sed -i '/boot_message =/a my_message = "YScreen by YGS / Starting";' "$SCRIPT_FILE"
    # Remplace l'affichage du texte principal par notre message custom
    sudo sed -i 's/Plymouth.DrawText(screen_width\/2-message_width\/2, screen_height\/2, boot_message)/Plymouth.DrawText(screen_width\/2-message_width\/2, screen_height\/2, my_message)/g' "$SCRIPT_FILE"

    echo "→ Texte personnalisé injecté dans le splash script."
else
    echo "Erreur : script.script introuvable."
    exit 1
fi

# 3. Recharge l'initramfs
sudo update-initramfs -u

echo ""
echo "== Fini ! Redémarre pour voir le résultat. =="
