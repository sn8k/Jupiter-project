#!/bin/bash
MEDIA_DIR="/var/cache/YGScreen/medias"
DEFAULT="$MEDIA_DIR/default.mp4"

# Écran noir avant toute chose (assure le fond noir)
setterm --background black --foreground black --clear all > /dev/tty1

while true; do
    if [ -d "$MEDIA_DIR" ]; then
        SUBFOLDERS=$(find "$MEDIA_DIR" -mindepth 1 -type d)
        if [ -n "$SUBFOLDERS" ]; then
            for folder in $SUBFOLDERS; do
                for vid in "$folder"/*.{mp4,mkv,avi,webm}; do
                    [ -f "$vid" ] || continue
                    mpv --fs --no-terminal --really-quiet "$vid"
                done
            done
        else
            if [ -f "$DEFAULT" ]; then
                mpv --fs --no-terminal --loop=inf --really-quiet "$DEFAULT"
            else
                sleep 5
            fi
        fi
    else
        sleep 5
    fi
done
