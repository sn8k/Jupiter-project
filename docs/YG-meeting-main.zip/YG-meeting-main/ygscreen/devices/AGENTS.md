Ce dossier contient des fichiers qui sont a installer sur des devices.
Ils doivent etre configurés pour un usage distant.

ils ne sont pas destinés au serveur.
