<?php
// File: frontend/index.php
// Version: 1.1.0 (2025-06-24)
// Home – YGS-Player upload/playlist
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>YGScreen Uploader</title>
    <style>
      body { font-family:sans-serif;background:#232323;color:#fff;padding:2em;}
      .main { max-width:600px;margin:auto;background:#333;border-radius:1em;padding:2em; }
      label { display:block;margin:1em 0 .3em; }
      input,select { width:100%;padding:.5em; border-radius:6px;border:none;}
      button { padding:.6em 2em; border-radius:8px; border:none; margin-top:1em; }
      .playlist { margin-top:2em; }
      video { width:100%; margin-top:1em; }
    </style>
</head>
<body>
<div class="main">
    <h1>YGScreen – Upload Vidéo</h1>
    <form id="uploadForm" enctype="multipart/form-data" method="post" action="upload.php">
        <label>Device</label>
        <select name="device_key" id="device_key"></select>

        <label>Mode d'affichage</label>
        <select name="mode">
          <option value="landscape">Paysage</option>
          <option value="portrait">Portrait</option>
        </select>

        <label>Ordre</label>
        <input name="order" type="number" min="1" max="999" value="1" />

        <label>Vidéo</label>
        <input type="file" name="video" accept="video/*" required />

        <button type="submit">Uploader</button>
    </form>
    <div id="preview" style="display:none;">
      <label>Preview :</label>
      <video controls id="videoPreview"></video>
    </div>
    <div class="playlist" id="playlistDiv"></div>
    <button onclick="clearCache()" style="background:#e33;color:#fff;">Effacer le cache du device</button>
</div>

<script>
  // Fetch devices pour le menu déroulant depuis l'API
  fetch('/api/devices')
    .then(r => r.json())
    .then(d => {
      let sel = document.getElementById('device_key');
      (d.devices || []).forEach(dev => {
        let opt = document.createElement('option');
        opt.value = dev.device_key;
        opt.innerText = (dev.device_name || dev.device_key) + ' (' + dev.device_key + ')';
        sel.appendChild(opt);
      });
      if (sel.value) loadPlaylist(sel.value);
    });

  // Preview
  document.querySelector('input[type="file"]').onchange = function(e){
    let f = e.target.files[0];
    if(f){
      let v = document.getElementById('videoPreview');
      v.src = URL.createObjectURL(f);
      document.getElementById('preview').style.display='block';
    }
  };

  function loadPlaylist(dev){
    fetch('playlist.php?device='+dev)
      .then(r=>r.text())
      .then(html=>{ document.getElementById('playlistDiv').innerHTML=html; });
  }

  document.getElementById('device_key').onchange = function(){
    loadPlaylist(this.value);
  };

  function clearCache(){
    let dev = document.getElementById('device_key').value;
    fetch('clear_cache.php?device='+dev).then(()=>alert("Demande d'effacement envoyée !"));
  }
</script>
</body>
</html>
