<?php
// File: frontend/playlist.php
// Version: 1.1.0 (2025-06-24)

$device = $_GET['device'] ?? '';
if ($device === '') {
    echo '<p>Aucun device sélectionné.</p>';
    exit;
}

$ch = curl_init('http://localhost/api/player/playlist/' . urlencode($device));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$res = curl_exec($ch);
curl_close($ch);

if ($res === false) {
    echo '<p>Erreur lors de la récupération de la playlist.</p>';
    exit;
}

$playlist = json_decode($res, true);
if (!is_array($playlist)) {
    echo '<p>Réponse invalide du backend.</p>';
    exit;
}

echo "<h2>Playlist du device $device</h2><ul>";
foreach ($playlist as $v) {
    $order = $v['order'] ?? '';
    $title = $v['title'] ?? '';
    $dir   = $v['dir'] ?? '';
    $file  = $v['file'] ?? '';
    echo "<li>[$order] $title ($dir/$file)</li>";
}
echo '</ul>';
?>
