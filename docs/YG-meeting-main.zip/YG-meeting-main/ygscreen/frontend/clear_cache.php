<?php
// File: frontend/clear_cache.php
// Version: 1.1.0 (2025-06-24)

$device = $_GET['device'] ?? '';
if ($device === '') {
    echo 'Aucun device fourni';
    exit;
}

$ch = curl_init('http://localhost/api/player/clear-cache/' . urlencode($device));
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$res = curl_exec($ch);
if ($res === false) {
    echo 'Erreur API: ' . curl_error($ch);
} else {
    echo $res;
}
curl_close($ch);
?>
