<?php
// File: frontend/upload.php
// Version: 1.1.0 (2025-06-24)

// Uploade réellement la vidéo vers l'API backend via cURL
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $device_key = $_POST['device_key'];
    $mode = $_POST['mode'];
    $order = $_POST['order'];
    $file = $_FILES['video'];

    $postFields = [
        'device_key' => $device_key,
        'mode'       => $mode,
        'order'      => $order,
        'video'      => new CURLFile($file['tmp_name'], $file['type'], $file['name'])
    ];

    $ch = curl_init('http://localhost:8500/api/player/upload');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    if ($response === false) {
        echo 'Erreur API: ' . curl_error($ch);
    } else {
        echo $response;
    }
    curl_close($ch);
    exit;
}
?>
