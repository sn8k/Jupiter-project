# SPECS.md

Version: 1.0.1 (2025-06-24)

## 🗂️ Arborescence de stockage device

- **Root** : `/var/cache/ygscreen/medias/{device_hash}/`
- **Partitionnement** : {device_hash} = 12+ caractères hash (sha1/sha256 ou UUID)
- **Sous-dossiers** : 2 caractères (premiers du hash du média)
- **Fichiers vidéos** : hashés (20-32 caractères), **pas d’extension**
- **playlist.json** : format JSON, mapping playlist

### Exemple
/var/cache/ygscreen/medias/af3c1e7b9a6c/
├── playlist.json
├── default
├── 0a/
│ ├── 4dff3b2ad934fb0e7f66ba12a84d97c230a4
│ └── ...
├── 1f/
│ └── 73cde19fabb203d9e2a1834b87ed22f37628
└── ...


---

## 🎬 **Schéma playlist.json**


{
  "mode": "landscape", // ou "portrait"
  "playlist": [
    {
      "dir": "0a",
      "file": "4dff3b2ad934fb0e7f66ba12a84d97c230a4",
      "order": 1,
      "title": "Bienvenue"
    },
    {
      "dir": "1f",
      "file": "73cde19fabb203d9e2a1834b87ed22f37628",
      "order": 2,
      "title": "Promo du mois"
    }
  ]
}
Un seul mode par device

Ordre : respecté par l’agent player

title : pour affichage éventuel

🛰️ API endpoints attendus
POST /api/player/upload

Payload : fichier vidéo, device_key, mode, ordre

Retourne : status, hash/fichier généré

GET /api/devices

Liste des devices disponibles (Meeting)

GET /api/player/playlist/{device_key}

Playlist actuelle (JSON) pour un device

GET /api/player/media/{device_key}/{dir}/{file}

Pour download individuel des médias

POST /api/player/clear-cache/{device_key}

(Optionnel) déclencheur reset cache côté agent

💾 Workflow synchronisation SD Saver
Lire playlist.json (présente ou récupérée via API)

Lister tous les fichiers présents sur disque (hors default/playlist.json)

Calculer :

Fichiers à télécharger : absents du disque mais listés dans playlist

Fichiers à supprimer : présents sur disque mais non listés dans playlist

Rien à faire : pour les fichiers déjà présents et référencés

Télécharger d’abord, supprimer ensuite

Purge globale = clear cache explicite uniquement

🚦 Clear cache
Supprime tout le contenu device_hash sauf playlist.json et default

Utilisé pour réinitialiser totalement le device

🦾 Best practices / TODO
Logs sur tmpfs ou rotation rapide pour SD

Pas d’extension vidéo ou dossier

Tout backup, purge ou migration : device par device, jamais global

RGPD/Privacy : purge d’un device = suppression de son dossier

Jamais de swap ou tempfiles inutiles sur la SD



---

---

# 🗂️ **Arborescence de base du projet**

/ygscreen/
    agents/
        ygs-player.sh      # agent bash ou node, lecture/sync
        ygs-player.js       # agent node, alternative avancée
    backend/
        api.js             # express backend, conversion, upload
        ffmpeg_worker.js   # workers pour la conversion vidéo
        ...
    frontend/
        index.php          # upload, playlist, clear cache, etc.
        ...
    docs/
        README.md
        AGENTS.md
        SPECS.md
    tests/
        ...

✅ Workflow de dev conseillé
Installer le backend (Node + dépendances)

Préparer la structure de stockage (voir specs)

Déployer le frontend PHP dans /var/www/meeting-backend/ygscreen

Écrire l’agent player pour RPi (bash/node)

Test synchro/playlist sur 1 device

Ajouter plus de devices/playlists, tester scalabilité

Valider logs/rotation et purge RGPD

(Pro) Itérer sur l’UI/UX, sécuriser l’API, automatiser la mise à jour des playlists

🚩 Attention
NE PAS utiliser de noms ou extensions reconnaissables sur la SD (hash only !)

NE PAS purger ou réécrire massivement sans raison

SD = ressource précieuse, logs en RAM, synchro par diff

API RESTful, pas de logique en dur côté frontend

