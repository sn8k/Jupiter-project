# AGENTS.md

## 🎥 Agents et Scripts attendus

### 1. Agent “player” device (Bash/Node, sur RPi3/4)

- **Rôle** : Synchro intelligente de la playlist et lecture vidéo (mpv)
- **Fonctions** :
    - Fetch playlist.json
    - Download fichiers manquants, supprimer les obsolètes (voir SD Saver)
    - Jouer dans l’ordre la playlist (mpv, mode fullscreen)
    - Réagir à la commande “clear cache”
- **Localisation** : `/usr/local/bin/ygs-player.sh` ou `/usr/local/bin/ygs-player.js`
- **Logging** : léger, rotation courte, ou tmpfs

### 2. Backend Conversion/Sync (Node.js)

- **Rôle** : Recevoir les uploads, convertir en mp4 adapté, générer/mettre à jour playlist.json device
- **Fonctions** :
    - Upload vidéo (API REST, voir SPECS)
    - Conversion via ffmpeg (mode landscape/portrait selon device)
    - Génération du mapping hash pour fichiers/dossiers
    - Stockage par device (`/var/meeting/ygscreen`)
    - Endpoints :
        - `POST /api/player/upload`
        - `GET /api/player/playlist/{device_key}`
        - `GET /api/player/media/{device_key}/{dir}/{file}`

### 3. Frontend PHP (temporaire)

- **Rôle** : UI simple pour uploader, visualiser, ordonner playlist, clear cache, preview
- **Fonctions** :
    - Form upload vidéo + choix device + mode
    - Liste des devices (via API Meeting)
    - Affichage et modification playlist.json par device
    - Preview vidéo
    - Bouton “effacer le cache” (commande backend)

### 4. Service “clear cache”

- **Rôle** : Sur ordre, efface tout le dossier medias du device (hors default/playlist)
- **Fonction** : Endpoint POST ou flag dans playlist
- **Action agent** : purge, puis resynchro

---

## 📁 **Autres scripts possibles (à discuter)**

- Agent de monitoring (logs, statut mpv, crash watchdog)
- Outil batch d’audit/migration (bulk import/export de playlists)
