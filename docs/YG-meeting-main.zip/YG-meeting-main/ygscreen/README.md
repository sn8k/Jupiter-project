# YGS-Player – Starter Kit

Version: 1.0.6 (2025-06-25)

Projet : Plateforme d’affichage dynamique multi-devices (RPi3/4, etc.)  
Stack : Backend Node.js, Frontend PHP (temporaire), Agent device Bash/Node  
Auteur : CreativeMind + Team Meeting
Date : 2025-06-25

---

## 🧩 **Résumé**

YGS-Player permet :
- L’upload et la conversion de vidéos pour affichage sur un parc de devices distants.
- Une playlist personnalisée et sécurisée (hash, obfuscation) par device.
- La synchronisation SD-card friendly, pensée pour 15 000 devices et plus.

---

## 📦 **Structure du projet**

/var/www/meeting-backend/ygscreen/ # Frontend PHP (upload, playlist, UI)
├── index.php
├── upload.php
├── playlist.php
└── ...
/var/meeting/ygscreen/ # Backend (stockage + conversion)
└── ...
/var/cache/ygscreen/medias/{device_hash}/ # Sur le device (voir SPECS)
├── playlist.json
├── default
├── 0a/
│ ├── 4dff3b2ad934fb0e7f66ba12a84d97c230a4
│ └── ...
└── ...


---

## 🚀 **Pour démarrer**

1. Lire les specs dans `SPECS.md`
2. Rôles/attentes agents/scripts dans `AGENTS.md`
3. Conventions/Best practices dans le README (voir plus bas)
4. (Dev) Installer les dépendances Node.js puis démarrer le backend :
   ```bash
   cd backend && npm install && npm start
   ```
   Ensuite lancer le frontend PHP et un agent local pour test
5. (Ops) Utiliser `tools/setup-files/install_ygscreen_backend.sh` pour déployer
   le backend sur le serveur. Le script installe Node.js et ffmpeg si nécessaire
   puis configure le service systemd.
6. (Ops) Préparer `/var/meeting/ygscreen` côté serveur, `/var/cache/ygscreen/medias/{device_hash}` côté device
7. Les opérations du backend sont consignées dans
   `/var/meeting/api/logs/ygscreen_backend.log` (paramètre `log_file` de `config.json`)


## 🔄 Workflow complet

1. L'utilisateur envoie une vidéo via **POST /api/player/upload**.
2. Le backend convertit le fichier et met à jour `playlist.json`.
3. Le player récupère la playlist via **GET /api/player/playlist/{device_key}**.
4. Pour chaque élément, il télécharge le média avec **GET /api/player/media/{device_key}/{dir}/{file}**.
5. Si besoin, **POST /api/player/clear-cache/{device_key}** purge le cache puis relance la synchronisation.

---

## 👥 **Contacts**

- PO/Tech Lead : [YG]
- Product Design : [YG]
- DevOps/Backend : [YG]
- QA : [YG]
- Slack/Matrix : #meeting-dev

---

## 🛠️ **Conventions**

- Nomination : voir SPECS.md (hashs, pas d’extensions, partitionnement)
- Tests unitaires : dès la v1 (voir dossier /tests/)
- Commit convention : Conventional Commits (feat:, fix:, docs:, chore:)
- Documentation : toute nouvelle fonctionnalité = une PR = une doc associée.
- Versionning : chaque fichier script/agent a son propre numéro de version en en-tête.

---

## 🎯 **Astuces et rappels**

- Les logs volumineux sur SD, c’est non (RAMdisk/tmpfs !)
- “clear cache” ne s’utilise que pour un reset complet, sinon synchro fine par diff.
- Tout fichier sans playlist.json est orphelin, purgeable sans danger.
- Pas d’extension sur les fichiers/dossiers médias = sécurité + obfuscation.

---

NOTES IMPORTANTES :
LES SCRIPTS CONTENUS DANS LES DOSSIERS PROTOTYPES ET DEVICES SONT DESTINéS A UNE INSTALLATION SUR DEVICE, ET NON SUR LE SERVEUR !
Si un script est a produire pour les devices dans ce dossier, il doit avoir :
- une documentation
- un installeur/desinstalleur/REinstalleur.
- etre loggué.


## 📢 **À faire / TODO**

- Ajout d’une interface pro après validation MVP.
- Sécurisation API.
- Gestion fine des quotas device.
