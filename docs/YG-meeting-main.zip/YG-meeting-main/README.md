# YG-meeting


Version: 1.0.33 (2025-07-21)


YG-meeting est une plateforme **API‑first** destinée à simplifier l’accès à des appareils situés derrière un NAT. Toutes les opérations (authentification, ouverture de tunnel, logs, droits utilisateur) transitent par un backend REST écrit en PHP. L’infrastructure de tunnel repose sur des utilitaires Node.js (`ygs-agent`, `ygs-proxy`) pilotés exclusivement via l’API.

## Sommaire

1. [Structure du dépôt](#structure-du-d%C3%A9p%C3%B4t)
2. [Mise en route rapide](#mise-en-route-rapide)
3. [Exemples d’utilisation](#exemples-dutilisation)
4. [Configuration](#configuration)
5. [Outils fournis](#outils-fournis)
6. [Journaux et LogCenter](#journaux-et-logcenter)
7. [Documentation](#documentation-suppl%C3%A9mentaire)
8. [Changelog](changelog.md)

## Structure du dépôt

- **/api** – Contrôleurs PHP et point d’entrée REST.
- **/admin** – Interface Web pour gérer les appareils, les tunnels et consulter les journaux.
- **/reverse_tunnel** – Code des outils `ygs-agent`, `ygs-proxy` et `ntp-server` (Node.js) permettant la mise en place du tunnel inversé et la synchronisation horaire.
- **/docs** – Documentation supplémentaire dont [Encyclopedie.md](docs/Encyclopedie.md) (référence complète de l’API) et les guides d’installation.
- **/tools** – Scripts utiles, notamment `api_diagnose.sh` pour tester automatiquement l’API.
- **/resident_tools** – Scripts destinés à être déployés sur les machines hôtes (forceCommand, synchronisation de clés SSH).
- **/medias_library** – Bibliothèque par défaut pour les médias à afficher sur les appareils.

## Mise en route rapide

### Prérequis

- PHP ≥ 8 avec les extensions courantes
- MySQL ou MariaDB
- Node.js ≥ 20 pour les agents de tunnel

### Installation de la base de données

Suivez [docs/mysql_setup.md](docs/mysql_setup.md) pour installer MySQL et créer la base `devices_db`. Une fois la base en place, initialisez le schéma :

```bash
php admin/db_check.php
```

### Lancement du backend

Placez le dépôt dans votre répertoire web (par exemple `webroot/`) et exposez `index.php`. Renseignez les informations de connexion à la base dans `api/config.php`.

### Mise en place du tunnel inversé

Les binaires Node se trouvent dans `reverse_tunnel`. Lancez le proxy sur une machine publique puis l’agent sur chaque appareil :

```bash
ygs-proxy        # sur le serveur/VPS
ygs-agent        # sur l’appareil
```

Pour activer les journaux détaillés, lancez le proxy avec `YGS_DEBUG=1` :

```bash
YGS_DEBUG=1 ygs-proxy            # ou : sudo -E YGS_DEBUG=1 ygs-proxy
```

Vous pouvez préciser le chemin de l’interface PHP via `YGS_PROXY_UI` :
```bash
export YGS_PROXY_UI=/var/www/meeting/admin/proxy_ui.php
```
Des unités systemd prêtes à l’emploi sont décrites dans [reverse_tunnel/README.md](reverse_tunnel/README.md).

### Serveur NTP

Le dépôt propose également un petit serveur NTP pour garder vos appareils à l'heure.

```bash
sudo ./tools/setup-files/install_ntp_server.sh
```

Pour arrêter et supprimer le service :

```bash
sudo ./tools/setup-files/uninstall_ntp_server.sh
```
### Client NTP

Installez `ygs-ntpclient` sur vos devices pour maintenir l'horloge a jour :
```bash
sudo ./tools/setup-files/install_ygs_ntpclient.sh
```
Pour le retirer :
```bash
sudo ./tools/setup-files/uninstall_ygs_ntpclient.sh
```

### Affichage dynamique (YGScreen)

YGScreen est le module d'affichage dynamique de Meeting. Il permet l'upload de
vidéos et la synchronisation d'une playlist sur vos players distants. Pour la
documentation complète et les scripts d'installation, consultez
[ygscreen/README.md](ygscreen/README.md).

### Charger sa clé avec Pageant (Windows)

1. Demandez à l'administrateur d'ajouter votre clé publique dans **User Manager** (`admin/user_manager.php`).
2. Convertissez votre clé privée au format `.ppk` à l'aide de *PuTTYgen* si besoin.
3. Lancez **Pageant** (fourni avec PuTTY) puis importez votre fichier `.ppk`.
4. Tant que Pageant reste actif, toutes les commandes `ssh`, `http`, `vnc` ou `scp` utiliseront cette clé automatiquement.


## Exemples d’utilisation

Une fois le tunnel en place, toutes les commandes passent par le serveur Meeting :

```bash
# Connexion SSH sans mot de passe
ssh <devicekey>@meeting.ygsoft.fr

# Relais HTTP (ouvre l’interface web de l’appareil)
http <devicekey>
# → Meeting renvoie une URL du type http://meeting.ygsoft.fr:9053

# Accès VNC
vnc <devicekey>

# Tunneler un port arbitraire
relay <devicekey> <port>
# → Si <port> est omis, le script le demandera

# Transfert de fichiers (SCP)
scp <devicekey>
# → Meeting fournit la commande complète avec le port alloué
```

## Configuration

Le fichier `api/config.php` contient les paramètres MySQL et divers secrets. Les agents créent automatiquement `reverse_tunnel/config.json` lors du premier lancement ; on peut y définir l’hôte du proxy, le jeton et l’intervalle de rafraîchissement.

Pour la production, modifiez impérativement le jeton partagé et, si besoin, activez l’authentification Basic dans l’interface web de l’agent/proxy (`uiUser`/`uiPass`).

Les variables d'environnement suivantes contrôlent le module **Distrib Builder** :

- `BUILDER_STORAGE_ROOT` : répertoire où sont stockés les fichiers temporaires et publiés.
- `BUILDER_LOGFILE` : chemin du journal des opérations du builder.
- `BUILDER_ALLOWED_EXTENSIONS` : extensions autorisées pour l'upload (séparées par des virgules).
- `BUILDER_MAX_UPLOAD_SIZE` : taille maximale d'un fichier téléversé en octets.
- `BUILDER_API_TOKEN` : jeton d'accès pour l'API du builder.

Vous pouvez les définir via un fichier `.env` placé à la racine ou à l'aide de commandes `export` :

```bash
export BUILDER_STORAGE_ROOT=/var/meeting/builder
export BUILDER_LOGFILE=/var/meeting/api/logs/builder_api.log
export BUILDER_ALLOWED_EXTENSIONS=tar.gz,zip,json,txt,png
export BUILDER_MAX_UPLOAD_SIZE=10485760
export BUILDER_API_TOKEN=REPLACE_ME
```

## Outils fournis

- `tools/api_diagnose.sh` : interroge tous les endpoints listés dans `docs/Encyclopedie.md` et génère un rapport JSON.
- `tools/setup-files/regen_meeting_sshkey.sh` : (re)génère la paire de clés SSH « meeting » et copie la clé publique sur le serveur.

- `tools/setup-files/install_proxy.sh` : installe `ygs-proxy` et crée le service systemd associé.
- `tools/setup-files/uninstall_proxy.sh` : supprime le binaire et le service `ygs-proxy`.

- `tools/setup-files/install_ygs_agent.sh` : installe `ygs-agent`, s'assure que Node.js ≥ 20 et `openssh-client` sont présents (les erreurs apt sont ignorées) puis crée le service systemd associé.
- `tools/setup-files/uninstall_ygs_agent.sh` : supprime l'agent et nettoie le service systemd.
- `tools/setup-files/install_ntp_server.sh` : installe `ntp-server` et crée le service systemd associé.
- `tools/setup-files/uninstall_ntp_server.sh` : supprime le binaire et le service `ntp-server`.

- `tools/setup-files/install_ygs_ntpclient.sh` : installe `ygs-ntpclient` et cree le service systemd associe.
- `tools/setup-files/uninstall_ygs_ntpclient.sh` : supprime le binaire et le service `ygs-ntpclient`.
- `tools/device_setup.sh` : assistant interactif pour configurer un device (serial, token). Détecte une installation existante, peut réutiliser les infos, installe automatiquement `curl` et `jq`, ajoute le dépôt apt (les erreurs sont ignorées), consomme un token, installe `ygs-agent`, récupère puis envoie les clés SSH, renomme le hostname, démarre le service et se relance automatiquement avec “sudo” si besoin.

  Détecte une installation existante, propose la réinstallation avec reprise des
  infos,
  installe `curl` et `jq`, déclare la clé publique locale avant l'installation,
  ajoute la clé publique Meeting à `authorized_keys`, génère `config.json` juste
  après vérification du token,
  affiche un logo YGSoft coloré en guise de bannière,
  ajoute le dépôt apt (erreurs ignorées), installe `ygs-agent`,
  récupère les clés SSH du serveur (l'envoi est actuellement désactivé),
  renomme le hostname, démarre le service et se relance automatiquement avec “sudo” si besoin.


- `tools/setup_environment.sh` : installe PHP et Node.js puis active uniquement le service `ygs-proxy`.

- `tools/setup-files/install_distrib_builder.sh` : installe le frontend Distrib Builder et prépare les dossiers nécessaires.
- `tools/setup-files/uninstall_distrib_builder.sh` : supprime la build et nettoie les dossiers du module.


- Scripts de maintenance dans `resident_tools` pour forcer la commande SSH et synchroniser les clés. `forceCommand.sh` accepte désormais l'option `--config` (ou la variable `FORCECOMMAND_CONFIG`) pour spécifier un fichier de configuration alternatif.

## Journaux et LogCenter

Tous les fichiers de log se trouvent désormais dans le répertoire `$MEETING_DATA_ROOT/api/logs/` (par défaut `/var/meeting/api/logs/`) et sont automatiquement listés dans l’interface **LogCenter** (`admin/log_center.php`).
Le dossier est créé lors de l’exécution du script `tools/log_create.sh` et contient notamment `backend_api.log` où chaque requête est enregistrée.
Utilisez LogCenter pour lire, télécharger ou exporter ces journaux.

## Documentation supplémentaire

La référence complète des endpoints ainsi que les principes de sécurité se trouvent dans [docs/Encyclopedie.md](docs/Encyclopedie.md). Ce document est indispensable pour développer ou déployer de nouveaux services autour de l’API Meeting.

- Une vue d'ensemble du depot est disponible dans [docs/structure_globale.md](docs/structure_globale.md).
- Pour réinstaller complètement le serveur, consultez [docs/server_reinstall.md](docs/server_reinstall.md).
- Pour l'utilitaire SSH interactif, consultez [docs/forcecommand.md](docs/forcecommand.md).

## Tests et intégration continue

Une suite Jest est disponible dans le dossier `tests/` afin de vérifier que certains scripts
et endpoints répondent correctement. Les tests sont lancés automatiquement sur GitHub Actions
à chaque `push`.

## Licence

Ce projet est distribué sous la **YG Proprietary License**. Toute redistribution ou modification est interdite sans autorisation écrite de YanG Soft. Le texte complet se trouve dans le fichier [LICENSE](LICENSE).

