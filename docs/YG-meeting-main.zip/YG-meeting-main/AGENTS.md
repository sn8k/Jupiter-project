# AGENTS.md  
*Meeting — Tunnel System, User Experience & API-Centric Architecture*  
*Version: 2.4 (2025-06-24)*

---

## Project Philosophy

Meeting is **API-first**:  
All user actions, device management, tunnels, access, logging, and security flow through the REST backend.  
The reverse-tunnel infrastructure is invisible and orchestrated entirely via the backend.

**The agent/proxy binaries are simple workers, controlled and configured by the backend API.**

---

## User Experience (as designed)

**For the end user, Meeting is a secure, seamless gateway to devices. All commands are simple and unified:**

```shell
# SSH access (no password, no manual port or NAT config)
ssh <devicekey>@meeting.ygsoft.fr

# HTTP relay (instant link to device web UI)
http <devicekey>
# → Meeting prints a URL to open in your browser: http://meeting.ygsoft.fr:9053

# VNC relay (full GUI)
vnc <devicekey>

# Relay custom port (for advanced users)
relay <devicekey> <port>
# → if <port> is missing : Meeting asks: "Which port to relay?" > instantly creates the tunnel

# SCP relay (for file transfer — WinSCP etc.)
scp <devicekey>
# → Meeting prints a link: scp -P 9054 user@meeting.ygsoft.fr:/remote/path .

No password or approval prompt is required.

No direct exposure of device IPs or ports.

All actions are logged and audited server-side.

User only needs the device key (or alias).

Technical Workflow (high-level)
User runs a command (ssh/http/vnc/relay/scp with a <devicekey>)

Backend API validates the device, authorization, and user rights.

Backend orchestrates the tunnel via the proxy/agent infrastructure.

If a tunnel exists: returns info instantly.

If not: instructs the agent via the tunnel protocol to create one, waits (or polls) for readiness.

User is redirected or connected through the meeting server (no direct device access, everything flows via Meeting).

Logging, metrics, authorization, and security are enforced and recorded centrally by the backend.

Architecture Schema
scss
Copier
Modifier
┌────────────┐     (ssh/http/vnc/relay/scp)    ┌────────────┐
│    USER    │ ───────────────────────────────►│  MEETING   │
│ (CLI/API)  │                                │  API + UI  │
└────────────┘                                └─────┬──────┘
                                                    │
     ◀──────────────  Secure tunnel  ───────────────┘
                (agent/proxy workers: internal only)
                                                    │
                                          ┌─────────▼─────────┐
                                          │  DEVICE(S)       │
                                          │ (behind NAT)     │
                                          └──────────────────┘
API-centric: All logic (auth, right, logs, mapping, link gen) is enforced via the Meeting backend.

Tunnel workers (agent/proxy): Only execute orders, never decide anything, and expose nothing directly.

No open ports on devices; no user credentials leak.

API: The Brain of Meeting
Everything is an API call — all flows are defined and controlled by documented endpoints.
See Encyclopedie.md for full endpoint list and expected responses.

Example: Opening an SSH tunnel
User: ssh <devicekey>@meeting.ygsoft.fr

Backend:

Validates device status and authorization

POST /api/devices/{device_key}/service with { "service": "ssh" }

If tunnel exists: returns { "port": 9051, "url": "ssh -p 9051 ..." }

If not: marks as pending, triggers agent, waits for readiness, then returns info.

User is transparently connected to the right tunnel, with all logs/metrics saved.

Same flow applies to http, vnc, relay, scp… with adapted payload and responses.

Tunnel Worker: What the Agent/Proxy Actually Does
Maintains a persistent TCP connection to the public proxy (agent → proxy)

Executes tunnel open/close requests from the API backend

Never exposes device services by default, only on-demand and only for authorized users

Sends regular heartbeats, status, and logs to the API

Local configuration (token, endpoint, interval) is managed via config.json and the Web UI

All authorization/permission checks happen in the backend, not in the agent/proxy

Security Rules
All tokens and credentials are server-side, never hardcoded in the agent

Backend logs every action, link, and tunnel (for audit/compliance)

Every device has unique keys and tokens

Proxies and agents do not listen on public ports except for the control/UI ports, and those are protected

All communication can be wrapped in TLS or run behind VPN for extra security

Summary / Mental Model
The REST API is the brain, and the only authority.

The agent/proxy stack is the muscle — executes, but never decides or authorizes.

Users interact only with the backend, never directly with the agent/proxy.

The tunnel is just plumbing — all access control, mapping, and auditing is API-driven.

Developer Onboarding Checklist
Always start by reading Encyclopedie.md

All device/tunnel/authorization/metrics flows are defined as REST endpoints

CLI/UX flows (ssh, http, vnc, relay, scp) are all routed via the API, not by manipulating the agent directly

Any new service = new API endpoint, then simple relay

When in doubt: the API wins (never patch agent/proxy logic without first defining the API flow!)

Files & References
Encyclopedie.md — API reference & workflows

ygs-agent.js, proxy.js — agent/proxy code (for infra only)

config.json — agent config (autogenerated)

README.md — systemd, install, and quickstart (for infra)

package.json — dependencies, if any

- [`/api/`](./api/) — PHP backend: all main controllers (Device, Tunnel, Logs, Availability, Flash, SSH Keys, Status, Metrics, etc.)
  - Exemples :  
    - `DeviceController.php`  
    - `TunnelController.php`  
    - `DeviceLogsController.php`  
    - `DeviceAvailabilityController.php`  
    - `DeviceRelationController.php`  
    - `SshKeysController.php`  
    - `ForceCommandController.php`  
    - `StatusController.php`  
    - `MetricsController.php`  
    - `FlashController.php`
- [`/admin/`](./admin/) — Admin panel (UI): interfaces for device/tunnel management, live monitoring, audit, and batch ops.
- [`config.php`](./config.php) — Main backend configuration (DB, security, ports, tokens, etc.)
- [`config.json`](./config.json) — Agent-side config (autogenerated, local only)
- [`ygs-agent.js`](./ygs-agent.js), [`proxy.js`](./proxy.js) — Node.js infra code (for tunnel worker logic)
- [`README.md`](./README.md) — Install, deployment, and systemd/service setup (for infra)
- [`package.json`](./package.json), [`package-lock.json`](./package-lock.json) — Node.js dependencies (infra)
- [`Encyclopedie.md`](./Encyclopedie.md) — API reference & all workflows (must-read for all devs)
- [`index.php`](./index.php) — Main HTTP entrypoint for backend (if present)
```
## Other Key Modules
- **Distrib Builder** (`distrib-builder-frontend/` + `builder_storage/`): assists in packaging and publishing firmware or assets. Uses React for the wizard and stores archives under `builder_storage`.
- **Device Designer** (`admin/device_designer.php`): web UI to create, edit, fork and merge device types. Relies on the API for CRUD operations.
- **LogCenter** (`admin/log_center.php`): centralized view over everything in `$MEETING_DATA_ROOT/api/logs/`.
- **NTP Server** (`reverse_tunnel/server/ntp-server.js`): Node.js service for time synchronization of devices.
- **YGScreen / Digital Signage** (`ygscreen/`): gestion des playlists vidéo. Endpoints `POST /api/player/upload`, `GET /api/player/playlist/{device_key}`, `GET /api/player/media/{device_key}/{dir}/{file}`, `POST /api/player/clear-cache/{device_key}`.


## IMPORTANT 
* mets a jour les numeros de version des fichiers à chaque edition.
* toujours repondre en francais, coder en anglais.
* si la base SQL doit etre modifiée ou mise a jour, le fichier /admin/db_check.php devra etre mis a jour.
* si des nouveaux dossiers ou fichiers contenant des données volatiles doivent etre créés, /tools/log_create.sh devra etre mis a jour.
* toujours mettre la date réèlle d'edition dans la nomenclature des fichiers.
* Toujours mettre a jour changelog.md
* Dans changelog, toujours presenter par Date du jour / changements. Les dates ne doivent pas etre dupliquées et les changements doivent completer le changelog du jour.
* si une logique doit etre radicalement modifiée, ne pas oublier de mettre a jour agents.md et les differentes documentations.
* si un endpoint doit etre modifié, ajouté ou supprimé, le fichier encyclopedie.md doit obligatoirement etre mis a jour.
* tous les fichiers php doivent afficher leur version actuelle (excepté links.php)
* le fichier /admin/links.php doit etre mis a jour en cas d'ajout d'une page admin.
* chaque script doit etre fourni avec un installateur/desinstallateur qui devra toujours etre a jour, si il ne peut pas etre directement integré au script via un argument --install et --remove.
* des instructions de reinstallation complete du serveur doivent etre tenu a jour.
* PRIMORDIAL : LE FICHIER LOG_CREATE.SH N'EST DESTINé QU'AU SERVEUR, ET NE DOIT PAS ETRE UTILISé SUR LES DEVICES.
* SI UN EQUIVALENT DE LOG_CREATE.SH POUR LES DEVICES EST NECESSAIRE, UTILISER LE FICHIER LOG_CREATE_DEVICE.SH (le creer si absent)
* en cas de tache sur une version destinée a windows, ne pas prendre en compte log_create.sh

**Note** :  
Tout nouveau dev doit commencer par explorer `/api/` (les contrôleurs), `/admin/` (gestion), et lire `Encyclopedie.md`.  
La logique métier, la sécurité, l’audit, l’autorisation : **tout est là**.  
Les agents/proxy sont de simples exécutants : jamais d’accès direct, tout passe par `/api/` !

---



Changelog
2025-06-19 (v2.2): Added NTP server module and documentation updates.
2025-06-24 (v2.3): Added meeting_users authentication overview.
2025-06-24 (v2.4): YGScreen module & endpoints documented.
2025-06-17 (v2.1): Added summary of Distrib Builder, Device Designer and LogCenter modules.
2025-06-09 (v2.0): Rewritten to clarify API-first model, UX, and infra roles.
