import { useEffect, useState } from 'react';
import { Box, Button, Typography, Table, TableHead, TableRow, TableCell, TableBody } from '@mui/material';

// Version: 0.3.0

export default function History({ token, onNewBuild }) {
  const [entries, setEntries] = useState([]);
  const authHeader = { Authorization: `Bearer ${token}` };

  const fetchHistory = async () => {
    const res = await fetch('/api/builder/history', { headers: authHeader });
    const data = await res.json();
    setEntries(data.history || []);
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const duplicate = async (e) => {
    const newV = prompt('New version', e.version);
    if (!newV) return;
    await fetch('/api/builder/duplicate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeader },
      body: JSON.stringify({ ...e, new_version: newV })
    });
    fetchHistory();
  };

  const rollback = async (e) => {
    if (!window.confirm(`Rollback to ${e.version}?`)) return;
    await fetch('/api/builder/rollback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeader },
      body: JSON.stringify(e)
    });
    fetchHistory();
  };

  return (
    <Box sx={{ mt: 4 }}>
      <Button variant="contained" onClick={onNewBuild}>New Build</Button>
      <Table sx={{ mt: 2 }}>
        <TableHead>
          <TableRow>
            <TableCell>Device Type</TableCell>
            <TableCell>Distribution</TableCell>
            <TableCell>Version</TableCell>
            <TableCell>Date</TableCell>
            <TableCell>Notes</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {entries.map((e, i) => (
            <TableRow key={i}>
              <TableCell>{e.device_type}</TableCell>
              <TableCell>{e.distribution}</TableCell>
              <TableCell>{e.version}</TableCell>
              <TableCell>{e.date}</TableCell>
              <TableCell>{e.notes}</TableCell>
              <TableCell>
                <Button size="small" onClick={() => duplicate(e)}>Duplicate</Button>
                <Button size="small" onClick={() => rollback(e)}>Rollback</Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Box>
  );
}
