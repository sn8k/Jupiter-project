import { useState } from 'react';
import { Box, Button, TextField, Typography } from '@mui/material';

// Version: 0.5.0
export default function Login({ onLogin }) {
  const [token, setToken] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const t = token.trim();
    if (!t) return;
    try {
      const res = await fetch('/api/builder/whoami', {
        headers: { Authorization: `Bearer ${t}` }
      });
      if (!res.ok) throw new Error('Invalid token');
      const data = await res.json();
      onLogin(t, data.user || '');
    } catch {
      setError('Invalid token');
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ mt: 4, display: 'flex', flexDirection: 'column', gap: 2, alignItems: 'center' }}>
      <Typography variant="h5">Distrib Builder Login</Typography>
      <TextField label="API Token" value={token} onChange={(e) => setToken(e.target.value)} required />
      {error && <Typography color="error">{error}</Typography>}
      <Button variant="contained" type="submit">Login</Button>
    </Box>
  );
}
