import { useMemo, useState } from 'react';
import { ThemeProvider, createTheme, CssBaseline, Button, Box } from '@mui/material';
import Login from './Login.jsx';
import Wizard from './Wizard.jsx';
import History from './History.jsx';
import './App.css';

// Version: 0.6.0

export default function App() {
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [showWizard, setShowWizard] = useState(false);
  const [mode, setMode] = useState('light');
  const theme = useMemo(() => createTheme({ palette: { mode } }), [mode]);

  const toggleMode = () => setMode((m) => (m === 'light' ? 'dark' : 'light'));

  const handleLogin = (t, u) => {
    setToken(t);
    setUser(u);
  };

  const logout = () => {
    setToken(null);
    setUser(null);
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ p: 2 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <Button size="small" onClick={toggleMode}>
            {mode === 'light' ? 'Dark' : 'Light'} Mode
          </Button>
          {token && (
            <Button size="small" onClick={logout}>
              Logout ({user})
            </Button>
          )}
        </Box>
        {token ? (
          showWizard ? (
            <Wizard token={token} onDone={() => setShowWizard(false)} />
          ) : (
            <History token={token} onNewBuild={() => setShowWizard(true)} />
          )
        ) : (
          <Login onLogin={handleLogin} />
        )}
      </Box>
    </ThemeProvider>
  );
}
