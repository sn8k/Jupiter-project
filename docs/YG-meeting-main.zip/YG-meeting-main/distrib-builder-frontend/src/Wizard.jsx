import { useEffect, useState, useRef } from 'react';
import { Box, Button, Step, StepLabel, Stepper, Typography, TextField, CircularProgress, Autocomplete, Snackbar, Alert } from '@mui/material';

// Version: 0.5.0

const steps = ['Device Type', 'Distribution', 'Upload Files', 'Manifest', 'Packaging', 'Preview', 'Commit'];

export default function Wizard({ token, onDone = () => {} }) {
  const [activeStep, setActiveStep] = useState(0);
  const [deviceType, setDeviceType] = useState('');
  const [distribution, setDistribution] = useState('');
  const [buildId, setBuildId] = useState(null);
  const [files, setFiles] = useState([]);
  const [manifest, setManifest] = useState('{}');
  const [jobId, setJobId] = useState(null);
  const [packStatus, setPackStatus] = useState('');
  const [downloadUrl, setDownloadUrl] = useState(null);
  const [deviceTypeOptions, setDeviceTypeOptions] = useState([]);
  const [distributionOptions, setDistributionOptions] = useState([]);
  const [error, setError] = useState('');
  const dropRef = useRef();

  const authHeader = { Authorization: `Bearer ${token}` };

  const fetchDeviceTypes = async (q = '') => {
    try {
      const res = await fetch(`/api/builder/device-types${q ? `?q=${encodeURIComponent(q)}` : ''}`, { headers: authHeader });
      const data = await res.json();
      setDeviceTypeOptions(data.device_types.map((d) => d.name));
    } catch {
      setError('Failed to load device types');
    }
  };

  const fetchDistributions = async () => {
    try {
      const res = await fetch(`/api/builder/distributions?type=${encodeURIComponent(deviceType)}`, { headers: authHeader });
      const data = await res.json();
      setDistributionOptions(data.distributions.map((d) => d.name));
    } catch {
      setError('Failed to load distributions');
    }
  };

  const handleNext = async () => {
    try {
      if (activeStep === 1) {
        const res = await fetch('/api/builder/start', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...authHeader },
          body: JSON.stringify({ type: deviceType, distribution }),
        });
        const data = await res.json();
        setBuildId(data.build_id);
      }

      if (activeStep === 2) {
        for (const file of files) {
          const formData = new FormData();
          formData.append('build_id', buildId);
          formData.append('file', file);
          await fetch('/api/builder/upload-file', {
            method: 'POST',
            headers: authHeader,
            body: formData,
          });
        }
        const res = await fetch(`/api/builder/manifest?build_id=${buildId}`, { headers: authHeader });
        const data = await res.json();
        setManifest(JSON.stringify(data.manifest || {}, null, 2));
      }

      if (activeStep === 3) {
        await fetch('/api/builder/manifest', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...authHeader },
          body: JSON.stringify({ build_id: buildId, manifest: JSON.parse(manifest) }),
        });
        const res = await fetch('/api/builder/package', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...authHeader },
          body: JSON.stringify({ build_id: buildId }),
        });
        const data = await res.json();
        setJobId(data.job_id);
      }

      if (activeStep === 6) {
        await fetch('/api/builder/commit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...authHeader },
          body: JSON.stringify({ job_id: jobId }),
        });
      }

      setActiveStep((prev) => prev + 1);
    } catch (err) {
      console.error(err);
      setError('An error occurred');
    }
  };

  const handleBack = () => {
    setActiveStep((prev) => prev - 1);
  };

  useEffect(() => {
    fetchDeviceTypes();
  }, []);

  useEffect(() => {
    if (activeStep === 1 && deviceType) {
      fetchDistributions();
    }
  }, [activeStep, deviceType]);

  useEffect(() => {
    if (activeStep === 4 && jobId) {
      const timer = setInterval(async () => {
        const res = await fetch(`/api/builder/package-status?job_id=${jobId}`, { headers: authHeader });
        const data = await res.json();

        setPackStatus(data.state);
        setDownloadUrl(data.download_url || null);
        if (data.state === 'done') {
          clearInterval(timer);
        }
      }, 2000);
      return () => clearInterval(timer);
    }
  }, [activeStep, jobId, authHeader]);


  return (
    <Box sx={{ width: '100%', mt: 4 }}>
      <Stepper activeStep={activeStep} alternativeLabel>
        {steps.map((label) => (
          <Step key={label}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      <Box sx={{ mt: 4 }}>
        {activeStep === 0 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Typography>Choose device type:</Typography>
            <Autocomplete
              freeSolo
              options={deviceTypeOptions}
              inputValue={deviceType}
              onInputChange={(e, value) => {
                setDeviceType(value);
                fetchDeviceTypes(value);
              }}
              renderInput={(params) => <TextField {...params} label="Device Type" />}
            />
            <Button variant="contained" onClick={handleNext} disabled={!deviceType}>Next</Button>
          </Box>
        )}
        {activeStep === 1 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Typography>Distribution name:</Typography>
            <Autocomplete
              freeSolo
              options={distributionOptions}
              inputValue={distribution}
              onInputChange={(e, value) => {
                setDistribution(value);
              }}
              renderInput={(params) => <TextField {...params} label="Distribution" />}
            />
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button variant="outlined" onClick={handleBack}>Back</Button>
              <Button variant="contained" onClick={handleNext} disabled={!distribution}>Next</Button>
            </Box>
          </Box>
        )}
        {activeStep === 2 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Typography>Upload files:</Typography>
            <Box
              ref={dropRef}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                setFiles(Array.from(e.dataTransfer.files));
              }}
              sx={{ border: '2px dashed grey', p: 4, textAlign: 'center' }}
            >
              {files.length === 0 ? 'Drop files here' : files.map((f) => (
                <div key={f.name}>{f.name}</div>
              ))}
            </Box>
            <Button variant="contained" onClick={handleNext} disabled={files.length === 0}>Next</Button>
          </Box>
        )}
        {activeStep === 3 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Typography>Edit manifest:</Typography>
            <TextField multiline minRows={8} value={manifest} onChange={(e) => setManifest(e.target.value)} />
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button variant="outlined" onClick={handleBack}>Back</Button>
              <Button variant="contained" onClick={handleNext}>Package</Button>
            </Box>
          </Box>
        )}
        {activeStep === 4 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, alignItems: 'center' }}>
            <Typography>Packaging status: {packStatus || 'pending...'}</Typography>
            {packStatus !== 'done' && <CircularProgress />}
            {downloadUrl && packStatus === 'done' && (
              <Button href={downloadUrl} target="_blank" download variant="outlined">Download archive</Button>
            )}
            <Button variant="contained" onClick={handleNext} disabled={packStatus !== 'done'}>Next</Button>
          </Box>
        )}
        {activeStep === 5 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <Typography variant="h6">Preview files</Typography>
            <Box sx={{ maxHeight: 150, overflow: 'auto', border: '1px solid grey', p: 1 }}>
              {files.map((f) => (
                <div key={f.name}>{f.name}</div>
              ))}
            </Box>
            <Typography variant="h6">Manifest</Typography>
            <TextField multiline minRows={8} value={manifest} InputProps={{ readOnly: true }} />
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button variant="outlined" onClick={handleBack}>Back</Button>
              <Button variant="contained" onClick={handleNext}>Commit</Button>
            </Box>
          </Box>
        )}
        {activeStep === 7 && (
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, alignItems: 'center' }}>
            <Typography>Build committed!</Typography>
            <Button variant="contained" onClick={onDone}>Close</Button>
          </Box>
        )}
      </Box>
      <Snackbar open={!!error} autoHideDuration={6000} onClose={() => setError('')}>
        <Alert onClose={() => setError('')} severity="error" sx={{ width: '100%' }}>
          {error}
        </Alert>
      </Snackbar>
    </Box>
  );
}
