# AGENTS.md  
_Distrib Builder Project – Agents & Roles_  
Version : 1.0 (2025-06-12)

---

## 📦 Projet : Distrib Builder (Frontend + Backend)

Plateforme web pour générer, packager et publier des distributions logicielles (firmwares, scripts, assets…) à destination de devices IoT, avec workflow automatisé et expérience utilisateur assistée.

---

## 👤 Agents / Rôles du Projet

### 1. **Backend Developer (“API/Logic Agent”)**

#### **Responsabilités**
- Concevoir et implémenter une API REST sécurisée et robuste
- Gérer la logique métier : device-types, distributions, packaging, versioning, publication
- Assurer la validation, le traitement et le stockage des fichiers uploadés
- Orchestrer la génération des manifest.json, la gestion asynchrone des jobs de packaging (tar.gz/zip), et l’indexation en base/dossier
- Mettre en place la sécurité (authentification, validation des inputs, audit/logs)
- Maintenir la documentation de l’API, du workflow, et des endpoints

#### **Stack recommandée**
- Node.js (Express)
- MariaDB/MySQL ou SQLite (index/distribs)
- Stockage fichiers : local ou distant
- Sécurité : JWT/API Key, rate limiting
- Option : outils de compression et checksum (tar, zip, shasum)

#### **Tâches principales**
- Développement endpoints REST CRUD (device-types, distribs, fichiers)
- Upload multi-fichiers sécurisé
- Génération et édition de manifest.json
- Packaging asynchrone (avec monitoring job/status)
- Endpoints commit/publication, duplication, rollback, historique
- Rédaction de la doc API et des guides d’intégration

---

### 2. **Frontend Developer (“UI/UX Agent”)**

#### **Responsabilités**
- Développer un wizard web moderne et user-friendly (multi-step, validation live)
- Implémenter l’authentification, la gestion de session et l’appel à l’API backend
- Offrir une expérience guidée, avec suggestions automatiques, feedback en temps réel et gestion des erreurs
- Gérer l’upload multi-fichiers, l’intégration des templates/scripts, et la visualisation du manifest
- Proposer des outils de preview, d’édition, de duplication et d’historique des distribs
- Rendre l’UI responsive, professionnelle et accessible

#### **Stack recommandée**
- React.js (Vite ou Next.js)
- UI Framework : shadcn/ui, Material UI, Chakra UI
- Bibliothèques : React Router, Axios, Formik, Yup, React Dropzone
- Option : gestion état avancée (Redux, Zustand), notifications (notistack/toast)

#### **Tâches principales**
- Wizard multi-étapes avec navigation et validation
- Gestion des appels API (device-types, distribs, files, manifest…)
- Upload drag & drop, preview, suppression et renommage de fichiers
- Visualisation graphique et édition du manifest (treeview, mode expert JSON)
- Packaging, commit, feedback utilisateur (progress, logs, notifications)
- Historique des builds/distribs, duplication, rollback
- Tests UI de base, documentation utilisateur

---

### 3. **QA & Documentation Agent**

#### **Responsabilités**
- Rédiger et maintenir la documentation utilisateur et développeur (README, guides d’utilisation du wizard, exemples d’appel API, bonnes pratiques)
- Vérifier la couverture des cas d’usage : création, duplication, rollback, suppression de distribs, packaging, validation manifest, etc.
- Assurer la cohérence UI/UX et la clarté des messages d’erreur ou de succès

#### **Stack recommandée**
- Markdown
- Outils de doc (Docusaurus, MkDocs, Notion…)
- Capture d’écran et screencast

#### **Tâches principales**
- Rédaction du README (backend & frontend)
- Écriture de guides utilisateurs (premier build, packaging, rollback…)
- Contribution à la doc API (swagger ou markdown)
- Recette fonctionnelle de l’application (parcours complet)

---

### 4. **DevOps & Intégration Agent (optionnel pour CI/CD)**

#### **Responsabilités**
- Mettre en place le déploiement automatisé (Docker, scripts setup, intégration continue)
- Sécuriser et documenter l’accès au storage, à l’API, et à l’interface web
- Maintenir la reproductibilité de l’installation et la sauvegarde des données

#### **Stack recommandée**
- Docker, docker-compose
- GitHub Actions, GitLab CI, ou équivalent
- Scripts bash/python pour setup et backup

#### **Tâches principales**
- Écrire les Dockerfile/backend/frontend
- Configurer les scripts d’installation et de déploiement
- Tester la restauration d’un environnement complet à partir du repo

---

## 📝 **Principes et attendus pour tous les agents**
- Chaque livrable doit être versionné et documenté
- Respect du workflow API-first : le backend définit la source de vérité, le frontend consomme exclusivement l’API
- Robustesse, validation, sécurité : aucune action critique n’est faite sans confirmation ou validation côté serveur
- UX : l’utilisateur doit pouvoir aller au bout du wizard sans connaissance technique avancée
- Documentation claire et exhaustive (dev et utilisateur)
- Code propre, maintenable, commenté

---

## 🏁 **Livrables**
- Backend complet (API, packaging, sécurité, doc)
- Frontend complet (SPA wizard, UX, intégration API, doc)
- Scripts d’installation et de setup
- Documentation technique et utilisateur
- (Option) Images Docker, exemples de manifest.json, changelog, scripts

---

> Pour toute question ou clarification, se référer au README principal ou contacter le Product Owner du projet.

