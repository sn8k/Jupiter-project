<?php
// File: admin/device_creation.php
// Version: 2.2.2
// Date: 2025-06-13
// Description: Device creation UI (Meeting), Bootstrap 5, dark mode, responsive, unified admin design
// CHANGELOG:
// - 2.2.1 (2025-06-13): Utilise storage_path défini dans config.php
// - 2.2.0 (2025-05-26): Migration Bootstrap 5, harmonisation UI avec SSH Key Admin, dark mode natif
// - 2.1.0 (2025-05-24): Migration vers config.php centralisé array + PDO local, plus de variable globale

$config = require __DIR__ . '/../api/config.php';
$links = include __DIR__ . '/links.php';

// === Création dynamique du PDO ===
try {
    $pdo = new PDO(
        "mysql:host={$config['db_host']};dbname={$config['db_name']};charset={$config['db_charset']}",
        $config['db_user'],
        $config['db_pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . htmlspecialchars($e->getMessage()));
}

// Scan device types and distributions
function get_types_and_distributions_fs($storageRoot) {
    $types = [];
    $dists = [];
    if (!is_dir($storageRoot)) return [[], []];
    foreach (scandir($storageRoot) as $devtype) {
        if ($devtype === '.' || $devtype === '..' || !is_dir("$storageRoot/$devtype")) continue;
        $types[] = $devtype;
        foreach (scandir("$storageRoot/$devtype") as $dist) {
            if ($dist === '.' || $dist === '..' || !is_dir("$storageRoot/$devtype/$dist")) continue;
            $dists[$devtype][] = $dist;
        }
    }
    return [$types, $dists];
}
[$deviceTypes, $allDists] = get_types_and_distributions_fs($config['storage_path'] ?? ($config['flash_storage_root'] ?? dirname(__DIR__) . '/storage'));

// Find next available serial
function find_next_serial($pdo) {
    $used = [];
    $stmt = $pdo->query("SELECT product_serial FROM devices WHERE product_serial IS NOT NULL");
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN, 0) as $s) {
        if (preg_match('/^V1-S01-(\d{5})$/', $s, $m)) $used[(int)$m[1]] = true;
    }
    for ($i = 1; $i <= 99999; $i++) {
        if (!isset($used[$i])) return sprintf("V1-S01-%05d", $i);
    }
    return null;
}
$serial = find_next_serial($pdo);
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <title>MEETING - DEVICE CREATION</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 CSS (dark) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body {
            background: #171b20 !important;
            color: #f3f7fa !important;
            min-height: 100vh;
            margin: 0; padding: 0;
        }
        .navbar {
            background: #111316 !important;
            color: #fff;
            min-height: 56px;
            box-shadow: 0 3px 12px #0008;
        }
        .navbar .brand {
            font-size: 1.35em;
            font-weight: bold;
            color: #2196f3 !important;
            letter-spacing: 1.1px;
            padding-left: 16px;
        }
        .navbar .nav-link, .navbar .nav-icon {
            color: #fff !important;
        }
        .navbar .nav-link.active, .navbar .nav-link:focus, .navbar .nav-link:hover {
            background: #2196f3 !important;
            color: #fff !important;
        }
        .nav-icon {
            font-size: 1.1em;
            margin-right: 5px;
        }
        .dark-toggle {
            border: none;
            background: #232832;
            color: #fff;
            border-radius: 22px;
            padding: 5px 17px;
            cursor: pointer;
            font-size: 1em;
            margin-left: 18px;
        }
        .dashboard-main {
            max-width: 1480px;
            margin: 42px auto 22px auto;
            padding: 0 2vw;
            display: flex;
            gap: 38px;
            flex-wrap: wrap;
            align-items: flex-start;
        }
        .panel {
            background: #20242a;
            border-radius: 13px;
            box-shadow: 0 4px 18px #0007;
            padding: 30px 26px;
            margin-bottom: 20px;
            flex: 1 1 340px;
            min-width: 320px;
            max-width: 560px;
        }
        .form-panel {
            max-width: 430px;
        }
        h2 {
            color: #2196f3;
            margin-bottom: 26px;
            font-weight: 600;
            font-size: 1.3em;
        }
        .form-label { font-weight: 500; }
        .form-actions {
            display: flex; gap: 10px; margin-top: 14px;
        }
        .table {
            background: #171b20;
            color: #f3f7fa;
            border-radius: 10px;
            overflow: hidden;
        }
        .table thead th {
            background: #232832;
            color: #2196f3;
            font-weight: 600;
        }
        .auth-checkbox {
            transform: scale(1.18);
            cursor: pointer;
        }
        .icon-btn, .purge-btn, .edit-btn {
            border: none;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 6px 10px;
            font-size: 1.07em;
            transition: background .13s;
            background: #212529;
            color: #e53935;
        }
        .icon-btn.edit-btn { color: #43a047; }
        .icon-btn.edit-btn:hover { background: #2ba15721; color: #2ba157; }
        .icon-btn:hover { background: #e5393522; color: #fff; }
        .purge-btn {
            background: #ffa000 !important; color: #fff !important;
            padding: 6px 14px;
            font-size: 1em;
            margin-left: 4px;
        }
        .purge-btn:hover { background: #ef6c00 !important; }
        .pagination button {
            margin: 0 3px; font-size: 1em; padding: 5px 14px;
        }
        .modal {
            display: none; position: fixed; z-index: 1055;
            left: 0; top: 0; width: 100vw; height: 100vh;
            background: rgba(30, 30, 40, 0.23);
            align-items: center; justify-content: center;
        }
        .modal-content {
            background: #232832;
            color: #f3f7fa;
            border-radius: 10px;
            box-shadow: 0 4px 24px #0008;
            padding: 28px 24px 20px 24px;
            min-width: 340px; max-width: 98vw;
            display: flex; flex-direction: column; align-items: stretch;
        }
        .modal-content label { margin-bottom: 8px; }
        .modal-content input, .modal-content select { margin-bottom: 16px; }
        .modal-content .modal-actions { text-align: right; }
        .modal-content button { margin-left: 10px; }
        /* Responsive */
        @media (max-width: 1100px) {
            .dashboard-main { flex-direction: column; gap: 32px; }
            .panel { max-width: 98vw; }
        }
        @media (max-width: 600px) {
            .dashboard-main { padding: 0 1vw; gap: 19px;}
            .panel { padding: 14px 2vw 14px 2vw;}
            .navbar .brand { font-size: 1em; padding-left: 7px;}
            .navbar .nav-link { font-size: 0.97em; padding: 6px 9px;}
            .dark-toggle { margin-right: 6px; font-size: 0.95em;}
        }
    </style>
</head>
<body class="dark">
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container-fluid">
            <span class="brand">🟦 MEETING Admin</span>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 navlinks">
                    <?php foreach ($links as $link): ?>
                        <?php
                            $icon = isset($link['icon']) ? '<span class="nav-icon">'.htmlspecialchars($link['icon']).'</span>' : '';
                            $name = htmlspecialchars($link['name']);
                            if (isset($link['file'])) {
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['file']}\">{$icon}{$name}</a></li>";
                            } else if (isset($link['url'])) {
                                $target = isset($link['target']) ? " target=\"{$link['target']}\"" : "";
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['url']}\"$target>{$icon}{$name}</a></li>";
                            } else {
                                echo "<li class=\"nav-item\"><span class=\"nav-link\">{$icon}{$name}</span></li>";
                            }
                        ?>
                    <?php endforeach; ?>
                </ul>
            </div>
            <button class="dark-toggle" onclick="toggleDarkMode()" title="Toggle light/dark mode">
                <svg width="18" height="18" viewBox="0 0 20 20"><path fill="currentColor" d="M10 2a8 8 0 1 0 8 8a8 8 0 0 0-8-8Zm0 14a6 6 0 1 1 6-6a6 6 0 0 1-6 6Zm0-11a1 1 0 1 0 1 1a1 1 0 0 0-1-1Z"/></svg>
                Dark mode
            </button>
        </div>
    </nav>
    <div class="dashboard-main">
        <!-- PANEL: Device Creation Form -->
        <div class="panel form-panel">
            <h2>Add a New Device</h2>
            <div class="mb-3">
                <label for="deviceKeyToAdd" class="form-label">DeviceKey to add :</label>
                <div class="input-group mb-2">
                    <input type="text" class="form-control" id="deviceKeyToAdd" maxlength="32" placeholder="Manual or auto-generated deviceKey">
                    <button class="btn btn-outline-primary" onclick="generateDeviceKey()" type="button">Generate</button>
                </div>
            </div>
            <div class="mb-3">
                <label for="tokenCode" class="form-label">Token code :</label>
                <div class="input-group mb-2">
                    <input type="text" class="form-control" id="tokenCode" maxlength="32" placeholder="Token code (1-32 chars)">
                    <button class="btn btn-outline-secondary" onclick="generateTokenCode()" type="button">Random</button>
                </div>
            </div>
            <div class="mb-3">
                <label for="deviceType" class="form-label">Device Type :</label>
                <select class="form-select" id="deviceType"></select>
            </div>
            <div class="mb-3">
                <label for="distribution" class="form-label">Distribution :</label>
                <select class="form-select" id="distribution"></select>
            </div>
            <div class="mb-3">
                <label for="productSerial" class="form-label">Serial number :</label>
                <input type="text" class="form-control" id="productSerial" maxlength="20" readonly value="<?php echo htmlspecialchars($serial ? $serial : 'NO AVAILABLE SERIAL'); ?>">
            </div>
            <div class="form-actions">
                <button class="btn btn-primary" onclick="addManualDevice()">Add DeviceKey</button>
                <button class="btn btn-outline-light" onclick="resetAll()" type="button">Reset all Values</button>
            </div>
        </div>
        <!-- PANEL: Devices List -->
        <div class="panel">
            <h2>Recorded Devices</h2>
            <div class="devices-list">
                <table id="devicesTable" class="table table-dark table-striped table-hover align-middle">
                    <thead>
                        <tr>
                            <th class="text-center">Auth</th>
                            <th>DeviceKey</th>
                            <th>Token</th>
                            <th>Type</th>
                            <th>Distribution</th>
                            <th>Serial</th>
                            <th class="text-center" style="width:70px;"># tokens</th>
                            <th>Time Added</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody id="devicesTbody"></tbody>
                </table>
                <div class="pagination" id="pagination"></div>
            </div>
        </div>
    </div>
    <!-- Modal for editing device -->
    <div class="modal" id="editModal">
        <div class="modal-content">
            <h3>Edit Device</h3>
            <input type="hidden" id="editDeviceKey">
            <label for="editSerial">Serial Number :</label>
            <input type="text" id="editSerial" maxlength="20">
            <label for="editType">Device Type :</label>
            <select id="editType"></select>
            <div class="modal-actions">
                <button class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
                <button class="btn btn-success" onclick="saveEditDevice()">Save</button>
            </div>
        </div>
    </div>
<!-- Bootstrap 5 JS + Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
let limit = 25, offset = 0, total = 0;
let deviceTypes = <?php echo json_encode($deviceTypes); ?>;
let allDists = <?php echo json_encode($allDists); ?>;

function fillDropdown(id, values) {
    let s = document.getElementById(id);
    s.innerHTML = '';
    if (!values.length) {
        let opt = document.createElement('option');
        opt.value = '';
        opt.textContent = '—';
        s.appendChild(opt);
        return;
    }
    values.forEach(v => {
        let opt = document.createElement('option');
        opt.value = v;
        opt.textContent = v;
        s.appendChild(opt);
    });
}

function updateDistributions() {
    let type = document.getElementById('deviceType').value;
    let dists = allDists[type] || [];
    fillDropdown('distribution', dists);
}

fillDropdown('deviceType', deviceTypes);
document.getElementById('deviceType').addEventListener('change', updateDistributions);
if (deviceTypes.length) {
    fillDropdown('distribution', allDists[deviceTypes[0]] || []);
}

// Devices display
function fetchDevices() {
    fetch(`/api/devices?limit=${limit}&offset=${offset}`)
    .then(res => res.json())
    .then(data => {
        let tbody = document.getElementById('devicesTbody');
        tbody.innerHTML = '';
        if (data.devices && data.devices.length > 0) {
            data.devices.forEach(d => {
                let checked = d.authorized == 1 ? 'checked' : '';
                let tr = document.createElement('tr');
                tr.innerHTML = `<td class="text-center">
                                    <input type="checkbox" class="auth-checkbox" ${checked}
                                           onchange="toggleAuth('${d.device_key}', this.checked)">
                                </td>
                                <td class="nowrap">${d.device_key}</td>
                                <td class="nowrap">${d.token_code || '-'}</td>
                                <td>${d.device_type || '-'}</td>
                                <td>${d.distribution || '-'}</td>
                                <td class="nowrap">${d.product_serial || '-'}</td>
                                <td class="text-center">${d.token_count ?? 0}</td>
                                <td>${d.registered_at || '-'}</td>
                                <td class="text-center">
                                    <span class="action-btns">
                                        <button class="icon-btn" onclick="deleteDevice('${d.device_key}')" title="Delete">
                                            <svg width="19" height="19" viewBox="0 0 20 20"><path fill="currentColor" d="M7.25 2A1.25 1.25 0 0 0 6 3.25v1.5H3.25a.75.75 0 1 0 0 1.5H4.4l.86 10.1A2.25 2.25 0 0 0 7.5 18h5a2.25 2.25 0 0 0 2.24-1.65l.86-10.1h1.15a.75.75 0 1 0 0-1.5H14V3.25A1.25 1.25 0 0 0 12.75 2h-5ZM7.5 3.5h5a.25.25 0 0 1 .25.25V4.75h-5.5V3.75A.25.25 0 0 1 7.5 3.5ZM7.26 16.38l-.84-9.88h7.16l-.84 9.88a.75.75 0 0 1-.75.62h-4a.75.75 0 0 1-.75-.62Z"/></svg>
                                        </button>
                                        <button class="icon-btn purge-btn" title="Purge logs" onclick="purgeLogs('${d.device_key}')">
                                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                                <path fill="#ffa000" d="M5.5 6a.5.5 0 0 1 .5.5v7.8a1.7 1.7 0 0 0 1.7 1.7h4.6a1.7 1.7 0 0 0 1.7-1.7V6.5a.5.5 0 0 1 1 0v7.8a2.7 2.7 0 0 1-2.7 2.7H7.7A2.7 2.7 0 0 1 5 14.3V6.5a.5.5 0 0 1 .5-.5Z"/>
                                                <path fill="#ffa000" d="M8 8.75a.5.5 0 1 1 1 0v5a.5.5 0 1 1-1 0v-5Zm3 0a.5.5 0 1 1 1 0v5a.5.5 0 1 1-1 0v-5Zm-5-3.25a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v.5h3a.5.5 0 1 1 0 1H3.5a.5.5 0 1 1 0-1h3v-.5ZM7 5.5v-.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 .5.5v.5H7Z"/>
                                            </svg>
                                        </button>
                                        <button class="icon-btn edit-btn" onclick="openEditModal('${d.device_key}', '${d.product_serial || ''}', '${d.device_type || ''}')" title="Edit">
                                            <svg width="18" height="18" viewBox="0 0 20 20"><path fill="currentColor" d="M4.293 16.707a1 1 0 0 0 .708.293h9a1 1 0 1 0 0-2h-8.586l9.293-9.293a1 1 0 0 0-1.414-1.414l-9.293 9.293v-8.586a1 1 0 1 0-2 0v9a1 1 0 0 0 .293.707ZM18.707 5.707l-4.414-4.414a1 1 0 0 0-1.414 0l-2.828 2.828a1 1 0 0 0 0 1.414l4.414 4.414a1 1 0 0 0 1.414 0l2.828-2.828a1 1 0 0 0 0-1.414Z"/></svg>
                                        </button>
                                    </span>
                                </td>`;
                tbody.appendChild(tr);
            });
        } else {
            tbody.innerHTML = '<tr><td colspan=9>No devices found.</td></tr>';
        }
        total = data.total;
        updatePagination();
    });
}
function updatePagination() {
    let div = document.getElementById('pagination');
    let pages = Math.ceil(total / limit);
    let page = Math.floor(offset / limit) + 1;
    let html = '';
    for (let i=1; i<=pages; ++i) {
        html += `<button class="btn btn-sm btn-outline-primary${i===page?' active':''}" onclick="gotoPage(${i})">${i}</button>`;
    }
    div.innerHTML = html;
}
function gotoPage(n) { offset = (n-1)*limit; fetchDevices(); }
function generateDeviceKey() {
    let keyField = document.getElementById('deviceKeyToAdd');
    if (keyField.value.trim()) {
        alert('DeviceKey to add must be empty to generate a random DeviceKey !');
        return;
    }
    fetch('/api/devices/generate-key')
    .then(res => res.json())
    .then(data => {
        if (data.devicekey)
            keyField.value = data.devicekey;
        if (data.token_code) {
            let tokenField = document.getElementById('tokenCode');
            if (!tokenField.value.trim())
                tokenField.value = data.token_code;
        }
    });
}
function generateTokenCode() {
    let tokenField = document.getElementById('tokenCode');
    if (tokenField.value.trim()) {
        alert('Token code must be empty to generate a random token code !');
        return;
    }
    let chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let token = '';
    for (let i=0; i<6; ++i) token += chars.charAt(Math.floor(Math.random()*chars.length));
    tokenField.value = token;
}
function addManualDevice() {
    let key = document.getElementById('deviceKeyToAdd').value.trim();
    let token = document.getElementById('tokenCode').value.trim();
    let deviceType = document.getElementById('deviceType').value;
    let distribution = document.getElementById('distribution').value;
    let serial = document.getElementById('productSerial').value.trim();

    if (!key || !token) return alert('Please enter deviceKey and token code.');
    if (!deviceType) return alert('Please select a device type.');
    if (!distribution) return alert('Please select a distribution.');
    if (!serial || serial === 'NO AVAILABLE SERIAL') return alert('No serial available, cannot add.');

    if (token.length < 1 || token.length > 32) return alert('Token code must be 1-32 chars.');
    fetch('/api/devices/manual-create', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
            devicekey: key,
            token_code: token,
            device_type: deviceType,
            distribution: distribution,
            product_serial: serial
        })
    }).then(res => res.json())
    .then(data => {
        if (data.error) alert(data.error);
        else {
            alert('Device added!');
            fetchDevices();
            resetAll();
        }
    });
}
function resetAll() {
    document.getElementById('deviceKeyToAdd').value = '';
    document.getElementById('tokenCode').value = '';
    document.getElementById('deviceType').selectedIndex = 0;
    updateDistributions();
    location.reload();
}
function deleteDevice(deviceKey) {
    if (!confirm('Delete this device key?')) return;
    fetch(`/api/devices/${deviceKey}`, { method: 'DELETE' })
        .then(res => res.json())
        .then(data => { fetchDevices(); });
}
function toggleAuth(deviceKey, authorized) {
    fetch(`/api/devices/${deviceKey}/authorize`, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({authorized: authorized ? 1 : 0})
    })
    .then(res => res.json())
    .then(data => {
        if (data.success !== true) {
            alert('Failed to update authorization: ' + (data.error || 'Unknown error'));
            fetchDevices();
        }
    })
    .catch(() => {
        alert('Failed to update authorization (network error)');
        fetchDevices();
    });
}
function purgeLogs(deviceKey) {
    if (!confirm('This will permanently delete all logs for this device.\nAre you sure?')) return;
    fetch(`/api/devices/${deviceKey}/purge-logs`, { method: 'POST' })
    .then(res => res.json())
    .then(data => {
        if (data.success) alert('Logs purged successfully.');
        else alert('Error purging logs: ' + (data.error || 'Unknown error'));
    })
    .catch(() => alert('Error purging logs (network error)'));
}
// --- EDIT DEVICE MODAL ---
function openEditModal(deviceKey, serial, type) {
    document.getElementById('editDeviceKey').value = deviceKey;
    document.getElementById('editSerial').value = serial;
    fillDropdown('editType', deviceTypes);
    document.getElementById('editType').value = type || '';
    document.getElementById('editModal').style.display = 'flex';
}
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}
function saveEditDevice() {
    let deviceKey = document.getElementById('editDeviceKey').value;
    let serial = document.getElementById('editSerial').value.trim();
    let type = document.getElementById('editType').value;
    if (!serial) return alert('Serial number is required.');
    if (!type) return alert('Device type is required.');
    fetch(`/api/devices/${deviceKey}/product-serial`, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ product_serial: serial })
    })
    .then(res => res.json())
    .then(data => {
        if (!data.success) {
            alert('Failed to update serial: ' + (data.error || 'Unknown error'));
        } else {
            fetch(`/api/devices/${deviceKey}/device-type`, {
                method: 'PUT',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ device_type: type })
            })
            .then(res2 => res2.json())
            .then(data2 => {
                if (!data2.success) {
                    alert('Failed to update device type: ' + (data2.error || 'Unknown error'));
                } else {
                    alert('Device updated!');
                    closeEditModal();
                    fetchDevices();
                }
            });
        }
    });
}
window.onload = function() {
    fetchDevices();
    // Dark mode forced by default
    if(!document.body.classList.contains('dark')) {
        document.body.classList.add('dark');
    }
};
function toggleDarkMode() {
    document.body.classList.toggle('dark');
    if(document.body.classList.contains('dark')) {
        document.documentElement.style.setProperty('--bs-body-bg','#171b20');
        document.documentElement.style.setProperty('--bg-main','#171b20');
        document.documentElement.style.setProperty('--fg-main','#f3f7fa');
        document.documentElement.style.setProperty('--bg-panel','#20242a');
    } else {
        document.documentElement.style.setProperty('--bs-body-bg','#f3f7fa');
        document.documentElement.style.setProperty('--bg-main','#f3f7fa');
        document.documentElement.style.setProperty('--fg-main','#191c21');
        document.documentElement.style.setProperty('--bg-panel','#fff');
    }
}
</script>
</body>
</html>
