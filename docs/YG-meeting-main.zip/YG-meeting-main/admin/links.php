<?php
// File: admin/links.php
// Version: 1.4.0
return [
    [
        'name' => 'Dashboard',
        'file' => 'dashboard.php',
        'icon' => '📊',
    ],
    [
        'name' => 'Metrics Manager',
        'file' => 'metrics_manager.php',
        'icon' => '📈',
    ],
    [
        'name' => 'Global Settings',
        'file' => 'global_settings.php',
        'icon' => '⚙️',
    ],
    [
        'name' => 'DB Check',
        'file' => 'db_check.php',
        'icon' => '🩺',
    ],
    [
        'name' => 'DB Manager',
        'file' => 'db_manager.php',
        'icon' => '🗄️',
    ],
    [
        'name' => 'Device Creation',
        'file' => 'device_creation.php',
        'icon' => '➕',
    ],
    [
        'name' => 'Device Creation (Beta)',
        'file' => 'device_creation_beta.php',
        'icon' => '🧪',
    ],
    [
        'name' => 'Distribution Manager',
        'file' => 'distribution_manager.php',
        'icon' => '🗂️',
    ],
    [
        'name' => 'Device Designer',
        'file' => 'device_designer.php',
        'icon' => '🛠️',
    ],
    [
        'name' => 'User Manager',
        'file' => 'user_manager.php',
        'icon' => '👥',
    ],
    [
        'name' => 'SSH Keys Admin',
        'file' => 'admin_ssh_keys.php',
        'icon' => '🔑',
    ],
];
