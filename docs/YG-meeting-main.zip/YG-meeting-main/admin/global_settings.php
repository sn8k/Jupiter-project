<?php
// File: admin/global_settings.php
// Version: 2.2.0
// Date: 2025-06-24
// Author: Meeting Server Team
// Description: UI complète d'édition et de consultation de la config centrale (config.php). PIN pour masquage des secrets, multi-tabs dynamiques.
// CHANGELOG:
// - 2.2.0 (2025-06-24): Ajout ntp_logfile, user_keys_sync_logfile et device_type_icon_dir. Onglets pilotés par Bootstrap.
// - 2.1.2 (2025-06-13): Navigation entre onglets fonctionnant sans Bootstrap.
// - 2.1.1 (2025-06-13): Correction des identifiants d'onglets (espaces -> underscore).
// - 2.1.0 (2025-06-13): Ajout des nouveaux paramètres (builder, clés serveur,
//   backend_logfile, device_keys_root) et catégories mises à jour.
// - 2.0.0 (2025-05-31): Full intégration dynamique avec config.php, description auto, édition/sauvegarde directe, protection PIN, refonte clean.

define('MASTER_PIN', '182930');
session_start();
$links = require __DIR__ . '/links.php';
$has_pin = isset($_SESSION['has_pin']) && $_SESSION['has_pin'] === true;

// -- Master PIN process
if (isset($_POST['masterpin'])) {
    if ($_POST['masterpin'] === MASTER_PIN) {
        $_SESSION['has_pin'] = true;
        $has_pin = true;
    } else {
        $pin_error = "PIN incorrect.";
    }
}

// -- Charger la vraie config centrale !
$config_file = __DIR__ . '/../api/config.php';
$config = include $config_file;

// -- Définir les descriptions à la volée, pour tous les params
// (Astuce : tu peux affiner ici si besoin, ça reste facile à compléter)
$descriptions = [
    // Database
    'db_host'        => "Adresse de la base MySQL/MariaDB.",
    'db_name'        => "Nom de la base utilisée.",
    'db_user'        => "Nom d’utilisateur SQL (masqué, modifiable avec PIN).",
    'db_pass'        => "Mot de passe SQL (masqué, PIN).",
    'db_charset'     => "Charset MySQL (utf8mb4 recommandé).",
    // API/SSH/Auth
    'user_key_sync_script' => "Script de synchro des clés utilisateurs.",
    'admin_user'     => "Nom d’utilisateur admin pour le panneau.",
    'admin_pass'     => "Mot de passe admin.",
    // Devices
    'device_heartbeat_timeout' => "Délai max (sec) avant qu’un device soit jugé offline.",
    // Tunnel
    'tunnel_requests_dir'  => "Dossier où les demandes de tunnel sont stockées.",
    'tunnel_status_dir'    => "Dossier pour status des tunnels.",
    'tunnel_logfile'       => "Fichier de log des tunnels.",
    'tunnel_host'          => "Nom d’hôte des tunnels.",
    'scp_default_path'     => "Chemin par défaut pour SCP.",
    // Status
    'status_logfile'    => "Fichier log pour le status API.",
    'status_max_logs'   => "Nombre max de logs device (rotation).",
    // SSH
    'ssh_keys_logfile'  => "Log SSH keys.",
    'user_keys_sync_logfile' => "Log du script de synchro des clés utilisateurs.",
    'ssh_api_token'     => "Token API SSH autorisé (forcecommand).",
    // Metrics
    'metrics_logfile'   => "Log metrics API.",
    'backend_logfile'   => "Log g\xC3\xA9n\xC3\xA9ral backend API.",
    'device_keys_root'  => "Dossier cl\xC3\xA9s priv\xC3\xA9es devices.",
    'server_pubkey_date' => "Date de g\xC3\xA9n\xC3\xA9ration de la cl\xC3\xA9.",
    'server_key_last_deploy' => "Dernier d\xC3\xA9ploiement de la cl\xC3\xA9 serveur.",
    'builder_storage_root' => "Racine stockage temporaire builder.",
    'builder_logfile'       => "Log du builder.",
    'ntp_logfile'           => "Log du serveur NTP interne.",
    'device_type_icon_dir'  => "Répertoire des icônes DeviceType.",
    'builder_allowed_extensions' => "Extensions upload autoris\xC3\xA9es.",
    'builder_max_upload_size'    => "Taille max upload builder (octets).",
    // ForceCommand/tunnels
    'forcecommand_port_min'  => "Port minimal pour tunnels forcecommand.",
    'forcecommand_port_max'  => "Port max pour tunnels forcecommand.",
    'forcecommand_max_last_seen' => "Délai max last_seen pour valider un tunnel (sec).",
    'forcecommand_reservation_duration' => "Durée réservation port tunnel (sec).",
    // Flash/storage
    'flash_storage_root' => "Chemin racine pour stockage flash/distrib.",
    // DeviceController/service
    'device_logfile'    => "Log device API.",
    'device_note_logfile' => "Log notes device.",
    'storage_path'      => "Chemin racine stockage principal.",
    'key_sync_script'   => "Script de synchro des clés SSH.",
    'tunnel_debug_logfile' => "Log debug tunnel (fichiers temporaires).",
    'tunnel_timeout'    => "Timeout pour attente tunnel (sec).",
    // Admin/Metrics frontend
    'metrics_api_url'   => "Endpoint utilisé pour l’API metrics dans l’admin.",
];

$sensitive = [
    'db_user', 'db_pass', 'admin_pass', 'ssh_api_token'
];

// -- Organiser par catégorie/tab dynamiquement (modifiable au besoin)
$tabs = [
    'Database' => ['db_host', 'db_name', 'db_user', 'db_pass', 'db_charset'],
    'Admin/API/Auth' => ['admin_user', 'admin_pass', 'ssh_api_token'],
    'Devices/Status' => ['device_heartbeat_timeout', 'status_logfile', 'status_max_logs', 'device_logfile', 'device_note_logfile'],
    'Tunnel/Network' => ['tunnel_requests_dir','tunnel_status_dir','tunnel_logfile','tunnel_host','scp_default_path','tunnel_debug_logfile','tunnel_timeout','forcecommand_port_min','forcecommand_port_max','forcecommand_max_last_seen','forcecommand_reservation_duration'],
    'Storage/Flash'  => ['flash_storage_root','storage_path','key_sync_script','user_key_sync_script','device_keys_root'],
    'Metrics'        => ['backend_logfile','metrics_logfile','metrics_api_url'],
    'SSH/Server Keys' => ['ssh_keys_logfile','user_keys_sync_logfile','server_pubkey_date','server_key_last_deploy'],
    'Builder'        => ['builder_storage_root','builder_logfile','ntp_logfile','device_type_icon_dir','builder_allowed_extensions','builder_max_upload_size'],
];

// -- Sauvegarde (prototype : écriture du fichier config.php)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($has_pin || empty(array_intersect(array_keys($_POST), $sensitive)))) {
    // Màj dynamique (tu peux améliorer la sécurité ici !)
    $new_config = $config;
    foreach ($config as $key => $val) {
        if (isset($_POST[$key])) {
            $postVal = $_POST[$key];
            if ($postVal === "1" || $postVal === "true") $postVal = true;
            elseif ($postVal === "0" || $postVal === "false") $postVal = false;
            elseif (is_numeric($val) && is_numeric($postVal)) $postVal = $postVal + 0;
            $new_config[$key] = $postVal;
        }
    }
    // Écriture de config.php (exemple simplifié - fais une vraie vérif en prod !)
    $filecontent = "<?php\n// Version auto-generated " . date('Y-m-d H:i:s') . "\nreturn " . var_export($new_config, true) . ";\n";
    file_put_contents($config_file, $filecontent);
    $config = include $config_file;
    $saved = true;
}

$icons = [
    'Database'=>'🗄️','Admin/API/Auth'=>'🔐','Devices/Status'=>'📦',
    'Tunnel/Network'=>'🌐','Storage/Flash'=>'💾','Metrics'=>'📊',
    'SSH/Server Keys'=>'🔑','Builder'=>'🛠️'
];
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <title>MEETING - Global Settings</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body { background: #171b20 !important; color: #f3f7fa !important; min-height: 100vh; }
        .navbar { background: #111316 !important; color: #fff; min-height: 56px; box-shadow: 0 3px 12px #0008; }
        .navbar .brand { font-size: 1.35em; font-weight: bold; color: #17d1a7 !important; letter-spacing: 1.1px; padding-left: 16px; }
        .main-content { width: 100%; max-width: 1240px; margin: 0 auto; padding: 35px 2vw 40px 2vw; }
        .settings-panel { background: #20242a; border-radius: 13px; box-shadow: 0 4px 18px #0007; padding: 35px 38px 32px 38px; margin-bottom: 30px;}
        .settings-title { color: #17d1a7; font-size: 1.34em; font-weight: 600; margin-bottom: 28px;}
        .form-label { color: #b2cdf7; font-weight: 500; }
        .desc { color: #a1b2c8; font-size: 0.99em; margin-bottom: 6px;}
        .save-btn { background: #17d1a7; color: #20242a; border-radius: 8px; border: none; padding: 8px 17px; font-size: 1.04em;}
        .save-btn:hover { background: #149880; color: #fff; }
        .inline-save-btn { margin-left: 9px; border: none; background: none; color: #17d1a7; font-size: 1.15em; cursor: pointer;}
        .inline-save-btn:active { color: #fff; }
        .form-control, .form-check-input { background: #232832 !important; color: #fff !important; border: 1px solid #31353a; }
        .nav-tabs { border-bottom: 2px solid #232832;}
        .nav-tabs .nav-link { background: none; color: #eee; border: none; border-bottom: 3px solid transparent;}
        .nav-tabs .nav-link.active { border-color: #17d1a7; background: #232832; color: #17d1a7; }
        .field-row { display: flex; align-items: flex-end; gap: 20px; margin-bottom: 23px;}
        .field-row .form-control, .field-row .form-select { max-width: 310px;}
        .field-row .desc { min-width: 220px; max-width: 350px;}
        .lock-icon { color: #cbb1fb; font-size: 1.18em; margin-right:7px; }
        .hidden-credentials { background: #282933; border-radius: 7px; color: #bbb; padding: 4px 12px; border:1px dashed #31353a; }
        .pin-box { background: #20242a; border-radius: 13px; padding: 19px 32px; box-shadow: 0 4px 18px #0006; margin-bottom: 22px;}
        .alert-danger { background: #311e1e; color: #ff8585; border: 1px solid #c0392b;}
        @media (max-width: 900px) { .main-content { padding: 7px 2vw 10px 2vw;} .settings-panel { padding: 17px 4vw 16px 4vw;} }
    </style>
</head>
<body class="dark">
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container-fluid">
            <span class="brand">🟩 MEETING Admin</span>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 navlinks">
                    <?php foreach ($links as $link): ?>
                        <?php
                            $icon = isset($link['icon']) ? '<span class="nav-icon">'.htmlspecialchars($link['icon']).'</span>' : '';
                            $name = htmlspecialchars($link['name']);
                            if (isset($link['file'])) {
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['file']}\">{$icon}{$name}</a></li>";
                            } else if (isset($link['url'])) {
                                $target = isset($link['target']) ? " target=\"{$link['target']}\"" : "";
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['url']}\"$target>{$icon}{$name}</a></li>";
                            } else {
                                echo "<li class=\"nav-item\"><span class=\"nav-link\">{$icon}{$name}</span></li>";
                            }
                        ?>
                    <?php endforeach; ?>
                </ul>
            </div>
            <button class="dark-toggle" onclick="toggleDarkMode()" title="Toggle light/dark mode">
                <svg width="18" height="18" viewBox="0 0 20 20"><path fill="currentColor" d="M10 2a8 8 0 1 0 8 8a8 8 0 0 0-8-8Zm0 14a6 6 0 1 1 6-6a6 6 0 0 1-6 6Zm0-11a1 1 0 1 0 1 1a1 1 0 0 0-1-1Z"/></svg>
                Dark mode
            </button>
        </div>
    </nav>
    <div class="main-content">
        <div class="pin-box">
            <form method="POST" class="row g-2 align-items-center" style="margin:0;">
                <div class="col-auto"><b>Master PIN:</b></div>
                <div class="col-auto">
                    <input type="password" class="form-control" name="masterpin" maxlength="6" pattern="\d{4,10}" placeholder="******" style="width:110px;" <?= $has_pin ? 'value="******" disabled' : '' ?>>
                </div>
                <div class="col-auto">
                    <?php if (!$has_pin): ?>
                        <button class="btn btn-success btn-sm" type="submit">Unlock</button>
                    <?php else: ?>
                        <span style="color:#43a047;">✔️ Unlocked</span>
                    <?php endif; ?>
                </div>
                <?php if (isset($pin_error)): ?>
                    <div class="col-auto alert alert-danger py-1 px-2 mb-0 ms-3"><?= htmlspecialchars($pin_error) ?></div>
                <?php endif; ?>
                <div class="col-auto ms-3" style="color:#aaa;font-size:0.98em;">Champs sensibles masqués/sauvegardables seulement avec PIN</div>
            </form>
        </div>
        <?php if (!empty($saved)): ?>
            <div class="alert alert-success mb-3">✅ Modifications enregistrées !</div>
        <?php endif; ?>
        <div class="settings-panel">
            <div class="settings-title">Global Project Settings</div>
            <!-- Onglets -->
            <ul class="nav nav-tabs mb-4" id="settingsTabs" role="tablist">
                <?php $i = 0; foreach ($tabs as $tab => $fields): ?>
                <li class="nav-item" role="presentation">
                    <?php $slug = strtolower(str_replace(['/', ' '], '_', $tab)); ?>
                    <button class="nav-link<?= $i++ == 0 ? ' active' : '' ?>" id="tab-<?= $slug ?>" data-bs-toggle="tab" data-bs-target="#tabc-<?= $slug ?>" type="button" role="tab"><?= $icons[$tab] ?? '' ?> <?= htmlspecialchars($tab) ?></button>
                </li>
                <?php endforeach; ?>
            </ul>
            <form id="allSettingsForm" method="POST" autocomplete="off">
                <div class="tab-content" id="settingsTabsContent">
                    <?php $i = 0; foreach ($tabs as $tab => $fields): ?>
                    <?php $slug = strtolower(str_replace(['/', ' '], '_', $tab)); ?>
                    <div class="tab-pane fade<?= $i++ == 0 ? ' show active' : '' ?>" id="tabc-<?= $slug ?>" role="tabpanel">
                        <h4 style="color:#17d1a7;font-weight:600;margin-bottom:23px;"><?= $icons[$tab] ?? '' ?> <?= htmlspecialchars($tab) ?></h4>
                        <?php foreach ($fields as $key): if (!isset($config[$key])) continue; ?>
                            <div class="field-row" id="row-<?= htmlspecialchars($key) ?>">
                                <div class="w-100">
                                    <label class="form-label" for="<?= $key ?>"><?= htmlspecialchars($key) ?>
                                        <?php if (in_array($key, $sensitive)): ?><span class="lock-icon" title="PIN required">&#x1F512;</span><?php endif; ?>
                                    </label>
                                    <div class="desc"><?= htmlspecialchars($descriptions[$key] ?? '') ?></div>
                                    <?php
                                    $value = $config[$key];
                                    $type = 'text';
                                    if (is_numeric($value) && !preg_match('/^0\d+$/',$value)) $type = 'number';
                                    if (is_bool($value) || $value === "true" || $value === "false") $type = 'checkbox';
                                    $is_sensitive = in_array($key, $sensitive);
                                    ?>
                                    <?php if ($is_sensitive && !$has_pin): ?>
                                        <div class="hidden-credentials">PIN requise pour afficher/modifier ce champ.</div>
                                    <?php else: ?>
                                        <?php if ($type == 'checkbox'): ?>
                                            <input type="checkbox" class="form-check-input" id="<?= $key ?>" name="<?= $key ?>" value="1"<?= ($value || $value==="true") ? ' checked' : '' ?>>
                                        <?php elseif (strpos($key, 'pass') !== false || strpos($key, 'secret') !== false || strpos($key, 'token') !== false): ?>
                                            <input type="password" class="form-control" id="<?= $key ?>" name="<?= $key ?>" value="<?= htmlspecialchars($value) ?>" autocomplete="new-password">
                                        <?php else: ?>
                                            <input type="text" class="form-control" id="<?= $key ?>" name="<?= $key ?>" value="<?= htmlspecialchars($value) ?>">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <button class="inline-save-btn" type="button" title="Save only this field" onclick="saveSingleSetting('<?= $key ?>')" <?= ($is_sensitive && !$has_pin) ? 'disabled' : '' ?>>
                                        💾
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="text-end mt-4">
                    <button type="submit" class="save-btn" name="save_all">💾 Save All Changes</button>
                </div>
            </form>
        </div>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function saveSingleSetting(key) {
    let form = document.getElementById('allSettingsForm');
    let input = document.createElement('input');
    input.type = 'hidden';
    input.name = 'save_single';
    input.value = key;
    form.appendChild(input);
    form.submit();
}
function toggleDarkMode() {
    document.body.classList.toggle('dark');
}
</script>
</body>
</html>
