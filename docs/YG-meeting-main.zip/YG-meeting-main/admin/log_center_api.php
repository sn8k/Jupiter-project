<?php
// File: admin/log_center_api.php
// Version: 1.2.0
session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    echo json_encode(['success'=>false, 'error'=>'Not authorized']);
    exit;
}

// Dynamically build folders list from config.php (create missing dirs)
$config = include __DIR__ . '/../api/config.php';
$logFolders = [];
foreach ($config as $k => $v) {
    if (str_ends_with($k, '_logfile')) {
        $dir = dirname($v);
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        $real = realpath($dir) ?: $dir;
        $logFolders[$real] = true;
    }
}
if (empty($logFolders)) {
    $dir = __DIR__ . '/../api/logs';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $real = realpath($dir) ?: $dir;
    $logFolders[$real] = true;
}
$logFolders = array_keys($logFolders);

function is_valid_dir(string $dir): bool {
    global $logFolders;
    $norm = rtrim($dir, '/') . '/';
    foreach ($logFolders as $allowed) {
        if ($norm === rtrim($allowed, '/') . '/' && is_dir($allowed)) {
            return true;
        }
    }
    return false;
}
$action = $_GET['action'] ?? '';
$dir = $_GET['dir'] ?? '';
$file = isset($_GET['file']) ? basename($_GET['file']) : null;

if ($action === 'list_files' && is_valid_dir($dir)) {
    $res = [];
    foreach (glob($dir.'*.log') as $f) {
        $res[] = [
            'name' => basename($f),
            'size' => filesize($f),
            'mtime'=> date('Y-m-d H:i:s', filemtime($f)),
        ];
    }
    echo json_encode(['success'=>true, 'files'=>$res]);
    exit;
}

if ($action === 'read' && is_valid_dir($dir) && $file) {
    $lines = isset($_GET['lines']) ? max(10,intval($_GET['lines'])) : 100;
    $search = $_GET['search'] ?? '';
    $type = $_GET['type'] ?? '';
    $full = realpath($dir.'/'.$file);
    if (!$full || strpos($full, realpath($dir)) !== 0 || !file_exists($full)) {
        echo json_encode(['success'=>false, 'error'=>'File not found']);
        exit;
    }
    // Lecture tail, filtrage texte/type
    $buffer = [];
    $total = 0; $match = 0;
    $start = 0;
    $fp = fopen($full, "r");
    if ($fp !== false) {
        fseek($fp, 0, SEEK_END);
        $pos = ftell($fp);
        $line = '';
        $cnt = 0;
        while ($pos > 0 && $cnt < $lines*10) {
            $pos--;
            fseek($fp, $pos, SEEK_SET);
            $char = fgetc($fp);
            if ($char === "\n" && $line !== '') {
                array_unshift($buffer, strrev($line));
                $line = '';
                $cnt++;
            } else {
                $line .= $char;
            }
        }
        if ($line !== '') array_unshift($buffer, strrev($line));
        fclose($fp);
    }
    // Filtrage search/type
    $display = [];
    foreach ($buffer as $l) {
        $l = trim($l); if ($l==="") continue; $total++;
        $ok = true;
        if ($search && !preg_match('/'.preg_quote($search,'/').'/i', $l)) $ok=false;
        if ($type) {
            if ($type==='error' && stripos($l,'error')===false) $ok=false;
            if ($type==='warning' && stripos($l,'warn')===false) $ok=false;
            if ($type==='info' && stripos($l,'info')===false) $ok=false;
            if ($type==='debug' && stripos($l,'debug')===false) $ok=false;
        }
        if ($ok) { $display[] = $l; $match++; }
    }
    $display = array_slice($display, -1*intval($_GET['lines']??100));
    $start = max(0, $total - count($display));
    echo json_encode([
        'success'=>true,
        'log'=>$display,
        'total'=>$total,
        'match'=>$match,
        'start'=>$start,
        'live'=>isset($_GET['live'])
    ]);
    exit;
}

if ($action === 'download' && is_valid_dir($dir) && $file) {
    $full = realpath($dir.'/'.$file);
    if (!$full || strpos($full, realpath($dir)) !== 0 || !file_exists($full)) {
        http_response_code(404);
        exit;
    }
    header('Content-Type: text/plain');
    header('Content-Disposition: attachment; filename="' . $file . '"');
    readfile($full);
    exit;
}

if ($action === 'export' && is_valid_dir($dir) && $file) {
    $format = $_GET['format'] ?? 'csv';
    $lines = isset($_GET['lines']) ? max(10,intval($_GET['lines'])) : 100;
    $search = $_GET['search'] ?? '';
    $type = $_GET['type'] ?? '';
    $full = realpath($dir.'/'.$file);
    if (!$full || strpos($full, realpath($dir)) !== 0 || !file_exists($full)) {
        http_response_code(404); exit;
    }
    $buffer = file($full, FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES) ?: [];
    $filtered = [];
    foreach ($buffer as $l) {
        $ok = true;
        if ($search && !preg_match('/'.preg_quote($search,'/').'/i', $l)) $ok=false;
        if ($type) {
            if ($type==='error' && stripos($l,'error')===false) $ok=false;
            if ($type==='warning' && stripos($l,'warn')===false) $ok=false;
            if ($type==='info' && stripos($l,'info')===false) $ok=false;
            if ($type==='debug' && stripos($l,'debug')===false) $ok=false;
        }
        if ($ok) $filtered[] = $l;
    }
    $filtered = array_slice($filtered, -1*intval($lines));
    if ($format==='json') {
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="'.$file.'.json"');
        echo json_encode($filtered, JSON_PRETTY_PRINT);
    } else {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="'.$file.'.csv"');
        foreach ($filtered as $line) echo '"'.str_replace('"','""',$line)."\"\n";
    }
    exit;
}

if ($action === 'clear' && is_valid_dir($dir) && $file) {
    $full = realpath($dir.'/'.$file);
    if (!$full || strpos($full, realpath($dir)) !== 0 || !file_exists($full)) {
        echo json_encode(['success'=>false, 'error'=>'File not found']);
        exit;
    }
    file_put_contents($full, '');
    echo json_encode(['success'=>true]);
    exit;
}

if ($action === 'delete' && is_valid_dir($dir) && $file) {
    $full = realpath($dir.'/'.$file);
    if (!$full || strpos($full, realpath($dir)) !== 0 || !file_exists($full)) {
        echo json_encode(['success'=>false, 'error'=>'File not found']);
        exit;
    }
    unlink($full);
    echo json_encode(['success'=>true]);
    exit;
}

if ($action === 'archive' && is_valid_dir($dir) && $file) {
    $full = realpath($dir.'/'.$file);
    if (!$full || strpos($full, realpath($dir)) !== 0 || !file_exists($full)) {
        echo json_encode(['success'=>false, 'error'=>'File not found']);
        exit;
    }
    $zip = $full . '.zip';
    $zipObj = new ZipArchive();
    if ($zipObj->open($zip, ZipArchive::CREATE)!==TRUE) {
        echo json_encode(['success'=>false, 'error'=>'Archive failed']);
        exit;
    }
    $zipObj->addFile($full, $file);
    $zipObj->close();
    echo json_encode(['success'=>true, 'archive'=>basename($zip)]);
    exit;
}

if ($action === 'archive_all' && is_valid_dir($dir)) {
    $zip = $dir . 'logs_' . date('Ymd_His') . '.zip';
    $zipObj = new ZipArchive();
    if ($zipObj->open($zip, ZipArchive::CREATE)!==TRUE) {
        echo json_encode(['success'=>false, 'error'=>'Archive failed']);
        exit;
    }
    foreach (glob($dir.'*.log') as $f) $zipObj->addFile($f, basename($f));
    $zipObj->close();
    echo json_encode(['success'=>true, 'archive'=>basename($zip)]);
    exit;
}

echo json_encode(['success'=>false, 'error'=>'Bad request']);
exit;
