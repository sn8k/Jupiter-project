<?php
// File: admin/log_center.php
// Version: 1.2.0
// Date: 2025-06-11
// Author: Meeting Server Team
// Description: Advanced LogCenter (multi-dossiers, filtre, actions, stats, color, live, search)

session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: index.php');
    exit;
}
$links = require __DIR__ . '/links.php';
$config = include __DIR__ . '/../api/config.php';

// Folders to scan (derived from all *_logfile entries in config.php)
$logFolders = [];
foreach ($config as $k => $v) {
    if (str_ends_with($k, '_logfile')) {
        $dir = dirname($v);
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        $real = realpath($dir) ?: $dir;
        $logFolders[$real] = true;
    }
}
if (empty($logFolders)) {
    $dir = __DIR__ . '/../api/logs';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $real = realpath($dir) ?: $dir;
    $logFolders[$real] = true;
}
$tmpFolders = [];
foreach (array_keys($logFolders) as $dir) {
    $title = 'Logs';
    if (strpos($dir, '/api/') !== false) $title = 'API Logs';
    elseif (strpos($dir, '/tmp') !== false) $title = 'Temp Logs';
    else $title = ucfirst(basename($dir)).' Logs';
    $tmpFolders[$title] = rtrim($dir, '/') . '/';
}
$logFolders = $tmpFolders;

// Notifications (PHP)
$notifications = [];
if (isset($_SESSION['notif'])) {
    $notifications[] = $_SESSION['notif'];
    unset($_SESSION['notif']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>LogCenter - Server Logs</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fira+Mono:wght@500&family=Montserrat:wght@600&display=swap" rel="stylesheet">
    <style>
        :root {
            --main-bg: #191c23;
            --panel-bg: #24283b;
            --accent: #17d1a7;
            --accent2: #3083dc;
            --input-bg: #232936;
            --input-border: #303545;
            --text-main: #f3f7fa;
            --text-muted: #90a4b7;
            --error: #e84d6c;
            --success: #5df88a;
        }
        body {
            background: linear-gradient(120deg, #171b20 60%, #212b42 100%);
            min-height: 100vh;
            font-family: 'Montserrat', 'Fira Mono', monospace;
            color: var(--text-main);
            margin: 0;
        }
        .navbar {
            background: #111316;
            display: flex;
            align-items: center;
            padding: 0.7em 1.2em;
            border-bottom: 2px solid var(--accent2);
            justify-content: space-between;
            color: #fff;
            min-height: 56px;
            box-shadow: 0 3px 12px #0008;
        }
        .navbar .brand {
            display: flex;
            align-items: center;
            font-size: 1.3em;
            font-weight: 700;
            letter-spacing: 1px;
            color: var(--accent);
            gap: 0.5em;
        }
        .navbar .actions {
            display: flex;
            gap: 1em;
            align-items: center;
        }
        .navbar button, .navbar .darkmode-btn {
            background: var(--input-bg);
            color: var(--text-main);
            border: none;
            border-radius: 7px;
            padding: 0.35em 1em;
            cursor: pointer;
            font-size: 1em;
            font-family: inherit;
            transition: background 0.18s, color 0.16s;
        }
        .navbar .darkmode-btn.active {
            background: var(--accent2);
            color: #fff;
        }
        .navbar button:hover, .navbar .darkmode-btn:hover {
            background: var(--accent2);
            color: #fff;
        }
        .container-logcenter {
            display: flex;
            max-width: 1220px;
            margin: 2.4em auto 0 auto;
            gap: 1.6em;
            min-height: 600px;
            padding: 0 1em;
        }
        .sidebar {
            width: 220px;
            background: #20242a;
            border-radius: 13px;
            box-shadow: 0 2px 14px #0004;
            padding: 1.1em 1em 1.5em 1em;
            height: fit-content;
        }
        .sidebar h3 {
            font-size: 1.07em;
            color: var(--accent2);
            margin-bottom: 15px;
        }
        .sidebar ul { list-style: none; padding: 0; margin: 0 0 15px 0; }
        .sidebar li {
            margin: 0 0 9px 0;
            padding: 6px 10px;
            border-radius: 8px;
            color: #fff;
            background: none;
            cursor: pointer;
            font-size: 1.08em;
        }
        .sidebar li.active, .sidebar li:hover {
            background: #2a2e38;
            color: var(--accent);
        }
        .sidebar .folder-actions {
            margin-top: 13px;
        }
        .sidebar .folder-actions button {
            width: 100%; margin-bottom:6px;
            background: #17d1a7; color: #20242a; font-weight:600;
        }
        .sidebar .folder-actions button:hover { background: #149880; color: #fff; }
        .main-panel {
            flex: 1;
            min-width: 0;
        }
        .notification-box {
            background: #282933;
            border-radius: 11px;
            box-shadow: 0 2px 12px #0006;
            color: #e7fff6;
            font-size: 1.08em;
            padding: 1.1em 1.3em;
            margin-bottom: 18px;
            border-left: 5px solid #17d1a7;
            display: none;
            animation: notif-in 0.6s cubic-bezier(.16,.88,.63,1.46) both;
        }
        .notification-box.active { display: block; }
        .notification-box .notif-close {
            float: right; cursor: pointer; color: #17d1a7; font-size:1.1em;
            background: none; border:none; outline:none; margin-left:14px;
        }
        @keyframes notif-in {
            0% { transform: translateY(-25px); opacity: 0; }
            100% { transform: none; opacity: 1;}
        }
        .logcenter-panel {
            background: #20242a;
            border-radius: 14px;
            box-shadow: 0 2px 12px 0 #0007;
            padding: 2.2em 2em 1.8em 2em;
            margin-bottom: 2em;
            min-height: 220px;
        }
        .logcenter-title {
            color: var(--accent2);
            font-size: 1.28em;
            font-weight: 600;
            margin-bottom: 28px;
        }
        .file-list-table {
            width: 100%; border-collapse: collapse;
            margin-bottom: 16px;
        }
        .file-list-table th, .file-list-table td {
            font-size:1.06em; padding:7px 10px; text-align:left;
            color: #d7f6f9;
        }
        .file-list-table th { color: #17d1a7; border-bottom: 2px solid #232832; }
        .file-list-table tr:hover { background: #22262f; }
        .file-list-table .file-actions button {
            background: #232832; color: #17d1a7; border-radius:6px; border:none; padding:4px 10px; margin-right:3px; font-size:1em;
        }
        .file-list-table .file-actions button:hover { background: #17d1a7; color: #20242a; }
        .file-list-table .delete { color: #e84d6c; }
        .file-list-table .delete:hover { background: #e84d6c; color: #fff; }
        .log-toolbar {
            display: flex;
            gap: 1.1em;
            flex-wrap: wrap;
            align-items: flex-end;
            margin-bottom: 14px;
        }
        .log-toolbar input, .log-toolbar select {
            background: #232832; color: #fff; border: 1px solid #31353a;
            border-radius: 6px; font-size: 1em; padding: 5px 8px; min-width:80px;
        }
        .log-toolbar button {
            background: #17d1a7;
            color: #20242a;
            border-radius: 8px;
            border: none;
            padding: 7px 13px;
            font-size: 1.01em;
        }
        .log-toolbar button:hover { background: #149880; color: #fff; }
        .log-toolbar .danger { background: #e84d6c; color: #fff; }
        .log-toolbar .danger:hover { background: #b81b3d; color: #fff; }
        .log-content {
            background: #232832;
            border-radius: 7px;
            color: #c1e1fd;
            font-family: "Fira Mono", "Consolas", monospace;
            font-size: 1em;
            max-height: 380px;
            min-height: 90px;
            overflow: auto;
            border: 1px solid #232a33;
            padding: 15px 13px;
            white-space: pre-wrap;
            margin-bottom: 1.5em;
        }
        .log-content .info { color: #99e699; }
        .log-content .warning { color: #ffd97a; }
        .log-content .error { color: #e84d6c; font-weight: bold;}
        .log-content .debug { color: #7dcfff; }
        .log-content .line-num { color: #505080; margin-right: 8px; font-size:0.94em;}
        .log-stats { color:#aeeeee; font-size:1em; margin-bottom:1em; }
        .live-indicator { color:#17d1a7; font-weight:700; margin-left:10px; font-size:1.12em; }
        @media (max-width: 900px) {
            .container-logcenter { flex-direction:column; gap:0.4em; }
            .sidebar { width:100%; }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="brand">
            <svg height="30" width="30" viewBox="0 0 64 64" style="margin-right:7px;">
                <circle cx="32" cy="32" r="29" stroke="#17d1a7" stroke-width="4" fill="none"/>
                <circle cx="32" cy="32" r="17" stroke="#3083dc" stroke-width="2" opacity="0.3" fill="none"/>
                <circle cx="32" cy="32" r="7" fill="#17d1a7" opacity="0.8"/>
                <path d="M32 8V24" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
                <path d="M32 40V56" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
                <path d="M8 32H24" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
                <path d="M40 32H56" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
            </svg>
            LogCenter
        </div>
        <div class="actions">
            <button onclick="window.location.href='?logout=1'">Logout</button>
            <button class="darkmode-btn" id="darkModeBtn" title="Toggle dark/light mode">🌙</button>
        </div>
    </nav>
    <div class="container-logcenter">
        <div class="sidebar">
            <h3>Folders</h3>
            <ul id="folders">
                <?php foreach ($logFolders as $title => $dir): ?>
                    <li data-dir="<?= htmlspecialchars($dir) ?>" class="<?= $title==='API Logs'?'active':'' ?>"><?= htmlspecialchars($title) ?></li>
                <?php endforeach; ?>
            </ul>
            <div class="folder-actions">
                <button onclick="archiveAllLogs()" title="Archive all logs in this folder">🗜️ Archive All</button>
            </div>
        </div>
        <div class="main-panel">
            <div id="notifBox" class="notification-box<?= !empty($notifications) ? ' active' : '' ?>">
                <?php if (!empty($notifications)):
                    foreach($notifications as $n): ?>
                        <span><?= htmlspecialchars($n) ?></span>
                    <?php endforeach;
                else: ?>
                    <span style="color:#b6d7cc;">No notifications</span>
                <?php endif; ?>
                <button class="notif-close" onclick="hideNotifBox()" title="Close notification">&times;</button>
            </div>
            <div class="logcenter-panel">
                <div class="logcenter-title">Server Logs Viewer</div>
                <div id="fileListArea"></div>
                <form class="log-toolbar" id="logToolbar" onsubmit="return false;">
                    <label>
                        File:
                        <select id="logFile" style="min-width:200px;"></select>
                    </label>
                    <label>
                        Lines:
                        <input type="number" id="logLines" value="100" min="10" max="1000" step="10">
                    </label>
                    <label>
                        Search:
                        <input type="text" id="logSearch" placeholder="Error, regex...">
                    </label>
                    <label>
                        Type:
                        <select id="logType">
                            <option value="">All</option>
                            <option value="error">Error</option>
                            <option value="warning">Warning</option>
                            <option value="info">Info</option>
                            <option value="debug">Debug</option>
                        </select>
                    </label>
                    <button type="button" onclick="refreshLog()">⟳ Refresh</button>
                    <button type="button" onclick="downloadLog()" title="Download this log">⬇️ Download</button>
                    <button type="button" onclick="exportLog('csv')" title="Export CSV">📑 CSV</button>
                    <button type="button" onclick="exportLog('json')" title="Export JSON">🧾 JSON</button>
                    <button type="button" class="danger" onclick="clearLog()" title="Clear this log">🧹 Clear</button>
                    <button type="button" class="danger" onclick="deleteLog()" title="Delete this log">❌ Delete</button>
                    <label style="margin-left:12px;">
                        <input type="checkbox" id="liveMode" onchange="toggleLiveMode()"> Live
                    </label>
                </form>
                <div class="log-stats" id="logStats"></div>
                <div class="log-content" id="logContent">Select a log file and refresh to display logs.</div>
            </div>
        </div>
    </div>
    <script>
    // ------------------- Helpers
    function ajax(url, cb) {
        fetch(url)
            .then(r => r.json())
            .then(cb)
            .catch(() => cb({success:false,error:'AJAX error'}));
    }
    function hideNotifBox() {
        document.getElementById('notifBox').classList.remove('active');
    }
    // ------------------- Folder/file navigation
    let currentFolder = "<?= reset($logFolders) ?>";
    let liveModeTimer = null;

    function loadFileList() {
        ajax('log_center_api.php?action=list_files&dir=' + encodeURIComponent(currentFolder), function(data){
            let area = document.getElementById('fileListArea');
            let fileSel = document.getElementById('logFile');
            fileSel.innerHTML = '';
            area.innerHTML = '';
            if (data.success && data.files) {
                let tbl = `<table class="file-list-table"><tr>
                    <th>File</th><th>Size</th><th>Last Modified</th><th>Actions</th></tr>`;
                data.files.forEach(f => {
                    let sel = document.createElement('option');
                    sel.value = f.name;
                    sel.innerText = f.name;
                    fileSel.appendChild(sel);
                    tbl += `<tr>
                        <td>${escapeHtml(f.name)}</td>
                        <td>${formatBytes(f.size)}</td>
                        <td>${f.mtime}</td>
                        <td class="file-actions">
                            <button onclick="selectLogFile('${escapeHtml(f.name)}')">Open</button>
                            <button onclick="downloadLogFile('${escapeHtml(f.name)}')">⬇️</button>
                            <button class="danger" onclick="deleteLogFile('${escapeHtml(f.name)}')">❌</button>
                            <button onclick="archiveLogFile('${escapeHtml(f.name)}')">🗜️</button>
                        </td>
                    </tr>`;
                });
                tbl += "</table>";
                area.innerHTML = tbl;
            } else {
                area.innerHTML = "<span style='color:#e84d6c;'>No log files found.</span>";
            }
            refreshLog();
        });
    }
    function selectLogFile(name) {
        let fileSel = document.getElementById('logFile');
        for(let i=0;i<fileSel.options.length;i++) {
            if(fileSel.options[i].value===name) {
                fileSel.selectedIndex=i; break;
            }
        }
        refreshLog();
    }
    function downloadLogFile(name) {
        window.open('log_center_api.php?action=download&dir=' + encodeURIComponent(currentFolder) + '&file=' + encodeURIComponent(name));
    }
    function deleteLogFile(name) {
        if(confirm('Delete this log file?')) {
            ajax('log_center_api.php?action=delete&dir=' + encodeURIComponent(currentFolder) + '&file=' + encodeURIComponent(name), function(data){
                loadFileList();
                if(data.success) notify("Log deleted.");
            });
        }
    }
    function archiveLogFile(name) {
        ajax('log_center_api.php?action=archive&dir=' + encodeURIComponent(currentFolder) + '&file=' + encodeURIComponent(name), function(data){
            if(data.success) notify("Log archived: " + escapeHtml(data.archive));
        });
    }
    function archiveAllLogs() {
        ajax('log_center_api.php?action=archive_all&dir=' + encodeURIComponent(currentFolder), function(data){
            if(data.success) notify("All logs archived.");
        });
    }
    function downloadLog() {
        let file = document.getElementById('logFile').value;
        if(file) downloadLogFile(file);
    }
    function clearLog() {
        let file = document.getElementById('logFile').value;
        if(file && confirm("Clear this log file?")) {
            ajax('log_center_api.php?action=clear&dir='+encodeURIComponent(currentFolder)+'&file='+encodeURIComponent(file), function(data){
                refreshLog();
                if(data.success) notify("Log cleared.");
            });
        }
    }
    function deleteLog() {
        let file = document.getElementById('logFile').value;
        if(file) deleteLogFile(file);
    }
    function exportLog(format) {
        let file = document.getElementById('logFile').value;
        let lines = document.getElementById('logLines').value;
        let search = document.getElementById('logSearch').value;
        let type = document.getElementById('logType').value;
        if(file) window.open('log_center_api.php?action=export&format='+format+'&dir='+encodeURIComponent(currentFolder)+'&file='+encodeURIComponent(file)+'&lines='+lines+'&search='+encodeURIComponent(search)+'&type='+encodeURIComponent(type));
    }
    function formatBytes(bytes) {
        if (!bytes || isNaN(bytes)) return '—';
        if (bytes < 1024) return bytes + ' B';
        let k = 1024;
        let sizes = ['KB', 'MB', 'GB', 'TB', 'PB'];
        let i = Math.floor(Math.log(bytes) / Math.log(k));
        return (bytes / Math.pow(k, i)).toFixed(2) + ' ' + sizes[i-1];
    }
    function escapeHtml(t) {
        if (!t) return '';
        return t.replace(/[<>&"']/g, m => ({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[m]));
    }
    // ------------------- Log viewer & stats
    function refreshLog() {
        let file = document.getElementById('logFile').value;
        let lines = document.getElementById('logLines').value;
        let search = document.getElementById('logSearch').value;
        let type = document.getElementById('logType').value;
        if(!file) {
            document.getElementById('logContent').innerHTML = "<span style='color:#aaa;'>No log selected.</span>";
            document.getElementById('logStats').innerText = '';
            return;
        }
        ajax('log_center_api.php?action=read&dir='+encodeURIComponent(currentFolder)+'&file='+encodeURIComponent(file)+'&lines='+lines+'&search='+encodeURIComponent(search)+'&type='+encodeURIComponent(type), function(data){
            let html = "";
            let stats = "";
            if(data.success && data.log) {
                let countErr=0, countWarn=0, countInfo=0, countDebug=0;
                html += data.log.map((l,i) => {
                    let klass = "";
                    if(/error/i.test(l)) klass+=" error",countErr++;
                    else if(/warn/i.test(l)) klass+=" warning",countWarn++;
                    else if(/debug/i.test(l)) klass+=" debug",countDebug++;
                    else if(/info/i.test(l)) klass+=" info",countInfo++;
                    return `<span class="line-num">${data.start+i+1}</span><span class="${klass.trim()}">${escapeHtml(l)}</span>`;
                }).join("\n");
                stats = `Lines: <b>${data.total}</b> | Errors: <span style="color:#e84d6c;">${countErr}</span> | Warnings: <span style="color:#ffd97a;">${countWarn}</span> | Info: <span style="color:#99e699;">${countInfo}</span> | Debug: <span style="color:#7dcfff;">${countDebug}</span>`;
                if(data.live) stats += `<span class="live-indicator">LIVE</span>`;
                if(data.match) stats += ` | <b>${data.match} match${data.match>1?'es':''}</b>`;
            } else {
                html = "<span style='color:#e84d6c;'>No log or error.</span>";
            }
            document.getElementById('logContent').innerHTML = `<pre style="margin:0;font-size:1em;line-height:1.48em;">${html}</pre>`;
            document.getElementById('logStats').innerHTML = stats;
        });
    }
    // --------------- Live mode (tail-f)
    function toggleLiveMode() {
        if(document.getElementById('liveMode').checked) {
            liveModeTimer = setInterval(refreshLog, 2000);
        } else {
            if(liveModeTimer) clearInterval(liveModeTimer);
            liveModeTimer = null;
        }
    }
    // --------------- Notif
    function notify(msg) {
        let box = document.getElementById('notifBox');
        box.classList.add('active');
        box.querySelector('span').innerText = msg;
        setTimeout(()=>{ box.classList.remove('active'); }, 5000);
    }
    // --------------- Folders navigation
    document.querySelectorAll('#folders li').forEach(li => {
        li.onclick = function() {
            document.querySelectorAll('#folders li').forEach(el=>el.classList.remove('active'));
            this.classList.add('active');
            currentFolder = this.dataset.dir;
            loadFileList();
        }
    });
    document.addEventListener("DOMContentLoaded", function() {
        loadFileList();
        let saved = localStorage.getItem('admin_theme');
        setMode(saved === "light" ? "light" : "dark");
        document.getElementById('darkModeBtn').onclick = function() {
            const isLight = document.body.classList.toggle('light-mode');
            this.innerText = isLight ? '🌞' : '🌙';
            localStorage.setItem('admin_theme', isLight ? 'light' : 'dark');
        };
    });
    function setMode(mode) {
        if (mode === "light") {
            document.body.classList.add('light-mode');
            document.getElementById('darkModeBtn').innerText = '🌞';
        } else {
            document.body.classList.remove('light-mode');
            document.getElementById('darkModeBtn').innerText = '🌙';
        }
        localStorage.setItem('admin_theme', mode);
    }
    </script>
</body>
</html>
