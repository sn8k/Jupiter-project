<?php
// File: admin/index.php
// Version: 1.3.1
// Date: 2025-06-13
// Author: Meeting Server Team
// Description: Admin login page for Meeting API utilities, credentials taken from config.php
// Changelog:
// - 1.3.0 (2025-06-13): store Distrib Builder token in session on login

session_start();

// Charge login/pass depuis config.php (array)
$config = require(__DIR__ . '/../api/config.php');
$ADMIN_USER = $config['admin_user'] ?? 'admin';
$ADMIN_PASS = $config['admin_pass'] ?? 'change_this';

try {
    $pdo = new PDO(
        "mysql:host={$config['db_host']};dbname={$config['db_name']};charset={$config['db_charset']}",
        $config['db_user'],
        $config['db_pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    $pdo = null;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';
    $ok = false;
    if ($pdo) {
        $stmt = $pdo->prepare('SELECT password FROM builder_users WHERE username=? AND role="admin"');
        $stmt->execute([$user]);
        $hash = $stmt->fetchColumn();
        if ($hash && password_verify($pass, $hash)) {
            $ok = true;
        }
    }
    if (!$ok && $user === $ADMIN_USER && $pass === $ADMIN_PASS) {
        $ok = true;
    }
    if ($ok) {
        $_SESSION['admin'] = true;
        if ($pdo) {
            $stmt = $pdo->prepare('SELECT token FROM builder_users WHERE username=?');
            $stmt->execute([$user]);
            $_SESSION['builder_token'] = $stmt->fetchColumn() ?: '';
        }
        header('Location: dashboard.php');
        exit;
    }
    $error = "Invalid credentials.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Meeting Admin Login</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fira+Mono:wght@500&family=Montserrat:wght@600&display=swap" rel="stylesheet">
    <style>
        :root {
            --main-bg: #191c23;
            --panel-bg: #24283b;
            --accent: #37e6e8;
            --accent2: #3083dc;
            --input-bg: #232936;
            --input-border: #303545;
            --text-main: #f7fafd;
            --text-muted: #90a4b7;
            --error: #e84d6c;
        }
        body {
            background: linear-gradient(120deg, #191c23 60%, #212b42 100%);
            min-height: 100vh;
            font-family: 'Montserrat', 'Fira Mono', monospace;
            color: var(--text-main);
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            background: var(--panel-bg);
            border-radius: 14px;
            box-shadow: 0 8px 24px 0 #000a  ;
            padding: 2.5rem 2rem 2rem 2rem;
            min-width: 330px;
            max-width: 350px;
            width: 95%;
            text-align: center;
        }
        .logo-net {
            margin-bottom: 1.2rem;
        }
        .logo-net svg {
            height: 56px;
            width: 56px;
            display: inline-block;
        }
        h1 {
            margin: 0 0 0.2em 0;
            font-weight: 600;
            letter-spacing: 1px;
            font-size: 2rem;
            color: var(--accent);
        }
        .subtitle {
            color: var(--text-muted);
            font-size: 1rem;
            margin-bottom: 1.7em;
            letter-spacing: 0.5px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 1em;
        }
        input[type="text"], input[type="password"] {
            background: var(--input-bg);
            border: 1.5px solid var(--input-border);
            border-radius: 7px;
            font-size: 1rem;
            color: var(--text-main);
            padding: 0.8em 1em;
            transition: border 0.2s;
            outline: none;
            font-family: 'Fira Mono', monospace;
        }
        input[type="text"]:focus, input[type="password"]:focus {
            border-color: var(--accent2);
        }
        button {
            background: linear-gradient(100deg, var(--accent), var(--accent2));
            color: #fff;
            font-weight: 600;
            font-size: 1.07em;
            border: none;
            border-radius: 7px;
            padding: 0.9em 0;
            box-shadow: 0 2px 6px 0 #0003;
            cursor: pointer;
            transition: background 0.2s, transform 0.13s;
        }
        button:hover {
            background: linear-gradient(90deg, var(--accent2) 60%, var(--accent));
            transform: translateY(-2px) scale(1.02);
        }
        .error {
            color: var(--error);
            margin-bottom: 1em;
            font-size: 1em;
        }
        .footer {
            margin-top: 2.3em;
            font-size: 0.92em;
            color: var(--text-muted);
            letter-spacing: 0.5px;
        }
        @media (max-width: 500px) {
            .container { min-width: 98vw; padding: 2rem 0.8rem; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo-net">
            <!-- SVG icon: network/IOT style -->
            <svg viewBox="0 0 64 64" fill="none">
                <circle cx="32" cy="32" r="30" stroke="#37e6e8" stroke-width="3"/>
                <circle cx="32" cy="32" r="19" stroke="#3083dc" stroke-width="2" opacity="0.3"/>
                <circle cx="32" cy="32" r="7" fill="#37e6e8" opacity="0.7"/>
                <path d="M32 8V24" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
                <path d="M32 40V56" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
                <path d="M8 32H24" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
                <path d="M40 32H56" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
            </svg>
        </div>
        <h1>Meeting Admin</h1>
        <div class="subtitle">IoT Device & Network Utilities</div>
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="post" autocomplete="off">
            <input type="text" name="username" placeholder="Username" required autofocus>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <div class="footer">
            <span>© <?= date('Y') ?> Meeting Project &ndash; Admin Panel</span>
        </div>
    </div>
</body>
</html>
