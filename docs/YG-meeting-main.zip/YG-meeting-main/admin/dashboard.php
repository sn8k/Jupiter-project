<?php
// File: admin/dashboard.php
// Version: 1.2.1
// Date: 2025-05-31
// Author: Meeting Server Team
// Description: Admin dashboard with dynamic links, live metrics (AJAX), notification box, dark/light mode, logout

session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: index.php');
    exit;
}

// Gestion "Last access date"
if (!isset($_SESSION['last_access'])) {
    $_SESSION['last_access'] = date('Y-m-d H:i:s');
}
$last_access = $_SESSION['last_access'];
$_SESSION['last_access'] = date('Y-m-d H:i:s'); // Mise à jour

// Charger la config centralisée et les liens dynamiques
$config = include __DIR__ . '/../../api/config.php';
$links = require __DIR__ . '/links.php';

// Paramètres configurables (API Metrics URL etc.)
$metrics_api_url = $config['metrics_api_url'] ?? '/api/metrics';

// Gestion notifications (exemple : tu peux injecter ici en PHP ou remplir dynamiquement en JS)
$notifications = [];
if (isset($_SESSION['notif'])) {
    $notifications[] = $_SESSION['notif'];
    unset($_SESSION['notif']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Meeting Admin Dashboard</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Fira+Mono:wght@500&family=Montserrat:wght@600&display=swap" rel="stylesheet">
    <style>
        :root {
            --main-bg: #191c23;
            --panel-bg: #24283b;
            --accent: #17d1a7;
            --accent2: #3083dc;
            --input-bg: #232936;
            --input-border: #303545;
            --text-main: #f3f7fa;
            --text-muted: #90a4b7;
            --error: #e84d6c;
            --success: #5df88a;
        }
        body {
            background: linear-gradient(120deg, #171b20 60%, #212b42 100%);
            min-height: 100vh;
            font-family: 'Montserrat', 'Fira Mono', monospace;
            color: var(--text-main);
            margin: 0;
        }
        .navbar {
            background: #111316;
            display: flex;
            align-items: center;
            padding: 0.7em 1.2em;
            border-bottom: 2px solid var(--accent2);
            justify-content: space-between;
            color: #fff;
            min-height: 56px;
            box-shadow: 0 3px 12px #0008;
        }
        .navbar .brand {
            display: flex;
            align-items: center;
            font-size: 1.3em;
            font-weight: 700;
            letter-spacing: 1px;
            color: var(--accent);
            gap: 0.5em;
        }
        .navbar .actions {
            display: flex;
            gap: 1em;
            align-items: center;
        }
        .navbar button, .navbar .darkmode-btn {
            background: var(--input-bg);
            color: var(--text-main);
            border: none;
            border-radius: 7px;
            padding: 0.35em 1em;
            cursor: pointer;
            font-size: 1em;
            font-family: inherit;
            transition: background 0.18s, color 0.16s;
        }
        .navbar .darkmode-btn.active {
            background: var(--accent2);
            color: #fff;
        }
        .navbar button:hover, .navbar .darkmode-btn:hover {
            background: var(--accent2);
            color: #fff;
        }

        .main {
            max-width: 1000px;
            margin: 2.4em auto 0 auto;
            padding: 0 1.5em;
        }
        .notification-box {
            background: #282933;
            border-radius: 11px;
            box-shadow: 0 2px 12px #0006;
            color: #e7fff6;
            font-size: 1.08em;
            padding: 1.1em 1.3em;
            margin-bottom: 18px;
            border-left: 5px solid #17d1a7;
            display: none;
            animation: notif-in 0.6s cubic-bezier(.16,.88,.63,1.46) both;
        }
        .notification-box.active { display: block; }
        .notification-box .notif-close {
            float: right; cursor: pointer; color: #17d1a7; font-size:1.1em;
            background: none; border:none; outline:none; margin-left:14px;
        }
        @keyframes notif-in {
            0% { transform: translateY(-25px); opacity: 0; }
            100% { transform: none; opacity: 1;}
        }
        .metrics-area {
            background: #20242a;
            border-radius: 14px;
            box-shadow: 0 2px 12px 0 #0007;
            padding: 2em 1.2em 1.7em 1.2em;
            margin-bottom: 2em;
            margin-top: 1.2em;
            min-height: 120px;
        }
        .metrics-area h2 {
            margin-top: 0;
            color: var(--accent2);
            font-size: 1.16em;
            letter-spacing: 0.3px;
            margin-bottom: 0.5em;
            font-weight: 600;
        }
        .metrics-table th, .metrics-table td {
            color: #e3eefb;
            font-size:1.07em;
            padding: 7px 10px 7px 0;
            text-align: left;
        }
        .metrics-table th { min-width: 110px; font-weight: 600;}
        .metrics-table { width:100%; border-collapse:collapse; margin: 0;}
        .refresh-btn {
            background: #17d1a7;
            color: #20242a;
            border-radius: 8px;
            border: none;
            padding: 6px 15px;
            font-size: 1.03em;
            margin-left: 15px;
            transition: background 0.18s, color 0.16s;
        }
        .refresh-btn:hover { background: #149880; color: #fff; }
        .cards {
            display: flex;
            flex-wrap: wrap;
            gap: 2em;
            margin-top: 2em;
        }
        .card {
            background: #20242a;
            border-radius: 12px;
            box-shadow: 0 4px 24px 0 #000a;
            padding: 1.6em 1.5em 1.3em 1.5em;
            flex: 1 1 320px;
            min-width: 280px;
            max-width: 340px;
            display: flex;
            flex-direction: column;
            gap: 1.2em;
            position: relative;
        }
        .card h2 {
            margin: 0;
            color: var(--accent2);
            font-size: 1.21em;
            letter-spacing: 0.5px;
            font-weight: 600;
        }
        .card-links {
            display: flex;
            flex-direction: column;
            gap: 0.9em;
        }
        .card-links a {
            text-decoration: none;
            color: var(--accent);
            background: #232832;
            padding: 0.78em 0.9em;
            border-radius: 8px;
            font-size: 1.06em;
            font-family: 'Fira Mono', monospace;
            display: flex;
            align-items: center;
            gap: 0.7em;
            transition: background 0.18s, color 0.14s;
        }
        .card-links a:hover {
            background: var(--accent2);
            color: #fff;
        }
        .last-access {
            margin-top: 2.2em;
            color: var(--text-muted);
            font-size: 0.99em;
            text-align: right;
            letter-spacing: 0.2px;
        }
        .spinner-border {width: 1.6rem; height: 1.6rem; margin-left:13px; vertical-align:-4px;}
        @media (max-width: 600px) {
            .main { padding: 0 0.2em; }
            .cards { flex-direction: column; gap: 1.2em; }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="brand">
            <svg height="30" width="30" viewBox="0 0 64 64" style="margin-right:7px;">
                <circle cx="32" cy="32" r="29" stroke="#17d1a7" stroke-width="4" fill="none"/>
                <circle cx="32" cy="32" r="17" stroke="#3083dc" stroke-width="2" opacity="0.3" fill="none"/>
                <circle cx="32" cy="32" r="7" fill="#17d1a7" opacity="0.8"/>
                <path d="M32 8V24" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
                <path d="M32 40V56" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
                <path d="M8 32H24" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
                <path d="M40 32H56" stroke="#3083dc" stroke-width="2" stroke-linecap="round"/>
            </svg>
            Admin Panel
        </div>
        <div class="actions">
            <button onclick="window.location.href='?logout=1'">Logout</button>
            <button class="darkmode-btn" id="darkModeBtn" title="Toggle dark/light mode">🌙</button>
        </div>
    </nav>
    <div class="main">
        <!-- Notification box -->
        <div id="notifBox" class="notification-box<?= !empty($notifications) ? ' active' : '' ?>">
            <?php if (!empty($notifications)):
                foreach($notifications as $n): ?>
                    <span><?= htmlspecialchars($n) ?></span>
                <?php endforeach;
            else: ?>
                <span style="color:#b6d7cc;">No notifications</span>
            <?php endif; ?>
            <button class="notif-close" onclick="hideNotifBox()" title="Close notification">&times;</button>
        </div>
        <h1 style="margin:0; font-size:2.2em; color:var(--accent); font-weight:700;">Dashboard</h1>
        <div class="metrics-area" id="metrics">
            <div style="display:flex; align-items:center; gap:10px;">
                <h2 style="flex:1;">System Metrics</h2>
                <button class="refresh-btn" onclick="refreshMetrics()" id="refreshBtn">⟳ Refresh</button>
                <span id="metricsSpinner" style="display:none;">
                    <span class="spinner-border" style="display:inline-block;border:0.20em solid #17d1a7;border-right:0.20em solid transparent;border-radius:50%;"></span>
                </span>
            </div>
            <div id="metricsContent" style="margin-top:0.6em;">
                <span style="color:#90a4b7;">Loading metrics...</span>
            </div>
        </div>
        <div class="cards">
            <div class="card">
                <h2>Admin Utilities</h2>
                <div class="card-links">
                <?php foreach ($links as $link):
                    $icon = $link['icon'] ?? '🔗';
                    $target = $link['target'] ?? '_self';
                    if (isset($link['url'])): ?>
                        <a href="<?= htmlspecialchars($link['url']) ?>" target="<?= htmlspecialchars($target) ?>"><?= $icon ?> <?= htmlspecialchars($link['name']) ?></a>
                    <?php else: ?>
                        <a href="<?= htmlspecialchars($link['file']) ?>" target="<?= htmlspecialchars($target) ?>"><?= $icon ?> <?= htmlspecialchars($link['name']) ?></a>
                    <?php endif;
                endforeach; ?>
                </div>
            </div>
        </div>
        <div class="last-access">
            Last admin access: <b><?= htmlspecialchars($last_access) ?></b>
        </div>
    </div>
    <script>
    // -------------- Notification box
    function hideNotifBox() {
        document.getElementById('notifBox').classList.remove('active');
    }
    // ------------------ Metrics AJAX (centralisé sur config)
    const metricsApiUrl = "<?= htmlspecialchars($metrics_api_url) ?>";
    function refreshMetrics() {
        document.getElementById('metricsSpinner').style.display = '';
        fetch(metricsApiUrl + '?action=get')
            .then(res => res.json())
            .then(data => {
                let html = '';
                if (data.success && data.metrics) {
                    const m = data.metrics;
                    html += `<table class="metrics-table">
                        <tr><th>CPU Load</th><td>${m.cpu.loadavg_1min ?? '—'} / ${m.cpu.loadavg_5min ?? '—'} / ${m.cpu.loadavg_15min ?? '—'} <span style="color:#17d1a7; font-size:0.93em;">(1/5/15 min)</span></td></tr>
                        <tr><th>RAM</th><td>${m.memory.used_mb ?? '—'} MB used / ${m.memory.free_mb ?? '—'} MB free / ${m.memory.total_mb ?? '—'} MB total</td></tr>
                        <tr><th>Disk</th><td>${formatBytes(m.disk.used_bytes)} used / ${formatBytes(m.disk.free_bytes)} free / ${formatBytes(m.disk.total_bytes)} total</td></tr>
                        <tr><th>Uptime</th><td>${formatUptime(m.uptime_sec)}</td></tr>
                        <tr><th>Temp. CPU</th><td>${(m.temperature_c !== null && m.temperature_c !== undefined) ? m.temperature_c + '°C' : '<span style="color:#aaa;">n/a</span>'}</td></tr>
                        <tr><th>PHP Version</th><td>${m.php_version ?? '—'}</td></tr>
                        <tr><th>Users</th><td>${m.users_logged_in ?? '—'}</td></tr>
                        <tr><th>Network</th><td>${m.network ? (m.network.interface + ': ' + formatBytes(m.network.rx_bytes) + ' in / ' + formatBytes(m.network.tx_bytes) + ' out') : '<span style="color:#aaa;">n/a</span>'}</td></tr>
                        <tr><th>DB</th><td>${dbInfo(m.db_metrics)}</td></tr>
                        <tr><th>Date</th><td>${m.timestamp ?? '—'}</td></tr>
                    </table>`;
                } else {
                    html = `<div style="color:#e84d6c;">Error loading metrics: ${(data.error || 'Unknown error')}</div>`;
                }
                document.getElementById('metricsContent').innerHTML = html;
            })
            .catch(err => {
                document.getElementById('metricsContent').innerHTML = '<div style="color:#e84d6c;">API error.</div>';
            })
            .finally(() => {
                document.getElementById('metricsSpinner').style.display = 'none';
            });
    }
    function formatBytes(bytes) {
        if (!bytes || isNaN(bytes)) return '—';
        if (bytes < 1024) return bytes + ' B';
        let k = 1024;
        let sizes = ['KB', 'MB', 'GB', 'TB', 'PB'];
        let i = Math.floor(Math.log(bytes) / Math.log(k));
        return (bytes / Math.pow(k, i)).toFixed(2) + ' ' + sizes[i-1];
    }
    function formatUptime(sec) {
        if (!sec || isNaN(sec)) return '—';
        let d = Math.floor(sec/86400), h = Math.floor((sec%86400)/3600), m = Math.floor((sec%3600)/60), s = sec%60;
        return (d ? (d+"d ") : "") + (h ? (h+"h ") : "") + (m ? (m+"m ") : "") + (s ? (s+"s") : "");
    }
    function dbInfo(db) {
        if (!db) return '<span style="color:#aaa;">n/a</span>';
        if (db.connected === false) return '<span style="color:#e84d6c;">DB error</span>';
        return `✔️ Connexions: <b>${db.active_connections ?? "?"}</b>, Tables: <b>${db.num_tables ?? "?"}</b>, Size: <b>${db.db_size_mb ?? "?"} MB</b>`;
    }
    document.addEventListener("DOMContentLoaded", function() {
        refreshMetrics();
    });
    // ------------------ Dark mode
    function setMode(mode) {
        if (mode === "light") {
            document.body.classList.add('light-mode');
            document.getElementById('darkModeBtn').innerText = '🌞';
        } else {
            document.body.classList.remove('light-mode');
            document.getElementById('darkModeBtn').innerText = '🌙';
        }
        localStorage.setItem('admin_theme', mode);
    }
    document.getElementById('darkModeBtn').onclick = function() {
        const isLight = document.body.classList.toggle('light-mode');
        this.innerText = isLight ? '🌞' : '🌙';
        localStorage.setItem('admin_theme', isLight ? 'light' : 'dark');
    };
    (function initTheme() {
        let saved = localStorage.getItem('admin_theme');
        if (saved === "light") setMode("light");
        else setMode("dark");
    })();
    </script>
</body>
</html>
