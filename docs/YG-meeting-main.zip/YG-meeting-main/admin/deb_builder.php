<?php
/*
  File        : /var/www/meeting-backend/admin/deb_builder.php
  Version     : 2.0.0 (2025-06-17)
  Author      : CreativeMind Team
  Description : Builder .deb Meeting (ZIP OU multi-fichiers/chemin cible), ultra interactif.
*/

// DEBUG (désactive si prod)
ini_set('display_errors', 1); error_reporting(E_ALL);

$APT_ROOT   = realpath(__DIR__ . '/../apt');
$APT_TARGET = $APT_ROOT . '/dists/stable/main/binary-amd64';
$TMP_BASE   = sys_get_temp_dir() . '/deb-builder-' . uniqid();

function json_response($data) {
  header('Content-Type: application/json'); echo json_encode($data); exit;
}

// ------ Traitement ZIP (mode rapide) ------
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_GET['zipbuild'])) {
  // ... Garde le code actuel du mode ZIP ici (identique à version précédente) ...
  // Réponse : json_response([...])
}

// ------ Traitement multi-fichiers (mode avancé) ------
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_GET['advbuild'])) {
  $files    = $_FILES['files'] ?? [];
  $targets  = $_POST['target_path'] ?? [];
  $name     = trim($_POST['name'] ?? "meeting-agent-".substr(md5(uniqid()), 0, 6));
  $version  = trim($_POST['version'] ?? "1.0.0");
  $desc     = trim($_POST['description'] ?? "Agent/service Meeting");
  $deps     = trim($_POST['deps'] ?? "nodejs (>=16)");
  $section  = trim($_POST['section'] ?? "utils");
  $maintainer= trim($_POST['maintainer'] ?? "Meeting Team <noreply@meeting.ygsoft.fr>");

  $build_dir = "$TMP_BASE/build/{$name}_$version";
  @mkdir("$build_dir/DEBIAN", 0777, true);

  // Placement des fichiers
  foreach ($files['name'] as $idx=>$orig) {
    $dest = trim($targets[$idx]);
    if (!$dest || strpos($dest, '/')!==0) continue; // sécurité : chemin absolu only
    $data = file_get_contents($files['tmp_name'][$idx]);
    $fullpath = $build_dir . $dest;
    @mkdir(dirname($fullpath), 0777, true);
    file_put_contents($fullpath, $data);
    chmod($fullpath, 0755);
  }

  // Control
  $control = "Package: $name
Version: $version
Section: $section
Priority: optional
Architecture: all
Depends: $deps
Maintainer: $maintainer
Description: $desc
";
  file_put_contents("$build_dir/DEBIAN/control", $control);

  // Si un .service est présent, on auto-génère postinst
  foreach ($targets as $dest) {
    if (preg_match('#^/lib/systemd/system/.*\.service$#', $dest)) {
      $servicefile = basename($dest);
      $postinst = "#!/bin/bash
set -e
systemctl daemon-reload || true
systemctl enable $servicefile || true
systemctl restart $servicefile || true
";
      file_put_contents("$build_dir/DEBIAN/postinst", $postinst);
      chmod("$build_dir/DEBIAN/postinst", 0755);
      break;
    }
  }

  $deb_file = "{$name}_{$version}_all.deb";
  $deb_path = "$TMP_BASE/$deb_file";
  $cmd_build = "dpkg-deb --build " . escapeshellarg($build_dir) . " " . escapeshellarg($deb_path);
  $out = []; $ret = 0;
  exec($cmd_build . " 2>&1", $out, $ret);

  if (!is_file($deb_path)) json_response(['ok'=>false, 'error'=>'Erreur build .deb','log'=>$out]);

  $copy_depot = false;
  if (is_dir($APT_TARGET) && is_writable($APT_TARGET)) {
    copy($deb_path, "$APT_TARGET/$deb_file");
    chmod("$APT_TARGET/$deb_file", 0644);
    $cmd_index = "cd " . escapeshellarg($APT_TARGET) . " && dpkg-scanpackages . /dev/null | gzip -9c > Packages.gz";
    $index_log = [];
    exec($cmd_index . " 2>&1", $index_log, $r);
    $copy_depot = true;
  }

  json_response([
    'ok'=>true,
    'deb_file'=>$deb_file,
    'deb_url'=>'?dl='.urlencode($deb_file).'&tmp='.urlencode($deb_path),
    'log'=>$out,
    'copy_depot'=>$copy_depot,
    'copy_path'=>$APT_TARGET.'/'.$deb_file
  ]);
}

// --- Download direct du deb (tmp, sécurité) ---
if (isset($_GET['dl']) && isset($_GET['tmp']) && is_file($_GET['tmp'])) {
  $f = $_GET['tmp'];
  header('Content-Type: application/octet-stream');
  header('Content-Disposition: attachment; filename="'.basename($f).'"');
  header('Content-Length: ' . filesize($f));
  readfile($f); exit;
}

// --- UI HTML+JS ---

?><!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <title>Meeting - Builder .deb avancé</title>
  <style>
    body { font-family: system-ui, sans-serif; background: #191d21; color: #eee; margin: 0; padding: 2em; }
    h1 { font-size: 2em; }
    .switch { margin-bottom:1.3em; }
    .modebtn { padding:0.7em 2em; font-size:1em; border-radius:7px; border:none; margin-right:1em; background:#202c39;color:#8ad;cursor:pointer;}
    .modebtn.active { background:#246;}
    .zone {display:none;}
    .file-list {margin-top:1em;}
    .file-row {display:flex;align-items:center;margin-bottom:0.7em;}
    .file-row input[type=text] {width: 50%;margin-left:1em;}
    .file-row .del {margin-left:1em;color:#e77;cursor:pointer;}
    .param-form input, .param-form textarea { width: 100%; padding: .4em; margin-bottom: .8em; background: #111; color: #eee; border: 1px solid #444; border-radius: 5px; }
    .param-form label { font-weight: bold; }
    .param-form button { padding: .6em 2em; font-size: 1.1em; border: none; border-radius: 5px; background: #4c8ef7; color: #fff; margin-top: 1em; cursor: pointer; }
    .log { background: #131313; border-radius: 6px; padding: 1em; font-size: 0.97em; margin-top: 1em; white-space: pre-line; }
    .result { background: #223322; color: #b3ffb3; border-radius: 6px; padding: .7em; margin: 1em 0;}
    .error  { background: #331a1a; color: #ffb3b3; }
    .dl-link { color: #7ec8ff; text-decoration: underline; font-weight: bold;}
  </style>
</head>
<body>
<h1>Meeting – Builder .deb (ZIP ou fichiers individuels)</h1>
<div class="switch">
  <button class="modebtn active" id="btn-zip" type="button">Mode ZIP rapide</button>
  <button class="modebtn" id="btn-adv" type="button">Mode avancé (fichier par fichier)</button>
</div>

<!-- MODE ZIP -->
<div class="zone" id="zone-zip" style="display:block">
  <form id="zipform" enctype="multipart/form-data">
    <label>Archive ZIP : <input type="file" name="debzip" accept=".zip" required /></label>
    <button type="submit">Analyser et Builder</button>
  </form>
  <div id="zip-result"></div>
  <div id="zip-log" class="log"></div>
</div>

<!-- MODE AVANCÉ -->
<div class="zone" id="zone-adv">
  <div style="margin-bottom:1em;">
    <input type="file" id="filepicker" multiple style="display:none;">
    <button type="button" onclick="document.getElementById('filepicker').click()">+ Ajouter fichier(s)</button>
    <div id="adv-dropzone" style="margin:1em 0;padding:1.5em;border:2px dashed #6ad;border-radius:7px;text-align:center;cursor:pointer;">
      <b>Glissez/déposez ici vos fichiers à packager</b>
    </div>
  </div>
  <form id="advform" class="param-form" style="display:none">
    <div id="filelist" class="file-list"></div>
    <label>Nom du paquet (.deb) :<input name="name" required></label>
    <label>Version :<input name="version" required></label>
    <label>Description :<textarea name="description" rows="2" required></textarea></label>
    <label>Dépendances :<input name="deps" value="nodejs (>=16)" required></label>
    <label>Section :<input name="section" value="utils" required></label>
    <label>Maintainer :<input name="maintainer" value="Meeting Team &lt;noreply@meeting.ygsoft.fr&gt;" required></label>
    <button type="submit">Builder et publier le .deb</button>
  </form>
  <div id="adv-result"></div>
  <div id="adv-log" class="log"></div>
</div>

<script>
// --- Switch modes ---
const btnZip = document.getElementById('btn-zip'), btnAdv = document.getElementById('btn-adv');
btnZip.onclick = () => {btnZip.classList.add('active');btnAdv.classList.remove('active');zoneZip.style.display='block';zoneAdv.style.display='none';}
btnAdv.onclick = () => {btnAdv.classList.add('active');btnZip.classList.remove('active');zoneZip.style.display='none';zoneAdv.style.display='block';}
const zoneZip = document.getElementById('zone-zip'), zoneAdv = document.getElementById('zone-adv');

// --- Mode ZIP classique (form AJAX) ---
document.getElementById('zipform').onsubmit = function(e){
  e.preventDefault();
  document.getElementById('zip-result').innerHTML = 'Analyse...';
  document.getElementById('zip-log').textContent = '';
  const fd = new FormData(this);
  fetch('?zipbuild', {method:'POST',body:fd}).then(r=>r.json()).then(d=>{
    if (d.ok) {
      document.getElementById('zip-result').innerHTML = `<b>✅ Build terminé !</b><br>
        <a href="${d.deb_url}" class="dl-link">Télécharger le .deb</a>
        ${d.copy_depot?'<br>Paquet publié dans le dépôt APT.':'<br><b>⚠️ Pas publié dans le dépôt (droits manquants).</b>'}
        <br>Nom du paquet : <b>${fd.get('name')}</b>`;
    } else {
      document.getElementById('zip-result').innerHTML = `<div class="error">Erreur build : ${d.error||'?'}</div>`;
    }
    if (d.log) document.getElementById('zip-log').textContent = (d.log||[]).join("\n");
  });
};

// --- Mode Avancé : fichier par fichier ---
let advFiles = [];
const filepicker = document.getElementById('filepicker');
const dropzone = document.getElementById('adv-dropzone');
const advform = document.getElementById('advform');
const filelist = document.getElementById('filelist');
function suggestTarget(filename) {
  if (/\.js$|\.sh$|\.bin$/i.test(filename)) return '/usr/local/bin/'+filename;
  if (/\.service$/i.test(filename)) return '/lib/systemd/system/'+filename;
  if (/config\.json$/i.test(filename)) return '/usr/local/bin/config.json';
  if (/\.json$/i.test(filename)) return '/etc/meeting/'+filename;
  return '/usr/share/'+filename;
}
function addAdvFiles(files) {
  for (let f of files) {
    if (advFiles.find(e=>e.name===f.name)) continue;
    advFiles.push({file:f, name:f.name, target:suggestTarget(f.name)});
  }
  refreshAdvFileList();
  advform.style.display = advFiles.length?'':'none';
}
function refreshAdvFileList() {
  filelist.innerHTML = '';
  advFiles.forEach((f, idx) => {
    filelist.innerHTML += `<div class="file-row">
      <span>${f.name}</span>
      <input type="text" value="${f.target}" onchange="advFiles[${idx}].target=this.value">
      <span class="del" onclick="advFiles.splice(${idx},1);refreshAdvFileList();advform.style.display=advFiles.length?'':'none';">✖</span>
    </div>`;
  });
}
filepicker.onchange = e => addAdvFiles(e.target.files);
dropzone.ondragover = e => { e.preventDefault(); dropzone.style.borderColor='#2f7'; }
dropzone.ondragleave = e => { e.preventDefault(); dropzone.style.borderColor='#6ad'; }
dropzone.ondrop = e => {
  e.preventDefault(); dropzone.style.borderColor='#6ad';
  addAdvFiles(e.dataTransfer.files);
};
advform.onsubmit = function(e){
  e.preventDefault();
  document.getElementById('adv-result').innerHTML = 'Build en cours…';
  document.getElementById('adv-log').textContent = '';
  const fd = new FormData(advform);
  advFiles.forEach(f=>{
    fd.append('files[]',f.file);
    fd.append('target_path[]',f.target);
  });
  fetch('?advbuild', {method:'POST',body:fd}).then(r=>r.json()).then(d=>{
    if (d.ok) {
      document.getElementById('adv-result').innerHTML = `<b>✅ Build terminé !</b><br>
        <a href="${d.deb_url}" class="dl-link">Télécharger le .deb</a>
        ${d.copy_depot?'<br>Paquet publié dans le dépôt APT.':'<br><b>⚠️ Pas publié dans le dépôt (droits manquants).</b>'}
        <br>Nom du paquet : <b>${fd.get('name')}</b>`;
    } else {
      document.getElementById('adv-result').innerHTML = `<div class="error">Erreur build : ${d.error||'?'}</div>`;
    }
    if (d.log) document.getElementById('adv-log').textContent = (d.log||[]).join("\n");
  });
};
</script>
</body>
</html>
