<?php
// File: admin/db_manager.php
// Version: 1.2.0
// Date: 2025-05-27
// Author: Meeting Server Team
// Description: Modern UI for Meeting DB Manager, Bootstrap 5, dark mode, harmonized admin look
// CHANGELOG:
// - 1.2.0 (2025-05-27): Refonte graphique complète Bootstrap 5, UI admin harmonisée (device_creation, admin_ssh)

$apiConfig = __DIR__ . '/../api/config.php';
if (!file_exists($apiConfig)) {
    die("Config file not found: $apiConfig");
}
$config = require($apiConfig);

$links = include __DIR__ . '/links.php';

// === Création dynamique du PDO ===
try {
    $pdo = new PDO(
        "mysql:host={$config['db_host']};dbname={$config['db_name']};charset={$config['db_charset']}",
        $config['db_user'],
        $config['db_pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . htmlspecialchars($e->getMessage()));
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <title>MEETING - DB Manager</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 CSS (dark) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body {
            background: #171b20 !important;
            color: #f3f7fa !important;
            min-height: 100vh;
            margin: 0; padding: 0;
        }
        .navbar {
            background: #111316 !important;
            color: #fff;
            min-height: 56px;
            box-shadow: 0 3px 12px #0008;
        }
        .navbar .brand {
            font-size: 1.35em;
            font-weight: bold;
            color: #2196f3 !important;
            letter-spacing: 1.1px;
            padding-left: 16px;
        }
        .navbar .nav-link, .navbar .nav-icon {
            color: #fff !important;
        }
        .navbar .nav-link.active, .navbar .nav-link:focus, .navbar .nav-link:hover {
            background: #2196f3 !important;
            color: #fff !important;
        }
        .nav-icon {
            font-size: 1.1em;
            margin-right: 5px;
        }
        .dark-toggle {
            border: none;
            background: #232832;
            color: #fff;
            border-radius: 22px;
            padding: 5px 17px;
            cursor: pointer;
            font-size: 1em;
            margin-left: 18px;
        }
        .main-content {
            width: 100%;
            max-width: 1500px;
            margin: 0 auto;
            padding: 34px 2vw 40px 2vw;
        }
        .admin-section {
            background: #20242a;
            border-radius: 14px;
            box-shadow: 0 6px 22px #0008;
            padding: 30px 34px 26px 34px;
            margin-bottom: 34px;
        }
        .section-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 18px;
        }
        .section-header h2 {
            color: #2196f3;
            font-weight: 600;
            font-size: 1.3em;
            margin: 0;
        }
        .table {
            background: transparent;
            color: #f3f7fa;
            border-radius: 10px;
            overflow: hidden;
        }
        .table thead th {
            background: #232832;
            color: #2196f3;
            font-weight: 600;
            position: sticky; top: 0; z-index: 2;
        }
        .btn, button, input[type="submit"] {
            border-radius: 7px !important;
        }
        .danger, .btn-danger, .btn-delete {
            color: #ff6161 !important;
        }
        .btn-delete {
            background: transparent;
            border: none;
            padding: 0 5px;
            color: #ff6161 !important;
            font-weight: 500;
        }
        .btn-delete:hover {
            background: #ff616133 !important;
        }
        .sql-box {
            background: #232832;
            color: #f3f7fa;
            border-radius: 9px;
            border: 1.2px solid #283142;
            width: 100%;
            min-height: 72px;
            padding: 7px 13px;
            font-family: "JetBrains Mono", "Consolas", monospace;
            font-size: 1.07em;
        }
        .btn-sql {
            background: #2196f3;
            color: #fff;
            padding: 7px 28px;
            margin-top: 8px;
            border-radius: 8px;
            border: none;
        }
        .btn-sql:hover { background: #1761ac; }
        .alert-warning {
            color: #ffe082;
        }
        .sql-result-table {
            margin-top: 16px;
        }
        @media (max-width: 900px) {
            .admin-section { padding: 15px 3vw 18px 3vw;}
        }
        @media (max-width: 600px) {
            .main-content { padding: 7px 2vw 8px 2vw;}
            .navbar .brand { font-size: 1em; padding-left: 7px;}
            .navbar .nav-link { font-size: 0.97em; padding: 6px 9px;}
            .dark-toggle { margin-right: 6px; font-size: 0.95em;}
        }
    </style>
</head>
<body class="dark">
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container-fluid">
            <span class="brand">🟦 MEETING Admin</span>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 navlinks">
                    <?php foreach ($links as $link): ?>
                        <?php
                            $icon = isset($link['icon']) ? '<span class="nav-icon">'.htmlspecialchars($link['icon']).'</span>' : '';
                            $name = htmlspecialchars($link['name']);
                            if (isset($link['file'])) {
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['file']}\">{$icon}{$name}</a></li>";
                            } else if (isset($link['url'])) {
                                $target = isset($link['target']) ? " target=\"{$link['target']}\"" : "";
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['url']}\"$target>{$icon}{$name}</a></li>";
                            } else {
                                echo "<li class=\"nav-item\"><span class=\"nav-link\">{$icon}{$name}</span></li>";
                            }
                        ?>
                    <?php endforeach; ?>
                </ul>
            </div>
            <button class="dark-toggle" onclick="toggleDarkMode()" title="Toggle light/dark mode">
                <svg width="18" height="18" viewBox="0 0 20 20"><path fill="currentColor" d="M10 2a8 8 0 1 0 8 8a8 8 0 0 0-8-8Zm0 14a6 6 0 1 1 6-6a6 6 0 0 1-6 6Zm0-11a1 1 0 1 0 1 1a1 1 0 0 0-1-1Z"/></svg>
                Dark mode
            </button>
        </div>
    </nav>
    <div class="main-content">
        <!-- SECTION: CONFIG -->
        <div class="admin-section mb-4">
            <div class="section-header">
                <h2>Meeting DB Manager</h2>
                <span style="font-size:0.97em;color:#b2cdf7;">
                    [Config: <?=htmlspecialchars($config['db_host'])?>/<?=htmlspecialchars($config['db_name'])?>]
                </span>
            </div>
            <hr style="margin:12px 0 22px 0;border-color:#2a3441;">
<?php
// == List Tables ==
if (isset($_GET['table'])) {
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $_GET['table']);
} else {
    $table = null;
}

// == SQL Query tool ==
if (isset($_POST['run_sql'])) {
    $sql = trim($_POST['sql_query'] ?? '');
    echo "<div class='admin-section mt-3'>";
    echo "<div class='section-header'><h2>Query Result</h2></div>";
    echo "<pre style=\"background:#191b23;border-radius:6px;padding:8px 13px;font-size:1em;color:#b2cdf7;margin-bottom:11px;\">".htmlspecialchars($sql)."</pre>";
    if (stripos($sql, 'select') === 0) {
        try {
            $stmt = $pdo->query($sql);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if ($rows) {
                echo "<div class='table-responsive sql-result-table'><table class='table table-dark table-striped table-bordered table-hover align-middle'>";
                echo "<tr>";
                foreach (array_keys($rows[0]) as $col) {
                    echo "<th>$col</th>";
                }
                echo "</tr>";
                foreach ($rows as $r) {
                    echo "<tr>";
                    foreach ($r as $v) echo "<td>".htmlspecialchars($v)."</td>";
                    echo "</tr>";
                }
                echo "</table></div>";
            } else {
                echo "<div class='alert alert-warning'>Empty result.</div>";
            }
        } catch(Exception $e) {
            echo "<span class='danger'>Query error: ".htmlspecialchars($e->getMessage())."</span>";
        }
    } else {
        try {
            $affected = $pdo->exec($sql);
            echo "<b>$affected row(s) affected.</b>";
        } catch(Exception $e) {
            echo "<span class='danger'>Query error: ".htmlspecialchars($e->getMessage())."</span>";
        }
    }
    echo "<a href='db_manager.php' class='btn btn-outline-info btn-sm mt-3'>&larr; Back</a>";
    echo "</div>";
    echo "<hr style='border-color:#283142;'>";
}

// -- Delete row
if (isset($_GET['delete']) && $table) {
    $id = $_GET['delete'];
    $pk = $_GET['pk'] ?? 'id';
    try {
        $sql = "DELETE FROM `$table` WHERE `$pk` = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$id]);
        echo "<div class='alert alert-danger'>Row deleted. <a href='?table=$table' class='ms-2'>&larr; Back to table</a></div>";
    } catch(Exception $e) {
        echo "<span class='danger'>Delete error: ".htmlspecialchars($e->getMessage())."</span>";
    }
}

// == Table List ==
echo "<div class='section-header mt-4 mb-2'><h2 style='font-size:1.1em;'>Tables</h2></div>";
$res = $pdo->query("SHOW TABLES");
$tables = $res->fetchAll(PDO::FETCH_NUM);
echo "<div class='d-flex flex-wrap gap-2 mb-3'>";
foreach($tables as $row) {
    $t = $row[0];
    $sel = ($table === $t) ? "<b class='me-2 text-primary'>&#8594;</b>" : "";
    echo "$sel<a class='btn btn-outline-info btn-sm' href='?table=$t' style='margin-bottom:3px;'>$t</a>";
}
echo "</div>";

// == Table View ==
if ($table) {
    echo "<hr style='border-color:#283142;'><div class='section-header mt-4'><h2 style='font-size:1.08em;'>Table: $table</h2></div>";
    // Trouver la clé primaire (suppose qu'il y a 'id' ou le premier champ auto_increment)
    $pk = 'id';
    $colinfo = $pdo->query("SHOW COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($colinfo as $c) {
        if ($c['Key'] == 'PRI') {
            $pk = $c['Field'];
            break;
        }
    }
    $stmt = $pdo->query("SELECT * FROM `$table` ORDER BY `$pk` DESC LIMIT 100");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if ($rows) {
        echo "<div class='table-responsive'><table class='table table-dark table-striped table-hover align-middle'><tr>";
        foreach (array_keys($rows[0]) as $col) echo "<th>$col</th>";
        echo "<th>Action</th></tr>";
        foreach ($rows as $r) {
            echo "<tr>";
            foreach ($r as $k=>$v) echo "<td>".htmlspecialchars($v)."</td>";
            echo "<td>
                <a class='btn-delete' href='?table=$table&delete=".urlencode($r[$pk])."&pk=$pk' onclick=\"return confirm('Delete row?')\" title='Delete row'>
                    <svg width='19' height='19' viewBox='0 0 20 20'><path fill='#ff6161' d='M7.25 2A1.25 1.25 0 0 0 6 3.25v1.5H3.25a.75.75 0 1 0 0 1.5H4.4l.86 10.1A2.25 2.25 0 0 0 7.5 18h5a2.25 2.25 0 0 0 2.24-1.65l.86-10.1h1.15a.75.75 0 1 0 0-1.5H14V3.25A1.25 1.25 0 0 0 12.75 2h-5ZM7.5 3.5h5a.25.25 0 0 1 .25.25V4.75h-5.5V3.75A.25.25 0 0 1 7.5 3.5ZM7.26 16.38l-.84-9.88h7.16l-.84 9.88a.75.75 0 0 1-.75.62h-4a.75.75 0 0 1-.75-.62Z'/></svg>
                </a>
                </td>";
            echo "</tr>";
        }
        echo "</table></div>";
    } else {
        echo "<div class='alert alert-warning mt-3'>No rows.</div>";
    }
}
?>
        </div>
        <!-- SECTION: SQL Query tool -->
        <div class="admin-section">
            <div class="section-header mb-2">
                <h2>SQL Query</h2>
            </div>
            <form method="post" class="mb-2">
                <textarea name="sql_query" rows="3" class="sql-box mb-2" placeholder="Ex: SELECT * FROM devices LIMIT 10"></textarea><br>
                <button type="submit" name="run_sql" class="btn-sql">Run Query</button>
            </form>
            <div class="alert alert-warning" style="font-size:0.92em;">(!) Only use with caution on production. Delete = hard delete, no undo.</div>
        </div>
    </div>
    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function toggleDarkMode() {
        document.body.classList.toggle('dark');
        if(document.body.classList.contains('dark')) {
            document.documentElement.style.setProperty('--bs-body-bg','#171b20');
            document.documentElement.style.setProperty('--bg-main','#171b20');
            document.documentElement.style.setProperty('--fg-main','#f3f7fa');
            document.documentElement.style.setProperty('--bg-panel','#20242a');
        } else {
            document.documentElement.style.setProperty('--bs-body-bg','#f3f7fa');
            document.documentElement.style.setProperty('--bg-main','#f3f7fa');
            document.documentElement.style.setProperty('--fg-main','#191c21');
            document.documentElement.style.setProperty('--bg-panel','#fff');
        }
    }
    </script>
</body>
</html>
