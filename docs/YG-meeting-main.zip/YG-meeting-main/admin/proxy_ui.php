<?php
// File: admin/proxy_ui.php
// Version: 1.0.0 (2025-06-17)
// Description: Interface web du proxy Meeting (port 9500).
?>
<!DOCTYPE html><meta charset=utf8><title>YGS Proxy</title>
<style>:root{color-scheme:dark;font-family:system-ui}body{margin:0;background:#111;color:#eee;display:grid;place-content:center;height:100vh;text-align:center}section{background:#1a1a1a;border:1px solid #444;padding:2rem 3rem;border-radius:12px;min-width:38rem}h1{font-size:2rem;margin:.1em 0 .5em}table{width:100%;border-collapse:collapse;margin:.6em 0}th,td{padding:.4em;border-bottom:1px solid #333;text-align:center;font-size:.9em}.vgreen{color:#1fc77a;font-weight:bold}.vred{color:#e03344;font-weight:bold}pre{background:#0003;padding:.6em;border-radius:8px;max-height:8em;overflow:auto;font-size:.8em;text-align:left}small{color:#999;font-size:.8em}</style>
<section><h1>YGS Proxy</h1><div id=stat>…</div>
<table id=tbl><tr>
  <th>DeviceKey</th>
  <th>Port public</th>
  <th>Port local</th>
  <th>Stream</th>
  <th>Last heartbeat</th>
</tr></table>
<pre id=log>(logs)</pre><small>UI : port 9500</small>
<script>
const $=q=>document.querySelector(q);
async function refresh(){
  const s = await fetch('/state').then(r=>r.json());
  $('#stat').innerHTML=`<b>${s.agent?'🟢':'🔴'} Proxy online</b> — mappings: ${s.maps.length}`;
  $('#tbl').innerHTML='<tr><th>DeviceKey</th><th>Port public</th><th>Port local</th><th>Stream</th><th>Last heartbeat</th></tr>'+
    s.maps.map(m=>{
      let stream = m.stream ? '<span class="vred">🔴</span>' : '<span class="vgreen">🟢</span>';
      return `<tr><td>${m.deviceKey}</td><td>${m.pub}</td><td>${m.local}</td><td>${stream}</td><td>${m.heartbeat}</td></tr>`;
    }).join('');
  $('#log').textContent=s.logs.join('\n');
}
refresh(); setInterval(refresh,2000);
</script></section>
