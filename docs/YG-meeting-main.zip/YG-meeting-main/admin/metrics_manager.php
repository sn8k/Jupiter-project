<?php
// File: admin/metrics_manager.php
// Version: 1.1.0
// Date: 2025-05-31
// CHANGELOG:
// - 1.1.0 (2025-05-31): Intégration config.php pour tous les paramètres variables (logs, API URL, etc).
// - 1.0.0 (2025-05-25): Création initiale. Visualisation live des métriques système et logs Metrics API. Charte graphique admin MEETING.

// Navbar & config
$links = require __DIR__ . '/links.php';
$config = include __DIR__ . '/../api/config.php';
session_start();
$has_pin = isset($_SESSION['has_pin']) && $_SESSION['has_pin'] === true;

// Endpoints dynamiques
$metrics_api_url = $config['metrics_api_url'] ?? '/api/metrics';
$metrics_logfile = $config['metrics_logfile'] ?? '../api/logs/metrics_api.log';

?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <title>MEETING - Metrics Manager</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body { background: #171b20 !important; color: #f3f7fa !important; min-height: 100vh; }
        .navbar { background: #111316 !important; color: #fff; min-height: 56px; box-shadow: 0 3px 12px #0008; }
        .navbar .brand { font-size: 1.35em; font-weight: bold; color: #17d1a7 !important; letter-spacing: 1.1px; padding-left: 16px; }
        .navbar .nav-link, .navbar .nav-icon { color: #fff !important; }
        .dark-toggle { border: none; background: #232832; color: #fff; border-radius: 22px; padding: 5px 17px; cursor: pointer; font-size: 1em; margin-left: 18px; }
        .main-content { width: 100%; max-width: 1240px; margin: 0 auto; padding: 35px 2vw 40px 2vw; }
        .metrics-panel { background: #20242a; border-radius: 13px; box-shadow: 0 4px 18px #0007; padding: 35px 38px 32px 38px; margin-bottom: 30px;}
        .metrics-title { color: #17d1a7; font-size: 1.34em; font-weight: 600; margin-bottom: 28px;}
        .metrics-table th, .metrics-table td { color: #e3eefb; font-size:1.08em; }
        .refresh-btn { background: #17d1a7; color: #20242a; border-radius: 8px; border: none; padding: 6px 14px; font-size: 1.04em;}
        .refresh-btn:hover { background: #149880; color: #fff; }
        .logs-box { background: #232832; border-radius: 8px; padding: 18px; margin-top: 26px; font-family: "Fira Mono", "Consolas", monospace; color: #b8c6ef; max-height: 330px; overflow: auto; border: 1px solid #232a33;}
        .small-title { color: #b2cdf7; font-size: 1.04em; margin-bottom:12px; font-weight: 500;}
        .spinner-border {width: 1.6rem; height: 1.6rem; margin-left:15px;}
        @media (max-width: 900px) { .main-content { padding: 7px 2vw 10px 2vw;} .metrics-panel { padding: 17px 4vw 16px 4vw;} }
    </style>
</head>
<body class="dark">
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container-fluid">
            <span class="brand">🟩 MEETING Admin</span>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 navlinks">
                    <?php foreach ($links as $link): ?>
                        <?php
                            $icon = isset($link['icon']) ? '<span class="nav-icon">'.htmlspecialchars($link['icon']).'</span>' : '';
                            $name = htmlspecialchars($link['name']);
                            if (isset($link['file'])) {
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['file']}\">{$icon}{$name}</a></li>";
                            } else if (isset($link['url'])) {
                                $target = isset($link['target']) ? " target=\"{$link['target']}\"" : "";
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['url']}\"$target>{$icon}{$name}</a></li>";
                            } else {
                                echo "<li class=\"nav-item\"><span class=\"nav-link\">{$icon}{$name}</span></li>";
                            }
                        ?>
                    <?php endforeach; ?>
                </ul>
            </div>
            <button class="dark-toggle" onclick="toggleDarkMode()" title="Toggle light/dark mode">
                <svg width="18" height="18" viewBox="0 0 20 20"><path fill="currentColor" d="M10 2a8 8 0 1 0 8 8a8 8 0 0 0-8-8Zm0 14a6 6 0 1 1 6-6a6 6 0 0 1-6 6Zm0-11a1 1 0 1 0 1 1a1 1 0 0 0-1-1Z"/></svg>
                Dark mode
            </button>
        </div>
    </nav>
    <div class="main-content">
        <div class="metrics-panel">
            <div class="metrics-title">System Metrics Dashboard</div>
            <div class="d-flex align-items-center mb-3">
                <div class="small-title flex-grow-1">Realtime System Metrics</div>
                <button class="refresh-btn" onclick="refreshMetrics()" id="refreshBtn">⟳ Refresh</button>
                <div id="metricsSpinner" style="display:none;">
                    <span class="spinner-border text-info"></span>
                </div>
            </div>
            <div id="metricsContent">
                <!-- Les metrics sont chargées en AJAX ici -->
            </div>
            <div class="small-title mt-4 mb-2">Metrics API Logs</div>
            <div class="d-flex mb-2" style="gap:15px;">
                <button class="refresh-btn" style="padding: 3px 14px; font-size:0.99em;" onclick="refreshLogs()">⟳ Logs</button>
                <input type="number" min="10" max="1000" step="10" id="logLines" class="form-control" value="100" style="width:90px;display:inline-block;">
                <span style="color:#a1b2c8;font-size:0.95em;margin-left:7px;">lines</span>
            </div>
            <div id="logsContent" class="logs-box">Loading logs...</div>
        </div>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const metricsApiUrl = "<?= htmlspecialchars($metrics_api_url) ?>";
function refreshMetrics() {
    document.getElementById('metricsSpinner').style.display = '';
    fetch(metricsApiUrl + '?action=get')
        .then(res => res.json())
        .then(data => {
            let html = '';
            if (data.success) {
                const m = data.metrics;
                html += `<table class="table metrics-table table-borderless align-middle mb-2">
                    <tr><th>CPU Load (1min/5min/15min)</th><td>${m.cpu.loadavg_1min} / ${m.cpu.loadavg_5min} / ${m.cpu.loadavg_15min}</td></tr>
                    <tr><th>RAM (Used / Free / Total MB)</th><td>${m.memory.used_mb} / ${m.memory.free_mb} / ${m.memory.total_mb}</td></tr>
                    <tr><th>Disk (Used / Free / Total)</th><td>${formatBytes(m.disk.used_bytes)} / ${formatBytes(m.disk.free_bytes)} / ${formatBytes(m.disk.total_bytes)}</td></tr>
                    <tr><th>Uptime (seconds)</th><td>${m.uptime_sec}</td></tr>
                    <tr><th>PHP Version</th><td>${m.php_version}</td></tr>
                    <tr><th>Date</th><td>${m.timestamp}</td></tr>
                </table>`;
            } else {
                html = `<div class="alert alert-danger">Error loading metrics: ${data.error || 'Unknown error'}</div>`;
            }
            document.getElementById('metricsContent').innerHTML = html;
        })
        .catch(err => {
            document.getElementById('metricsContent').innerHTML = '<div class="alert alert-danger">API error.</div>';
        })
        .finally(() => {
            document.getElementById('metricsSpinner').style.display = 'none';
        });
}
function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    let k = 1024;
    let sizes = ['KB', 'MB', 'GB', 'TB', 'PB'];
    let i = Math.floor(Math.log(bytes) / Math.log(k));
    return (bytes / Math.pow(k, i)).toFixed(2) + ' ' + sizes[i-1];
}
function refreshLogs() {
    let lines = parseInt(document.getElementById('logLines').value) || 100;
    document.getElementById('logsContent').innerHTML = '<span class="spinner-border text-info"></span>';
    fetch(metricsApiUrl + '?action=logs&lines=' + lines)
        .then(res => res.json())
        .then(data => {
            if (data.success && data.log) {
                document.getElementById('logsContent').innerHTML = `<pre style="margin:0;font-size:0.98em;line-height:1.43em;">${data.log.map(l=>escapeHtml(l)).join('\n')}</pre>`;
            } else {
                document.getElementById('logsContent').innerHTML = '<div class="alert alert-danger">No logs available.</div>';
            }
        })
        .catch(err => {
            document.getElementById('logsContent').innerHTML = '<div class="alert alert-danger">API error loading logs.</div>';
        });
}
function escapeHtml(text) {
    if (!text) return '';
    return text.replace(/[<>&"']/g, function(m) {
        return {'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&#39;'}[m];
    });
}
function toggleDarkMode() {
    document.body.classList.toggle('dark');
}
document.addEventListener("DOMContentLoaded", function() {
    refreshMetrics();
    refreshLogs();
});
</script>
</body>
</html>
