<?php
// File: admin/distribution_manager.php
// Version: 1.4.2
// Date: 2025-06-13
// Author: Meeting Server Team
// Description: Admin GUI for device types/distributions management, Bootstrap 5 modern UI, distrib.json generator, collapsible UX, info panel, dark mode, responsive
//
// CHANGELOG:
// - 1.4.1 (2025-06-13): Chemins de stockage basés sur config.php (MEETING_DATA_ROOT)
// - 1.4.0 (2025-05-27): Harmonisation Bootstrap 5/dark mode, UI admin modernisée (device_creation, admin_ssh), responsive & refonte graphique
// - 1.3.2 (2025-05-23): Fix bouton Generate Distrib, refonte passage fichiers JS, full inline
//


session_start();
$config = require __DIR__ . '/../api/config.php';
$storageRoot = $config['storage_path'] ?? ($config['flash_storage_root'] ?? dirname(__DIR__) . '/storage');

$links = require __DIR__ . '/links.php';

function sanitizeName($name) {
    return preg_replace('/[^a-zA-Z0-9_-]/', '', $name);
}

// ===================== AJAX ACTIONS =========================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json; charset=UTF-8');
    $resp = ['ok' => false];

    // Add Device Type
    if ($_POST['action'] === 'new_devtype' && !empty($_POST['devtype'])) {
        $devtype = sanitizeName($_POST['devtype']);
        $devPath = "$storageRoot/$devtype";
        if (strlen($devtype) < 2) {
            $resp['error'] = "Nom du device type trop court.";
        } elseif (is_dir($devPath)) {
            $resp['error'] = "Device type '$devtype' already exists.";
        } elseif (!is_writable($storageRoot)) {
            $resp['error'] = "Erreur : le dossier racine n'est pas accessible en écriture.";
        } elseif (mkdir($devPath, 0775, true)) {
            $resp['ok'] = true;
            $resp['devtype'] = $devtype;
        } else {
            $resp['error'] = "Failed to create device type (vérifie les droits sur $storageRoot).";
        }
        echo json_encode($resp); exit;
    }
    // New Distribution
    if ($_POST['action'] === 'new_dist' && !empty($_POST['devtype']) && !empty($_POST['distribution'])) {
        $devtype = sanitizeName($_POST['devtype']);
        $dist = sanitizeName($_POST['distribution']);
        $distPath = "$storageRoot/$devtype/$dist";
        if (!is_dir("$storageRoot/$devtype")) {
            $resp['error'] = "Device type does not exist.";
        } elseif (is_dir($distPath)) {
            $resp['error'] = "Distribution '$dist' already exists.";
        } elseif (mkdir($distPath, 0775, true)) {
            $resp['ok'] = true;
            $resp['distribution'] = $dist;
        } else {
            $resp['error'] = "Failed to create distribution.";
        }
        echo json_encode($resp); exit;
    }
    // Upload file
    if ($_POST['action'] === 'upload_file' && !empty($_POST['devtype']) && !empty($_POST['distribution']) && isset($_FILES['file'])) {
        $devtype = sanitizeName($_POST['devtype']);
        $dist = sanitizeName($_POST['distribution']);
        $distPath = "$storageRoot/$devtype/$dist";
        if (!is_dir($distPath)) {
            $resp['error'] = "Distribution path missing.";
        } else {
            $file = $_FILES['file'];
            $fname = basename($file['name']);
            $target = "$distPath/$fname";
            if (move_uploaded_file($file['tmp_name'], $target)) {
                $resp['ok'] = true;
                $resp['filename'] = $fname;
            } else {
                $resp['error'] = "Failed to upload file.";
            }
        }
        echo json_encode($resp); exit;
    }
    // Delete file
    if ($_POST['action'] === 'delete_file' && !empty($_POST['devtype']) && !empty($_POST['distribution']) && !empty($_POST['filename'])) {
        $devtype = sanitizeName($_POST['devtype']);
        $dist = sanitizeName($_POST['distribution']);
        $fname = basename($_POST['filename']);
        $target = "$storageRoot/$devtype/$dist/$fname";
        if (is_file($target) && unlink($target)) {
            $resp['ok'] = true;
        } else {
            $resp['error'] = "Failed to delete file.";
        }
        echo json_encode($resp); exit;
    }
    // Edit distrib.json (edit+save)
    if ($_POST['action'] === 'save_distrib' && !empty($_POST['devtype']) && !empty($_POST['distribution'])) {
        $devtype = sanitizeName($_POST['devtype']);
        $dist = sanitizeName($_POST['distribution']);
        $content = $_POST['content'] ?? '{}';
        $distPath = "$storageRoot/$devtype/$dist";
        if (!is_dir($distPath)) {
            $resp['error'] = "Distribution path missing.";
        } else {
            file_put_contents("$distPath/distrib.json", $content);
            $resp['ok'] = true;
        }
        echo json_encode($resp); exit;
    }
    // Generate distrib.json
    if ($_POST['action'] === 'generate_distrib_json' && !empty($_POST['devtype']) && !empty($_POST['distribution'])) {
        $devtype = sanitizeName($_POST['devtype']);
        $dist = sanitizeName($_POST['distribution']);
        $files = isset($_POST['files']) ? json_decode($_POST['files'], true) : [];
        $launchServices = isset($_POST['services']) ? json_decode($_POST['services'], true) : [];
        $targetPath = trim($_POST['target_path'] ?? '');
        if (!is_dir("$storageRoot/$devtype/$dist")) {
            echo json_encode(['ok' => false, 'error' => 'Distribution path missing.']); exit;
        }
        $arr = [];
        foreach ($files as $file) {
            $arr[] = [
                'filename'          => $file,
                'launch_as_service' => in_array($file, $launchServices),
                'target_path'       => $targetPath
            ];
        }
        $json = json_encode([
            'distribution' => $dist,
            'device_type'  => $devtype,
            'generated_at' => date('c'),
            'files'        => $arr
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        file_put_contents("$storageRoot/$devtype/$dist/distrib.json", $json);
        echo json_encode(['ok' => true, 'json' => $json]); exit;
    }
    exit;
}

// ================== STORAGE TREE HELPER ===================
function get_storage_tree($storageRoot) {
    $result = [];
    if (!is_dir($storageRoot)) return $result;
    foreach (scandir($storageRoot) as $devtype) {
        if ($devtype === '.' || $devtype === '..' || !is_dir("$storageRoot/$devtype")) continue;
        $dists = [];
        foreach (scandir("$storageRoot/$devtype") as $dist) {
            if ($dist === '.' || $dist === '..' || !is_dir("$storageRoot/$devtype/$dist")) continue;
            $files = [];
            foreach (scandir("$storageRoot/$devtype/$dist") as $file) {
                if ($file === '.' || $file === '..') continue;
                $files[] = $file;
            }
            $dists[] = [
                'name' => $dist,
                'files' => $files
            ];
        }
        $result[] = [
            'name' => $devtype,
            'dists' => $dists
        ];
    }
    return $result;
}
$tree = get_storage_tree($storageRoot);

// AJAX pour reload rapide côté JS
if (isset($_GET['ajax']) && $_GET['ajax'] === 'tree') {
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(get_storage_tree($storageRoot));
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <title>MEETING - Distribution Manager</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 CSS (dark) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body {
            background: #171b20 !important;
            color: #f3f7fa !important;
            min-height: 100vh;
            margin: 0; padding: 0;
        }
        .navbar {
            background: #111316 !important;
            color: #fff;
            min-height: 56px;
            box-shadow: 0 3px 12px #0008;
        }
        .navbar .brand {
            font-size: 1.35em;
            font-weight: bold;
            color: #17d1a7 !important;
            letter-spacing: 1.1px;
            padding-left: 16px;
        }
        .navbar .nav-link, .navbar .nav-icon {
            color: #fff !important;
        }
        .navbar .nav-link.active, .navbar .nav-link:focus, .navbar .nav-link:hover {
            background: #17d1a7 !important;
            color: #111316 !important;
        }
        .nav-icon {
            font-size: 1.1em;
            margin-right: 5px;
        }
        .dark-toggle {
            border: none;
            background: #232832;
            color: #fff;
            border-radius: 22px;
            padding: 5px 17px;
            cursor: pointer;
            font-size: 1em;
            margin-left: 18px;
        }
        .main-content {
            width: 100%;
            max-width: 1800px;
            margin: 0 auto;
            padding: 34px 2vw 40px 2vw;
            display: flex;
            flex-wrap: wrap;
        }
        .main-panel {
            flex: 1 1 68%;
            min-width: 350px;
            max-width: 1100px;
            margin-right: 38px;
        }
        .right-panel {
            flex: 1 1 28%;
            min-width: 270px;
            max-width: 420px;
            background: #20242a;
            border-radius: 14px;
            box-shadow: 0 6px 22px #0008;
            padding: 30px 24px 24px 24px;
            margin-top: 10px;
            margin-left: 0;
            height: fit-content;
        }
        .panel {
            background: #20242a;
            border-radius: 12px;
            box-shadow: 0 3px 14px #0006;
            padding: 26px 24px 22px 24px;
            margin-bottom: 25px;
            min-width: 280px;
            max-width: 420px;
        }
        .section-title {
            color: #17d1a7;
            font-weight: 600;
            font-size: 1.13em;
            margin-top: 0; margin-bottom: 18px;
        }
        .form-label { font-weight: 500; color: #b2cdf7; margin-bottom: 4px;}
        .btn, button, input[type="submit"] {
            border-radius: 7px !important;
            font-size: 1em;
        }
        .btn-accent {
            background: #17d1a7;
            color: #191a1e !important;
            border: none;
        }
        .btn-accent:hover {
            background: #0ca584;
            color: #fff !important;
        }
        .danger, .btn-danger, .btn-delete {
            color: #ff6161 !important;
        }
        .btn-delete {
            background: transparent;
            border: none;
            padding: 0 5px;
            color: #ff6161 !important;
            font-weight: 500;
        }
        .btn-delete:hover {
            background: #ff616133 !important;
        }
        .device-type-accordion {
            background: #191a1e;
            border-radius: 7px;
            margin-bottom: 13px;
            box-shadow: 0 2px 5px #0002;
        }
        .device-type-header {
            cursor: pointer;
            font-weight: bold;
            padding: 13px 18px;
            border-radius: 7px;
            background: #17181d;
            font-size: 1.12em;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: #17d1a7;
            transition: background 0.15s;
            user-select: none;
        }
        .device-type-header:hover { background: #20222a;}
        .device-type-content {
            display: none;
            padding: 9px 20px 10px 25px;
            border-radius: 0 0 7px 7px;
            background: #1e2026;
        }
        .device-type-accordion.expanded .device-type-content { display: block; animation: fadeIn 0.26s;}
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; }}
        .dist-block {
            margin-bottom: 13px;
            background: #181b1f;
            padding: 12px 15px 15px 15px;
            border-radius: 8px;
            border-left: 5px solid #17d1a7;
        }
        .dist-block.selected { border-left: 7px solid #33eec0; background: #1c2326;}
        .dist-block h3 { margin-bottom: 9px;}
        .file-list { margin: 9px 0 0 0; padding: 0; list-style: none;}
        .file-list li { display: flex; align-items: center; gap: 13px; padding: 4px 0; border-bottom: 1px solid #222;}
        .file-list li:last-child { border-bottom: none;}
        .file-link { color: #17d1a7; text-decoration: underline;}
        .file-action { color: #ff6161; cursor: pointer; font-size: 1.14em; margin-left: 9px;}
        .file-action:hover { color: #fff; background: #ff6161; border-radius: 4px;}
        .upload-box { margin-top: 9px;}
        textarea { width: 100%; min-height: 110px; background: #191a1e; color: #eee; font-family: 'Fira Mono', 'Consolas', 'monospace'; border-radius: 5px; border: 1px solid #31333a; padding: 7px 11px; font-size: 1em;}
        #distribEditModal, #distribModal {
            display: none; position: fixed; z-index: 11000; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(22,25,30,0.60);
            align-items: center; justify-content: center;
        }
        #distribEditModal > div, #distribModal > div {
            background: #20242a; padding: 23px 32px 18px 32px; border-radius: 13px; min-width: 320px; max-width: 98vw; box-shadow: 0 6px 34px #0007;
        }
        #distribModal table { width:100%;border-collapse:collapse;}
        #distribModal th, #distribModal td { padding:7px 6px; font-size:0.99em;}
        #distribModal th { color: #17d1a7; background: #191a1e;}
        #distribModal tr:nth-child(even) { background: #181b1f;}
        #distribModal tr:nth-child(odd) { background: #222328;}
        #distribModal input[type="checkbox"] { transform:scale(1.2);}
        #distribModalNotif { margin-top:7px;font-size:0.98em; min-height:20px;}
        @media (max-width: 1200px) {
            .main-content { flex-direction: column;}
            .main-panel, .right-panel { margin-right: 0; max-width: 100%; }
            .right-panel { margin-top: 24px;}
        }
        @media (max-width: 900px) {
            .main-content { padding: 10px 0 0 0;}
            .panel { max-width: 100%; min-width: 0;}
            .right-panel { min-width: 0; max-width: 100%;}
        }
    </style>
</head>
<body class="dark">
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container-fluid">
            <span class="brand">🛠️ Distribution Manager</span>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 navlinks">
                    <?php foreach ($links as $link): ?>
                        <?php
                            $icon = isset($link['icon']) ? '<span class="nav-icon">'.htmlspecialchars($link['icon']).'</span>' : '';
                            $name = htmlspecialchars($link['name']);
                            if (isset($link['file'])) {
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['file']}\">{$icon}{$name}</a></li>";
                            } else if (isset($link['url'])) {
                                $target = isset($link['target']) ? " target=\"{$link['target']}\"" : "";
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['url']}\"$target>{$icon}{$name}</a></li>";
                            } else {
                                echo "<li class=\"nav-item\"><span class=\"nav-link\">{$icon}{$name}</span></li>";
                            }
                        ?>
                    <?php endforeach; ?>
                </ul>
            </div>
            <button class="dark-toggle" onclick="toggleDarkMode()" title="Toggle light/dark mode">
                <svg width="18" height="18" viewBox="0 0 20 20"><path fill="currentColor" d="M10 2a8 8 0 1 0 8 8a8 8 0 0 0-8-8Zm0 14a6 6 0 1 1 6-6a6 6 0 0 1-6 6Zm0-11a1 1 0 1 0 1 1a1 1 0 0 0-1-1Z"/></svg>
                Dark mode
            </button>
        </div>
    </nav>
    <div class="main-content">
        <div class="main-panel">
            <h1 style="color:#17d1a7; font-weight:600;font-size:1.35em;margin-bottom:19px;">Device Type & Distribution Management</h1>
            <div class="d-flex flex-wrap gap-3 mb-4">
                <!-- Device Type Creation -->
                <div class="panel me-2 mb-2">
                    <h2 style="color:#17d1a7;font-size:1.12em;margin-bottom:13px;">➕ Add Device Type</h2>
                    <div class="mb-3">
                        <input type="text" id="newDevType" maxlength="32" class="form-control mb-2" placeholder="Device type (ex: y-cam)">
                        <button class="btn btn-accent" onclick="createDevType()">Create</button>
                    </div>
                    <div id="addDevTypeMsg" style="color:#ff6161;margin-top:7px;font-size:0.99em;"></div>
                </div>
                <!-- Distribution Creation -->
                <div class="panel mb-2">
                    <h2 style="color:#17d1a7;font-size:1.12em;margin-bottom:13px;">➕ Add Distribution</h2>
                    <div class="mb-3 d-flex gap-2">
                        <select id="devTypeForDist" class="form-select"></select>
                        <input type="text" id="newDistribution" maxlength="32" class="form-control" placeholder="Distribution (ex: debian12)">
                        <button class="btn btn-accent" onclick="createDistribution()">Create</button>
                    </div>
                </div>
            </div>
            <hr style="margin:18px 0 21px 0;border:1px solid #222;">
            <div>
                <h2 class="section-title mb-2">📦 Device Types & Distributions</h2>
                <div id="treeList"></div>
            </div>
        </div>
        <div class="right-panel" id="rightPanelInfo">
            <h3 style="color:#17d1a7;margin-bottom:12px;">ℹ️ Info</h3>
            <div id="rightPanelContent" style="color:#bbc;">Sélectionne une distribution pour voir ses infos et actions.</div>
        </div>
    </div>

    <!-- Modal for distrib.json editing -->
    <div id="distribEditModal">
        <div>
            <h3 style="color:#17d1a7;">Edit distrib.json</h3>
            <textarea id="distribEditContent"></textarea>
            <div class="d-flex justify-content-end mt-2 gap-2">
                <button class="btn btn-outline-secondary" onclick="closeDistribEditModal()">Cancel</button>
                <button class="btn btn-accent" onclick="saveDistribEdit()">Save</button>
            </div>
        </div>
    </div>
    <!-- Modal "Generate distrib" -->
    <div id="distribModal">
        <div>
            <h3 style="margin-bottom:14px;color:#17d1a7;font-size:1.18em;">Generate distrib.json</h3>
            <div class="mb-2">
                <label><b>Target path on device:</b></label>
                <input type="text" id="distribTargetPath" class="form-control" style="width:80%;display:inline-block;margin-left:7px;" placeholder="/mnt/flash/" value="/mnt/flash/">
            </div>
            <div id="distribModalFiles" style="max-height:210px;overflow:auto;margin-bottom:16px;"></div>
            <div class="d-flex justify-content-end gap-2">
                <button class="btn btn-outline-secondary" onclick="closeDistribPopup()">Cancel</button>
                <button class="btn btn-accent" onclick="generateDistribJson()">Générer distrib.json</button>
            </div>
            <div id="distribModalNotif" style="margin-top:9px;font-size:0.98em;"></div>
        </div>
    </div>

<script>
let storageTree = <?= json_encode($tree) ?>;
let distribFilesMap = {}; // [devtype][dist] = [files...];

function toggleAccordion(idx) {
    let accs = document.querySelectorAll('.device-type-accordion');
    accs.forEach((a, i) => {
        if (i === idx) a.classList.toggle('expanded');
        else a.classList.remove('expanded');
    });
}

let selectedDist = { devtype: '', dist: '' };

function renderTreeList() {
    let div = document.getElementById('treeList');
    distribFilesMap = {}; // reset
    if (!storageTree.length) {
        div.innerHTML = '<p style="color:#b0b0b0">Aucun device type pour l\'instant. Ajoute-en !</p>';
        return;
    }
    let html = '';
    storageTree.forEach((dt, idx) => {
        html += `<div class="device-type-accordion">
            <div class="device-type-header" onclick="toggleAccordion(${idx})">
                <span>🖥️ ${dt.name}</span>
                <span style="font-size:1.15em;">&#x25BC;</span>
            </div>
            <div class="device-type-content">`;
        if (!dt.dists.length) {
            html += `<div style="color:#bbb;margin-left:18px;">Aucune distribution.</div>`;
        } else {
            dt.dists.forEach(dist => {
                let isSelected = (selectedDist.devtype === dt.name && selectedDist.dist === dist.name);
                if (!distribFilesMap[dt.name]) distribFilesMap[dt.name] = {};
                distribFilesMap[dt.name][dist.name] = dist.files;
                html += `<div class="dist-block${isSelected ? ' selected' : ''}" onclick="selectDist('${dt.name}','${dist.name}', this)">
                    <strong>💾 ${dist.name}</strong>
                    <button class="btn btn-sm btn-outline-info ms-2" onclick="event.stopPropagation();openUpload('${dt.name}','${dist.name}')">Upload Files</button>
                    <button class="btn btn-sm btn-outline-secondary ms-1" onclick="event.stopPropagation();editDistrib('${dt.name}','${dist.name}')">Distrib.json</button>
                    <button class="btn btn-sm btn-accent ms-1" onclick="event.stopPropagation();openDistribPopup('${dt.name}','${dist.name}')">Generate distrib</button>
                    <ul class="file-list mt-2">`;
                if (!dist.files.length) {
                    html += `<li><span style="color:#bbb;">Aucun fichier.</span></li>`;
                } else {
                    dist.files.forEach(f => {
                        html += `<li>
                            <a class="file-link" href="/storage/${dt.name}/${dist.name}/${f}" target="_blank">${f}</a>
                            <span class="file-action" title="Supprimer" onclick="event.stopPropagation();deleteFile('${dt.name}','${dist.name}','${f}')">🗑️</span>
                        </li>`;
                    });
                }
                html += `</ul>
                <div class="upload-box" id="uploadBox_${dt.name}_${dist.name}" style="display:none;margin-top:6px;">
                    <form onsubmit="return doUploadFile(event,'${dt.name}','${dist.name}')">
                        <input type="file" name="file" class="form-control d-inline-block" style="color:#fff;width:auto;max-width:165px;" required>
                        <button type="submit" class="btn btn-accent btn-sm ms-1">Upload</button>
                        <button type="button" class="btn btn-outline-secondary btn-sm ms-1" onclick="closeUpload('${dt.name}','${dist.name}')">Cancel</button>
                    </form>
                </div>
                </div>`;
            });
        }
        html += '</div></div>';
    });
    div.innerHTML = html;
}

function selectDist(devtype, dist, block) {
    selectedDist = { devtype, dist };
    document.querySelectorAll('.dist-block').forEach(el => el.classList.remove('selected'));
    if (block) block.classList.add('selected');
    let dt = storageTree.find(d => d.name === devtype);
    let d = dt ? dt.dists.find(dd => dd.name === dist) : null;
    let html = '';
    html += `<div><b>Device type:</b> <span style="color:#fff">${devtype}</span><br>`;
    html += `<b>Distribution:</b> <span style="color:#fff">${dist}</span><br>`;
    if (!d || !d.files.length) {
        html += `<i style="color:#888;">Aucun fichier dans cette distribution.</i></div>`;
    } else {
        html += `<b>Fichiers (${d.files.length}):</b><ul style="margin:4px 0 0 12px;color:#fff;">`;
        d.files.forEach(f => {
            html += `<li><a class="file-link" href="/storage/${devtype}/${dist}/${f}" target="_blank">${f}</a></li>`;
        });
        html += '</ul></div>';
        if (d.files.includes('distrib.json')) {
            html += `<div style="margin-top:11px;">
                <a href="/storage/${devtype}/${dist}/distrib.json" target="_blank" style="color:#17d1a7;text-decoration:underline;font-weight:bold;">⬇️ Télécharger distrib.json</a>
            </div>`;
        }
    }
    document.getElementById('rightPanelContent').innerHTML = html;
}

function updateDevTypeSelect() {
    let s = document.getElementById('devTypeForDist');
    s.innerHTML = '';
    storageTree.forEach(dt => {
        let opt = document.createElement('option');
        opt.value = dt.name;
        opt.textContent = dt.name;
        s.appendChild(opt);
    });
}

function reloadTree() {
    fetch('distribution_manager.php?ajax=tree')
        .then(r => r.json())
        .then(tree => {
            storageTree = tree;
            updateDevTypeSelect();
            renderTreeList();
            document.getElementById('rightPanelContent').innerHTML = 'Sélectionne une distribution pour voir ses infos et actions.';
        });
}

function openUpload(devtype, dist) {
    document.getElementById('uploadBox_' + devtype + '_' + dist).style.display = 'block';
}
function closeUpload(devtype, dist) {
    document.getElementById('uploadBox_' + devtype + '_' + dist).style.display = 'none';
}

function doUploadFile(e, devtype, dist) {
    e.preventDefault();
    let form = e.target;
    let fd = new FormData(form);
    fd.append('action', 'upload_file');
    fd.append('devtype', devtype);
    fd.append('distribution', dist);
    fetch('distribution_manager.php', {
        method: 'POST',
        body: fd
    }).then(r => r.json())
    .then(data => {
        if (data.ok) {
            alert('Fichier uploadé !');
            closeUpload(devtype, dist);
            reloadTree();
        } else alert(data.error || 'Erreur serveur');
    });
    return false;
}

function deleteFile(devtype, dist, fname) {
    if (!confirm('Supprimer ce fichier ?')) return;
    fetch('distribution_manager.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=delete_file&devtype=' + encodeURIComponent(devtype) + '&distribution=' + encodeURIComponent(dist) + '&filename=' + encodeURIComponent(fname)
    }).then(r => r.json())
    .then(data => {
        if (data.ok) {
            reloadTree();
        } else alert(data.error || 'Erreur serveur');
    });
}

let distribEditDevType = '', distribEditDist = '';
function editDistrib(devtype, dist) {
    distribEditDevType = devtype;
    distribEditDist = dist;
    let url = `/storage/${devtype}/${dist}/distrib.json`;
    fetch(url)
        .then(r => r.ok ? r.text() : '{}')
        .then(txt => {
            document.getElementById('distribEditContent').value = txt;
            document.getElementById('distribEditModal').style.display = 'flex';
        });
}
function closeDistribEditModal() {
    document.getElementById('distribEditModal').style.display = 'none';
}
function saveDistribEdit() {
    let val = document.getElementById('distribEditContent').value;
    fetch('distribution_manager.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=save_distrib&devtype=' + encodeURIComponent(distribEditDevType) + '&distribution=' + encodeURIComponent(distribEditDist) + '&content=' + encodeURIComponent(val)
    }).then(r => r.json())
    .then(data => {
        if (data.ok) {
            alert('distrib.json sauvegardé !');
            closeDistribEditModal();
        } else alert(data.error || 'Erreur serveur');
    });
}

let currentDistrib = {devtype: '', dist: '', files: []};
function openDistribPopup(devtype, dist) {
    let files = [];
    if (distribFilesMap[devtype] && distribFilesMap[devtype][dist]) {
        files = distribFilesMap[devtype][dist];
    }
    currentDistrib = {devtype, dist, files};
    let box = document.getElementById('distribModalFiles');
    let html = '';
    let filteredFiles = files.filter(f => f !== "distrib.json" && f !== "manifest.json");
    if (!filteredFiles.length) html = "<i style='color:#aaa;'>Aucun fichier dans cette distribution.</i>";
    else {
        html = `<table>
            <tr style="background:#202226;">
                <th></th>
                <th>File</th>
                <th>Launch as service</th>
            </tr>`;
        filteredFiles.forEach(f => {
            html += `<tr>
                <td><input type="checkbox" class="distrib_file_cb" data-file="${f}" checked></td>
                <td style="padding:3px 0;">${f}</td>
                <td style="text-align:center;">
                  <input type="checkbox" class="distrib_service_cb" data-file="${f}">
                </td>
            </tr>`;
        });
        html += '</table>';
    }
    box.innerHTML = html;
    document.getElementById('distribModalNotif').innerHTML = '';
    document.getElementById('distribModal').style.display = 'flex';
}
function closeDistribPopup() {
    document.getElementById('distribModal').style.display = 'none';
}
function generateDistribJson() {
    let notif = document.getElementById('distribModalNotif');
    let checkboxes = document.querySelectorAll('.distrib_file_cb');
    let files = [];
    checkboxes.forEach(cb => { if (cb.checked) files.push(cb.getAttribute('data-file')); });
    if (!files.length) {
        notif.innerHTML = "<span style='color:#ff6161;'>Aucun fichier sélectionné.</span>";
        return;
    }
    let services = [];
    document.querySelectorAll('.distrib_service_cb').forEach(cb => {
        if (cb.checked && files.includes(cb.getAttribute('data-file'))) services.push(cb.getAttribute('data-file'));
    });
    let targetPath = document.getElementById('distribTargetPath').value.trim();
    if (!targetPath) {
        notif.innerHTML = "<span style='color:#ff6161;'>Target path requis !</span>";
        return;
    }
    notif.innerHTML = "⏳ Génération en cours...";
    fetch('distribution_manager.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body:
            'action=generate_distrib_json'
            + '&devtype=' + encodeURIComponent(currentDistrib.devtype)
            + '&distribution=' + encodeURIComponent(currentDistrib.dist)
            + '&files=' + encodeURIComponent(JSON.stringify(files))
            + '&services=' + encodeURIComponent(JSON.stringify(services))
            + '&target_path=' + encodeURIComponent(targetPath)
    })
    .then(r => r.json())
    .then(data => {
        if (data.ok) {
            notif.innerHTML = "<span style='color:#17d1a7;'>distrib.json généré avec succès !</span>";
            setTimeout(() => { closeDistribPopup(); reloadTree(); }, 1200);
        } else {
            notif.innerHTML = "<span style='color:#ff6161;'>Erreur : " + (data.error || 'Serveur') + "</span>";
        }
    });
}

function createDevType() {
    let name = document.getElementById('newDevType').value.trim();
    let msg = document.getElementById('addDevTypeMsg');
    msg.textContent = '';
    if (!name || name.length < 2) {
        msg.textContent = "Nom trop court.";
        return;
    }
    fetch('distribution_manager.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=new_devtype&devtype=' + encodeURIComponent(name)
    }).then(r => r.json())
    .then(data => {
        if (data.ok) {
            msg.style.color = "#17d1a7";
            msg.textContent = "Device type créé !";
            document.getElementById('newDevType').value = '';
            reloadTree();
        } else {
            msg.style.color = "#ff6161";
            msg.textContent = data.error || "Erreur serveur";
            console.error("Add Device Type error:", data);
        }
    })
    .catch(err => {
        msg.style.color = "#ff6161";
        msg.textContent = "Erreur AJAX";
        console.error("Add Device Type AJAX error:", err);
    });
}

function createDistribution() {
    let s = document.getElementById('devTypeForDist');
    let devtype = s.value;
    let name = document.getElementById('newDistribution').value.trim();
    if (!devtype || !name) return;
    fetch('distribution_manager.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=new_dist&devtype=' + encodeURIComponent(devtype) + '&distribution=' + encodeURIComponent(name)
    }).then(r => r.json())
    .then(data => {
        if (data.ok) {
            document.getElementById('newDistribution').value = '';
            reloadTree();
        } else alert(data.error || "Erreur serveur");
    });
}

document.addEventListener('DOMContentLoaded', function() {
    updateDevTypeSelect();
    renderTreeList();
});

function toggleDarkMode() {
    document.body.classList.toggle('dark');
    // Optionally, more advanced toggling.
}
</script>
</body>
</html>
