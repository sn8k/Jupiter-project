<?php
// File: admin/device_creation_beta.php
// Version: 2.5.2
// Date: 2025-06-13
// Description: Device creation UI (Meeting), dashboard, "Setup"/"Global" par défaut, batch create, édition type/distribution
// CHANGELOG:
// - 2.5.1 (2025-06-13): Utilise storage_path défini dans config.php
// - 2.5.0 (2025-05-27): Defaults type/distrib to 'Setup'/'Global', corrections JS, batch modal, édition complète

$config = require __DIR__ . '/../api/config.php';
$links = include __DIR__ . '/links.php';

// === Création dynamique du PDO ===
try {
    $pdo = new PDO(
        "mysql:host={$config['db_host']};dbname={$config['db_name']};charset={$config['db_charset']}",
        $config['db_user'],
        $config['db_pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . htmlspecialchars($e->getMessage()));
}

// Scan device types and distributions
function get_types_and_distributions_fs($storageRoot) {
    $types = [];
    $dists = [];
    if (!is_dir($storageRoot)) return [[], []];
    foreach (scandir($storageRoot) as $devtype) {
        if ($devtype === '.' || $devtype === '..' || !is_dir("$storageRoot/$devtype")) continue;
        $types[] = $devtype;
        foreach (scandir("$storageRoot/$devtype") as $dist) {
            if ($dist === '.' || $dist === '..' || !is_dir("$storageRoot/$devtype/$dist")) continue;
            $dists[$devtype][] = $dist;
        }
    }
    return [$types, $dists];
}
[$deviceTypes, $allDists] = get_types_and_distributions_fs($config['storage_path'] ?? ($config['flash_storage_root'] ?? dirname(__DIR__) . '/storage'));

function find_next_serial($pdo) {
    $used = [];
    $stmt = $pdo->query("SELECT product_serial FROM devices WHERE product_serial IS NOT NULL");
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN, 0) as $s) {
        if (preg_match('/^V1-S01-(\d{5})$/', $s, $m)) $used[(int)$m[1]] = true;
    }
    for ($i = 1; $i <= 99999; $i++) {
        if (!isset($used[$i])) return sprintf("V1-S01-%05d", $i);
    }
    return null;
}
$serial = find_next_serial($pdo);
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <title>MEETING - DEVICE CREATION</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 CSS (dark) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body {
            background: #171b20 !important;
            color: #f3f7fa !important;
            min-height: 100vh;
            margin: 0; padding: 0;
        }
        .navbar {
            background: #111316 !important;
            color: #fff;
            min-height: 56px;
            box-shadow: 0 3px 12px #0008;
        }
        .navbar .brand {
            font-size: 1.35em;
            font-weight: bold;
            color: #2196f3 !important;
            letter-spacing: 1.1px;
            padding-left: 16px;
        }
        .navbar .nav-link, .navbar .nav-icon {
            color: #fff !important;
        }
        .navbar .nav-link.active, .navbar .nav-link:focus, .navbar .nav-link:hover {
            background: #2196f3 !important;
            color: #fff !important;
        }
        .nav-icon {
            font-size: 1.1em;
            margin-right: 5px;
        }
        .dark-toggle {
            border: none;
            background: #232832;
            color: #fff;
            border-radius: 22px;
            padding: 5px 17px;
            cursor: pointer;
            font-size: 1em;
            margin-left: 18px;
        }
        .main-content {
            width: 100%;
            max-width: 1800px;
            margin: 0 auto;
            padding: 34px 2vw 40px 2vw;
        }
        .admin-toolbar {
            background: #20242a;
            border-radius: 12px 12px 0 0;
            box-shadow: 0 3px 14px #0006;
            display: flex;
            flex-wrap: wrap;
            gap: 18px 30px;
            align-items: end;
            padding: 26px 30px 22px 30px;
            margin-bottom: 0;
        }
        .admin-toolbar .form-label {
            font-weight: 500;
            margin-bottom: 4px;
            color: #b2cdf7;
        }
        .admin-toolbar .input-group,
        .admin-toolbar .form-select {
            min-width: 170px;
        }
        .admin-toolbar .btn, .csv-export-btn {
            height: 40px;
            min-width: 48px;
            font-size: 1em;
        }
        .csv-export-btn {
            background: #2196f3;
            color: #fff;
            border-radius: 8px;
            border: none;
            padding: 0 19px;
        }
        .csv-export-btn:hover { background: #1761ac; }
        .search-box {
            min-width: 220px;
        }
        .admin-table-wrap {
            background: #20242a;
            border-radius: 0 0 14px 14px;
            box-shadow: 0 6px 22px #0008;
            padding: 0 18px 26px 18px;
            margin-bottom: 44px;
        }
        .table {
            margin-bottom: 0;
            background: transparent;
            color: #f3f7fa;
        }
        .table thead th {
            background: #232832;
            color: #2196f3;
            font-weight: 600;
            position: sticky; top: 0; z-index: 2;
        }
        .auth-checkbox {
            transform: scale(1.18);
            cursor: pointer;
        }
        .icon-btn, .purge-btn, .edit-btn {
            border: none;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 6px 10px;
            font-size: 1.07em;
            transition: background .13s;
            background: #212529;
            color: #e53935;
        }
        .icon-btn.edit-btn { color: #43a047; }
        .icon-btn.edit-btn:hover { background: #2ba15721; color: #2ba157; }
        .icon-btn:hover { background: #e5393522; color: #fff; }
        .purge-btn {
            background: #ffa000 !important; color: #fff !important;
            padding: 6px 10px;
            font-size: 1em;
            margin-left: 4px;
        }
        .purge-btn:hover { background: #ef6c00 !important; }
        .copy-btn {
            background: transparent;
            border: none;
            margin-left: 3px;
            color: #2196f3;
            cursor: pointer;
            padding: 0 3px;
        }
        .copy-btn:active { color: #1761ac; }
        .pagination {
            margin: 18px 0 2px 0;
            text-align: center;
        }
        .pagination button {
            margin: 0 3px; font-size: 1em; padding: 5px 14px;
        }
        .modal {
            display: none; position: fixed; z-index: 1055;
            left: 0; top: 0; width: 100vw; height: 100vh;
            background: rgba(30, 30, 40, 0.23);
            align-items: center; justify-content: center;
        }
        .modal-content {
            background: #232832;
            color: #f3f7fa;
            border-radius: 10px;
            box-shadow: 0 4px 24px #0008;
            padding: 28px 24px 20px 24px;
            min-width: 340px; max-width: 98vw;
            display: flex; flex-direction: column; align-items: stretch;
        }
        .modal-content label { margin-bottom: 8px; }
        .modal-content input, .modal-content select { margin-bottom: 16px; }
        .modal-content .modal-actions { text-align: right; }
        .modal-content button { margin-left: 10px; }
        @media (max-width: 1100px) {
            .main-content { padding: 18px 2vw 16px 2vw; }
            .admin-toolbar { flex-direction: column; gap: 12px 0; }
            .admin-table-wrap { padding: 0 2vw 12px 2vw; }
        }
        @media (max-width: 600px) {
            .main-content { padding: 7px 2vw 8px 2vw;}
            .admin-toolbar { padding: 8px 6px 8px 6px;}
            .admin-table-wrap { padding: 0 0 8px 0; }
            .navbar .brand { font-size: 1em; padding-left: 7px;}
            .navbar .nav-link { font-size: 0.97em; padding: 6px 9px;}
            .dark-toggle { margin-right: 6px; font-size: 0.95em;}
        }
        /* Bouton batch-create identique autres boutons */
        #batchCreateBtn {
            min-width: 48px;
            height: 40px;
            padding-left: 18px;
            padding-right: 18px;
            margin-left: 7px;
        }
        .admin-table-headbar {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            flex-wrap: wrap;
        }
        .admin-table-headbar .head-title {
            font-size: 1.18em;
            color: #2196f3;
            font-weight: 600;
        }
        .admin-table-headbar .search-wrap {
            margin-bottom: 2px;
        }
        .search-wrap {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-left: auto;
        }
    </style>
</head>
<body class="dark">
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container-fluid">
            <span class="brand">🟦 MEETING Admin</span>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0 navlinks">
                    <?php foreach ($links as $link): ?>
                        <?php
                            $icon = isset($link['icon']) ? '<span class="nav-icon">'.htmlspecialchars($link['icon']).'</span>' : '';
                            $name = htmlspecialchars($link['name']);
                            if (isset($link['file'])) {
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['file']}\">{$icon}{$name}</a></li>";
                            } else if (isset($link['url'])) {
                                $target = isset($link['target']) ? " target=\"{$link['target']}\"" : "";
                                echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['url']}\"$target>{$icon}{$name}</a></li>";
                            } else {
                                echo "<li class=\"nav-item\"><span class=\"nav-link\">{$icon}{$name}</span></li>";
                            }
                        ?>
                    <?php endforeach; ?>
                </ul>
            </div>
            <button class="dark-toggle" onclick="toggleDarkMode()" title="Toggle light/dark mode">
                <svg width="18" height="18" viewBox="0 0 20 20"><path fill="currentColor" d="M10 2a8 8 0 1 0 8 8a8 8 0 0 0-8-8Zm0 14a6 6 0 1 1 6-6a6 6 0 0 1-6 6Zm0-11a1 1 0 1 0 1 1a1 1 0 0 0-1-1Z"/></svg>
                Dark mode
            </button>
        </div>
    </nav>
    <div class="main-content">
        <!-- TOOLBAR -->
        <div class="admin-toolbar flex-wrap gap-4">
            <form class="row row-cols-lg-auto g-3 align-items-end" onsubmit="event.preventDefault();addManualDevice();">
                <div class="col">
                    <label for="deviceKeyToAdd" class="form-label">DeviceKey</label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="deviceKeyToAdd" maxlength="32" placeholder="Manual or auto-generated deviceKey">
                        <button class="btn btn-outline-primary" onclick="generateDeviceKey()" type="button">Generate</button>
                    </div>
                </div>
                <div class="col">
                    <label for="tokenCode" class="form-label">Token</label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="tokenCode" maxlength="32" placeholder="Token code (1-32 chars)">
                        <button class="btn btn-outline-secondary" onclick="generateTokenCode()" type="button">Random</button>
                    </div>
                </div>
                <div class="col">
                    <label for="deviceType" class="form-label">Type</label>
                    <select class="form-select" id="deviceType"></select>
                </div>
                <div class="col">
                    <label for="distribution" class="form-label">Distribution</label>
                    <select class="form-select" id="distribution"></select>
                </div>
                <div class="col">
                    <label for="productSerial" class="form-label">Serial</label>
                    <input type="text" class="form-control" id="productSerial" maxlength="20" readonly value="<?php echo htmlspecialchars($serial ? $serial : 'NO AVAILABLE SERIAL'); ?>">
                </div>
                <div class="col d-flex align-items-end gap-2">
                    <button class="btn btn-primary" type="submit">Add</button>
                    <button class="btn btn-outline-light" onclick="resetAll()" type="button">Reset</button>
                    <button class="btn btn-success" id="batchCreateBtn" type="button" onclick="openBatchModal()">
                        Batch Create
                    </button>
                </div>
            </form>
        </div>
        <!-- TABLE & CONTENT -->
        <div class="admin-table-wrap mt-0">
            <div class="pt-4 admin-table-headbar">
                <span class="head-title">Recorded Devices</span>
                <span class="search-wrap">
                    <input type="text" class="form-control search-box" id="searchInput" placeholder="Search DeviceKey, Type, Serial..." onkeyup="searchDevices()">
                    <button class="csv-export-btn" onclick="exportCSV()">Export CSV</button>
                </span>
            </div>
            <div class="devices-list">
                <table id="devicesTable" class="table table-dark table-striped table-hover align-middle">
                    <thead>
                        <tr>
                            <th class="text-center">Auth</th>
                            <th>DeviceKey</th>
                            <th></th>
                            <th>Token</th>
                            <th>Type</th>
                            <th>Distribution</th>
                            <th>Serial</th>
                            <th class="text-center" style="width:70px;"># tokens</th>
                            <th>Time Added</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody id="devicesTbody"></tbody>
                </table>
                <div class="pagination" id="pagination"></div>
            </div>
        </div>
    </div>
    <!-- Modal for editing device -->
    <div class="modal" id="editModal">
        <div class="modal-content">
            <h3>Edit Device</h3>
            <input type="hidden" id="editDeviceKey">
            <label for="editSerial">Serial Number :</label>
            <input type="text" id="editSerial" maxlength="20">
            <label for="editType">Device Type :</label>
            <select id="editType"></select>
            <label for="editDistribution">Distribution :</label>
            <select id="editDistribution"></select>
            <div class="modal-actions">
                <button class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
                <button class="btn btn-success" onclick="saveEditDevice()">Save</button>
            </div>
        </div>
    </div>
    <!-- Batch Create Modal -->
    <div class="modal" id="batchModal">
        <div class="modal-content">
            <h3>Batch Create Devices</h3>
            <label for="batchCount">Number of devices to create:</label>
            <input type="number" id="batchCount" class="form-control mb-2" value="2" min="1" max="100">
            <label for="batchType">Type (optional):</label>
            <select id="batchType" class="form-select mb-2"></select>
            <label for="batchDistribution">Distribution (optional):</label>
            <select id="batchDistribution" class="form-select mb-2"></select>
            <div class="modal-actions">
                <button class="btn btn-secondary" onclick="closeBatchModal()">Cancel</button>
                <button class="btn btn-success" onclick="batchCreateDevices()">Create</button>
            </div>
        </div>
    </div>
<!-- Bootstrap 5 JS + Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
let limit = 25, offset = 0, total = 0;
let allDevices = [];
let filteredDevices = [];
let deviceTypes = <?php echo json_encode($deviceTypes); ?>;
let allDists = <?php echo json_encode($allDists); ?>;

// Valeurs par défaut
const defaultDeviceType = deviceTypes.includes('Setup') ? 'Setup' : '';
const defaultDistribution = (allDists['Setup']||[]).includes('Global') ? 'Global' : '';

function fillDropdown(id, values, allowEmpty=false, defval="") {
    let s = document.getElementById(id);
    s.innerHTML = '';
    if (allowEmpty) {
        let opt = document.createElement('option');
        opt.value = '';
        opt.textContent = '—';
        s.appendChild(opt);
    }
    values.forEach(v => {
        let opt = document.createElement('option');
        opt.value = v;
        opt.textContent = v;
        if (defval && v === defval) opt.selected = true;
        s.appendChild(opt);
    });
}

function updateDistributions(forceEmpty=false) {
    let typeSel = document.getElementById('deviceType');
    let distSel = document.getElementById('distribution');
    let type = typeSel.value;
    let dists = allDists[type] || [];
    fillDropdown('distribution', dists, true, defaultDistribution);
    // Si dans la création, on veut forcer la sélection "Global" par défaut, on le fait
    if(!distSel.value && dists.includes('Global')) distSel.value = 'Global';
}

function fillMainDropdowns() {
    fillDropdown('deviceType', deviceTypes, true, defaultDeviceType);
    updateDistributions();
    document.getElementById('deviceType').addEventListener('change', updateDistributions);
}

fillMainDropdowns();

// Fetch and render all devices
function fetchDevices() {
    fetch(`/api/devices?limit=1000&offset=0`)
    .then(res => res.json())
    .then(data => {
        allDevices = data.devices || [];
        total = allDevices.length;
        filteredDevices = allDevices;
        renderDevicesPage();
        updatePagination();
    });
}

function renderDevicesPage() {
    let tbody = document.getElementById('devicesTbody');
    tbody.innerHTML = '';
    let page = Math.floor(offset / limit);
    let view = filteredDevices.slice(page*limit, (page+1)*limit);

    if (view.length > 0) {
        view.forEach(d => {
            let checked = d.authorized == 1 ? 'checked' : '';
            let tr = document.createElement('tr');
            tr.innerHTML = `<td class="text-center">
                                <input type="checkbox" class="auth-checkbox" ${checked}
                                       onchange="toggleAuth('${d.device_key}', this.checked)">
                            </td>
                            <td class="nowrap">${d.device_key}</td>
                            <td class="nowrap">
                                <button class="copy-btn" title="Copy DeviceKey" onclick="copyToClipboard('${d.device_key}')">
                                    <svg width="19" height="19" viewBox="0 0 20 20"><path fill="#2196f3" d="M7 2a2 2 0 0 0-2 2v1H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-1h1a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H7Zm0 2h7a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1h-1V6a2 2 0 0 0-2-2H7V4Zm4 2a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h7Z"/></svg>
                                </button>
                            </td>
                            <td class="nowrap">${d.token_code || '-'}</td>
                            <td>${d.device_type || '-'}</td>
                            <td>${d.distribution || '-'}</td>
                            <td class="nowrap">${d.product_serial || '-'}</td>
                            <td class="text-center">${d.token_count ?? 0}</td>
                            <td>${d.registered_at || '-'}</td>
                            <td class="text-center">
                                <span class="action-btns">
                                    <button class="icon-btn" onclick="deleteDevice('${d.device_key}')" title="Delete">
                                        <svg width="19" height="19" viewBox="0 0 20 20"><path fill="currentColor" d="M7.25 2A1.25 1.25 0 0 0 6 3.25v1.5H3.25a.75.75 0 1 0 0 1.5H4.4l.86 10.1A2.25 2.25 0 0 0 7.5 18h5a2.25 2.25 0 0 0 2.24-1.65l.86-10.1h1.15a.75.75 0 1 0 0-1.5H14V3.25A1.25 1.25 0 0 0 12.75 2h-5ZM7.5 3.5h5a.25.25 0 0 1 .25.25V4.75h-5.5V3.75A.25.25 0 0 1 7.5 3.5ZM7.26 16.38l-.84-9.88h7.16l-.84 9.88a.75.75 0 0 1-.75.62h-4a.75.75 0 0 1-.75-.62Z"/></svg>
                                    </button>
                                    <button class="icon-btn purge-btn" title="Purge logs" onclick="purgeLogs('${d.device_key}')">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path fill="#ffa000" d="M5.5 6a.5.5 0 0 1 .5.5v7.8a1.7 1.7 0 0 0 1.7 1.7h4.6a1.7 1.7 0 0 0 1.7-1.7V6.5a.5.5 0 0 1 1 0v7.8a2.7 2.7 0 0 1-2.7 2.7H7.7A2.7 2.7 0 0 1 5 14.3V6.5a.5.5 0 0 1 .5-.5Z"/>
                                            <path fill="#ffa000" d="M8 8.75a.5.5 0 1 1 1 0v5a.5.5 0 1 1-1 0v-5Zm3 0a.5.5 0 1 1 1 0v5a.5.5 0 1 1-1 0v-5Zm-5-3.25a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v.5h3a.5.5 0 1 1 0 1H3.5a.5.5 0 1 1 0-1h3v-.5ZM7 5.5v-.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 .5.5v.5H7Z"/>
                                        </svg>
                                    </button>
                                    <button class="icon-btn edit-btn" onclick="openEditModal('${d.device_key}', '${d.product_serial || ''}', '${d.device_type || ''}', '${d.distribution || ''}')" title="Edit">
                                        <svg width="18" height="18" viewBox="0 0 20 20"><path fill="currentColor" d="M4.293 16.707a1 1 0 0 0 .708.293h9a1 1 0 1 0 0-2h-8.586l9.293-9.293a1 1 0 0 0-1.414-1.414l-9.293 9.293v-8.586a1 1 0 1 0-2 0v9a1 1 0 0 0 .293.707ZM18.707 5.707l-4.414-4.414a1 1 0 0 0-1.414 0l-2.828 2.828a1 1 0 0 0 0 1.414l4.414 4.414a1 1 0 0 0 1.414 0l2.828-2.828a1 1 0 0 0 0-1.414Z"/></svg>
                                    </button>
                                </span>
                            </td>`;
            tbody.appendChild(tr);
        });
    } else {
        tbody.innerHTML = '<tr><td colspan=10>No devices found.</td></tr>';
    }
}

function updatePagination() {
    let div = document.getElementById('pagination');
    let pages = Math.ceil(filteredDevices.length / limit);
    let page = Math.floor(offset / limit) + 1;
    let html = '';
    for (let i=1; i<=pages; ++i) {
        html += `<button class="btn btn-sm btn-outline-primary${i===page?' active':''}" onclick="gotoPage(${i})">${i}</button>`;
    }
    div.innerHTML = html;
}
function gotoPage(n) { offset = (n-1)*limit; renderDevicesPage(); updatePagination(); }

// Search live (on page)
function searchDevices() {
    let q = document.getElementById('searchInput').value.trim().toLowerCase();
    if (!q) {
        filteredDevices = allDevices;
    } else {
        filteredDevices = allDevices.filter(d =>
            (d.device_key && d.device_key.toLowerCase().includes(q)) ||
            (d.token_code && d.token_code.toLowerCase().includes(q)) ||
            (d.device_type && d.device_type.toLowerCase().includes(q)) ||
            (d.product_serial && d.product_serial.toLowerCase().includes(q)) ||
            (d.distribution && d.distribution.toLowerCase().includes(q))
        );
    }
    offset = 0;
    renderDevicesPage();
    updatePagination();
}

// Export CSV (frontend only)
function exportCSV() {
    if (!allDevices.length) return alert("No data to export.");
    let csv = "DeviceKey,Token,Type,Distribution,Serial,#tokens,Time Added,Authorized\n";
    allDevices.forEach(d => {
        csv += [
            d.device_key,
            d.token_code || "",
            d.device_type || "",
            d.distribution || "",
            d.product_serial || "",
            d.token_count ?? 0,
            d.registered_at || "",
            d.authorized == 1 ? "Yes" : "No"
        ].map(v => `"${String(v).replace(/"/g, '""')}"`).join(",") + "\n";
    });
    let blob = new Blob([csv], {type: "text/csv"});
    let url = URL.createObjectURL(blob);
    let a = document.createElement('a');
    a.href = url;
    a.download = "devices_export.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// Clipboard copy DeviceKey
function copyToClipboard(val) {
    navigator.clipboard.writeText(val).then(function() {
        // Optionally show feedback
    });
}

function generateDeviceKey() {
    let keyField = document.getElementById('deviceKeyToAdd');
    if (keyField.value.trim()) {
        alert('DeviceKey to add must be empty to generate a random DeviceKey !');
        return;
    }
    fetch('/api/devices/generate-key')
    .then(res => res.json())
    .then(data => {
        if (data.devicekey)
            keyField.value = data.devicekey;
        if (data.token_code) {
            let tokenField = document.getElementById('tokenCode');
            if (!tokenField.value.trim())
                tokenField.value = data.token_code;
        }
    });
}
function generateTokenCode() {
    let tokenField = document.getElementById('tokenCode');
    if (tokenField.value.trim()) {
        alert('Token code must be empty to generate a random token code !');
        return;
    }
    let chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let token = '';
    for (let i=0; i<6; ++i) token += chars.charAt(Math.floor(Math.random()*chars.length));
    tokenField.value = token;
}
function addManualDevice() {
    let key = document.getElementById('deviceKeyToAdd').value.trim();
    let token = document.getElementById('tokenCode').value.trim();
    let deviceType = document.getElementById('deviceType').value;
    let distribution = document.getElementById('distribution').value;
    let serial = document.getElementById('productSerial').value.trim();

    if (!key || !token) return alert('Please enter deviceKey and token code.');
    if (!serial || serial === 'NO AVAILABLE SERIAL') return alert('No serial available, cannot add.');
    // Si vide on force les valeurs par défaut
    if (!deviceType && defaultDeviceType) deviceType = defaultDeviceType;
    if (!distribution && defaultDistribution) distribution = defaultDistribution;

    if (token.length < 1 || token.length > 32) return alert('Token code must be 1-32 chars.');
    fetch('/api/devices/manual-create', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
            devicekey: key,
            token_code: token,
            device_type: deviceType,
            distribution: distribution,
            product_serial: serial
        })
    }).then(res => res.json())
    .then(data => {
        if (data.error) alert(data.error);
        else {
            alert('Device added!');
            fetchDevices();
            resetAll();
        }
    });
}
function resetAll() {
    document.getElementById('deviceKeyToAdd').value = '';
    document.getElementById('tokenCode').value = '';
    document.getElementById('deviceType').value = defaultDeviceType;
    updateDistributions();
    document.getElementById('distribution').value = defaultDistribution;
}
function deleteDevice(deviceKey) {
    if (!confirm('Delete this device key?')) return;
    fetch(`/api/devices/${deviceKey}`, { method: 'DELETE' })
        .then(res => res.json())
        .then(data => { fetchDevices(); });
}
function toggleAuth(deviceKey, authorized) {
    fetch(`/api/devices/${deviceKey}/authorize`, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({authorized: authorized ? 1 : 0})
    })
    .then(res => res.json())
    .then(data => {
        if (data.success !== true) {
            alert('Failed to update authorization: ' + (data.error || 'Unknown error'));
            fetchDevices();
        }
    })
    .catch(() => {
        alert('Failed to update authorization (network error)');
        fetchDevices();
    });
}
function purgeLogs(deviceKey) {
    if (!confirm('This will permanently delete all logs for this device.\nAre you sure?')) return;
    fetch(`/api/devices/${deviceKey}/purge-logs`, { method: 'POST' })
    .then(res => res.json())
    .then(data => {
        if (data.success) alert('Logs purged successfully.');
        else alert('Error purging logs: ' + (data.error || 'Unknown error'));
    })
    .catch(() => alert('Error purging logs (network error)'));
}

// --- EDIT DEVICE MODAL ---
function openEditModal(deviceKey, serial, type, distribution) {
    document.getElementById('editDeviceKey').value = deviceKey;
    document.getElementById('editSerial').value = serial;
    fillDropdown('editType', deviceTypes, true, type);
    let dists = allDists[type] || [];
    fillDropdown('editDistribution', dists, true, distribution);
    document.getElementById('editType').addEventListener('change', function() {
        let dists = allDists[this.value] || [];
        fillDropdown('editDistribution', dists, true);
    });
    document.getElementById('editModal').style.display = 'flex';
}
function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}
function saveEditDevice() {
    let deviceKey = document.getElementById('editDeviceKey').value;
    let serial = document.getElementById('editSerial').value.trim();
    let type = document.getElementById('editType').value;
    let distribution = document.getElementById('editDistribution').value;

    if (!serial) return alert('Serial number is required.');
    if (!type) return alert('Device type is required.');
    fetch(`/api/devices/${deviceKey}/product-serial`, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ product_serial: serial })
    })
    .then(res => res.json())
    .then(data => {
        if (!data.success) {
            alert('Failed to update serial: ' + (data.error || 'Unknown error'));
        } else {
            let chain = Promise.resolve();
            // update type
            chain = chain.then(() =>
                fetch(`/api/devices/${deviceKey}/device-type`, {
                    method: 'PUT',
                    headers: {'Content-Type':'application/json'},
                    body: JSON.stringify({ device_type: type })
                }).then(r => r.json())
            );
            // update distribution
            chain = chain.then(() =>
                fetch(`/api/devices/${deviceKey}/distribution`, {
                    method: 'PUT',
                    headers: {'Content-Type':'application/json'},
                    body: JSON.stringify({ distribution: distribution })
                }).then(r => r.json())
            );
            chain.then(() => {
                alert('Device updated!');
                closeEditModal();
                fetchDevices();
            });
        }
    });
}

// --- BATCH MODAL ---
function openBatchModal() {
    fillDropdown('batchType', deviceTypes, true, defaultDeviceType);
    updateBatchDistributions();
    document.getElementById('batchType').addEventListener('change', updateBatchDistributions);
    document.getElementById('batchDistribution').value = defaultDistribution;
    document.getElementById('batchCount').value = 2;
    document.getElementById('batchModal').style.display = 'flex';
}
function closeBatchModal() {
    document.getElementById('batchModal').style.display = 'none';
}
function updateBatchDistributions() {
    let type = document.getElementById('batchType').value;
    let dists = allDists[type] || [];
    fillDropdown('batchDistribution', dists, true, defaultDistribution);
}

function batchCreateDevices() {
    let n = parseInt(document.getElementById('batchCount').value, 10);
    let type = document.getElementById('batchType').value;
    let dist = document.getElementById('batchDistribution').value;
    if (!n || n < 1 || n > 100) {
        alert("Number of devices must be between 1 and 100.");
        return;
    }
    // Force defaults si vide
    if (!type && defaultDeviceType) type = defaultDeviceType;
    if (!dist && defaultDistribution) dist = defaultDistribution;

    // Placeholder: à remplacer par backend réel si besoin
    let reqs = [];
    for(let i=0; i<n; ++i) {
        let key = ''; // empty for auto
        let token = ''; // empty for random
        let serial = ''; // handled by backend
        reqs.push(
            fetch('/api/devices/manual-create', {
                method: 'POST',
                headers: {'Content-Type':'application/json'},
                body: JSON.stringify({
                    devicekey: key,
                    token_code: token,
                    device_type: type,
                    distribution: dist,
                    product_serial: serial
                })
            })
        );
    }
    Promise.all(reqs).then(() => {
        alert(n + " device(s) created!");
        closeBatchModal();
        fetchDevices();
    });
}

window.onload = function() {
    fetchDevices();
    if(!document.body.classList.contains('dark')) {
        document.body.classList.add('dark');
    }
};
function toggleDarkMode() {
    document.body.classList.toggle('dark');
    if(document.body.classList.contains('dark')) {
        document.documentElement.style.setProperty('--bs-body-bg','#171b20');
        document.documentElement.style.setProperty('--bg-main','#171b20');
        document.documentElement.style.setProperty('--fg-main','#f3f7fa');
        document.documentElement.style.setProperty('--bg-panel','#20242a');
    } else {
        document.documentElement.style.setProperty('--bs-body-bg','#f3f7fa');
        document.documentElement.style.setProperty('--bg-main','#f3f7fa');
        document.documentElement.style.setProperty('--fg-main','#191c21');
        document.documentElement.style.setProperty('--bg-panel','#fff');
    }
}
// Modal close on background click
document.addEventListener('mousedown', function(e) {
    document.querySelectorAll('.modal').forEach(function(m) {
        if (m.style.display === 'flex' && !m.querySelector('.modal-content').contains(e.target)) {
            m.style.display = 'none';
        }
    });
});
</script>
</body>
</html>
