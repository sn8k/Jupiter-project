<?php
// File: admin_ssh_keys.php
// Version: 1.16.0
// Date: 2025-06-17
// Description: Meeting - Admin panel for SSH key management, advanced, API/DB-driven, audit-ready

$links = include __DIR__ . '/links.php';
$config = include __DIR__ . '/../api/config.php';

$data_root = getenv('MEETING_DATA_ROOT') ?: '/var/meeting';
$pub_file  = "$data_root/meeting_id_rsa.pub";
$finger_file = "$data_root/meeting_id_rsa.pub.sha256";
$server_pubkey = is_file($pub_file) ? trim(file_get_contents($pub_file)) : '';
$server_fingerprint = is_file($finger_file) ? trim(file_get_contents($finger_file)) : '';
if (!$server_fingerprint && $server_pubkey) {
    $parts = explode(' ', $server_pubkey);
    if (count($parts) >= 2) {
        $decoded = base64_decode($parts[1], true);
        if ($decoded !== false) {
            $server_fingerprint = 'SHA256:' . rtrim(base64_encode(hash('sha256', $decoded, true)), '=');
        }
    }
}
$server_pubkey_date    = $config['server_pubkey_date'] ?? "";
$server_key_last_deploy= $config['server_key_last_deploy'] ?? "";
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
  <meta charset="UTF-8">
  <title>SSH Key Management - Meeting Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
  <style>
    body { background: #181b1f; color: #ececec; }
    .container-main { max-width: 980px; margin: 32px auto 0 auto; }
    .card { border-radius: 1.1rem; background: #23262b; color: #fff; box-shadow: 0 1.5px 10px rgba(0,0,0,0.23); border: none;}
    .ssh-keybox { font-family: monospace; font-size: .98em; background: #282b30; color: #aee3fc; border-radius: 6px; padding: 8px 10px; margin: 0; word-break: break-all;}
    .device-row td { vertical-align: middle !important; }
    .btn-action { margin-right: 8px; }
    .btn-squared { min-width: 130px; }
    @media (max-width: 700px) { .btn-squared { min-width: 0; width: 100%; } }
    .badge-status { font-size: .95em; }
    .table thead { background: #23262b; color: #7dcfff; }
    .table tbody { background: #1b1e23; }
    .table td, .table th { border-color: #34384a; }
    .card-header { background: #23262b !important; color: #7dcfff !important;}
    .modal-content { background: #222; color: #fff; }
    .modal-header.bg-danger, .modal-header.bg-secondary { color: #fff !important;}
    .mass-action-bar { display: flex; align-items: center; gap: 12px; margin-bottom: 7px; flex-wrap: wrap;}
    .mass-action-bar .btn { font-size: 0.95em; }
    .input-key { font-family: monospace; width: 100%; min-width: 250px; }
    .searchbar { max-width: 400px; margin-bottom: 14px;}
    .audit-btn { margin-right: 6px; }
    @media (max-width: 900px) { .container-main { max-width: 100vw; margin: 10px;} .card { border-radius: 0.8rem;} .ssh-keybox { font-size: 0.93em; } .table { font-size: 0.97em;} }
    @media (max-width: 700px) { .container-main { margin: 2px;} .card { border-radius: 0.6rem;} .ssh-keybox { font-size: 0.85em; padding: 5px 6px;} .table { font-size: 0.89em;} .mass-action-bar { flex-direction: column; align-items: flex-start; } }
    @media (max-width: 480px) { .card { border-radius: 0.45rem;} h2 { font-size: 1.2rem;} .card-header { font-size: 1.03rem;} }
    .navbar-admin { width: 100vw; min-height: 54px; background: #101215; color: #fff; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; left: 0; z-index: 20; box-shadow: 0 3px 12px #0008;}
    .navbar-admin .brand { font-size: 1.25em; font-weight: bold; padding: 0 24px; letter-spacing: 1.2px; color: #2196f3; }
    .navbar-admin .navlinks { display: flex; align-items: center; gap: 8px; }
    .navbar-admin .navlinks a, .navbar-admin .navlinks span {
      color: #fff; background: none; padding: 6px 16px 6px 11px; border-radius: 5px;
      font-size: 1em; text-decoration: none; display: flex; align-items: center;
      transition: background 0.18s, color 0.18s;
    }
    .navbar-admin .navlinks a:hover { background: #2196f3; color: #fff; }
    .navbar-admin .nav-icon { font-size: 1.15em; margin-right: 6px; }
    .dark-toggle { margin-right: 22px; border: none; background: #232832; color: #fff; border-radius: 22px; padding: 5px 17px; cursor: pointer; font-size: 1em; display: flex; align-items: center;}
    .dark-toggle svg { margin-right: 7px; }
  </style>
</head>
<body>
  <nav class="navbar-admin">
    <span class="brand">🟦 MEETING Admin</span>
    <span class="navlinks">
    <?php foreach ($links as $link): ?>
      <?php
        $icon = isset($link['icon']) ? '<span class="nav-icon">'.htmlspecialchars($link['icon']).'</span>' : '';
        $name = htmlspecialchars($link['name']);
        if (isset($link['file'])) {
          echo "<a href=\"{$link['file']}\">{$icon}{$name}</a>";
        } else if (isset($link['url'])) {
          $target = isset($link['target']) ? " target=\"{$link['target']}\"" : "";
          echo "<a href=\"{$link['url']}\"$target>{$icon}{$name}</a>";
        } else {
          echo "<span>{$icon}{$name}</span>";
        }
      ?>
    <?php endforeach; ?>
    </span>
    <button class="dark-toggle" onclick="toggleDarkMode()" title="Toggle light/dark mode">
      <svg width="18" height="18" viewBox="0 0 20 20"><path fill="currentColor" d="M10 2a8 8 0 1 0 8 8a8 8 0 0 0-8-8Zm0 14a6 6 0 1 1 6-6a6 6 0 0 1-6 6Zm0-11a1 1 0 1 0 1 1a1 1 0 0 0-1-1Z"/></svg>
      Dark mode
    </button>
  </nav>
  <div class="container container-main">
    <h2 class="mb-4 mt-3 text-info"><i class="bi bi-shield-lock"></i> SSH Key Management – Meeting Admin</h2>
    <!-- Server SSH Key Section -->
    <div class="card mb-4">
      <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
        <span><b>Server SSH Key (for devices)</b></span>
        <button class="btn btn-outline-info btn-sm btn-squared ms-auto" disabled title="En attente dev API">
          <i class="bi bi-upload"></i> Deploy new server key to all authorized devices
        </button>
      </div>
      <div class="card-body">
        <?php if (!$server_pubkey): ?>
          <div class="alert alert-warning">Server public key is missing!<br>File expected: <code><?= htmlspecialchars($pub_file) ?></code></div>
        <?php endif; ?>
        <div class="row align-items-center">
          <div class="col-md-10">
            <div class="mb-2"><b>Current key (public):</b></div>
            <pre class="ssh-keybox" id="serverPubkey"><?= htmlspecialchars($server_pubkey) ?></pre>
            <small>Fingerprint: <span class="text-secondary" id="serverFingerprint"><?= htmlspecialchars($server_fingerprint) ?></span></small><br>
            <small>Last generated: <span class="text-secondary" id="serverPubkeyDate"><?= htmlspecialchars($server_pubkey_date) ?></span></small><br>
            <small>Last deployment: <span class="text-success" id="serverKeyLastDeploy"><?= htmlspecialchars($server_key_last_deploy) ?></span></small>
          </div>
          <div class="col-md-2 text-end mt-2 mt-md-0 d-flex flex-column gap-2 align-items-end">
            <button class="btn btn-success btn-sm btn-action btn-squared" onclick="downloadKey()"><i class="bi bi-download"></i> Download</button>
            <button class="btn btn-danger btn-sm btn-action btn-squared" onclick="confirmRegenerate()"><i class="bi bi-arrow-clockwise"></i> Regenerate</button>
            <button class="btn btn-outline-secondary btn-sm btn-action btn-squared" onclick="saveKey()"><i class="bi bi-save"></i> Save</button>
          </div>
        </div>
      </div>
    </div>
    <!-- ADD SSH KEY (manual) -->
    <div class="card mb-4">
      <div class="card-header bg-info text-white">
        <b>Add New Device SSH Key</b>
      </div>
      <div class="card-body">
        <form id="addKeyForm" class="row g-2 align-items-end">
          <div class="col-md-3">
            <label class="form-label">Device Key</label>
            <input type="text" class="form-control" id="addDeviceKey" required maxlength="32" minlength="8" placeholder="Device Key (hex)">
          </div>
          <div class="col-md-3">
            <label class="form-label">SSH User</label>
            <input type="text" class="form-control" id="addSshUser" required maxlength="64" placeholder="Device SSH User">
          </div>
          <div class="col-md-3">
            <label class="form-label">SSH Public Key</label>
            <input type="text" class="form-control input-key" id="addPubKey" required placeholder="ssh-rsa ...">
          </div>
          <div class="col-md-2">
            <label class="form-label">Status</label>
            <select class="form-select" id="addStatus" required>
              <option value="authorized">Authorized</option>
              <option value="revoked">Revoked</option>
            </select>
          </div>
          <div class="col-md-1">
            <button type="submit" class="btn btn-primary w-100">Add</button>
          </div>
        </form>
      </div>
    </div>
    <!-- SEARCH & FILTER -->
    <div class="mb-2 d-flex align-items-center">
      <input class="form-control searchbar me-3" id="searchInput" type="search" placeholder="Search by Device key, SSH User, Status, Fingerprint…" oninput="applySearch()">
      <select class="form-select w-auto" id="filterStatus" onchange="applySearch()">
        <option value="">All Statuses</option>
        <option value="authorized">Authorized</option>
        <option value="revoked">Revoked</option>
      </select>
      <button class="btn btn-outline-secondary ms-3" onclick="fetchDeviceKeys()">Refresh</button>
    </div>
    <!-- Devices Key List -->
    <div class="card">
      <div class="card-header bg-secondary text-white">
        <b>Devices</b> <span class="badge bg-info ms-2" id="apiStatus">Loading…</span>
      </div>
      <div class="card-body pb-1">
        <div class="mass-action-bar">
          <button class="btn btn-outline-danger btn-sm" onclick="massDelete()" id="massDeleteBtn" disabled>
            <i class="bi bi-trash"></i> Mass Delete
          </button>
          <button class="btn btn-outline-info btn-sm" onclick="exportCSV()">
            <i class="bi bi-file-earmark-spreadsheet"></i> Export CSV
          </button>
          <button class="btn btn-outline-secondary btn-sm" onclick="copyAllKeys()">
            <i class="bi bi-clipboard"></i> Copier toutes les clés
          </button>
          <span class="text-warning small ms-2">⚠️ Toute suppression est immédiate et irréversible !</span>
        </div>
        <div class="table-responsive">
        <table class="table table-sm align-middle table-hover" id="deviceTable">
          <thead>
            <tr>
              <th><input type="checkbox" id="selectAll" onchange="toggleSelectAll(this)"></th>
              <th>Device Key</th>
              <th>SSH User</th>
              <th>Status</th>
              <th>Added</th>
              <th>Modified</th>
              <th>Fingerprint</th>
              <th>Last SSH</th>
              <th>Key</th>
              <th class="text-end">Actions</th>
            </tr>
          </thead>
          <tbody id="deviceTableBody">
            <!-- Content will be loaded by JS -->
          </tbody>
        </table>
        </div>
      </div>
    </div>
  </div>
  <!-- Modals -->
  <div class="modal fade" id="modalConfirm" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title" id="modalTitle">Confirmation Required</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body" id="modalBody">Are you sure you want to perform this action?</div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-danger" id="modalConfirmBtn">Yes, Proceed</button>
        </div>
      </div>
    </div>
  </div>
  <div class="modal fade" id="modalKeyView" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-secondary text-white">
          <h5 class="modal-title" id="keyModalTitle">SSH Public Key</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body" id="keyModalBody"></div>
      </div>
    </div>
  </div>
  <div class="modal fade" id="modalAuditLog" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-info text-white">
          <h5 class="modal-title" id="auditLogTitle">Audit Log</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body" id="auditLogBody"><i>Chargement…</i></div>
      </div>
    </div>
  </div>
  <div class="modal fade" id="modalEditKey" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-warning text-dark">
          <h5 class="modal-title">Edit Device Key</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <form id="editKeyForm" class="row g-2">
            <div class="col-12">
              <label class="form-label">SSH User</label>
              <input type="text" class="form-control" id="editSshUser">
            </div>
            <div class="col-12">
              <label class="form-label">Status</label>
              <select class="form-select" id="editStatus">
                <option value="authorized">Authorized</option>
                <option value="revoked">Revoked</option>
              </select>
            </div>
            <div class="col-12">
              <label class="form-label">SSH Public Key</label>
              <textarea class="form-control" id="editPubKey" rows="3"></textarea>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-primary" id="editSaveBtn">Save</button>
        </div>
      </div>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    const API_BASE = '/api';
    let deviceList = []; // Cache for filtering/search

    // ========== DEVICES AJAX ===========
    async function sshFingerprint(pubkey) {
      try {
        const b64 = pubkey.split(' ')[1];
        const bin = atob(b64);
        const buf = new Uint8Array(bin.length);
        for(let i=0;i<bin.length;i++) buf[i] = bin.charCodeAt(i);
        const hash = await crypto.subtle.digest('SHA-256', buf);
        const b64hash = btoa(String.fromCharCode(...new Uint8Array(hash))).replace(/=+$/, '');
        return 'SHA256:' + b64hash;
      } catch(e) { return ''; }
    }

    async function fetchDeviceKeys() {
      document.getElementById('apiStatus').innerText = "Loading…";
      const resp = await fetch(API_BASE+'/devices?limit=1000');
      let data;
      try { data = await resp.json(); } catch { data = {}; }
      if (!Array.isArray(data.devices)) {
        document.getElementById('apiStatus').innerText = "Failed";
        return;
      }
      deviceList = [];
      for (let dev of data.devices) {
        let item = {
          device_key: dev.device_key,
          pubkey: dev.ssh_public_key || '',
          ssh_user: dev.ssh_user || '',
          status: dev.revoked ? 'revoked' : (dev.authorized ? 'authorized' : 'unknown'),
          added: dev.registered_at,
          modified: dev.modified,
          last_ssh: dev.last_seen,
          fingerprint: ''
        };
        if(item.pubkey) item.fingerprint = await sshFingerprint(item.pubkey);
        deviceList.push(item);
      }
      document.getElementById('apiStatus').innerText = "OK";
      renderDeviceTable(deviceList);
    }

    // ========== TABLE RENDER + SEARCH/FILTER ===========
    function renderDeviceTable(list) {
      let html = '';
      list.forEach(dev => {
        html += `<tr class="device-row">
          <td><input type="checkbox" class="row-check" onchange="updateMassAction()" data-device="${dev.device_key}"></td>
          <td><code>${dev.device_key.slice(0,12)}…</code></td>
          <td>${dev.ssh_user || ''}</td>
          <td>
            <span class="badge bg-${dev.status==='authorized'?'success':dev.status==='revoked'?'danger':'secondary'} badge-status">${dev.status?dev.status.charAt(0).toUpperCase()+dev.status.slice(1):''}</span>
            <button class="btn btn-sm btn-outline-warning audit-btn ms-1" title="Revoke/Restore" onclick="toggleRevoke('${dev.device_key}', '${dev.status}')">${dev.status==='revoked'?'Restore':'Revoke'}</button>
          </td>
          <td><small>${dev.added||''}</small></td>
          <td><small>${dev.modified||''}</small></td>
          <td><small>${dev.fingerprint||'-'}</small></td>
          <td><small>${dev.last_ssh||'-'}</small></td>
          <td>
            <span class="d-block text-break ssh-keybox" style="max-width: 240px;">
              ${(dev.pubkey||'').slice(0,34)}…
            </span>
          </td>
          <td class="text-end">
            ${!dev.pubkey ? `<button class="btn btn-outline-primary btn-sm btn-action" title="Get from device" onclick="getKeyFromDevice('${dev.device_key}')"><i class="bi bi-download"></i></button>` : ''}
            <button class="btn btn-warning btn-sm btn-action" title="Edit" onclick="editDeviceKey('${dev.device_key}')"><i class="bi bi-pencil-square"></i></button>
            <button class="btn btn-outline-danger btn-sm btn-action" title="Delete" onclick="confirmDeleteDevice('${dev.device_key}')"><i class="bi bi-trash"></i></button>
            <button class="btn btn-outline-secondary btn-sm btn-action" title="Show Full Key" onclick="showFullKey('${dev.device_key}','${encodeURIComponent(dev.pubkey)}')"><i class="bi bi-eye"></i></button>
            <button class="btn btn-outline-info btn-sm btn-action" title="Audit Log" onclick="showAuditLog('${dev.device_key}')"><i class="bi bi-clipboard-data"></i></button>
            <button class="btn btn-outline-success btn-sm btn-action" title="Deploy server key" disabled><i class="bi bi-upload"></i></button>
            <button class="btn btn-outline-primary btn-sm btn-action" title="Sync/Ping" disabled><i class="bi bi-arrow-repeat"></i></button>
          </td>
        </tr>`;
      });
      document.getElementById('deviceTableBody').innerHTML = html;
      updateMassAction();
    }

    function applySearch() {
      let term = document.getElementById('searchInput').value.toLowerCase();
      let status = document.getElementById('filterStatus').value;
      let filtered = deviceList.filter(dev => {
        let s = JSON.stringify(dev).toLowerCase();
        let pass = (!status || dev.status === status);
        return s.includes(term) && pass;
      });
      renderDeviceTable(filtered);
    }

    // ========== ADD KEY ===========
    document.getElementById('addKeyForm').onsubmit = async function(e) {
      e.preventDefault();
      let payload = {
        pubkey: document.getElementById('addPubKey').value.trim(),
        ssh_user: document.getElementById("addSshUser").value.trim(),
        status: document.getElementById('addStatus').value
      };
      let device_key = document.getElementById('addDeviceKey').value.trim();
      let resp = await fetch(`${API_BASE}/devices/${device_key}/ssh-key`, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(payload)
      });
      if(resp.ok) {
        await fetchDeviceKeys();
        this.reset();
      } else {
        alert("Erreur lors de l'ajout/modification.");
      }
    }

    // ========== Revoke/Restore ===========
    async function toggleRevoke(device_key, status) {
      let newStatus = status === 'revoked' ? 'authorized' : 'revoked';
      let resp = await fetch(`${API_BASE}/devices/${device_key}/ssh-key`, {
        method:'PUT',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({status:newStatus})
      });
      if(resp.ok) fetchDeviceKeys();
      else alert("Erreur lors de la modification du statut.");
    }

    // ========== Audit Log modal ===========
    async function showAuditLog(device_key) {
      document.getElementById('auditLogTitle').innerText = "Audit log – Device "+device_key;
      let body = document.getElementById('auditLogBody');
      body.innerHTML = "<i>Chargement…</i>";
      let resp = await fetch(`${API_BASE}/devices/${device_key}/ssh-key-log`);
      if(resp.ok) {
        let logs = await resp.json();
        if(Array.isArray(logs) && logs.length) {
          body.innerHTML = "<ul>"+logs.map(l=>`<li>${l.timestamp} — ${l.event||'-'} : ${l.detail||'-'}</li>`).join('')+"</ul>";
        } else {
          body.innerHTML = "<i>Aucun événement.</i>";
        }
      } else {
        body.innerHTML = "<i>Erreur lors du chargement.</i>";
      }
      var myModal = new bootstrap.Modal(document.getElementById('modalAuditLog'));
      myModal.show();
    }

    // ========== KEY UTILS et actions classiques ===========
    function downloadKey() {
      const key = document.getElementById('serverPubkey').innerText.trim();
      const blob = new Blob([key], {type: "text/plain"});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = "meeting_id_rsa.pub";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
    async function saveKey() {
      const key = document.getElementById('serverPubkey').innerText.trim();
      let resp = await fetch(`${API_BASE}/ssh-keys/server`, {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({pubkey:key})
      });
      if(resp.ok) {
        let data = await resp.json();
        document.getElementById('serverFingerprint').innerText = data.fingerprint || '';
        document.getElementById('serverPubkeyDate').innerText = data.date || '';
        alert('Server key saved');
      } else {
        alert('Erreur lors de la sauvegarde');
      }
    }
    function confirmRegenerate() {
      showConfirm('Regenerate Server Key','Cette opération va régénérer la clé SSH serveur. Continuer ?', async function(){
        let resp = await fetch(`${API_BASE}/ssh-keys/server/regenerate`, {method:'POST'});
        if(resp.ok) {
          let data = await resp.json();
          if(data.pubkey) document.getElementById('serverPubkey').innerText = data.pubkey;
          if(data.fingerprint) document.getElementById('serverFingerprint').innerText = data.fingerprint;
          if(data.date) document.getElementById('serverPubkeyDate').innerText = data.date;
        } else { alert('Erreur lors de la régénération'); }
      });
    }
    async function editDeviceKey(device_key) {
      let resp = await fetch(`${API_BASE}/forcecommand/get_device_key?device_key=${device_key}`);
      let data = null;
      if(resp.ok) {
        let key = await resp.text();
        if(key && !key.startsWith('{')) {
          data = {ssh_user:'', status:'authorized', pubkey:key};
        }
      }
      if(!data) { alert('Erreur chargement'); return; }
      document.getElementById('editKeyForm').dataset.device = device_key;
      document.getElementById('editSshUser').value = data.ssh_user || '';
      document.getElementById('editStatus').value = data.status || 'authorized';
      document.getElementById('editPubKey').value = data.pubkey || '';
      new bootstrap.Modal(document.getElementById('modalEditKey')).show();
    }
    document.getElementById('editSaveBtn').onclick = async function(){
      let device_key = document.getElementById('editKeyForm').dataset.device;
      let payload = {
        ssh_user: document.getElementById('editSshUser').value.trim(),
        status: document.getElementById('editStatus').value,
        pubkey: document.getElementById('editPubKey').value.trim()
      };
      let resp = await fetch(`${API_BASE}/devices/${device_key}/ssh-key`, {
        method:'PUT',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(payload)
      });
      if(resp.ok) {
        bootstrap.Modal.getInstance(document.getElementById('modalEditKey')).hide();
        fetchDeviceKeys();
      } else {
        alert('Erreur lors de la sauvegarde');
      }
    };
    async function getKeyFromDevice(device_key) {
      let resp = await fetch(`${API_BASE}/forcecommand/get_device_key?device_key=${device_key}`);
      if(resp.ok) {
        let key = await resp.text();
        if(key && !key.startsWith('{')) {
          await fetch(`${API_BASE}/devices/${device_key}/ssh-key`, {method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({pubkey:key})});
          fetchDeviceKeys();
          return;
        }
      }
      alert('Clé introuvable');
    }
    function confirmDeleteDevice(device_key) {
      showConfirm("Delete Device Key", "Are you sure you want to delete the SSH key for device:<br><code>"+device_key+"</code> ?", async function(){
        let resp = await fetch(`${API_BASE}/devices/${device_key}/ssh-key`, {method:'DELETE'});
        if(resp.ok) {
          await fetchDeviceKeys();
        } else {
          alert("Erreur lors de la suppression.");
        }
      });
    }
    function showFullKey(device_key, pubkey) {
      pubkey = decodeURIComponent(pubkey);
      document.getElementById("keyModalTitle").innerText = "Device "+device_key+" - SSH Key";
      document.getElementById("keyModalBody").innerHTML = "<pre class='ssh-keybox'>"+pubkey+"</pre>";
      var myModal = new bootstrap.Modal(document.getElementById('modalKeyView'));
      myModal.show();
    }
    function showConfirm(title, body, cb) {
      document.getElementById("modalTitle").innerText = title;
      document.getElementById("modalBody").innerHTML = body;
      var btn = document.getElementById("modalConfirmBtn");
      btn.onclick = function(){ cb(); var modal = bootstrap.Modal.getInstance(document.getElementById('modalConfirm')); modal.hide(); };
      var myModal = new bootstrap.Modal(document.getElementById('modalConfirm'));
      myModal.show();
    }
    function updateMassAction() {
      let checked = document.querySelectorAll('.row-check:checked').length;
      document.getElementById('massDeleteBtn').disabled = checked === 0;
    }
    function toggleSelectAll(cb) {
      document.querySelectorAll('.row-check').forEach(box => { box.checked = cb.checked; });
      updateMassAction();
    }
    function massDelete() {
      let boxes = document.querySelectorAll('.row-check:checked');
      if (boxes.length === 0) return;
      let deviceKeys = Array.from(boxes).map(b=>b.dataset.device);
      showConfirm("Mass Delete", "Are you sure you want to delete <b>"+deviceKeys.length+"</b> device keys ?<br><code>"+deviceKeys.join(", ")+"</code>", async function(){
        for(let key of deviceKeys) {
          await fetch(`${API_BASE}/devices/${key}/ssh-key`, {method:'DELETE'});
        }
        await fetchDeviceKeys();
      });
    }
    function exportCSV() {
      let rows = [];
      let headers = ["device_key", "ssh_user", "status", "added", "modified", "fingerprint", "last_ssh", "pubkey"];
      rows.push(headers.join(","));
      deviceList.forEach(dev => {
        rows.push([
          dev.device_key,
          dev.ssh_user||'',
          dev.status||'',
          dev.added||'',
          dev.modified||'',
          dev.fingerprint||'',
          dev.last_ssh||'',
          dev.pubkey||''
        ].map(x=>`"${(x||'').replace(/"/g,'""')}"`).join(","));
      });
      const csv = rows.join("\n");
      const blob = new Blob([csv], {type: "text/csv"});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = "devices_ssh_keys.csv";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
    function copyAllKeys() {
      let keys = deviceList.map(e=>e.pubkey||'');
      navigator.clipboard.writeText(keys.join("\n"));
      alert("Toutes les clés device copiées dans le presse-papier !");
    }
    function toggleDarkMode() {
      let theme = document.documentElement.getAttribute('data-bs-theme');
      document.documentElement.setAttribute('data-bs-theme', theme === 'dark' ? 'light' : 'dark');
    }
    window.addEventListener('DOMContentLoaded', () => {
      fetchDeviceKeys();
      // fetchServerKeyInfo(); // Décommente si endpoint dédié clé serveur
    });
  </script>
</body>
</html>
