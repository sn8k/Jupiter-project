<?php
// File: admin/device_designer.php
// Version: 1.2.4
// Date: 2025-06-13
// Author: Meeting Server Team
// Description: Device Designer admin page (Bootstrap 5 dark mode). Allows creating/editing device definitions, listing existing types and launching Distrib Builder with token.
// Changelog:
// - 1.1.0 (2025-06-13): autoload builder token from session and list device types via API
// - 1.2.0 (2025-06-13): édition et fork des types avec confirmation du token pour la suppression
// - 1.2.4 (2025-06-13): affichage de l'historique DeviceType depuis backend_api.log
// - 1.2.5 (2025-06-13): version header and title synchronized

session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: index.php');
    exit;
}

$links = require __DIR__ . '/links.php';
$config = require __DIR__ . '/../api/config.php';

$storageRoot = $config['storage_path'] ?? ($config['flash_storage_root'] ?? dirname(__DIR__) . '/storage');

function list_distributions(string $root): array {
    $dists = [];
    if (is_dir($root)) {
        foreach (scandir($root) as $d) {
            if ($d === '.' || $d === '..' || !is_dir("$root/$d")) continue;
            $dists[] = $d;
        }
    }
    return $dists;
}

$distDir = "$storageRoot/distributions";
$distributions = list_distributions($distDir);
if (!$distributions) {
    $distributions = list_distributions($storageRoot);
}

$logFile = $config['backend_logfile'] ?? '';
$history = [];
if (is_file($logFile)) {
    $lines = @file($logFile, FILE_IGNORE_NEW_LINES);
    if ($lines) {
        $lines = array_reverse($lines);
        foreach ($lines as $ln) {
            if (strpos($ln, 'DeviceType') !== false) {
                $history[] = $ln;
                if (count($history) >= 50) break;
            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="fr" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <title>MEETING - Device Designer</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#171b20; color:#f3f7fa; }
            <input type="text" name="serial_prefix" class="form-control" placeholder="Ex: SEN" data-bs-toggle="tooltip" title="Préfixe unique" required>
        .brand { color:#17d1a7 !important; font-weight:bold; padding-left:16px; }
        .nav-link { color:#fff !important; }
        .main { max-width:900px; margin:30px auto; }
        .log-content { background:#232832; border-radius:7px; padding:10px; font-family:monospace; max-height:240px; overflow:auto; }
    </style>
</head>
<body class="dark">
<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container-fluid">
        <span class="brand">🟩 MEETING Admin</span>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <?php foreach ($links as $link): ?>
                    <?php if(isset($link['file'])): ?>
                        <li class="nav-item"><a class="nav-link" href="<?= $link['file'] ?>"><?= isset($link['icon'])?'<span class=\'nav-icon\'>'.$link['icon'].'</span>':'' ?><?= htmlspecialchars($link['name']) ?></a></li>
                    <?php endif; ?>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="main container">

    <h3>Device Designer <small class="text-muted">v1.2.5 - 2025-06-13</small></h3>

    <div id="msg" class="alert d-none"></div>
    <form method="post" enctype="multipart/form-data" class="row g-3">
        <input type="hidden" id="edit_id" value="">
        <div class="col-md-6">
            <label class="form-label">Nom</label>
            <input type="text" name="name" class="form-control" placeholder="Ex: Sensor X" data-bs-toggle="tooltip" title="Nom du type" required>
        </div>
        <div class="col-md-6">
            <label class="form-label">Préfixe unique</label>
            <input type="text" name="prefix" class="form-control" placeholder="Ex: SEN" data-bs-toggle="tooltip" title="Préfixe unique" required>
        </div>
        <div class="col-md-6">
            <label class="form-label">Plateforme</label>
            <input type="text" name="platform" class="form-control" placeholder="Ex: Linux" data-bs-toggle="tooltip" title="Plateforme cible">
        </div>
        <div class="col-md-6">
            <label class="form-label">Distribution par défaut</label>
            <select name="distribution" class="form-select" data-bs-toggle="tooltip" title="Distribution par défaut">
                <?php foreach ($distributions as $d): ?>
                    <option value="<?= htmlspecialchars($d) ?>"><?= htmlspecialchars($d) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12">
            <label class="form-label">Services par défaut</label><br>
            <?php foreach (["ssh","vnc","scp","http"] as $svc): ?>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="services[]" value="<?= $svc ?>" id="svc<?= $svc ?>">
                    <label class="form-check-label" for="svc<?= $svc ?>"><?= strtoupper($svc) ?></label>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="col-md-6">
            <label class="form-label">Icône</label>
            <input type="file" name="icon" class="form-control" data-bs-toggle="tooltip" title="Icône (png ou svg)">
        </div>
        <div class="col-md-6">
            <label class="form-label">Tags</label>
            <input type="text" name="tags" class="form-control" data-bs-toggle="tooltip" title="Liste de tags séparés par des virgules" placeholder="tag1, tag2">
        </div>
        <div class="col-12">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" placeholder="Description du device" data-bs-toggle="tooltip" title="Description détaillée" rows="3"></textarea>
        </div>
        <div class="col-md-4">
            <label class="form-label">Statut</label>
            <select name="status" class="form-select" data-bs-toggle="tooltip" title="Statut du type">
                <option value="active">Actif</option>
                <option value="inactive">Inactif</option>
            </select>
        </div>
        <div class="col-md-8">
            <label class="form-label">Token Distrib Builder</label>
            <input type="text" id="builder_token" name="builder_token" class="form-control" data-bs-toggle="tooltip" title="Token distrib" placeholder="Ex: a1b2c3d4" value="<?= htmlspecialchars($_SESSION['builder_token'] ?? '') ?>">
        </div>
        <div class="col-12 text-end">
            <button type="button" id="builderBtn" class="btn btn-warning">Créer/modifier la distrib</button>
            <button type="button" id="saveBtn" class="btn btn-success">Enregistrer</button>
            <button type="button" id="forkBtn" class="btn btn-secondary ms-2">Forker</button>
        </div>
    </form>
    <h4 class="mt-5">Liste des device types</h4>
    <table class="table table-dark table-striped" id="typesTable">
        <thead>
            <tr><th>Nom</th><th>Préfixe</th><th>Plateforme</th><th>Statut</th><th>Actions</th></tr>
        </thead>
        <tbody></tbody>
    </table>


    <h4 class="mt-5">Historique DeviceType (backend)</h4>
    <div class="log-content">
        <?php if ($history): ?>
            <?php foreach ($history as $line): ?>
                <?= htmlspecialchars($line) ?><br>
            <?php endforeach; ?>
        <?php else: ?>
            <em>Aucune action DeviceType trouvée.</em>
        <?php endif; ?>
    </div>
</div>
<form id="builderForm" action="/distrib-builder-frontend/" method="post" target="_blank" style="display:none;">
    <input type="hidden" name="token" id="builderFormToken">
</form>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const API_BASE = '/api';
let currentId = null;
function showMessage(type, text){
  const m=document.getElementById('msg');
  m.className='alert alert-'+type;
  m.textContent=text;
  m.classList.remove('d-none');
}

document.addEventListener('DOMContentLoaded', ()=> {
  const tt=[].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  tt.forEach(t=>new bootstrap.Tooltip(t));
  document.getElementById('builderBtn').addEventListener('click', ()=> {
    const t=document.getElementById('builder_token').value.trim();
    if(!t){ showMessage('danger','Token requis'); return; }
  document.querySelector('[name=serial_prefix]').value=t.serial_prefix;
    document.getElementById('builderForm').submit();
  });
  document.getElementById('saveBtn').addEventListener('click', ()=> saveType(false));
  document.getElementById('forkBtn').addEventListener('click', ()=> saveType(true));
  loadDeviceTypes();
});

async function loadDeviceTypes(){
  const resp=await fetch(API_BASE+'/device-types');
  const data=await resp.json().catch(()=>({device_types:[]}));
  const tbody=document.querySelector('#typesTable tbody');
  tbody.innerHTML='';
  data.device_types.forEach(t=>{
    const tr=document.createElement('tr');
    tr.innerHTML=`<td>${t.name}</td><td>${t.serial_prefix}</td><td>${t.platform||''}</td><td>${t.status}</td>`+
      `<td><button class="btn btn-sm btn-primary me-1" onclick="editType(${t.id})">Edit</button>`+
      `<button class="btn btn-sm btn-danger" onclick="deleteType(${t.id})">Suppr.</button></td>`;
    tbody.appendChild(tr);
  });
}

async function deleteType(id){
  const tokenPrompt=prompt('Entrez le token pour confirmer:');
  if(tokenPrompt!==document.getElementById('builder_token').value.trim()) return;
  await fetch(API_BASE+'/device-types/'+id,{method:'DELETE'});
  showMessage('success','Type supprimé');
  loadDeviceTypes();
}

async function editType(id){
  const resp=await fetch(API_BASE+'/device-types');
  const data=await resp.json();
  const t=data.device_types.find(x=>x.id==id);
  if(!t) return;
  document.querySelector('[name=name]').value=t.name;
  document.querySelector('[name=prefix]').value=t.serial_prefix;
  document.querySelector('[name=platform]').value=t.platform||'';
  document.querySelector('[name=distribution]').value=t.default_distribution||'';
  document.querySelector('[name=tags]').value=t.tags||'';
  document.querySelector('[name=description]').value=t.description||'';
  document.querySelector('[name=status]').value=t.status;
  const services=t.services_default? t.services_default.split(','):[];
  document.querySelectorAll('input[name="services[]"]').forEach(cb=>cb.checked=services.includes(cb.value));
  currentId=id;
}

async function saveType(fork){
  const form=document.querySelector('form');
  const fd=new FormData(form);

  const payload={};
  fd.forEach((v,k)=>{ if(k==='services[]'){ (payload.services=payload.services||[]).push(v); } else payload[k]=v; });
  payload.services_default=(payload.services||[]).join(',');
  let url=API_BASE+'/device-types';
  let method='POST';
  if(currentId && !fork){ url += '/' + currentId; method='PUT'; }
  if(currentId && fork){ url += '/' + currentId + '/fork'; method='POST'; }
  const resp=await fetch(url,{method:method,headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  if(resp.ok){
    showMessage('success','Type enregistré');
    form.reset();
    currentId=null;
    loadDeviceTypes();
  } else {
    let msg='Erreur lors de la sauvegarde';
    try{ const data=await resp.json(); if(data.error) msg=data.error; }catch(e){}
    showMessage('danger',msg);
  }
}
</script>
</body>
</html>

