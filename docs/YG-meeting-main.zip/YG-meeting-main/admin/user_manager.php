<?php
// File: admin/user_manager.php
// Version: 1.3.0
// Date: 2025-06-24
// Author: Meeting Server Team
// Description: Manage backend users and generate tokens for Distrib Builder.

session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: index.php');
    exit;
}

$links  = require __DIR__ . '/links.php';
$config = require __DIR__ . '/../api/config.php';
$syncScript = $config['user_key_sync_script'] ?? dirname(__DIR__) . '/resident_tools/ygs-UserKeysSync.sh';

try {
    $pdo = new PDO(
        "mysql:host={$config['db_host']};dbname={$config['db_name']};charset={$config['db_charset']}",
        $config['db_user'],
        $config['db_pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('DB connection error');
}

function randomToken($len = 32) {
    return bin2hex(random_bytes($len / 2));
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $user = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? 'user';
        $pubkey = trim($_POST['ssh_pubkey'] ?? '');
        $authorized = isset($_POST['authorized']) ? (int)$_POST['authorized'] : 1;
        if ($user && $pass && in_array($role, ['admin','user'], true)) {
            $token = randomToken();
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('INSERT INTO builder_users (username, password, role, token, ssh_pubkey, authorized) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->execute([$user, $hash, $role, $token, $pubkey, $authorized]);
            $message = "Utilisateur ajouté";
            exec('sudo ' . escapeshellarg($syncScript) . ' --sync > /dev/null 2>&1 &');
        }
    } elseif ($action === 'regen') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $token = randomToken();
            $stmt = $pdo->prepare('UPDATE builder_users SET token=? WHERE id=?');
            $stmt->execute([$token, $id]);
            $message = "Token régénéré";
        }
    } elseif ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        $current = isset($_POST['current']) ? (int)$_POST['current'] : 0;
        if ($id) {
            $stmt = $pdo->prepare('UPDATE builder_users SET authorized=? WHERE id=?');
            $stmt->execute([$current ? 0 : 1, $id]);
            $message = $current ? "Utilisateur révoqué" : "Utilisateur autorisé";
            exec('sudo ' . escapeshellarg($syncScript) . ' --sync > /dev/null 2>&1 &');
        }
    } elseif ($action === 'uploadkey') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id && !empty($_FILES['pubkey']['tmp_name'])) {
            $key = trim(file_get_contents($_FILES['pubkey']['tmp_name']));
            $stmt = $pdo->prepare('UPDATE builder_users SET ssh_pubkey=? WHERE id=?');
            $stmt->execute([$key, $id]);
            $message = "Clé SSH mise à jour";
            exec('sudo ' . escapeshellarg($syncScript) . ' --sync > /dev/null 2>&1 &');
        }
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $stmt = $pdo->prepare('DELETE FROM builder_users WHERE id=?');
            $stmt->execute([$id]);
            $message = "Utilisateur supprimé";
            exec('sudo ' . escapeshellarg($syncScript) . ' --sync > /dev/null 2>&1 &');
        }
    }
}

$users = $pdo->query('SELECT * FROM builder_users ORDER BY id ASC')->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <title>Users Administration (v1.3.0)</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background:#171b20; color:#f3f7fa; }
        .navbar { background:#111316; box-shadow:0 3px 12px #0008; }
        .brand { color:#17d1a7 !important; font-weight:bold; padding-left:16px; }
        .nav-link { color:#fff !important; }
        .main { max-width:900px; margin:30px auto; }
        table td, table th { vertical-align:middle; }
    </style>
</head>
<body class="dark">
<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container-fluid">
        <span class="brand">🟩 MEETING Admin</span>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <?php foreach ($links as $link): ?>
                    <?php
                        $icon = isset($link['icon']) ? '<span class="nav-icon">'.htmlspecialchars($link['icon']).'</span>' : '';
                        $name = htmlspecialchars($link['name']);
                        if (isset($link['file'])) {
                            echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['file']}\">{$icon}{$name}</a></li>";
                        }
                    ?>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="main container">
    <?php if ($message): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <h3>Users Administration <small class="text-muted">v1.3.0 - 2025-06-24</small></h3>
    <form method="post" class="row g-2 mb-3">
        <div class="col-auto">
            <input type="text" name="username" class="form-control" placeholder="Username" required>
        </div>
        <div class="col-auto">
            <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        <div class="col-auto">
            <select name="role" class="form-select">
                <option value="user">user</option>
                <option value="admin">admin</option>
            </select>
        </div>
        <div class="col-auto">
            <input type="text" name="ssh_pubkey" class="form-control" placeholder="SSH Public Key">
        </div>
        <div class="col-auto">
            <select name="authorized" class="form-select">
                <option value="1">Authorized</option>
                <option value="0">Revoked</option>
            </select>
        </div>
        <input type="hidden" name="action" value="add">
        <div class="col-auto">
            <button type="submit" class="btn btn-success">Ajouter</button>
        </div>
    </form>
    <table class="table table-dark table-striped">
        <thead>
            <tr><th>ID</th><th>Username</th><th>Role</th><th>Status</th><th>SSH Key</th><th>Token</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($users as $u): ?>
            <tr>
                <td><?= $u['id'] ?></td>
                <td><?= htmlspecialchars($u['username']) ?></td>
                <td><?= htmlspecialchars($u['role']) ?></td>
                <td>
                    <span class="badge <?= $u['authorized'] ? 'bg-success' : 'bg-danger' ?>"><?= $u['authorized'] ? 'authorized' : 'revoked' ?></span>
                </td>
                <td style="font-family:monospace; max-width:150px; word-break:break-all;"><?= htmlspecialchars($u['ssh_pubkey']) ?></td>
                <td style="font-family:monospace;"><?= htmlspecialchars($u['token']) ?></td>
                <td>
                    <form method="post" style="display:inline">
                        <input type="hidden" name="id" value="<?= $u['id'] ?>">
                        <input type="hidden" name="action" value="regen">
                        <button class="btn btn-warning btn-sm" onclick="return confirm('Regénérer le token ?')">Regénérer</button>
                    </form>
                    <form method="post" style="display:inline">
                        <input type="hidden" name="id" value="<?= $u['id'] ?>">
                        <input type="hidden" name="action" value="toggle">
                        <input type="hidden" name="current" value="<?= $u['authorized'] ?>">
                        <button class="btn btn-secondary btn-sm" onclick="return confirm('Basculer le statut ?')">Toggle</button>
                    </form>
                    <form method="post" enctype="multipart/form-data" style="display:inline" id="keyform<?= $u['id'] ?>">
                        <input type="hidden" name="id" value="<?= $u['id'] ?>">
                        <input type="hidden" name="action" value="uploadkey">
                        <input type="file" name="pubkey" class="d-none" id="keyfile<?= $u['id'] ?>" accept=".pub,text/plain" onchange="document.getElementById('keyform<?= $u['id'] ?>').submit()">
                        <button type="button" class="btn btn-info btn-sm" onclick="document.getElementById('keyfile<?= $u['id'] ?>').click()">Upload SSH Key</button>
                    </form>
                    <form method="post" style="display:inline">
                        <input type="hidden" name="id" value="<?= $u['id'] ?>">
                        <input type="hidden" name="action" value="delete">
                        <button class="btn btn-danger btn-sm" onclick="return confirm('Supprimer cet utilisateur ?')">Supprimer</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
