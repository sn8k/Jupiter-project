<?php
// File: admin/db_check.php

// Version: 3.3.6
// Date: 2025-06-24


// Author: Meeting Server Team
// Description: Vérifie et corrige la structure SQL pour Meeting API (devices, tunnel_ports, flash_logs, connection_logs).
// Changelog:
// - v3.3.0 (2025-06-13): Ajout de la table device_types et preparation des relations parent/enfant.
// - v3.1.0 (2025-06-13): Interface web complète avec barre de navigation.
// - v3.0.5 (2025-06-13): Mise à jour mineure des métadonnées.
// - v3.0.1 (2025-06-13): Chargement des secrets via config.secrets.php.
// - v3.0.0 (2025-06-01): Réintégration de la table device_keys (ForceCommand) et
//                         ajout des colonnes last_seen et modified dans devices.
// - v2.0.0 (2025-05-25): Suppression définitive de device_keys (legacy). Ne maintient plus que devices, tunnel_ports, flash_logs, connection_logs. Structure 100% alignée avec l’infra Meeting moderne.

$config = require(__DIR__ . '/../api/config.php');

$log = [];
$isWeb = (php_sapi_name() !== "cli");
function logmsg($msg) {
    global $log, $isWeb;
    $log[] = $msg;
    if (!$isWeb) echo $msg . "\n";
}

function escape($pdo, $str) {
    return '`' . str_replace('`', '``', $str) . '`';
}

function tableExists(PDO $pdo, $table) {
    $table = addslashes($table);
    $stmt = $pdo->query("SHOW TABLES LIKE '{$table}'");
    return $stmt->fetch() !== false;
}

function columnExists(PDO $pdo, $table, $column) {
    $table = addslashes($table);
    $column = addslashes($column);
    $stmt = $pdo->query("SHOW COLUMNS FROM `{$table}` LIKE '{$column}'");
    return $stmt->fetch() !== false;
}

function getColumnInfo(PDO $pdo, $table, $column) {
    $table = addslashes($table);
    $column = addslashes($column);
    $stmt = $pdo->query("SHOW COLUMNS FROM `{$table}` WHERE Field = '{$column}'");
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function alterOrCreateTable(PDO $pdo, $table, $schema, $columns, $columnMods = []) {
    if (!tableExists($pdo, $table)) {
        logmsg("Création de la table <b>$table</b>");
        $pdo->exec($schema);
    } else {
        foreach ($columns as $col => $def) {
            if (!columnExists($pdo, $table, $col)) {
                logmsg("Ajout de la colonne <b>$col</b> à <b>$table</b>");
                $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN $def");
            } elseif (isset($columnMods[$col])) {
                $info = getColumnInfo($pdo, $table, $col);
                $expectedType = strtolower($columnMods[$col]['type']);
                $expectedDef = $columnMods[$col]['definition'];
                $actualType = strtolower($info['Type']);
                $needMod = false;
                if (preg_match('/varchar\((\d+)\)/', $expectedDef, $m)) {
                    $expectedLen = $m[1];
                    if (preg_match('/varchar\((\d+)\)/', $actualType, $n)) {
                        if ($n[1] != $expectedLen) $needMod = true;
                    } else {
                        $needMod = true;
                    }
                }
                if (strpos($expectedType, 'text') !== false && strpos($actualType, 'text') === false) $needMod = true;
                if (strpos($expectedType, 'tinyint') !== false && strpos($actualType, 'tinyint') === false) $needMod = true;
                if (strpos($expectedType, 'datetime') !== false && strpos($actualType, 'datetime') === false) $needMod = true;
                if (!$needMod && $actualType !== $expectedType) {
                    if ($col === 'event' && $actualType !== 'varchar(32)') $needMod = true;
                }
                if ($needMod) {
                    logmsg("Modification du type de colonne <b>$col</b> dans <b>$table</b> (actuel: {$info['Type']}, attendu: $expectedDef)");
                    $pdo->exec("ALTER TABLE `{$table}` MODIFY COLUMN {$expectedDef}");
                }
            }
        }
    }
}

try {
    $pdo = new PDO(
        "mysql:host={$config['db_host']};dbname={$config['db_name']};charset={$config['db_charset']}",
        $config['db_user'],
        $config['db_pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    logmsg("<span class='fail'>Erreur de connexion à la base : {$e->getMessage()}</span>");
    exit;
}

// ======================== DEVICES (core: Meeting API) ========================
$table = 'devices';
$schema = <<<SQL
CREATE TABLE `$table` (
    `device_key` VARCHAR(64) PRIMARY KEY,
    `ip_address` VARCHAR(255) DEFAULT NULL,
    `service_ssh` TINYINT(1) DEFAULT 0,
    `service_vnc` TINYINT(1) DEFAULT 0,
    `service_http` TINYINT(1) DEFAULT 0,
    `service_scp` TINYINT(1) DEFAULT 0,
    `authorized` TINYINT(1) DEFAULT 0,
    `token_count` INT DEFAULT 0,
    `distribution` VARCHAR(128) DEFAULT NULL,
    `token_code` VARCHAR(32) DEFAULT NULL,
    `registered_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `last_seen` DATETIME DEFAULT NULL,
    `modified` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `ap_ssid` VARCHAR(64) DEFAULT NULL,
    `ap_password` VARCHAR(32) DEFAULT NULL,
    `http_pw_low` VARCHAR(16) DEFAULT NULL,
    `http_pw_medium` VARCHAR(16) DEFAULT NULL,
    `http_pw_high` VARCHAR(16) DEFAULT NULL,
    `note` TEXT DEFAULT NULL,
    `product_serial` VARCHAR(64) DEFAULT NULL,
    `device_type` VARCHAR(64) DEFAULT NULL,
    `bundles` TEXT DEFAULT NULL,
    `ghost_candidate_url` VARCHAR(255) DEFAULT NULL,
    `parent_device_key` VARCHAR(64) DEFAULT NULL,
    `ssh_public_key` TEXT DEFAULT NULL,
    `ssh_user` VARCHAR(64) DEFAULT NULL,
    `revoked` TINYINT(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;

$columns = [
    'device_key'         => '`device_key` VARCHAR(64) PRIMARY KEY',
    'ip_address'         => '`ip_address` VARCHAR(255) DEFAULT NULL',
    'service_ssh'        => '`service_ssh` TINYINT(1) DEFAULT 0',
    'service_vnc'        => '`service_vnc` TINYINT(1) DEFAULT 0',
    'service_http'       => '`service_http` TINYINT(1) DEFAULT 0',
    'service_scp'        => '`service_scp` TINYINT(1) DEFAULT 0',
    'authorized'         => '`authorized` TINYINT(1) DEFAULT 0',
    'token_count'        => '`token_count` INT DEFAULT 0',
    'distribution'       => '`distribution` VARCHAR(128) DEFAULT NULL',
    'token_code'         => '`token_code` VARCHAR(32) DEFAULT NULL',
    'registered_at'      => '`registered_at` DATETIME DEFAULT CURRENT_TIMESTAMP',
    'last_seen'          => '`last_seen` DATETIME DEFAULT NULL',
    'modified'           => '`modified` DATETIME DEFAULT CURRENT_TIMESTAMP',
    'ap_ssid'            => '`ap_ssid` VARCHAR(64) DEFAULT NULL',
    'ap_password'        => '`ap_password` VARCHAR(32) DEFAULT NULL',
    'http_pw_low'        => '`http_pw_low` VARCHAR(16) DEFAULT NULL',
    'http_pw_medium'     => '`http_pw_medium` VARCHAR(16) DEFAULT NULL',
    'http_pw_high'       => '`http_pw_high` VARCHAR(16) DEFAULT NULL',
    'note'               => '`note` TEXT DEFAULT NULL',
    'product_serial'     => '`product_serial` VARCHAR(64) DEFAULT NULL',
    'device_type'        => '`device_type` VARCHAR(64) DEFAULT NULL',
    'bundles'            => '`bundles` TEXT DEFAULT NULL',
    'ghost_candidate_url'=> '`ghost_candidate_url` VARCHAR(255) DEFAULT NULL',
    'parent_device_key'  => '`parent_device_key` VARCHAR(64) DEFAULT NULL',
    'ssh_public_key'     => '`ssh_public_key` TEXT DEFAULT NULL',
    'ssh_user'           => '`ssh_user` VARCHAR(64) DEFAULT NULL',
    'revoked'            => '`revoked` TINYINT(1) DEFAULT 0'
];

$columnMods = [
    'ip_address'         => [ 'type' => 'varchar(255)', 'definition' => '`ip_address` VARCHAR(255) DEFAULT NULL' ],
    'ap_ssid'            => [ 'type' => 'varchar(64)', 'definition' => '`ap_ssid` VARCHAR(64) DEFAULT NULL' ],
    'ap_password'        => [ 'type' => 'varchar(32)', 'definition' => '`ap_password` VARCHAR(32) DEFAULT NULL' ],
    'http_pw_low'        => [ 'type' => 'varchar(16)', 'definition' => '`http_pw_low` VARCHAR(16) DEFAULT NULL' ],
    'http_pw_medium'     => [ 'type' => 'varchar(16)', 'definition' => '`http_pw_medium` VARCHAR(16) DEFAULT NULL' ],
    'http_pw_high'       => [ 'type' => 'varchar(16)', 'definition' => '`http_pw_high` VARCHAR(16) DEFAULT NULL' ],
    'note'               => [ 'type' => 'text',    'definition' => '`note` TEXT DEFAULT NULL' ],
    'product_serial'     => [ 'type' => 'varchar(64)', 'definition' => '`product_serial` VARCHAR(64) DEFAULT NULL' ],
    'device_type'        => [ 'type' => 'varchar(64)', 'definition' => '`device_type` VARCHAR(64) DEFAULT NULL' ],
    'bundles'            => [ 'type' => 'text',    'definition' => '`bundles` TEXT DEFAULT NULL' ],
    'ghost_candidate_url'=> [ 'type' => 'varchar(255)', 'definition' => '`ghost_candidate_url` VARCHAR(255) DEFAULT NULL' ],
    'parent_device_key'  => [ 'type' => 'varchar(64)', 'definition' => '`parent_device_key` VARCHAR(64) DEFAULT NULL' ],
    'ssh_public_key'     => [ 'type' => 'text',    'definition' => '`ssh_public_key` TEXT DEFAULT NULL' ],
    'ssh_user'           => [ 'type' => 'varchar(64)', 'definition' => '`ssh_user` VARCHAR(64) DEFAULT NULL' ],
    'revoked'            => [ 'type' => 'tinyint(1)', 'definition' => '`revoked` TINYINT(1) DEFAULT 0' ],
    'last_seen'          => [ 'type' => 'datetime', 'definition' => '`last_seen` DATETIME DEFAULT NULL' ],
    'modified'           => [ 'type' => 'datetime', 'definition' => '`modified` DATETIME DEFAULT CURRENT_TIMESTAMP' ],
    'service_ssh'        => [ 'type' => 'tinyint(1)', 'definition' => '`service_ssh` TINYINT(1) DEFAULT 0' ],
    'service_vnc'        => [ 'type' => 'tinyint(1)', 'definition' => '`service_vnc` TINYINT(1) DEFAULT 0' ],
    'service_http'       => [ 'type' => 'tinyint(1)', 'definition' => '`service_http` TINYINT(1) DEFAULT 0' ],
    'service_scp'        => [ 'type' => 'tinyint(1)', 'definition' => '`service_scp` TINYINT(1) DEFAULT 0' ],
    'authorized'         => [ 'type' => 'tinyint(1)', 'definition' => '`authorized` TINYINT(1) DEFAULT 0' ],
];

alterOrCreateTable($pdo, $table, $schema, $columns, $columnMods);


// ======================== MEETING_USERS ========================
$table = 'meeting_users';
$schema = <<<SQL
CREATE TABLE `$table` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(64) NOT NULL UNIQUE,
    `role` ENUM('admin','user') NOT NULL DEFAULT 'user',
    `ssh_pubkey` TEXT DEFAULT NULL,
    `authorized` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;
$columns = [
    'id'         => '`id` INT AUTO_INCREMENT PRIMARY KEY',
    'username'   => '`username` VARCHAR(64) NOT NULL UNIQUE',
    'role'       => "`role` ENUM('admin','user') NOT NULL DEFAULT 'user'",
    'ssh_pubkey' => '`ssh_pubkey` TEXT DEFAULT NULL',
    'authorized' => '`authorized` TINYINT(1) DEFAULT 0',
    'created_at' => '`created_at` DATETIME DEFAULT CURRENT_TIMESTAMP',
    'updated_at' => '`updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
];
$columnMods = [
    'username'   => [ 'type' => 'varchar(64)', 'definition' => '`username` VARCHAR(64) NOT NULL UNIQUE' ],
    'role'       => [ 'type' => "enum('admin','user')", 'definition' => "`role` ENUM('admin','user') NOT NULL DEFAULT 'user'" ],
    'ssh_pubkey' => [ 'type' => 'text', 'definition' => '`ssh_pubkey` TEXT DEFAULT NULL' ],
    'authorized' => [ 'type' => 'tinyint(1)', 'definition' => '`authorized` TINYINT(1) DEFAULT 0' ],
    'updated_at' => [ 'type' => 'datetime', 'definition' => '`updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP' ]
];
alterOrCreateTable($pdo, $table, $schema, $columns, $columnMods);

// ======================== BUILDER_USERS (Distrib Builder tokens) ==============
$table = 'builder_users';
$schema = <<<SQL
CREATE TABLE `$table` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(64) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('admin','user') NOT NULL DEFAULT 'user',
    `token` VARCHAR(64) NOT NULL,
    `ssh_pubkey` TEXT DEFAULT NULL,
    `authorized` TINYINT(1) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;
$columns = [
    'id'        => '`id` INT AUTO_INCREMENT PRIMARY KEY',
    'username'  => '`username` VARCHAR(64) NOT NULL UNIQUE',
    'password'  => '`password` VARCHAR(255) NOT NULL',
    'role'      => "`role` ENUM('admin','user') NOT NULL DEFAULT 'user'",
    'token'     => '`token` VARCHAR(64) NOT NULL',
    'ssh_pubkey'=> '`ssh_pubkey` TEXT DEFAULT NULL',
    'authorized'=> '`authorized` TINYINT(1) DEFAULT 0',
    'created_at'=> '`created_at` DATETIME DEFAULT CURRENT_TIMESTAMP'
];
$columnMods = [
    'username' => [ 'type' => 'varchar(64)', 'definition' => '`username` VARCHAR(64) NOT NULL UNIQUE' ],
    'password' => [ 'type' => 'varchar(255)', 'definition' => '`password` VARCHAR(255) NOT NULL' ],
    'role'     => [ 'type' => "enum('admin','user')", 'definition' => "`role` ENUM('admin','user') NOT NULL DEFAULT 'user'" ],
    'token'    => [ 'type' => 'varchar(64)', 'definition' => '`token` VARCHAR(64) NOT NULL' ],
    'ssh_pubkey'=> [ 'type' => 'text', 'definition' => '`ssh_pubkey` TEXT DEFAULT NULL' ],
    'authorized'=> [ 'type' => 'tinyint(1)', 'definition' => '`authorized` TINYINT(1) DEFAULT 0' ]
];
alterOrCreateTable($pdo, $table, $schema, $columns, $columnMods);

// ======================== DEVICE_TYPES ========================
$table = 'device_types';
$schema = <<<SQL
CREATE TABLE `$table` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(64) NOT NULL,
    `serial_prefix` VARCHAR(16) NOT NULL UNIQUE,
    `platform` VARCHAR(64) DEFAULT NULL,
    `services_default` VARCHAR(64) DEFAULT NULL,
    `description` TEXT DEFAULT NULL,
    `icon_path` VARCHAR(255) DEFAULT NULL,
    `tags` VARCHAR(255) DEFAULT NULL,
    `default_distribution` VARCHAR(64) DEFAULT NULL,
    `status` VARCHAR(32) DEFAULT 'active',
    `parent_id` INT DEFAULT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`parent_id`) REFERENCES `$table`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;
$columns = [
    'id'                  => '`id` INT AUTO_INCREMENT PRIMARY KEY',
    'name'                => '`name` VARCHAR(64) NOT NULL',
    'serial_prefix'       => '`serial_prefix` VARCHAR(16) NOT NULL UNIQUE',
    'platform'            => '`platform` VARCHAR(64) DEFAULT NULL',
    'services_default'    => '`services_default` VARCHAR(64) DEFAULT NULL',
    'description'         => '`description` TEXT DEFAULT NULL',
    'icon_path'           => '`icon_path` VARCHAR(255) DEFAULT NULL',
    'tags'                => '`tags` VARCHAR(255) DEFAULT NULL',
    'default_distribution'=> '`default_distribution` VARCHAR(64) DEFAULT NULL',
    'status'              => '`status` VARCHAR(32) DEFAULT \'active\'',
    'parent_id'           => '`parent_id` INT DEFAULT NULL',
    'created_at'          => '`created_at` DATETIME DEFAULT CURRENT_TIMESTAMP',
    'updated_at'          => '`updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
];
$columnMods = [
    'serial_prefix'       => [ 'type' => 'varchar(16)', 'definition' => '`serial_prefix` VARCHAR(16) NOT NULL UNIQUE' ],
    'platform'            => [ 'type' => 'varchar(64)', 'definition' => '`platform` VARCHAR(64) DEFAULT NULL' ],
    'services_default'    => [ 'type' => 'varchar(64)', 'definition' => '`services_default` VARCHAR(64) DEFAULT NULL' ],
    'icon_path'           => [ 'type' => 'varchar(255)', 'definition' => '`icon_path` VARCHAR(255) DEFAULT NULL' ],
    'tags'                => [ 'type' => 'varchar(255)', 'definition' => '`tags` VARCHAR(255) DEFAULT NULL' ],
    'default_distribution'=> [ 'type' => 'varchar(64)', 'definition' => '`default_distribution` VARCHAR(64) DEFAULT NULL' ],
    'status'              => [ 'type' => 'varchar(32)', 'definition' => '`status` VARCHAR(32) DEFAULT \'active\'' ],
    'parent_id'           => [ 'type' => 'int',         'definition' => '`parent_id` INT DEFAULT NULL' ],
    'updated_at'          => [ 'type' => 'datetime',    'definition' => '`updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP' ],
];
alterOrCreateTable($pdo, $table, $schema, $columns, $columnMods);

// ======================== DEVICE_KEYS (ForceCommand) ========================
$table = 'device_keys';
$schema = <<<SQL
CREATE TABLE `$table` (
    `device_key` VARCHAR(64) NOT NULL PRIMARY KEY,
    `pubkey` TEXT NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;
$columns = [
    'device_key' => '`device_key` VARCHAR(64) NOT NULL PRIMARY KEY',
    'pubkey'     => '`pubkey` TEXT NOT NULL',
    'created_at' => '`created_at` DATETIME DEFAULT CURRENT_TIMESTAMP'
];
alterOrCreateTable($pdo, $table, $schema, $columns);

// Migration : copie des clés présentes dans devices.ssh_public_key
logmsg("Synchronisation device_keys ↔ devices");
$syncRows = $pdo->query("SELECT device_key, ssh_public_key FROM devices WHERE ssh_public_key IS NOT NULL AND ssh_public_key != ''")->fetchAll(PDO::FETCH_ASSOC);
foreach ($syncRows as $r) {
    $ins = $pdo->prepare("INSERT INTO device_keys (device_key, pubkey, created_at) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE pubkey = VALUES(pubkey)");
    $ins->execute([$r['device_key'], $r['ssh_public_key']]);
}
logmsg("  synchronisées: " . count($syncRows));

// ======================== FLASH_LOGS ========================
$table = 'flash_logs';
$schema = <<<SQL
CREATE TABLE `$table` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `device_key` VARCHAR(64),
    `success` TINYINT(1) DEFAULT 1,
    `ts` DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`device_key`) REFERENCES devices(`device_key`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;
$columns = [
    'id'         => '`id` INT AUTO_INCREMENT PRIMARY KEY',
    'device_key' => '`device_key` VARCHAR(64)',
    'success'    => '`success` TINYINT(1) DEFAULT 1',
    'ts'         => '`ts` DATETIME DEFAULT CURRENT_TIMESTAMP'
];
alterOrCreateTable($pdo, $table, $schema, $columns);

// ======================== CONNECTION_LOGS ========================
$table = 'connection_logs';
$schema = <<<SQL
CREATE TABLE `$table` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `device_key` VARCHAR(64),
    `timestamp` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `event` VARCHAR(32),
    `host` VARCHAR(128),
    `remote` VARCHAR(128),
    FOREIGN KEY (`device_key`) REFERENCES devices(`device_key`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;
$columns = [
    'id'        => '`id` INT AUTO_INCREMENT PRIMARY KEY',
    'device_key'=> '`device_key` VARCHAR(64)',
    'timestamp' => '`timestamp` DATETIME DEFAULT CURRENT_TIMESTAMP',
    'event'     => '`event` VARCHAR(32)',
    'host'      => '`host` VARCHAR(128)',
    'remote'    => '`remote` VARCHAR(128)'
];
$columnMods = [
    'event'     => [ 'type' => 'varchar(32)', 'definition' => '`event` VARCHAR(32)' ],
    'host'      => [ 'type' => 'varchar(128)', 'definition' => '`host` VARCHAR(128)' ],
    'remote'    => [ 'type' => 'varchar(128)', 'definition' => '`remote` VARCHAR(128)' ],
];
alterOrCreateTable($pdo, $table, $schema, $columns, $columnMods);

// ======================== TUNNEL_PORTS (ForceCommand, device_key) ========================
$table = 'tunnel_ports';
$schema = <<<SQL
CREATE TABLE `$table` (
    `device_key` VARCHAR(64) NOT NULL,
    `service` VARCHAR(16) NOT NULL DEFAULT 'ssh',
    `local_port` INT NOT NULL DEFAULT 22,
    `port` INT NOT NULL UNIQUE,
    `expires_at` DATETIME NOT NULL,
    PRIMARY KEY(`device_key`, `service`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQL;
$columns = [
    'device_key'  => '`device_key` VARCHAR(64) NOT NULL',
    'service'     => "`service` VARCHAR(16) NOT NULL DEFAULT 'ssh'",
    'local_port'  => '`local_port` INT NOT NULL DEFAULT 22',
    'port'        => '`port` INT NOT NULL UNIQUE',
    'expires_at'  => '`expires_at` DATETIME NOT NULL'
];
$columnMods = [
    'port'       => [ 'type' => 'int', 'definition' => '`port` INT NOT NULL UNIQUE' ],
    'service'    => [ 'type' => 'varchar(16)', 'definition' => "`service` VARCHAR(16) NOT NULL DEFAULT 'ssh'" ],
    'local_port' => [ 'type' => 'int', 'definition' => '`local_port` INT NOT NULL DEFAULT 22' ],
    'expires_at' => [ 'type' => 'datetime', 'definition' => '`expires_at` DATETIME NOT NULL' ],
];
alterOrCreateTable($pdo, $table, $schema, $columns, $columnMods);

logmsg("<span style='color:green'>Vérification terminée !</span>");

// ==== Affichage HTML si navigateur ====
if ($isWeb) {
    $links = require __DIR__ . '/links.php';
    ?>
    <!DOCTYPE html>
    <html lang="fr" data-bs-theme="dark">
    <head>
        <meta charset="utf-8">
        <title>Meeting DB Check</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            html,body { background:#171b20 !important; color:#f3f7fa !important; min-height:100vh; }
            .navbar { background:#111316 !important; box-shadow:0 3px 12px #0008; }
            .navbar .brand { font-size:1.35em; font-weight:bold; color:#17d1a7 !important; padding-left:16px; }
            .navbar .nav-link { color:#fff !important; }
            .dark-toggle { border:none; background:#232832; color:#fff; border-radius:22px; padding:5px 17px; cursor:pointer; font-size:1em; margin-left:18px; }
            .main-content { max-width:900px; margin:40px auto; padding:0 2vw; }
            .log-box { background:#20242a; border-radius:10px; padding:22px; box-shadow:0 4px 18px #0007; }
            .log-box span { display:block; margin-bottom:6px; }
            .log-box .ok { color:#43a047; }
            .log-box .fail { color:#e53935; }
        </style>
    </head>
    <body class="dark">
        <nav class="navbar navbar-expand-lg sticky-top">
            <div class="container-fluid">
                <span class="brand">🟦 MEETING Admin</span>
                <div class="collapse navbar-collapse">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0 navlinks">
                        <?php foreach ($links as $link): ?>
                            <?php
                                $icon = isset($link['icon']) ? '<span class="nav-icon">'.htmlspecialchars($link['icon']).'</span>' : '';
                                $name = htmlspecialchars($link['name']);
                                if (isset($link['file'])) {
                                    echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['file']}\">{$icon}{$name}</a></li>";
                                } elseif (isset($link['url'])) {
                                    $target = isset($link['target']) ? " target=\"{$link['target']}\"" : "";
                                    echo "<li class=\"nav-item\"><a class=\"nav-link\" href=\"{$link['url']}\"$target>{$icon}{$name}</a></li>";
                                } else {
                                    echo "<li class=\"nav-item\"><span class=\"nav-link\">{$icon}{$name}</span></li>";
                                }
                            ?>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <button class="dark-toggle" onclick="toggleDarkMode()" title="Toggle light/dark mode">
                    <svg width="18" height="18" viewBox="0 0 20 20"><path fill="currentColor" d="M10 2a8 8 0 1 0 8 8a8 8 0 0 0-8-8Zm0 14a6 6 0 1 1 6-6a6 6 0 0 1-6 6Zm0-11a1 1 0 1 0 1 1a1 1 0 0 0-1-1Z"/></svg>
                    Dark mode
                </button>
            </div>
        </nav>
        <div class="main-content">
            <div class="log-box">
                <h2 style="color:#17d1a7; margin-bottom:18px;">Meeting Database Structure Check</h2>
                <?php foreach ($log as $l) echo "<span>$l</span>"; ?>
                <a href="db_check.php" class="btn btn-primary mt-3">Run again</a>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
        <script>function toggleDarkMode(){document.body.classList.toggle('dark');}</script>
    </body>
    </html>
    <?php
    exit;
}
?>
