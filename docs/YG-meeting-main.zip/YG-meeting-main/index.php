<?php
// YG Meeting Entry Point
// Version: 1.1.2 (2025-06-13)
//
// Changelog:
// - 2025-06-13: replaced placeholder text with redirect to /devices_frontend
//   and added version header with changelog.

header('Location: /devices_frontend/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>YG Meeting</title>
</head>
<body>
  <h1>YG Meeting Platform</h1>
  <p>If you are not redirected automatically, visit <a href="/devices_frontend/">/devices_frontend/</a>.</p>
  <p>Main entry points:</p>
  <ul>
    <li><a href="/devices_frontend/">Devices frontend</a></li>
    <li><a href="/api/">API endpoints</a></li>
  </ul>
</body>
</html>
