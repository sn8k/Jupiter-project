<?php
/*
  File: /var/www/html/devices/search.php
  Version: 2.3.4
  Author: CreativeMind Team
  Description: Devices search/list page – API-based, paginated, Meeting REST API, status-aware.
  Changelog:
    - 2.3.4 : Hide list until a search is made.
    - 2.3.3 : Use relative API path to fix list loading.
    - 2.3.2 : Improved error message if API unreachable.
    - 2.3.1 : Correction chargement infini lors d'erreurs API.
    - 2.3.0 : Renommage "Nom du device" en "Serial Number", ajout colonne Device Type, renommage "Note" en "Notes".
    - 2.2.0 : Suppression colonnes distribution, token_code, tokens, ip_address. Ajout colonne Note.
    - 2.1.0 : Full API, status online/offline, device_key color live, nom device, liens directs.
    - 2.0.0 : Ajout device_name, badge d’état, IP cliquable, HTTP action.
    - 1.1.0 : Version d’origine.
*/

session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
  header('Location: index.php');
  exit;
}

// Pagination and search setup
$limit = 25;
$page = isset($_GET['page']) && ctype_digit($_GET['page']) && $_GET['page'] > 0 ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$search_requested = isset($_GET['search']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Devices | Meeting</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #fff; font-family: 'Segoe UI', Arial, sans-serif; }
    .topbar {
      background: #222; color: #fff; height: 44px;
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 24px; font-size: 15px;
    }
    .topbar a { color: #ccd; text-decoration: none; margin-left: 28px; }
    .topbar .user { color: #bbe; font-weight: 500; margin-left: 14px;}
    .page-title { font-size: 2.5rem; font-weight: 400; margin: 40px 0 30px 0; text-align: left;}
    .form-label { font-weight: 500; color: #444;}
    .search-form { max-width: 1200px; margin: 0 auto 20px auto; }
    .devices-table { max-width: 1200px; margin: 0 auto 0 auto;}
    .devices-table th, .devices-table td { vertical-align: middle;}
    .devices-table .device-key.online { color: #13b000; font-weight: 700; text-decoration: none; }
    .devices-table .device-key.offline { color: #111; font-weight: 400; text-decoration: none; }
    .devices-table .device-serial { color: #2d72d6; font-weight: 500;}
    .pagination-container { margin: 18px 0 0 0; text-align: left;}
    .table-actions .btn { margin-right: 4px; }
    .note-preview { max-width:220px; max-height:34px; overflow:hidden; white-space:nowrap; text-overflow:ellipsis; color:#795100; }
    @media (max-width: 1100px) {
      .search-form, .devices-table { max-width: 99vw;}
    }
    @media (max-width: 600px) {
      .page-title { font-size: 1.3rem; }
    }
  </style>
</head>
<body>
  <!-- Header -->
  <nav class="topbar">
    <span style="font-weight:600;font-size:18px;">Devices</span>
    <div>
      <a href="#">Device reports</a>
      <a href="#">Device status</a>
      <a href="#">Bug reports</a>
      <a href="#">Batch from serial</a>
      <span class="user">✓ <?= htmlspecialchars($_SESSION['username']) ?></span>
      <a href="logout.php">Logout</a>
    </div>
  </nav>
  <div class="container" style="max-width:1200px;">
    <!-- Titre principal -->
    <div class="page-title mt-3 mb-3">Devices</div>
    <!-- Formulaire de recherche -->
    <form class="search-form mb-4" method="get" autocomplete="off">
      <div class="row mb-2">
        <div class="col-md-6 mb-2">
          <label class="form-label" for="search">Search terms</label>
          <input type="text" class="form-control" id="search" name="search" placeholder="Device key, serial, type, notes..." value="<?= htmlspecialchars($search) ?>">
        </div>
        <div class="col-md-6 mb-2 d-flex align-items-end flex-wrap gap-3">
          <button type="submit" class="btn btn-primary px-4 me-2">Search</button>
          <a href="search.php" class="btn btn-secondary px-4">Reset</a>
        </div>
      </div>
    </form>
    <!-- Tableau des devices -->
    <div id="devices-table-loader" class="text-center mt-5 mb-4">
      <div class="spinner-border" role="status"></div>
      <p style="color:#888;margin-top:15px;">Loading devices...</p>
    </div>
    <div id="devices-table-wrapper"></div>
    <!-- Pagination (dynamique) -->
    <div id="pagination-container"></div>
  </div>
  <script>
    const limit = <?= (int)$limit ?>;
    const offset = <?= (int)$offset ?>;
    const search = <?= json_encode($search) ?>;
    const searchRequested = <?= $search_requested ? 'true' : 'false' ?>;
    let total = 0, page = <?= (int)$page ?>;
    const apiBase = '../api';

    // Get devices from API
    async function fetchDevices() {
      let url = `${apiBase}/devices?offset=${offset}&limit=${limit}`;
      if (search) url += '&search=' + encodeURIComponent(search); // Si search supporté côté backend API
      try {
        let resp = await fetch(url);
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        let data = await resp.json();
        total = data.total || 0;
        renderDevicesTable(data.devices || []);
        renderPagination();
      } catch (e) {
        document.getElementById('devices-table-loader').innerHTML = `<div class="alert alert-danger mt-5 text-center">API error. Cannot fetch devices.</div>`;
      }
    }

    // Render table and then statuses
    function renderDevicesTable(devices) {
      document.getElementById('devices-table-loader').style.display = 'none';
      let rows = '';
      if (!devices.length) {
        rows = `<tr><td colspan="7" class="text-center text-muted">No results found.</td></tr>`;
      } else {
        devices.forEach(dev => {
          // Device key = clickable, style = offline par défaut (on mettra à jour JS après)
          let keyHtml = `<a href="detail.php?key=${encodeURIComponent(dev.device_key)}" class="device-key offline" id="devkey_${dev.device_key}" style="text-decoration:none; cursor:pointer;">${dev.device_key}</a>`;
          // Serial Number (=product_serial ou device_name ou fallback)
          let serial = dev.product_serial ? dev.product_serial : (dev.device_name ? dev.device_name : '—');
          let serialHtml = `<span class="device-serial">${serial}</span>`;
          // Device Type
          let devType = dev.device_type ? dev.device_type : '—';
          let devTypeHtml = `<span>${devType}</span>`;
          // Notes courte (preview)
          let note = dev.note ? dev.note.replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g," ").substr(0,80) : '';
          let noteHtml = note ? `<span class="note-preview" title="${dev.note.replace(/"/g, '&quot;')}">${note}</span>` : '<span class="text-muted">—</span>';
          rows += `
            <tr>
              <td>${keyHtml}</td>
              <td>${serialHtml}</td>
              <td>${devTypeHtml}</td>
              <td>${noteHtml}</td>
              <td>
                ${dev.authorized
                  ? '<span class="badge bg-success" title="Authorized">&#10004;</span>'
                  : '<span class="badge bg-secondary" title="Not authorized">&#10006;</span>'}
              </td>
              <td>${dev.registered_at || ''}</td>
              <td class="table-actions">
                <a href="detail.php?key=${encodeURIComponent(dev.device_key)}" class="btn btn-primary btn-sm">Details</a>
              </td>
            </tr>`;
        });
      }
      let table = `
        <table class="table table-bordered devices-table align-middle">
          <thead class="table-light">
            <tr>
              <th style="width:18%;">Device Key</th>
              <th style="width:18%;">Serial Number</th>
              <th style="width:14%;">Device Type</th>
              <th style="width:22%;">Notes</th>
              <th style="width:8%;">Auth.</th>
              <th style="width:14%;">Registered At</th>
              <th style="width:8%;">Actions</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      `;
      document.getElementById('devices-table-wrapper').innerHTML = table;

      // Après affichage, update status de chaque device (online/offline)
      (devices || []).forEach(dev => {
        fetch(`${apiBase}/devices/${dev.device_key}/availability`)
          .then(r => r.json())
          .then(status => {
            let el = document.getElementById('devkey_' + dev.device_key);
            if (!el) return;
            if (status && status.status === "Available") {
              el.classList.remove('offline');
              el.classList.add('online');
            } else {
              el.classList.remove('online');
              el.classList.add('offline');
            }
          })
          .catch(() => {}); // silencieux
      });
    }

    // Render Pagination
    function renderPagination() {
      let totalPages = Math.max(1, Math.ceil(total / limit));
      let item_from = total ? offset + 1 : 0;
      let item_to = Math.min(offset + limit, total);
      let html = '';
      if (totalPages > 1) {
        html += `<nav><ul class="pagination">`;
        for (let i = 1; i <= totalPages; i++) {
          html += `<li class="page-item${i === page ? ' active' : ''}">
            <a class="page-link" href="?search=${encodeURIComponent(search)}&page=${i}">${i}</a>
          </li>`;
        }
        html += `</ul><span class="ms-2">(${item_from}-${item_to}/${total})</span></nav>`;
      } else if (total) {
        html += `<span>(${item_from}-${item_to}/${total})</span>`;
      }
      document.getElementById('pagination-container').innerHTML = html;
    }

    // Load only if a search was submitted
    if (searchRequested) {
      fetchDevices();
    } else {
      document.getElementById('devices-table-loader').style.display = 'none';
      document.getElementById('devices-table-wrapper').innerHTML =
        '<p class="text-center text-muted">Use search to list devices.</p>';
    }
  </script>
</body>
</html>
