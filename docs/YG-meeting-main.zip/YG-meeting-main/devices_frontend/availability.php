<?php
/*
  File: /var/www/html/devices/availability.php
  Version: 1.0.0
  Description: Device availability & connection history (Meeting 2025)
*/
$device_key = $_GET['key'] ?? '';
if (!$device_key) die("Missing device key.");

// Appel API pour statut
$status = null;
$logs = [];

function api_get($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $resp = curl_exec($ch);
    curl_close($ch);
    return json_decode($resp, true);
}
$status = api_get("http://localhost/api/devices/$device_key/availability");
$logs = api_get("http://localhost/api/devices/$device_key/logs");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Availability | Meeting</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #fff; font-family: 'Segoe UI', Arial, sans-serif; }
    .main { max-width: 1100px; margin: 50px auto; }
    .status-ok { color: #229900; font-weight: 600;}
    .status-bad { color: #c30; font-weight: 600;}
    table tr:nth-child(even) { background: #e6f4fa;}
    table tr:nth-child(odd) { background: #f5fbe6;}
  </style>
</head>
<body>
  <div class="main">
    <h2 style="margin-top:22px;">Current status</h2>
    <div>
      <?php if ($status && $status['status'] === 'Available'): ?>
        <span class="status-ok">Available</span>
      <?php else: ?>
        <span class="status-bad">Disconnected</span>
      <?php endif; ?>
      <span style="color:#666;font-size:16px;margin-left:10px;">
        (since <?= htmlspecialchars($status['since'] ?? '-') ?>, uptime <?= htmlspecialchars($status['uptime'] ?? '-') ?> s)
      </span>
    </div>
    <h2 style="margin-top:34px;">History</h2>
    <table class="table table-bordered" style="background:#fff;">
      <thead>
        <tr>
          <th>Time</th><th>Event</th><th>Host</th><th>Remote</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($logs as $row): ?>
        <tr>
          <td><?= htmlspecialchars($row['timestamp']) ?></td>
          <td><?= htmlspecialchars($row['event']) ?></td>
          <td><?= htmlspecialchars($row['host']) ?></td>
          <td><?= htmlspecialchars($row['remote']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
