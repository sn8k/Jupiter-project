<?php
/*
  File: /var/www/html/devices/detail.php
  Version: 2.5.6
  Description: Device detail page – API-based, Home/Availability/Status/Config, édition dynamique, UX Meeting, full compliance, prod-ready.
  Auteur: CreativeMind Team
  Changelog:
    - 2.5.6 : Fix availability tab rendering (JS variable order).
    - 2.5.5 : Availability tab table headers updated, event log label removed.
    - 2.5.4 : Availability tab shows LAN/Public IP, cluster and MAC.
    - 2.5.3 : Login check and dynamic user info; working logout.
    - 2.5.2 : Use relative API path for improved portability.
    - 2.5.1 : Reloads PPK on each tab open; anti-cache param.
    - 2.5.0 : Onglet "Private key" avec génération de .ppk et mot de passe aléatoire.
    - 2.4.3 : Bouton Home (onglet) déclenche un refresh complet de la page (location.reload()).
    - 2.4.2 : Refresh automatique du tab Home après édition, UX modale améliorée.
    - 2.4.1 : Correction affichage codes d'accès (Low/Medium/High) même si '0000', esthétique Provision revue.
    - 2.4.0 : Device type/distribution dynamiques robustes, device access key fix, notes PUT robustes, bouton Home toujours actif, services checkboxes, UX avancée, gestion erreurs explicite, refactor clean.
    - 2.3.0 : Edition device_type/distribution dynamiques, affichage/edit distrib.json, amélioration UX onglets.
    - 2.2.0 : Onglet Status, Home always accessible, wording, bugfixes.
*/
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
  header('Location: index.php');
  exit;
}
// Device_key via GET param
$device_key = isset($_GET['key']) ? $_GET['key'] : '';
if (!$device_key) { http_response_code(400); die("Missing device_key."); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Device detail | Meeting</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #fff; font-family: 'Segoe UI', Arial, sans-serif; }
    .topbar {
      background: #222; color: #fff; height: 44px;
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 24px; font-size: 15px;
    }
    .topbar a { color: #ccd; text-decoration: none; margin-left: 28px; }
    .topbar .logo-devices { color: #fff; font-weight:600; font-size:18px; margin-left: 0; cursor:pointer;}
    .topbar .user { color: #bbe; font-weight: 500; margin-left: 14px;}
    .devicekey-title { font-family: monospace; font-size: 2.1rem; color: #4183c4; font-weight: 700; text-align: center; margin: 40px 0 14px 0; letter-spacing: 1.2px;}
    .tabs { border-bottom: 1.5px solid #e0e0e0; margin-bottom: 28px; display: flex; gap: 28px; font-size: 1.09rem; justify-content: center;}
    .tabs .tab { padding: 9px 0 12px 0; margin-right: 18px; border-bottom: 3px solid transparent; font-weight: 500; cursor: pointer; color: #555; min-width: 88px; text-align: center;}
    .tabs .tab.active { border-bottom: 3px solid #2186d4; color: #2186d4; font-weight: 700;}
    .device-detail-form { background: #fafbfc; border: 1px solid #e6e6e6; border-radius: 12px; padding: 32px 48px 24px 48px; max-width: 1100px; margin: 0 auto; box-shadow: 0 1px 10px 0 rgba(30,60,90,.07);}
    .device-detail-form .row-label { width: 180px; color: #444; font-weight: 500; vertical-align: middle;}
    .device-detail-form .note-block { background: #fffbe0; border: 1px solid #eee6a2; color: #ad7300; border-radius: 4px; padding: 7px 14px; font-size: 15px;}
    .device-detail-form .note-block.info { color: #8d8000;}
    .btn-open { min-width: 65px;}
    @media (max-width: 1300px) { .device-detail-form { padding: 20px 8px; max-width:98vw;} }
    @media (max-width: 900px) { .device-detail-form { padding: 10px 2vw; } .row-label { width: 105px !important; } }
    .device-access-row { margin-bottom: 10px !important; }
    .loading-spinner { margin: 100px auto 0 auto; display:block; }
    .availability-status-row { margin:30px 0 18px 0;}
    .availability-ip { font-size:1.08em; color:#888; margin-top:-9px; margin-bottom:18px;}
    .availability-table th { text-align:center; font-weight:600; }
    .availability-table td { text-align:center; font-family:monospace; }
    .status-refresh-row { margin-top: 24px; margin-bottom: 24px; }
    .histogram-bar { height: 18px; display:inline-block; margin-right:1px; border-radius:2px;}
    .status-filter-row input[type="date"] {max-width:145px;}
    .graphana-frame { background: #e0e0e0; border-radius: 8px; min-height: 250px; margin-top: 36px; display:flex; align-items:center; justify-content:center; color:#a2a2a2; font-size:2.4em;}
    .monospace-area { font-family: 'Fira Mono', monospace; font-size: 1em; min-height: 240px;}
    .json-valid { color: #19722c;}
    .json-invalid { color: #a71d2a;}
  </style>
</head>
<body>
  <!-- Header -->
  <nav class="topbar">
    <span class="logo-devices" onclick="window.location.href='./search.php'">Devices</span>
    <div>
      <a href="#">Device reports</a>
      <a href="#">Device status</a>
      <a href="#">Bug reports</a>
      <a href="#">Batch from serial</a>
      <span class="user">✓ <?= htmlspecialchars($_SESSION['username']) ?></span>
      <a href="logout.php">Logout</a>
    </div>
  </nav>
  <!-- Loader -->
  <div id="main-content" style="min-height:70vh;">
    <div id="loader" class="text-center">
      <div class="spinner-border loading-spinner" role="status"></div>
      <p style="font-size:1.2em; color:#888; margin-top:18px;">Loading device...</p>
    </div>
  </div>

  <!-- Modal Edit -->
  <div class="modal fade" id="editDeviceModal" tabindex="-1" aria-labelledby="editDeviceModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content" style="border-radius:8px;">
        <div class="modal-header">
          <h5 class="modal-title" id="editDeviceModalLabel" style="font-weight:600;">Edit infos</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="outline:none;"></button>
        </div>
        <form id="editDeviceForm" autocomplete="off">
          <div class="modal-body" style="padding-bottom:0;">
            <div class="row mb-3">
              <div class="col-md-4 mb-2">
                <label for="edit_token" class="form-label mb-1">Token :</label>
                <input type="text" class="form-control" name="edit_token" id="edit_token" value="">
              </div>
              <div class="col-md-4 mb-2">
                <label for="edit_token_count" class="form-label mb-1">Token(s) available :</label>
                <input type="number" class="form-control" name="edit_token_count" id="edit_token_count" min="0" value="">
              </div>
            </div>
            <div class="row mb-3">
              <div class="col-md-6 mb-2">
                <label for="edit_device_type" class="form-label mb-1">Device Type :</label>
                <select class="form-select" name="edit_device_type" id="edit_device_type" disabled>
                  <option value="">Loading...</option>
                </select>
              </div>
              <div class="col-md-6 mb-2">
                <label for="edit_distribution" class="form-label mb-1">Distribution :</label>
                <select class="form-select" name="edit_distribution" id="edit_distribution" disabled>
                  <option value="">Loading...</option>
                </select>
              </div>
            </div>
            <div class="mb-3">
              <label class="form-label mb-1">Services</label><br>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="svc_ssh" name="services[]" value="ssh">
                <label class="form-check-label" for="svc_ssh">SSH</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="svc_vnc" name="services[]" value="vnc">
                <label class="form-check-label" for="svc_vnc">VNC</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="svc_http" name="services[]" value="http">
                <label class="form-check-label" for="svc_http">HTTP</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" id="svc_scp" name="services[]" value="scp">
                <label class="form-check-label" for="svc_scp">SCP</label>
              </div>
            </div>
            <div class="mb-3">
              <label for="edit_note" class="form-label mb-1">Notes :</label>
              <textarea class="form-control" name="edit_note" id="edit_note" rows="3"></textarea>
            </div>
          </div>
          <div class="modal-footer" style="border-top:0;">
            <button type="submit" class="btn btn-success px-4" id="btn-save-edit">Save</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Modal for Editing distrib.json -->
  <div class="modal fade" id="editDistribJsonModal" tabindex="-1" aria-labelledby="editDistribJsonModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content" style="border-radius:8px;">
        <div class="modal-header">
          <h5 class="modal-title" id="editDistribJsonModalLabel" style="font-weight:600;">Edit distrib.json</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="outline:none;"></button>
        </div>
        <form id="editDistribJsonForm" autocomplete="off">
          <div class="modal-body" style="padding-bottom:0;">
            <textarea class="form-control monospace-area" id="distrib_json_area" spellcheck="false"></textarea>
            <div class="mt-2" id="json-validity"></div>
          </div>
          <div class="modal-footer" style="border-top:0;">
            <button type="submit" class="btn btn-success px-4" id="btn-save-distrib-json">Save</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    const device_key = "<?= addslashes($device_key) ?>";
    let device_data = {};
    let currentTab = "Home";
    const apiBase = '../api';
    let lastStatusRefresh = null;
    let statusLogsCache = [];
    let deviceTypes = [];
    let distributions = [];

    // safeval autorise 0, "0000", "000000" etc.
    function safeval(obj, k) {
      if(!obj) return "--";
      if(obj.hasOwnProperty(k) && obj[k] !== undefined && obj[k] !== null) return obj[k];
      return "--";
    }

    // Tabs rendering
    function renderTabs(activeTab) {
      const tabs = [
        "Home", "Business hosts", "Children", "Private key",
        "Availability", "Status", "Bug Reports", "Configuration"
      ];
      let html = `<div class="tabs container" style="max-width:1100px;">`;
      tabs.forEach(tab => {
        if(tab === "Home") {
          // Ici : bouton Home -> refresh complet
          html += `<span class="tab${activeTab === tab ? ' active' : ''}" data-tab="${tab}" onclick="window.location.reload()">${tab}</span>`;
        } else {
          html += `<span class="tab${activeTab === tab ? ' active' : ''}" data-tab="${tab}" onclick="goToTab('${tab}')">${tab}</span>`;
        }
      });
      html += `</div>`;
      return html;
    }

    // Tab navigation
    window.goToTab = function(tab) {
      currentTab = tab;
      if (tab === "Home") fetchDevice();
      else if (tab === "Availability") renderAvailabilityTab();
      else if (tab === "Status") renderStatusTab();
      else if (tab === "Configuration") renderConfigTab();
      else if (tab === "Private key") renderPrivateKeyTab();
      else {
        document.getElementById("main-content").innerHTML = `
          <div class="devicekey-title">${safeval(device_data, 'device_key')}</div>
          ${renderTabs(tab)}
          <div style="max-width:800px;margin:40px auto 0 auto;">
            <div class="alert alert-warning text-center" style="font-size:1.2em;">
              <b>${tab}</b> – Not implemented yet.
            </div>
            <div class="text-center mt-4">
              <a class="btn btn-outline-secondary" href="detail.php?key=${device_key}" style="min-width:150px;">Back to Home</a>
            </div>
          </div>
        `;
      }
    };

    // Fetch Device on load (and when needed)
    async function fetchDevice() {
      document.getElementById("loader").style.display = '';
      let resp = await fetch(`${apiBase}/devices/` + device_key);
      if (!resp.ok) {
        document.getElementById("main-content").innerHTML = '<div class="alert alert-danger mt-5 text-center">Device not found.</div>';
        return;
      }
      let dev = await resp.json();
      device_data = dev;
      document.getElementById("loader").style.display = 'none';
      if (currentTab === "Home") renderDetailForm(dev);
      else if (currentTab === "Availability") renderAvailabilityTab();
      else if (currentTab === "Status") renderStatusTab();
      else if (currentTab === "Configuration") renderConfigTab();
      else if (currentTab === "Private key") renderPrivateKeyTab();
    }

    // Récupère tous les device types depuis le backend
    async function fetchDeviceTypes() {
      try {
        let r = await fetch(`${apiBase}/devices/device-types`);
        if (!r.ok) throw new Error('fallback');
        let data = await r.json();
        deviceTypes = data.device_types || [];
      } catch {
        try {
          let r2 = await fetch(`${apiBase}/flash/device-types`);
          if (!r2.ok) throw new Error('err');
          let data2 = await r2.json();
          deviceTypes = data2.device_types || [];
        } catch { deviceTypes = []; }
      }
      return deviceTypes;
    }
    // Récupère toutes les distributions pour un type donné
    async function fetchDistributionsForType(type) {
      if(!type) { distributions = []; return []; }
      try {
        let r = await fetch(`${apiBase}/devices/device-types/` + encodeURIComponent(type) + '/distributions');
        if (!r.ok) throw new Error('fallback');
        let data = await r.json();
        distributions = data.distributions || [];
      } catch {
        try {
          let r2 = await fetch(`${apiBase}/flash/` + encodeURIComponent(type) + '/distributions');
          if (!r2.ok) throw new Error('err');
          let data2 = await r2.json();
          distributions = data2.distributions || [];
        } catch { distributions = []; }
      }
      return distributions;
    }

    // Remplit les listes déroulantes dans la modale
    async function fillEditModal() {
      document.getElementById("edit_token").value = safeval(device_data, "token_code");
      document.getElementById("edit_token_count").value = device_data.token_count || 0;
      document.getElementById("edit_note").value = device_data.note || "";

      // Remplissage device type (dynamique)
      let typeSel = document.getElementById("edit_device_type");
      typeSel.disabled = true;
      let types = await fetchDeviceTypes();
      typeSel.innerHTML = types.length ? types.map(t =>
        `<option value="${t}"${t === device_data.device_type ? ' selected' : ''}>${t}</option>`
      ).join('') : `<option value="">(No device types)</option>`;
      typeSel.disabled = !types.length ? true : false;

      // Distribution (selon type)
      let distSel = document.getElementById("edit_distribution");
      distSel.disabled = true;
      let dists = await fetchDistributionsForType(typeSel.value);
      distSel.innerHTML = dists.length ? dists.map(d =>
        `<option value="${d}"${d === device_data.distribution ? ' selected' : ''}>${d}</option>`
      ).join('') : `<option value="">(No distributions)</option>`;
      distSel.disabled = !dists.length ? true : false;

      // Sur changement de deviceType → reload distributions
      typeSel.onchange = async function() {
        let dists2 = await fetchDistributionsForType(typeSel.value);
        distSel.innerHTML = dists2.length ? dists2.map(d =>
          `<option value="${d}">${d}</option>`
        ).join('') : `<option value="">(No distributions)</option>`;
        distSel.disabled = !dists2.length ? true : false;
      };

      // Préselect
      distSel.value = device_data.distribution;

      // Services (checkboxes)
      let services = Array.isArray(device_data.services) ? device_data.services : [];
      document.getElementById('svc_ssh').checked  = services.includes('ssh');
      document.getElementById('svc_vnc').checked  = services.includes('vnc');
      document.getElementById('svc_http').checked = services.includes('http');
      document.getElementById('svc_scp').checked  = services.includes('scp');
    }

    // Render Detail Form (HOME)
    function renderDetailForm(dev) {
      let http_pw_low    = safeval(dev, 'http_pw_low');
      let http_pw_medium = safeval(dev, 'http_pw_medium');
      let http_pw_high   = safeval(dev, 'http_pw_high');
      let html = `
      <div class="devicekey-title">${safeval(dev, 'device_key')}</div>
      ${renderTabs("Home")}
      <form class="device-detail-form mb-4" id="main-detail-form">
        <div class="row mb-3 align-items-center">
          <div class="row-label col-12 col-md-3">Device key</div>
          <div class="col"><input type="text" readonly class="form-control" style="background:#eee;font-family:monospace" value="${safeval(dev, 'device_key')}"></div>
        </div>
        <div class="row mb-3 align-items-center">
          <div class="row-label col-12 col-md-3">Product serial</div>
          <div class="col"><input type="text" readonly class="form-control" style="background:#eee;" value="${safeval(dev, 'product_serial')}"></div>
          <div class="col-3"><input type="text" readonly class="form-control" style="background:#eee;" value="${dev.authorized ? 'Authorized' : 'Not authorized'}"></div>
        </div>
        <div class="row mb-3 align-items-center">
          <div class="row-label col-12 col-md-3">Device Type</div>
          <div class="col"><input type="text" readonly class="form-control" style="background:#eee;" value="${safeval(dev, 'device_type')}"></div>
        </div>
        <div class="row mb-0 align-items-center device-access-row">
          <div class="row-label col-12 col-md-3">Device access key</div>
          <div class="col">
            <div class="row g-1">
              <div class="col-12 col-lg-4 d-flex align-items-center mb-2 mb-lg-0">
                <span class="me-2">Low</span>
                <input type="text" readonly class="form-control me-2" style="max-width:160px;background:#eee;" value="${(http_pw_low !== undefined && http_pw_low !== null && http_pw_low !== '') ? http_pw_low : '--'}">
                <button type="button" class="btn btn-primary btn-sm btn-open" ${(http_pw_low !== undefined && http_pw_low !== null && http_pw_low !== '') ? '' : 'disabled'}>Open</button>
              </div>
              <div class="col-12 col-lg-4 d-flex align-items-center mb-2 mb-lg-0">
                <span class="me-2">Medium</span>
                <input type="text" readonly class="form-control me-2" style="max-width:160px;background:#eee;" value="${(http_pw_medium !== undefined && http_pw_medium !== null && http_pw_medium !== '') ? http_pw_medium : '--'}">
                <button type="button" class="btn btn-primary btn-sm btn-open" ${(http_pw_medium !== undefined && http_pw_medium !== null && http_pw_medium !== '') ? '' : 'disabled'}>Open</button>
              </div>
              <div class="col-12 col-lg-4 d-flex align-items-center">
                <span class="me-2">Expert</span>
                <input type="text" readonly class="form-control me-2" style="max-width:160px;background:#eee;" value="${(http_pw_high !== undefined && http_pw_high !== null && http_pw_high !== '') ? http_pw_high : '--'}">
                <button type="button" class="btn btn-primary btn-sm btn-open" ${(http_pw_high !== undefined && http_pw_high !== null && http_pw_high !== '') ? '' : 'disabled'}>Open</button>
              </div>
            </div>
          </div>
        </div>
        <div class="row mb-3 align-items-center">
          <div class="row-label col-12 col-md-3">Wifi</div>
          <div class="col d-flex flex-wrap align-items-center gap-2">
            <label class="me-1 mb-0" style="min-width:90px;">AP SSiD</label>
          <div class="col"><input type="text" readonly class="form-control" style="background:#eee;" value="${safeval(dev, 'ap_ssid')}"></div>
          <label class="me-1 mb-0" style="min-width:90px;">AP PassworD</label>
          <div class="col-3"><input type="text" readonly class="form-control" style="background:#eee;" value="${safeval(dev, 'ap_password')}"></div>
        </div>
        <div class="row mb-3 align-items-center">
          <div class="row-label col-12 col-md-3">Provision</div>
          <div class="col d-flex flex-wrap align-items-center gap-2">
            <label class="me-1 mb-0" style="min-width:90px;">Token Code</label>
            <input type="text" readonly class="form-control me-3" style="max-width:160px;background:#eee;" value="${safeval(dev, 'token_code')}">
            <label class="me-1 mb-0" style="min-width:90px;">Tokens Left</label>
            <input type="text" readonly class="form-control" style="max-width:70px;background:#eee;" value="${safeval(dev, 'token_count')}">
          </div>
        </div>
        <div class="row mb-3 align-items-center">
          <div class="row-label col-12 col-md-3">Distribution</div>
          <div class="col"><input type="text" readonly class="form-control" value="${safeval(dev, 'distribution')}" style="background:#eee;"></div>
        </div>
        <div class="row mb-3 align-items-center">
          <div class="row-label col-12 col-md-3">Services</div>
          <div class="col">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" id="svc_ssh_view" disabled ${Array.isArray(dev.services)&&dev.services.includes('ssh')?'checked':''}>
              <label class="form-check-label" for="svc_ssh_view">SSH</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" id="svc_scp_view" disabled ${Array.isArray(dev.services)&&dev.services.includes('scp')?'checked':''}>
              <label class="form-check-label" for="svc_scp_view">SCP</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" id="svc_vnc_view" disabled ${Array.isArray(dev.services)&&dev.services.includes('vnc')?'checked':''}>
              <label class="form-check-label" for="svc_vnc_view">VNC</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" id="svc_http_view" disabled ${Array.isArray(dev.services)&&dev.services.includes('http')?'checked':''}>
              <label class="form-check-label" for="svc_http_view">HTTP</label>
            </div>
          </div>
        </div>

        <div class="row mb-3 align-items-center">
          <div class="row-label col-12 col-md-3">Bundles</div>
          <div class="col"><ul class="mb-0" style="padding-left:20px;"><li>${Array.isArray(dev.bundles) ? dev.bundles.join(', ') : safeval(dev, 'bundles')}</li></ul></div>
        </div>
        <div class="row mb-3 align-items-center">
          <div class="row-label col-12 col-md-3">Ghost candidate</div>
          <div class="col">
            <a href="${safeval(dev, 'ghost_candidate_url') !== "--" ? safeval(dev, 'ghost_candidate_url') : '#'}" style="color:#2574A9;font-weight:500;">
              ${safeval(dev, 'ghost_candidate_url') !== "--" ? safeval(dev, 'ghost_candidate_url') : "N/A"}
            </a>
          </div>
        </div>
        <div class="row mb-3 align-items-center">
          <div class="row-label col-12 col-md-3">Parent</div>
          <div class="col">
            <div class="note-block">Device #${safeval(dev, 'device_key')} ${safeval(dev, 'parent_device_key') === "--" ? 'does not have parent !' : 'Parent : ' + safeval(dev, 'parent_device_key')}</div>
          </div>
        </div>
        <div class="row mb-3 align-items-center">
          <div class="row-label col-12 col-md-3">Note</div>
          <div class="col">
            <div class="note-block info" id="main-note">${dev.note ? dev.note.replace(/\n/g,"<br>") : "Not any notes for this device. Edit to add notes."}</div>
          </div>
        </div>
        <div class="text-center mt-4">
          <button type="button" class="btn btn-primary btn-lg px-5" style="font-size:18px;" data-bs-toggle="modal" data-bs-target="#editDeviceModal">Edit</button>
        </div>
      </form>
      `;
      document.getElementById("main-content").innerHTML = html;
    }

    // Render AVAILABILITY Tab
    async function renderAvailabilityTab() {
      document.getElementById("main-content").innerHTML = `
        <div style="max-width:1100px;margin:0 auto;">
          <div class="devicekey-title">${safeval(device_data, 'device_key')}</div>
          ${renderTabs("Availability")}
          <div class="text-center" style="margin:50px 0 30px 0;">
            <div class="spinner-border loading-spinner" role="status"></div>
            <p style="color:#888;">Fetching availability&hellip;</p>
          </div>
        </div>
      `;
      // Récupérer statut
      let status = null, logs = [];
      try {
        let res = await fetch(`${apiBase}/devices/${device_key}/availability`);
        status = await res.json();
      } catch { status = null; }
      try {
        let res2 = await fetch(`${apiBase}/devices/${device_key}/logs`);
        logs = await res2.json();
      } catch { logs = []; }

      // Infos réseau avec compatibilité rétro
      let ipLan = safeval(device_data, 'ip_lan');
      if(ipLan === '--') {
        const legacy = safeval(device_data, 'ip_address');
        ipLan = legacy !== '--' ? legacy : '';
      }
      let ipPub = safeval(device_data, 'ip_public');
      if(ipPub === '--') ipPub = '';
      let cluster = safeval(device_data, 'cluster_ip');
      if(cluster === '--') cluster = '';
      let mac = safeval(device_data, 'mac');
      if(mac === '--') mac = '';

      // Format du statut
      let color = status && status.status === "Available" ? "#18a447"
                : status && status.status === "Disconnected" ? "#c22"
                : "#bca900";
      let sinceStr = status && status.last_heartbeat ? `Last heartbeat ${status.last_heartbeat}` : "";
      let statTitle = status ? `<span style="color:${color};font-weight:600;">${status.status||"--"}</span>` : "--";

      // Table logs (status history)
      let logsRows = logs && logs.length
        ? logs.map(l =>
          `<tr>
            <td>${l.event || "--"}</td>
            <td>${l.timestamp || "--"}</td>
            <td>${fmt(ipLan)}</td>
            <td>${fmt(mac)}</td>
            <td>${fmt(cluster)}</td>
          </tr>`).join("")
        : `<tr><td colspan="5" class="text-center text-muted">No events</td></tr>`;

      function fmt(v) { return v ? v : '<span class="text-muted">?</span>'; }
      document.getElementById("main-content").innerHTML = `
        <div style="max-width:1100px;margin:0 auto;">
          <div class="devicekey-title">${safeval(device_data, 'device_key')}</div>
          ${renderTabs("Availability")}
          <div class="device-detail-form">
            <div class="availability-status-row text-center">
              <div style="font-size:1.6rem;margin-bottom:7px;">
                Status: ${statTitle}
              </div>
              <div class="availability-ip" style="margin-bottom:0;">
                Last heartbeat info
              </div>
              <div style="color:#aaa;font-size:1.05em;">
                ${sinceStr}
              </div>
            </div>
            <div class="table-responsive" style="margin-top:-10px;">
              <table class="table table-sm availability-table mb-3">
                <thead>
                  <tr><th>IP LAN</th><th>IP Publique</th><th>Cluster</th><th>Adresse MAC</th></tr>
                </thead>
                <tbody>
                  <tr><td>${fmt(ipLan)}</td><td>${fmt(ipPub)}</td><td>${fmt(cluster)}</td><td>${fmt(mac)}</td></tr>
                </tbody>
              </table>
            </div>
            <div style="max-height:320px;overflow:auto;border:1px solid #eee;border-radius:7px;">
              <table class="table table-sm table-striped mb-0">
                <thead>
                  <tr>
                    <th style="width:20%;">Status</th>
                    <th style="width:25%;">Since</th>
                    <th style="width:18%;">IP LAN</th>
                    <th style="width:18%;">MAC</th>
                    <th style="width:19%;">Cluster</th>
                  </tr>
                </thead>
                <tbody>
                  ${logsRows}
                </tbody>
              </table>
            </div>
            <div class="text-center mt-4">
              <button class="btn btn-outline-secondary" onclick="window.location.reload()" style="min-width:150px;">Back to Home</button>
            </div>
          </div>
        </div>
      `;
    }

    // Render STATUS Tab (identique)
    async function renderStatusTab() {
      document.getElementById("main-content").innerHTML = `
        <div style="max-width:1100px;margin:0 auto;">
          <div class="devicekey-title">${safeval(device_data, 'device_key')}</div>
          ${renderTabs("Status")}
          <div class="status-refresh-row text-start">
            <span id="status-last-refresh" style="font-size:1.1em;color:#666;">Last status fetched&hellip;</span>
            <a href="#" onclick="refreshStatusNow();return false;" style="margin-left:16px;font-size:1.08em;">(refresh now)</a>
          </div>
          <div id="status-content" class="mb-4"></div>
        </div>
      `;
      await fetchAndRenderStatusContent();
    }

    async function fetchAndRenderStatusContent(dateStart = null, dateEnd = null) {
      let logs = [];
      let status = null;
      try {
        let url = `${apiBase}/devices/${device_key}/logs`;
        let res = await fetch(url);
        logs = await res.json();
      } catch { logs = []; }
      statusLogsCache = logs;
      lastStatusRefresh = new Date();
      document.getElementById('status-last-refresh').innerHTML = `Last status fetched at ${lastStatusRefresh.toISOString().replace("T"," ").substring(0, 19)}`;
      let devName = safeval(device_data, "device_name");
      if(devName === "--") devName = "unknown name";
      let minDate = logs.length ? logs[0].timestamp : null;
      let maxDate = logs.length ? logs[logs.length-1].timestamp : null;
      let d1 = dateStart || (minDate ? minDate.substring(0, 10) : "");
      let d2 = dateEnd || (maxDate ? maxDate.substring(0, 10) : "");
      let lastEvent = logs.length ? logs[logs.length-1] : {};
      let statusLabel = lastEvent.event || "--";
      let statusFrom = logs.length ? logs[0].timestamp : "--";
      let statusTo = logs.length ? logs[logs.length-1].timestamp : "--";
      let bars = "";
      let colorMap = { "Connected":"#247E4A", "Request link":"#2B67A0", "Lost link":"#D94328", "--":"#bbb" };
      if(logs.length) {
        for(let i=0;i<logs.length;i++) {
          let col = colorMap[logs[i].event] || "#999";
          bars += `<span class="histogram-bar" style="background:${col};width:5px;"></span>`;
        }
      } else {
        bars = `<span style="color:#888;">No logs for this period.</span>`;
      }
      document.getElementById("status-content").innerHTML = `
        <div style="font-size:1.5em;margin-bottom:8px;">
          ${devName}
        </div>
        <div style="font-size:1.18em;margin-bottom:12px;">
          <b>${statusLabel}</b> global status <span style="font-size:0.92em;font-weight:400;">(From ${statusFrom} to ${statusTo})</span>
        </div>
        <form class="row g-2 align-items-center status-filter-row" style="margin-bottom:18px;max-width:440px;">
          <div class="col-auto">From</div>
          <div class="col-auto">
            <input type="date" class="form-control" id="status-date-from" value="${d1}">
          </div>
          <div class="col-auto">To</div>
          <div class="col-auto">
            <input type="date" class="form-control" id="status-date-to" value="${d2}">
          </div>
          <div class="col-auto">
            <button class="btn btn-secondary btn-sm" id="status-filter-btn">Filter</button>
          </div>
        </form>
        <div class="mb-4">
          ${bars}
        </div>
        <div class="graphana-frame">
          <span><i class="bi bi-graph-up"></i> Graphana stats</span>
        </div>
      `;
      document.getElementById("status-filter-btn").onclick = async function(e) {
        e.preventDefault();
        let v1 = document.getElementById("status-date-from").value;
        let v2 = document.getElementById("status-date-to").value;
        let filtered = statusLogsCache.filter(l => {
          let dt = l.timestamp ? l.timestamp.substring(0,10) : "";
          return (!v1 || dt >= v1) && (!v2 || dt <= v2);
        });
        let bars2 = "";
        for(let i=0;i<filtered.length;i++) {
          let col = colorMap[filtered[i].event] || "#999";
          bars2 += `<span class="histogram-bar" style="background:${col};width:5px;"></span>`;
        }
        if(!filtered.length) bars2 = `<span style="color:#888;">No logs for this period.</span>`;
        document.querySelector("#status-content .mb-4").innerHTML = bars2;
      };
    }

    function refreshStatusNow() { fetchAndRenderStatusContent(); }

    // Onglet Configuration : édition distrib.json
    async function renderConfigTab() {
      document.getElementById("main-content").innerHTML = `
        <div style="max-width:1100px;margin:0 auto;">
          <div class="devicekey-title">${safeval(device_data, 'device_key')}</div>
          ${renderTabs("Configuration")}
          <div class="device-detail-form">
            <div class="mb-3">
              <b>Edit distrib.json (distribution: ${safeval(device_data,'distribution')})</b>
              <div class="text-muted" style="font-size:0.98em;">You can edit the distrib.json of this distribution. Be careful, invalid JSON may brick the flash process!</div>
              <button class="btn btn-warning mt-3" id="btn-edit-distrib-json">Edit distrib.json</button>
            </div>
          </div>
        </div>
      `;
      document.getElementById("btn-edit-distrib-json").onclick = async function() {
        let url = `${apiBase}/devices/${device_key}/distrib-json`;
        let jsonContent = "{}";
        try {
          let resp = await fetch(url);
          jsonContent = await resp.text();
        } catch { jsonContent = "{}"; }
        document.getElementById("distrib_json_area").value = jsonContent;
        document.getElementById("json-validity").innerHTML = '';
        var modal = new bootstrap.Modal(document.getElementById('editDistribJsonModal'));
        modal.show();
      };
    }

    // Onglet Private key : génération PPK
    async function renderPrivateKeyTab() {
      document.getElementById("main-content").innerHTML = `
        <div style="max-width:800px;margin:0 auto;">
          <div class="devicekey-title">${safeval(device_data, 'device_key')}</div>
          ${renderTabs("Private key")}
          <div id="ppk-block" class="text-center" style="margin-top:40px;">
            <div class="spinner-border loading-spinner" role="status"></div>
            <p style="color:#888;">Generating PPK&hellip;</p>
          </div>
        </div>`;
      try {
        let resp = await fetch(`${apiBase}/devices/${device_key}/private-ppk?t=${Date.now()}`);
        if(!resp.ok) throw new Error('HTTP ' + resp.status);
        let pass = resp.headers.get('X-PPK-Passphrase') || '';
        let blob = await resp.blob();
        let url = URL.createObjectURL(blob);
        document.getElementById('ppk-block').innerHTML = `
          <p>Password: <b>${pass}</b></p>
          <a href="${url}" download="${device_key}.ppk" class="btn btn-primary">Download .ppk</a>
        `;
      } catch(err) {
        document.getElementById('ppk-block').innerHTML = `<div class="alert alert-danger">Error loading key</div>`;
      }
    }

    // Validation JSON live
    document.addEventListener('input', function(e) {
      if (e.target && e.target.id === "distrib_json_area") {
        let val = e.target.value;
        try {
          JSON.parse(val);
          document.getElementById("json-validity").innerHTML = '<span class="json-valid">JSON is valid</span>';
        } catch {
          document.getElementById("json-validity").innerHTML = '<span class="json-invalid">Invalid JSON!</span>';
        }
      }
    });

    // Save distrib.json
    document.getElementById("editDistribJsonForm").addEventListener("submit", async function(e) {
      e.preventDefault();
      let area = document.getElementById("distrib_json_area");
      try { JSON.parse(area.value); }
      catch { alert("Invalid JSON."); return; }
      let resp = await fetch(`/api/devices/${device_key}/distrib-json`, {
        method: "PUT",
        headers: {'Content-Type': 'application/json'},
        body: area.value
      });
      var modal = bootstrap.Modal.getInstance(document.getElementById('editDistribJsonModal'));
      modal.hide();
      if(resp.ok) alert("distrib.json updated!");
      else alert("Error updating distrib.json");
    });

    // Lorsqu'on ouvre la modale édition
    document.addEventListener('DOMContentLoaded', function() {
      fetchDevice();
      document.body.addEventListener('show.bs.modal', function(e) {
        if (e.target && e.target.id === "editDeviceModal") fillEditModal();
      });

      // PATCH 2.4.2: Rafraîchir Home UNIQUEMENT à la fermeture de la modale editDeviceModal
      let editModalEl = document.getElementById('editDeviceModal');
      if (editModalEl) {
        editModalEl.addEventListener('hidden.bs.modal', function () {
          // Ne rafraîchit que si on est sur Home
          if (currentTab === "Home") fetchDevice();
        });
      }
    });

    // Soumission du formulaire d'édition
    document.getElementById("editDeviceForm").addEventListener("submit", async function(e) {
      e.preventDefault();
      let errors = [];
      let token = document.getElementById("edit_token").value;
      let token_count = parseInt(document.getElementById("edit_token_count").value,10);
      let device_type = document.getElementById("edit_device_type").value;
      let distribution = document.getElementById("edit_distribution").value;
      let note = document.getElementById("edit_note").value;
      let services = [];
      if(document.getElementById('svc_ssh').checked)  services.push('ssh');
      if(document.getElementById('svc_vnc').checked)  services.push('vnc');
      if(document.getElementById('svc_http').checked) services.push('http');
      if(document.getElementById('svc_scp').checked)  services.push('scp');

      // API calls séparés, gestion erreurs
      async function safePut(endpoint, body) {
        try {
          let r = await fetch(endpoint, {
            method: "PUT",
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(body)
          });
          let txt = await r.text();
          let d = {};
          try { d = JSON.parse(txt); } catch { /* non json */ }
          if(!r.ok || (d && d.error)) throw new Error((d && d.error) ? d.error : txt);
        } catch(err) { errors.push(err.message); }
      }
      await safePut(`/api/devices/${device_key}/token-code`, {token_code: token});
      await safePut(`/api/devices/${device_key}/tokens`, {token_count: token_count});
      await safePut(`/api/devices/${device_key}/device-type`, {device_type: device_type});
      await safePut(`/api/devices/${device_key}/distribution`, {distribution: distribution});
      await safePut(`/api/devices/${device_key}/note`, {note: note});
      await safePut(`/api/devices/${device_key}`, {services: services}); // PUT sur l'objet pour les services

        var editModalEl = document.getElementById('editDeviceModal');
        var modal = bootstrap.Modal.getInstance(editModalEl);
        if(!modal) modal = new bootstrap.Modal(editModalEl);
        modal.hide();

        if(errors.length) alert("Some errors: " + errors.join("\n"));

        // Full page refresh for updated values
        window.location.reload();
    });

    // Réafficher device si modif deviceType ou distribution
    document.getElementById("editDeviceForm").addEventListener("change", function(e) {
      if (e.target.id === "edit_device_type" || e.target.id === "edit_distribution") {
        setTimeout(fetchDevice, 700);
      }
    });

    // Home tab accessible everywhere (logo + bouton)
    window.goToTab = goToTab;

  </script>
</body>
</html>
