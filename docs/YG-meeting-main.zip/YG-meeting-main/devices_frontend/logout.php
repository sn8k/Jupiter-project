<?php
/*
  File: /var/www/html/devices/logout.php
  Version: 1.0.0
  Description: Logout endpoint for Meeting Devices panel.
*/
session_start();
session_unset();
session_destroy();
header('Location: index.php');
exit;
