<?php
/*
  File: /var/www/html/devices/index.php
  Version: 1.1.0
  Description: Login page for Meeting Devices panel. Redirects to search.php after successful login.
  Auteur: CreativeMind Team
*/

session_start();
$login_error = '';

$config = require __DIR__ . '/../api/config.php';

try {
  $pdo = new PDO(
      "mysql:host={$config['db_host']};dbname={$config['db_name']};charset={$config['db_charset']}",
      $config['db_user'],
      $config['db_pass'],
      [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
  );
} catch (PDOException $e) {
  $pdo = null;
}

if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
  header('Location: search.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = isset($_POST['username']) ? trim($_POST['username']) : '';
  $password = isset($_POST['password']) ? $_POST['password'] : '';
  $ok = false;
  $role = 'user';
  if ($pdo) {
    $stmt = $pdo->prepare('SELECT password, role FROM builder_users WHERE username=?');
    $stmt->execute([$username]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row && password_verify($password, $row['password'])) {
      $ok = true;
      $role = $row['role'];
    }
  }
  if (!$ok && $username === ($config['admin_user'] ?? '') && $password === ($config['admin_pass'] ?? '')) {
    $ok = true;
    $role = 'admin';
  }
  if ($ok) {
    $_SESSION['logged_in'] = true;
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;
    header('Location: search.php');
    exit;
  } else {
    $login_error = "Invalid credentials.";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login | Meeting Devices</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #f9fafb; font-family: 'Segoe UI', Arial, sans-serif; }
    .login-container { max-width: 390px; margin: 90px auto; background: #fff; border-radius: 10px; box-shadow: 0 3px 20px rgba(0,0,0,0.08); padding: 40px 38px 32px 38px; }
    .login-title { font-size: 2rem; font-weight: 700; margin-bottom: 22px; color:#2574A9; text-align: center;}
    .form-label { font-weight: 500; }
    .btn-login { width: 100%; font-size: 1.14em; }
    .login-error { color: #b52c2c; text-align:center; margin-bottom:18px; font-weight: 500; }
  </style>
</head>
<body>
  <div class="login-container">
    <div class="login-title">Meeting Devices Login</div>
    <?php if ($login_error): ?>
      <div class="login-error"><?= htmlspecialchars($login_error) ?></div>
    <?php endif; ?>
    <form method="post" autocomplete="off">
      <div class="mb-3">
        <label class="form-label" for="username">Username</label>
        <input type="text" class="form-control" id="username" name="username" required autofocus>
      </div>
      <div class="mb-4">
        <label class="form-label" for="password">Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-login mb-2">Login</button>
    </form>
    <div class="mt-3 text-center text-muted" style="font-size:0.97em;">
      &copy; <?= date('Y') ?> CreativeMind / Meeting
    </div>
  </div>
</body>
</html>
