YGS Tunnel

A lightweight, self‑hosted reverse‑TCP tunnel written in vanilla Node.js (≥ 20) — no external dependencies.

✨ Features



ygs‑agent

ygs‑proxy

Single persistent control socket (default : 9001/TCP)

✅

✅

Random public‑port assignment from a pool (9050‑9130)

—

✅

Live dark‑mode Web UI

:3000

:9500

Add / delete services on‑the‑fly

—

✅

Auto refresh (re‑seed ports when idle)

✅

—

Zero external NPM deps

✅

✅

Systemd friendly + logs to stdout

✅

✅

📐 Architecture

┌──────────┐   tcp/9050..9130    ┌──────────────────┐  ctrl:9001  ┌──────────┐
│  Client  │ ────────────────► │  ygs‑proxy (VPS) │ ◄──────────► │ ygs‑agent │
└──────────┘                   │  public ↔ local  │              │  (NAT)    │
                              └──────────────────┘              └──────────┘

🚀 Quick start (beta)

# 1 – Prerequisites
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt-get install -y nodejs   # Node ≥ 20

# 2 – Install binaries
sudo install -m 755 ygs-proxy /usr/local/bin/ygs-proxy   # on the VPS
sudo install -m 755 ygs-agent /usr/local/bin/ygs-agent   # on the device

# 3 – Launch (development)
ssh vps "ygs-proxy"            # run in a screen / tmux
ssh pi  "ygs-agent"

Open http://vps:9500/ → the proxy UI. Three default mappings appear:

9050 → 22 (SSH)  •  9051 → 80 (HTTP)  •  9052 → 5900 (VNC)

⚙️ Configuration

Both components embed defaults and create config.json on first run.
Edit via the agent UI or by tweaking the constants at the top of each file.
You can override the proxy hostname by setting the `YGS_SERVER_HOST` environment variable.

Variable

Default

Side

Description

serverHost

meeting.ygsoft.fr

agent

FQDN / IP of the proxy

serverPort

9001

both

Control port

token

ChangeMe

both

Shared secret (edit!)

refreshMs

240000

agent

Idle‑refresh interval

reconnectDelay

5000

agent

Delay after lost link

uiPort

3000 / 9500

agent / proxy

Web UI ports

PORT_MIN–MAX

9050‑9130

proxy

Public pool

uiUser

(empty)

agent / proxy

Basic auth user (empty disables auth)

uiPass

(empty)

agent / proxy

Basic auth password

🖥️ Systemd units

# /etc/systemd/system/ygs-proxy.service
[Unit]
Description=YGS proxy
After=network.target

[Service]
ExecStart=/usr/local/bin/ygs-proxy
Environment=YGS_TOKEN=MyUltraSecret
Restart=on-failure

[Install]
WantedBy=multi-user.target

# /etc/systemd/system/ygs-agent.service
[Unit]
Description=YGS agent
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/usr/local/bin/ygs-agent
Environment=YGS_TOKEN=MyUltraSecret
Environment=YGS_SERVER_HOST=my.proxy.local
Restart=on-failure

[Install]
WantedBy=multi-user.target

🌑 Web UIs

Proxy http://<server>:9500/

Add: type a local port (e.g. 5432) → a free public port is assigned.

Del: click the del button.

Logs: real‑time tail (80 lines).

Agent http://<device>:3000/

Edit server, token, intervals — saved to config.json.

Shows countdown until next idle refresh.

🔒 Security tips

Change the default token – it’s a bearer secret.

Set `uiUser`/`uiPass` (or `YGS_USER`/`YGS_PASS` for the proxy) to enable the
built‑in Basic auth and keep the UIs private.

For transport encryption, put ygs-proxy behind an stunnel / HAProxy TLS 
terminator, or run the control channel on WireGuard.

🛠️ Roadmap

TLS built‑in on control socket

UDP forwarding (WireGuard, DNS…) 

Auth & RBAC in the UIs

Prometheus metrics

