#!/usr/bin/env node
/*
───────────────────────────────────────────────────────────────────────────────
  ygs-agent

  • Expected location & filename : /usr/local/bin/ygs-agent
  • Version                     : 1.2.13  (2025-06-25)
───────────────────────────────────────────────────────────────────────────────
  Lightweight TCP tunnel agent with:
   – Automatic server reconnection & periodic “port refresh”
   – Persistent JSON config (auto-created on first start)
   – REST heartbeat envoie : ip_lan, ip_public, cluster_ip, mac
   – NO WEB UI
   – Native file logging (/var/log/ygs-agent.log)
───────────────────────────────────────────────────────────────────────────────*/

import net    from 'node:net';
import fs     from 'node:fs';
import http   from 'node:http';
import https  from 'node:https';
import events from 'node:events';
import path   from 'node:path';
import os     from 'node:os';
import { execSync } from 'node:child_process';

const VERSION = '1.2.13';
const LOGFILE = '/var/log/ygs-agent.log';  // <--- change this if you want another path

/* ── 1 | persistent configuration ─────────────────────────────────────── */
const CFG_FILE = new URL('./config.json', import.meta.url).pathname;
const INFO_FILE = '/etc/meeting/device_info.json';
const DEFAULTS = {
  serverHost     : 'meeting.ygsoft.fr',
  serverPort     : 9001,
  serverProtocol : 'https',
  token          : 'ChangeMe',
  restApiHost     : 'meeting.ygsoft.fr',
  restApiPort     : 443,
  restApiProtocol : 'https',
  refreshMs      : 4 * 60 * 1000,
  reconnectDelay : 5000,
  heartbeatMs    : 60 * 1000,
  hostKeyApiUrl  : 'https://meeting.ygsoft.fr/api/ssh-hostkey',
  knownHostsFile : '/home/device/.ssh/known_hosts',
  hostKeyCheckMs : 10 * 60 * 1000,
  pubKeyFile     : '/home/device/.ssh/id_ed25519.pub',
  fetchedKeyFile : '/home/device/.ssh/device_key_remote.pub',
  connectionTimeout : 10 * 60 * 1000
};

function ensureLocalKey(){
  const pub = cfg.pubKeyFile;
  const priv = pub.replace(/\.pub$/, '');
  if(!fs.existsSync(pub) || !fs.existsSync(priv)){
    try{
      fs.mkdirSync(path.dirname(priv), { recursive: true });
      execSync(`ssh-keygen -t ed25519 -N "" -C "ygs-agent" -f "${priv}"`, {stdio:'ignore'});
      log('[ssh] generated local key', priv);
    }catch(e){
      log('[err] genkey', e.message);
    }
  }
}

function loadCfg() {
  try   { return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(CFG_FILE, 'utf8')) }; }
  catch { return { ...DEFAULTS }; }
}
let cfg = loadCfg();
if (process.env.YGS_SERVER_HOST) {
  cfg.serverHost = process.env.YGS_SERVER_HOST;
  if(!cfg.restApiHost) cfg.restApiHost = cfg.serverHost;
}
function saveCfg() { fs.writeFileSync(CFG_FILE, JSON.stringify(cfg, null, 2)); }

function loadInfo() {
  try   { return JSON.parse(fs.readFileSync(INFO_FILE, 'utf8')); }
  catch { return null; }
}
const deviceInfo = loadInfo();
let deviceKey = null;
if (deviceInfo && typeof deviceInfo.device_key !== 'undefined') {
  deviceKey = deviceInfo.device_key;
}
const argv = process.argv.slice(2);
const hasArg = f => argv.includes(f);
const getArg = f => {
  const p = argv.find(a => a.startsWith(f+'='));
  if(p) return p.slice(f.length+1);
  const i = argv.indexOf(f);
  return i>=0 ? argv[i+1] : undefined;
};
if(getArg('--key-file')) cfg.pubKeyFile = getArg('--key-file');
const hasInterval = argv.some(a => a === '--interval' || a.startsWith('--interval='));
const singleRun = !hasInterval && (hasArg('--upload-key') || hasArg('--fetch-key'));

/* ── 2 | runtime state & helpers ─────────────────────────────────────── */
let ctrlSock        = null;
const locals        = new Map();
const logBuffer     = [];
const log = (...msg) => {
  const line = new Date().toISOString() + ' ' + msg.join(' ');
  console.log(line);
  logBuffer.push(line); if (logBuffer.length > 40) logBuffer.shift();
  // Try to append to logfile, ignore error if any (eg. no perms)
  try {
    fs.appendFileSync(LOGFILE, line+'\n');
  } catch(e){}
};
if(deviceKey) log('[cfg] device_key', deviceKey);
const safeWrite = (sock, buf) => { if (sock && !sock.destroyed && sock.writable) sock.write(buf); };
const frame = (type, id, payload = Buffer.alloc(0)) => {
  const b = Buffer.alloc(9 + payload.length);
  b[0] = type.charCodeAt(0);
  b.writeUInt32BE(id, 1);
  b.writeUInt32BE(payload.length, 5);
  payload.copy(b, 9);
  return b;
};

/* ── 3 | agent ↔ server connection & multiplexing ────────────────────── */
let reconnectTimer = null;
let connTimer = null;
const scheduleReconnect = ms => { clearTimeout(reconnectTimer); reconnectTimer = setTimeout(connect, ms); };
const startConnTimer = () => {
  clearTimeout(connTimer);
  connTimer = setTimeout(() => {
    log('[ygs] connection timeout, reconnecting');
    if (ctrlSock && !ctrlSock.destroyed) ctrlSock.destroy();
  }, cfg.connectionTimeout);
};

function connect() {
  ctrlSock = net.connect(cfg.serverPort, cfg.serverHost, () => {
    const hello = JSON.stringify({token: cfg.token, name: deviceKey||''}) + '\n';
    safeWrite(ctrlSock, Buffer.from(hello));
    log('[ygs] connected to', cfg.serverHost, cfg.serverPort, 'as', deviceKey||'?');
    startConnTimer();
  });

  ctrlSock.on('error', err => {
    log('[err] ctrl', err.message);
    clearTimeout(connTimer);
    scheduleReconnect(cfg.reconnectDelay);
  });

  let buf = Buffer.alloc(0);
  ctrlSock.on('data', chunk => {
    startConnTimer();
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 9) {
      const t   = String.fromCharCode(buf[0]),
            id  = buf.readUInt32BE(1),
            len = buf.readUInt32BE(5);
      if (buf.length < 9 + len) break;
      const payload = buf.subarray(9, 9 + len);
      buf = buf.subarray(9 + len);

      if (t === 'N') {
        const lp = payload.readUInt16BE(0);
        const s  = net.connect(lp, '127.0.0.1');
        locals.set(id, s);
        log(`[==] stream ${id} → localhost:${lp}`);

        s.on('error', err => log('[err] stream', id, err.message));
        s.on('data', d => safeWrite(ctrlSock, frame('D', id, d)));
        s.on('close', () => { safeWrite(ctrlSock, frame('C', id)); locals.delete(id); });
      }
      else if (t === 'D') {
        const sock = locals.get(id);
        if (sock) sock.write(payload);
      }
      else if (t === 'C') {
        const sock = locals.get(id);
        if (sock) sock.destroy();
        locals.delete(id);
      }
    }
  });

  ctrlSock.on('close', () => {
    log('[ygs] disconnected');
    clearTimeout(connTimer);
    for (const s of locals.values()) s.destroy();
    locals.clear();
    scheduleReconnect(cfg.reconnectDelay);
  });
}

/* ── 4 | periodic “port refresh” ─────────────────────────────────────── */
let refreshTimer;
function resetRefreshTimer() {
  clearInterval(refreshTimer);
  refreshTimer = setInterval(() => {
    if (locals.size === 0 && ctrlSock && !ctrlSock.destroyed) {
      log('[ygs] refresh — no active streams, reconnecting');
      clearInterval(refreshTimer);
      ctrlSock.end();
    }
  }, cfg.refreshMs);
}
resetRefreshTimer();

/* ── 5 | IP/machine info helpers ─────────────────────────────────────── */
let cachedPublicIp = null;
let lastPublicIpFetch = 0;
const PUBLIC_IP_REFRESH = 60 * 60 * 1000; // 1h

function getLocalIpAndMac() {
  const ifaces = os.networkInterfaces();
  for (const name of Object.keys(ifaces)) {
    for (const iface of ifaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal && !iface.address.startsWith('169.254')) {
        return { ip: iface.address, mac: iface.mac || null };
      }
    }
  }
  return { ip: null, mac: null };
}

function getPublicIpPromise() {
  return new Promise((resolve, reject) => {
    https.get('https://api.ipify.org', res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data.trim()));
    }).on('error', reject);
  });
}

async function refreshPublicIp() {
  try {
    cachedPublicIp = await getPublicIpPromise();
    lastPublicIpFetch = Date.now();
    log('[ip] public', cachedPublicIp);
  } catch(e) {
    log('[err] get public ip', e.message);
  }
}
refreshPublicIp();
if(!singleRun) setInterval(refreshPublicIp, PUBLIC_IP_REFRESH);

/* ── 6 | REST API helpers (uses dedicated config) ───────────────────── */
function restCfg() {
  const host = cfg.restApiHost     || cfg.serverHost;
  const port = cfg.restApiPort     || ((cfg.restApiProtocol||cfg.serverProtocol||'https').toLowerCase()==='http' ? 80 : 443);
  const proto= (cfg.restApiProtocol||cfg.serverProtocol||'https').toLowerCase();
  return { host, port, proto: proto==='http' ? http : https, protocolStr: proto };
}

/* ── 6a | heartbeat to backend (envoie toutes infos IP) ──────────────── */
function sendHeartbeat() {
  if (!deviceKey) return;
  const { ip: ip_lan, mac } = getLocalIpAndMac();
  const ip_public = cachedPublicIp || null;
  const cluster_ip = cfg.serverHost;

  const payload = JSON.stringify({
    ip_lan,
    ip_public,
    cluster_ip,
    mac
  });

  const {host, port, proto, protocolStr} = restCfg();
  const opts = {
    method: 'POST',
    hostname: host,
    port: port,
    path: `/api/devices/${deviceKey}/online`,
    headers: {'Content-Type':'application/json','Content-Length': Buffer.byteLength(payload)}
  };

  const req = proto.request(opts, res => { res.resume(); });
  log('[hb] POST', opts.path, `(${protocolStr}:${opts.port})`, '| ip_lan:', ip_lan, '| ip_public:', ip_public, '| mac:', mac, '| cluster:', cluster_ip);
  req.on('error', e => log('[err] heartbeat', e.message));
  req.write(payload);
  req.end();
}
let hbTimer;
if(!singleRun){
  hbTimer = setInterval(sendHeartbeat, cfg.heartbeatMs);
  sendHeartbeat();
}

/* ── 7 | SSH host key synchronisation ───────────────────────────────── */
function fetchUrl(u){
  return new Promise((resolve,reject)=>{
    const p = u.startsWith('https') ? https : http;
    const req = p.get(u,res=>{
      if(res.statusCode!==200) return reject(new Error('HTTP '+res.statusCode));
      let d='';
      res.on('data',c=>d+=c); res.on('end',()=>resolve(d));
    });
    req.on('error',reject); req.end();
  });
}

async function checkHostKeys(){
  try{
    log('[ssh] fetching hostkey from', cfg.hostKeyApiUrl);
    const txt = await fetchUrl(cfg.hostKeyApiUrl);
    const lines = txt.split(/\n+/).map(l=>l.trim()).filter(Boolean);
    if(!lines.length) return log('[ssh] empty hostkey list');
    log('[ssh] fetched', lines.length, 'entry'+(lines.length>1?'ies':''));
    const lock = cfg.knownHostsFile+'.lock';
    try{ var fd = fs.openSync(lock,'wx'); }catch(e){ return; }
    try{
      let cur='';
      try{ cur=fs.readFileSync(cfg.knownHostsFile,'utf8'); }catch{}
      const existing = cur.split(/\n+/).filter(Boolean);
      const hosts = lines.map(l=>l.split(/\s+/)[0]);
      const filtered = existing.filter(l=>!hosts.some(h=>l.startsWith(h+' ')));
      const result = filtered.concat(lines).join('\n')+'\n';
      if(result!==cur+(cur?"\n":"")){
        fs.writeFileSync(cfg.knownHostsFile+'.tmp',result,{mode:0o644});
        fs.renameSync(cfg.knownHostsFile+'.tmp',cfg.knownHostsFile);
        log('[ssh] hostkey updated');
      } else {
        log('[ssh] hostkey unchanged');
      }
    }finally{ fs.closeSync(fd); fs.unlinkSync(lock); }
  }catch(e){ log('[err] hostkey',e.message); }
}

let hostKeyTimer;
if(process.argv.includes('--check-hostkey')){
  checkHostKeys().then(()=>process.exit(0));
} else if(!singleRun){
  hostKeyTimer = setInterval(checkHostKeys, cfg.hostKeyCheckMs);
  checkHostKeys();
}

/* ── 8 | device SSH key management ───────────────────────────────────── */
function readLocalKey(file=cfg.pubKeyFile){
  try{ return fs.readFileSync(file,'utf8').trim(); }
  catch(e){ log('[err] readkey',e.message); return null; }
}

async function uploadSshKey(){
  if(!deviceKey) return log('[ssh] no device_key');
  const key = readLocalKey();
  if(!key) return;
  const body = JSON.stringify({pubkey:key});
  const {host, port, proto, protocolStr} = restCfg();
  const opts = {
    method:'PUT', hostname:host, port:port,
    path:`/api/devices/${deviceKey}/ssh-key`,
    headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(body)}
  };
  return new Promise((res,rej)=>{
    const req=proto.request(opts,r=>{ let d=''; r.on('data',c=>d+=c); r.on('end',()=>{ log('[ssh] upload',r.statusCode); res(d);}); });
    req.on('error',e=>{ log('[err] upload',e.message); rej(e);});
    req.write(body); req.end();
  });
}

async function fetchDeviceKey(){
  if(!deviceKey) return log('[ssh] no device_key');
  const {host, port, proto, protocolStr} = restCfg();
  const path = `/api/forcecommand/get_device_key?device_key=${deviceKey}`;
  return new Promise((res,rej)=>{
    const req=proto.request({method:'GET',hostname:host,port:port,path},r=>{
      let d='';
      r.on('data',c=>d+=c);
      r.on('end',()=>{
        if(r.statusCode===200 && d && !d.startsWith('{')){
          try{ fs.writeFileSync(cfg.fetchedKeyFile,d.trim()+"\n"); log('[ssh] saved',cfg.fetchedKeyFile); }catch(e){ log('[err] save',e.message); }
        }
        log('[ssh] fetch',r.statusCode);
        res(d);
      });
    });
    req.on('error',e=>{ log('[err] fetch',e.message); rej(e);});
    req.end();
  });
}

/* ── 9 | startup ─────────────────────────────────────────────────────── */
saveCfg();                                  /* create file if missing */
ensureLocalKey();
log(`[ygs v${VERSION}] started`);
const interval = Number(getArg('--interval')) || 0;
if (singleRun) {
  (async () => {
    if (hasArg('--upload-key')) await uploadSshKey();
    if (hasArg('--fetch-key')) await fetchDeviceKey();
    process.exit(0);
  })();
} else {
  connect();
  if (hasArg('--upload-key')) {
    uploadSshKey();
    if (interval > 0) setInterval(uploadSshKey, interval);
  }
  if (hasArg('--fetch-key')) {
    fetchDeviceKey();
    if (interval > 0) setInterval(fetchDeviceKey, interval);
  }
}
