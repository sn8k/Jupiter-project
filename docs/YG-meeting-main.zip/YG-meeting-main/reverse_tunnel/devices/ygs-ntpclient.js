#!/usr/bin/env node
/*
-------------------------------------------------------------------------------
  ygs-ntpclient

  • Version  : 1.0.0 (2025-06-23)
  • NTP client syncing device clock with Meeting server
-------------------------------------------------------------------------------
*/
import dgram from 'node:dgram';
import { execSync } from 'node:child_process';

const SERVER = process.env.NTP_SERVER || '127.0.0.1';
const PORT = process.env.NTP_PORT ? parseInt(process.env.NTP_PORT,10) : 123;
const INTERVAL = process.env.NTP_INTERVAL_MS ? parseInt(process.env.NTP_INTERVAL_MS,10) : 600000;
const EPOCH = 2208988800;

function requestTime(){
  return new Promise((resolve,reject)=>{
    const client = dgram.createSocket('udp4');
    const buf = Buffer.alloc(48);
    buf[0] = 0x1b; // LI=0, VN=3, Mode=3 (client)
    client.once('message',msg=>{
      try{
        const secs = msg.readUInt32BE(40) - EPOCH;
        resolve(secs*1000);
      }catch(e){
        reject(e);
      }
      client.close();
    });
    client.once('error',err=>{ reject(err); client.close(); });
    client.send(buf,PORT,SERVER);
  });
}

async function sync(){
  try{
    const ms = await requestTime();
    execSync(`date -u -s @${Math.floor(ms/1000)}`);
    console.log('NTP sync:', new Date(ms).toISOString());
  }catch(e){
    console.error('NTP sync failed:', e.message);
  }
}

sync();
setInterval(sync, INTERVAL);
