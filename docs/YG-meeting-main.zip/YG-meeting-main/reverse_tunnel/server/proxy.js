#!/usr/bin/env node
/*
-------------------------------------------------------------------------------
  ygs-proxy

  • Version  : 2.0.7   (2025-06-24)
  • Refactor : Backend-driven tunnels, heartbeat, stream status
-------------------------------------------------------------------------------
*/

import net    from 'node:net';
import http   from 'node:http';
import https  from 'node:https';
import url    from 'node:url';
import events from 'node:events';
import fs     from 'node:fs';

/* -- config ----------------------------------------------------------- */
const API_URL  = 'https://meeting.ygsoft.fr';   // adapt if needed
const UI_PORT  = 9500;
const CTRL_PORT= 9001; // Pour la connexion agents
const TOKEN    = 'bXlfZnVja2luX3Rva2VuX2J5X3lncw==';
const UI_USER  = process.env.YGS_USER || '';
const UI_PASS  = process.env.YGS_PASS || '';
const DEBUG    = process.env.YGS_DEBUG === '1';

/* -- runtime state & helpers ------------------------------------------ */
const logBus  = new events.EventEmitter();
const logBuf  = [];
const log = (...a)=>{const l=new Date().toISOString()+' '+a.join(' ');
  console.log(l); logBuf.push(l); if(logBuf.length>80) logBuf.shift();
  logBus.emit('line',l);};
const dbg = (...a)=>{ if(DEBUG) log('[dbg]', ...a); };
const conns = new Map();    // streamID → public socket
const maps  = new Map();    // pubPort  → {localPort, server, deviceKey, service}
const agents = new Map();   // deviceKey → agentSock

const safeWrite = (sock, buf)=>{ if(sock && !sock.destroyed && sock.writable) sock.write(buf); };
const frame = (t,id,p=Buffer.alloc(0))=>{
  const b=Buffer.alloc(9+p.length); b[0]=t.charCodeAt(0);
  b.writeUInt32BE(id,1); b.writeUInt32BE(p.length,5); p.copy(b,9); return b;
};

/* -- simple fetch wrapper (https GET/POST, promesse) ------------------ */
function fetchAPI(path, method='GET', body=null) {
  return new Promise((resolve, reject) => {
    const isHttps = API_URL.startsWith('https');
    const lib = isHttps ? https : http;
    const apiUrl = new URL(path, API_URL);
    const opts = {
      method,
      hostname: apiUrl.hostname,
      port: apiUrl.port || (isHttps ? 443 : 80),
      path: apiUrl.pathname + (apiUrl.search || ''),
      headers: { 'Content-Type': 'application/json' }
    };
    if(isHttps) opts.rejectUnauthorized = false;
    // If you need token: opts.headers['Authorization'] = 'Bearer ...';
    if(DEBUG) log('[dbg] fetch', method, apiUrl.toString());
    const req = lib.request(opts, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if(res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
          try   { resolve(JSON.parse(data)); }
          catch { resolve({}); }
          if(DEBUG) log('[dbg] <-', data.trim().slice(0,100));
        } else {
          reject(new Error('HTTP '+res.statusCode));
        }
      });
    });
    req.setTimeout(5000, () => { req.destroy(); reject(new Error('timeout')); });
    req.on('error', err => { if(DEBUG) log('[dbg] fetch error', err.message); reject(err); });
    if(body) req.write(JSON.stringify(body));
    req.end();
  });
}

/* -- backend-driven: discover tunnels and keep them in sync ----------- */
async function syncTunnels() {
  try {
    const tunnels = (await fetchAPI('/api/tunnels')).tunnels || [];
  dbg("sync got", tunnels.length, "tunnels");
    // Remove obsolete listeners
    for(const [port, o] of maps)
      if(!tunnels.find(t => t.port == port)) { if(DEBUG) log('[dbg] remove', port); o.server.close(); maps.delete(port); }
    // Add/refresh listeners
    for(const t of tunnels) {
      if(!maps.has(t.port)) {
        dbg('add tunnel', t.device_key, t.port, t.service, 'local', t.local_port);
        addBackendTunnel(t.device_key, t.port, t.local_port, t.service);
      }
    }
  } catch(e) { log('[err] syncTunnels', e.message); }
}
setInterval(syncTunnels, 4000);
syncTunnels();

/* -- listen public port, bind to agent (deviceKey) -------------------- */
function addBackendTunnel(deviceKey, pubPort, localPort=22, service='ssh') {
  if(maps.has(pubPort)) return;
  let local = localPort;
  dbg('listen', deviceKey, '->', pubPort, 'service', service, 'local', local);

  const srv = net.createServer(sock => {
    const id = Math.floor(Math.random()*1e6);
    conns.set(id, sock);
    log(`[map] stream ${id} ext:${sock.remoteAddress}:${pubPort} ? device:${deviceKey} local:${local}`);

    const agentSock = agents.get(deviceKey);
    if(agentSock) {
      const pl=Buffer.alloc(2); pl.writeUInt16BE(local);
      dbg('send N', deviceKey, id, 'local', local);
      safeWrite(agentSock, frame('N',id,pl));
      sock.on('data', d => safeWrite(agentSock, frame('D',id,d)));
      sock.on('close',()=>{ safeWrite(agentSock, frame('C',id)); conns.delete(id); });
    } else {
      log(`[err] no agent for deviceKey ${deviceKey}`);
      sock.destroy();
    }
  })
  .on('error', err => log('[err] listener', err))
  .on('listening', () => {
    maps.set(pubPort, { localPort: local, server: srv, deviceKey, service });
    log(`[map] device ${deviceKey} public ${pubPort} (ready)`);
  });

  srv.listen(pubPort);
}

/* -- control socket (agent <=> proxy) --------------------------------- */
net.createServer(sock=>{
  log('[ygs] agent connected',sock.remoteAddress);
  sock.once('data',first=>{
    let hello;
    try { hello = JSON.parse(first.toString()); } catch { hello = {token:first.toString().trim(),name:''}; }
    if(hello.token!==TOKEN){ log('[auth] failed'); sock.destroy(); return; }
    const deviceKey = hello.name||'unknown';
    log('[ygs] agent authenticated',deviceKey);
    agents.set(deviceKey, sock);

    let buf = Buffer.alloc(0);

    sock.on('data', chunk => {
      buf = Buffer.concat([buf, chunk]);
      while (buf.length >= 9) {
        const t   = String.fromCharCode(buf[0]),
              id  = buf.readUInt32BE(1),
              len = buf.readUInt32BE(5);
        if (buf.length < 9 + len) break;
        const payload = buf.subarray(9, 9 + len);
        buf = buf.subarray(9 + len);

        if (t === 'N') {
          const lp = payload.readUInt16BE(0);
          dbg('recv N', deviceKey, id, 'local', lp);
          const s  = net.connect(lp, '127.0.0.1');
          conns.set(id, s);
          s.on('data', d => safeWrite(sock, frame('D', id, d)));
          s.on('close', () => { safeWrite(sock, frame('C', id)); conns.delete(id); });
        }
        else if (t === 'D') {
          dbg('recv D', deviceKey, id, payload.length);
          conns.get(id)?.write(payload);
        }
        else if (t === 'C') {
          dbg('recv C', deviceKey, id);
          conns.get(id)?.destroy(); conns.delete(id);
        }
      }
    });

    sock.on('close',()=>{ log('[ygs] agent disconnected',deviceKey); agents.delete(deviceKey); });
  });
}).listen(CTRL_PORT,()=>log('[ygs] waiting agent on',CTRL_PORT));

/* -- Web UI  ---------------------------------------------------------- */
const UI_FILE_CANDIDATES = [
  process.env.YGS_PROXY_UI,
  new URL('../../admin/proxy_ui.php', import.meta.url).pathname,
  '/usr/local/share/ygs/admin/proxy_ui.php'
];
let PAGE = '';
for (const p of UI_FILE_CANDIDATES) {
  if (p && fs.existsSync(p)) { PAGE = fs.readFileSync(p, 'utf8'); break; }
}
if(!PAGE) PAGE = '<h1>YGS Proxy</h1><p>UI missing</p>';

async function getHeartbeat(deviceKey) {
  try {
    const d = await fetchAPI('/api/devices/' + deviceKey + '/availability');
    return d.last_heartbeat || '–';
  } catch { return '–'; }
}
const state = async () => {
  // Pour perf, on peut batcher l’appel ou le cacher, ici naïf (1 appel par deviceKey)
  const arr = [...maps].map(async ([pub, o])=>{
    // "stream" = true si stream(s) ouvert(s) sur ce port
    const isStream = [...conns.values()].some(sock=>sock.remotePort==pub);
    const heartbeat = await getHeartbeat(o.deviceKey);
    return {
      pub,
      local:o.localPort,
      deviceKey:o.deviceKey,
      stream:isStream,
      heartbeat
    };
  });
  const mapsArr = await Promise.all(arr);
  return {
    agent:true,
    maps:mapsArr,
    logs:logBuf
  };
};

http.createServer(async (req,res)=>{
  if(UI_USER){
    const h=req.headers['authorization']||'';
    const b=h.startsWith('Basic ')?h.slice(6):'';
    const [u,p]=Buffer.from(b,'base64').toString().split(':');
    if(u!==UI_USER||p!==UI_PASS){
      res.writeHead(401,{"WWW-Authenticate":"Basic realm=\"ygs-proxy\""});
      return res.end('Auth required');
    }
  }
  const p=url.parse(req.url).pathname;
  if(p==='/'||p==='/index.html') return res.end(PAGE);
  if(p==='/state') {
    const s = await state();
    return res.end(JSON.stringify(s));
  }
  res.writeHead(404).end();
}).listen(UI_PORT,()=>log('[ui] http://localhost:'+UI_PORT));
