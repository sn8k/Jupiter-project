#!/usr/bin/env node
/*
-------------------------------------------------------------------------------
  ntp-server

  • Version  : 1.0.0 (2025-06-19)
  • Simple NTP server for Meeting devices
-------------------------------------------------------------------------------
*/
import dgram from 'node:dgram';
import fs from 'node:fs';
import path from 'node:path';

const PORT = process.env.NTP_PORT ? parseInt(process.env.NTP_PORT,10) : 123;
const LOG_FILE = process.env.NTP_LOG || '/var/meeting/api/logs/ntp_server.log';

function ensureLogDir(file){
  fs.mkdirSync(path.dirname(file), { recursive: true });
}
ensureLogDir(LOG_FILE);

const server = dgram.createSocket('udp4');
const EPOCH = 2208988800; // seconds between 1900 and 1970

function ntpBuffer(){
  const now = Date.now();
  const seconds = Math.floor(now/1000) + EPOCH;
  const fraction = Math.floor(((now % 1000) / 1000) * 2 ** 32);
  const buf = Buffer.alloc(48);
  buf[0] = 0x1c; // LI=0, Version=3, Mode=4
  buf.writeUInt32BE(seconds, 40);
  buf.writeUInt32BE(fraction,44);
  return buf;
}

function log(line){
  fs.appendFile(LOG_FILE, new Date().toISOString()+" "+line+"\n", ()=>{});
}

server.on('message',(msg,rinfo)=>{
  const resp = ntpBuffer();
  server.send(resp, rinfo.port, rinfo.address);
  log(`${rinfo.address}:${rinfo.port}`);
});

server.on('listening',()=>{
  const addr = server.address();
  console.log(`NTP server listening on udp://${addr.address}:${addr.port}`);
  log(`server started on port ${addr.port}`);
});

server.on('error',err=>{
  log(`ERROR ${err.message}`);
});

server.bind(PORT);
