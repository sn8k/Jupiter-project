# YGS-Agent for Windows

YGS-Agent is a lightweight background agent for **Meeting remote access infrastructure**, supporting **SSH/HTTP/VNC relays** and secure device onboarding for Windows systems.

---

## Features

- **First-launch wizard**: Accepts *either* a serial or a device_key
- **Automatic device_key resolution** if you enter a serial
- **Token enrollment/burn**: One-time token validation/registration with backend
- **SSH key management**: Ensures `id_ed25519` exists (auto-generates if needed)
- **Automatic SSH key upload**: Public key is sent to the backend after generation
- **Persistent config and device info**: All files in `C:\ProgramData\YGS-Agent\`
- **Heartbeat**: Device presence status posted every 60s
- **Multiplexed tunnel**: Persistent, authenticated binary TCP connection to proxy
- **Extensive logging**: All actions, failures, and setup steps logged to `ygs-agent.log`

---

## Quick Start

1. **Requirements**
    - Windows 10+ (admin rights for first setup recommended)
    - .NET 6+ (SDK or runtime)
    - `ssh-keygen.exe` available (`OpenSSH` or `Git for Windows`)
2. **Build or download** the binary
3. **Run** `YgsAgent.exe` (or `dotnet run` in source)
4. **At first launch:**
    - Enter either the device serial (ex: `V1-S01-00030`) or the full device_key (hex string)
    - Enter the provided enrollment token (one-time use)
5. Agent will:
    - Resolve serial to device_key if needed
    - Register ("burn") the token with the backend (`/flash-request`)
    - Save config and device info
    - Generate SSH key if absent
    - Upload the SSH public key automatically
    - Start heartbeat and tunnel loop

All activity is logged to:
C:\ProgramData\YGS-Agent\ygs-agent.log

---

## Files/Locations

| File                      | Purpose                         |
|---------------------------|---------------------------------|
| config.json               | Agent configuration             |
| device_info.json          | Stores device_key               |
| ygs-agent.log             | Log file (all events/errors)    |
| .ssh/id_ed25519*          | Device SSH keypair              |

---

## Troubleshooting

- **If you see:**  
  `ERREUR: Impossible de résoudre le numéro de série ... (code HTTP: NotFound)`  
  → Your serial does not exist in the backend, or API unreachable.
- **Agent won’t start?**  
  Check `ygs-agent.log` for error details.
- **No SSH key generated?**  
  Ensure `ssh-keygen.exe` is installed (part of OpenSSH or Git for Windows).

---

## Roadmap & Dev

- [x] SSH key upload to backend
- [ ] Windows service mode
- [ ] Advanced config and command-line options
- [ ] More REST endpoints and status monitoring

---

**See `AGENTS.md` for AI/codex or developer integration notes.**