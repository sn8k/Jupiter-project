// Program.cs -- YGS-Agent for Windows -- Version 0.3.5 (null safe, robust logging, serial/device_key compatible)
// Toutes les valeurs potentiellement nulles sont protégées. Prêt pour prod !

using System;
using System.IO;
using System.Text.Json;
using System.Net.Http;
using System.Diagnostics;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Concurrent;

class YgsAgentConfig
{
    public string ServerHost { get; set; } = "meeting.ygsoft.fr";
    public int ServerPort { get; set; } = 9001;
    public string ServerProtocol { get; set; } = "https";
    public string Token { get; set; } = "ChangeMe";
    public int HeartbeatMs { get; set; } = 60000;
    public string PubKeyFile { get; set; } = "";
    public string DeviceInfoFile { get; set; } = "";
    public string LogFile { get; set; } = "";
    public int LocalPort { get; set; } = 22;
    public int ReconnectDelayMs { get; set; } = 5000;
}

class Program
{
    static string ProgramData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
    static string UserProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
    static string AgentDir = Path.Combine(ProgramData, "YGS-Agent");
    static string SshDir = Path.Combine(UserProfile, ".ssh");

    static string ConfigPath = Path.Combine(AgentDir, "config.json");
    static string InfoPath = Path.Combine(AgentDir, "device_info.json");
    static string LogPath = Path.Combine(AgentDir, "ygs-agent.log");
    static string PubKeyPath = Path.Combine(SshDir, "id_ed25519.pub");
    static string PrivKeyPath = Path.Combine(SshDir, "id_ed25519");

    static YgsAgentConfig config = new YgsAgentConfig();
    static ConcurrentDictionary<int, TcpClient> localStreams = new ConcurrentDictionary<int, TcpClient>();
    static CancellationTokenSource cancelTunnel = new CancellationTokenSource();

    static void LogEarly(string msg)
    {
        try
        {
            Directory.CreateDirectory(AgentDir);
            var line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + msg;
            File.AppendAllText(LogPath, line + Environment.NewLine);
        }
        catch { }
    }

    static async Task Main(string[] args)
    {
        Directory.CreateDirectory(AgentDir);
        Directory.CreateDirectory(SshDir);

        // === Setup interactif si fichiers absents ===
        bool firstSetup = false;
        if (!File.Exists(ConfigPath) || !File.Exists(InfoPath))
        {
            firstSetup = true;
            Console.WriteLine("\n=== YGS-Agent Setup ===");
            Console.WriteLine("Configuration initiale requise.\n");

            // Demande SN ou device_key
            string snOrKey = "";
            do
            {
                Console.Write("Entrez le numéro de série (serial) OU la device_key : ");
                snOrKey = (Console.ReadLine() ?? "").Trim();
            } while (string.IsNullOrWhiteSpace(snOrKey));

            // Résolution du serial en device_key si besoin
            string deviceKey = snOrKey;
            if (!IsLikelyDeviceKey(snOrKey))
            {
                try
                {
                    using (var client = new HttpClient())
                    {
                        string url = $"https://meeting.ygsoft.fr/api/devices/by-serial/{snOrKey}";
                        var resp = client.GetAsync(url).Result;
                        if (!resp.IsSuccessStatusCode)
                        {
                            string errmsg = $"ERREUR: Impossible de résoudre le numéro de série '{snOrKey}' (code HTTP: {resp.StatusCode})";
                            LogEarly(errmsg);
                            Console.WriteLine("\n" + errmsg);
                            Environment.Exit(1);
                        }
                        var json = resp.Content.ReadAsStringAsync().Result ?? "";
                        using (JsonDocument doc = JsonDocument.Parse(json))
                        {
                            if (doc.RootElement.TryGetProperty("device_key", out var dk))
                            {
                                deviceKey = dk.GetString() ?? "";
                                Console.WriteLine($"Numéro de série reconnu ! Device Key = {deviceKey}");
                                LogEarly($"Numéro de série '{snOrKey}' reconnu -> device_key {deviceKey}");
                            }
                            else
                            {
                                string errmsg = "ERREUR: device_key introuvable dans la réponse API.";
                                LogEarly(errmsg);
                                Console.WriteLine("\n" + errmsg);
                                Environment.Exit(1);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    string errmsg = "ERREUR: Echec lors de la résolution du numéro de série : " + (ex.Message ?? "");
                    LogEarly(errmsg);
                    Console.WriteLine("\n" + errmsg);
                    Environment.Exit(1);
                }
            }

            // Demande token
            string token = "";
            do
            {
                Console.Write("Entrez le token d'enrôlement du device (fourni par l'admin) : ");
                token = (Console.ReadLine() ?? "").Trim();
            } while (string.IsNullOrWhiteSpace(token));

            // Brûler le token (POST /flash-request)
            try
            {
                using (var client = new HttpClient())
                {
                    string url = $"https://meeting.ygsoft.fr/api/devices/{deviceKey}/flash-request";
                    var content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json");
                    var resp = client.PostAsync(url, content).Result;
                    if (!resp.IsSuccessStatusCode)
                    {
                        string errmsg = $"ERREUR: Impossible d'enregistrer le device, code HTTP: {resp.StatusCode}";
                        LogEarly(errmsg);
                        Console.WriteLine("\n" + errmsg);
                        Console.WriteLine("Le token est peut-être déjà utilisé, incorrect ou le device non autorisé.");
                        Environment.Exit(1);
                    }
                    else
                    {
                        string msg = "Device enrôlé avec succès (token brûlé).";
                        LogEarly(msg);
                        Console.WriteLine(msg + "\n");
                    }
                }
            }
            catch (Exception ex)
            {
                string errmsg = "ERREUR: Echec lors de la requête d'enrôlement: " + (ex.Message ?? "");
                LogEarly(errmsg);
                Console.WriteLine("\n" + errmsg);
                Environment.Exit(1);
            }

            // Crée device_info.json (toujours device_key, jamais serial)
            var deviceInfo = $"{{\n  \"device_key\": \"{deviceKey}\"\n}}";
            File.WriteAllText(InfoPath, deviceInfo);

            // Crée config.json minimal avec token
            var configInit = new YgsAgentConfig
            {
                Token = token,
                PubKeyFile = PubKeyPath,
                DeviceInfoFile = InfoPath,
                LogFile = LogPath
            };
            File.WriteAllText(ConfigPath, JsonSerializer.Serialize(configInit, new JsonSerializerOptions { WriteIndented = true }));

            string okmsg = "Configuration enregistrée avec succès !";
            LogEarly(okmsg);
            Console.WriteLine(okmsg + "\n");
        }

        // 1. Charger la config
        config = LoadConfig();
        config.PubKeyFile = PubKeyPath;
        config.DeviceInfoFile = InfoPath;
        config.LogFile = LogPath;
        SaveConfig();

        // 2. S’assurer que la clé SSH existe puis l'envoyer au backend
        bool keyGenerated = EnsureLocalKey();
        if (firstSetup || keyGenerated)
            await UploadSshKeyAsync();

        // 3. Heartbeat (tâche en arrière-plan)
        _ = Task.Run(() => HeartbeatLoop(), cancelTunnel.Token);

        // 4. Main tunnel (connexion persistante proxy)
        while (true)
        {
            try
            {
                await RunTunnelProxy(cancelTunnel.Token);
            }
            catch (Exception ex)
            {
                Log("Erreur tunnel : " + (ex.Message ?? ""));
            }
            Log($"Reconnexion dans {config.ReconnectDelayMs / 1000}s ...");
            await Task.Delay(config.ReconnectDelayMs);
        }
    }

    static bool IsLikelyDeviceKey(string s)
    {
        return !string.IsNullOrWhiteSpace(s) && s.Length >= 16 && s.Length <= 40 && System.Text.RegularExpressions.Regex.IsMatch(s, "^[A-Fa-f0-9]+$");
    }

    static YgsAgentConfig LoadConfig()
    {
        try
        {
            if (File.Exists(ConfigPath))
                return JsonSerializer.Deserialize<YgsAgentConfig>(File.ReadAllText(ConfigPath)) ?? new YgsAgentConfig();
        }
        catch { }
        return new YgsAgentConfig();
    }

    static void SaveConfig()
    {
        File.WriteAllText(ConfigPath, JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true }));
    }

    static bool EnsureLocalKey()
    {
        if (File.Exists(PubKeyPath) && File.Exists(PrivKeyPath))
            return false;
        try
        {
            Log("Génération de clé SSH (id_ed25519)...");
            var psi = new ProcessStartInfo("ssh-keygen.exe", $"-t ed25519 -N \"\" -C \"ygs-agent\" -f \"{PrivKeyPath}\"")
            {
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false
            };
            var proc = Process.Start(psi);
            proc.WaitForExit();
            Log("Clé SSH générée avec succès.");
            return true;
        }
        catch (Exception ex)
        {
            Log("Erreur génération clé SSH : " + (ex.Message ?? ""));
            Console.WriteLine("ERREUR : ssh-keygen.exe introuvable. Installe OpenSSH ou Git for Windows.");
            Environment.Exit(1);
        }
        return false; // unreachable
    }

    static async Task UploadSshKeyAsync()
    {
        string deviceKey = LoadDeviceKey();
        if (string.IsNullOrWhiteSpace(deviceKey) || !File.Exists(PubKeyPath))
        {
            Log("Impossible d'envoyer la clé SSH (device_key ou fichier manquant).");
            return;
        }
        try
        {
            using var client = new HttpClient();
            string pub = File.ReadAllText(PubKeyPath);
            string url = $"{config.ServerProtocol}://{config.ServerHost}/api/devices/{deviceKey}/ssh-key";
            var content = new StringContent("{\"pubkey\":\"" + pub.Replace("\"","\\\"") + "\"}", System.Text.Encoding.UTF8, "application/json");
            var resp = await client.PutAsync(url, content);
            Log($"Envoi clé SSH : {resp.StatusCode}");
        }
        catch (Exception ex)
        {
            Log("Erreur envoi clé SSH : " + (ex.Message ?? ""));
        }
    }

    static async Task HeartbeatLoop()
    {
        while (!cancelTunnel.Token.IsCancellationRequested)
        {
            await SendHeartbeat();
            await Task.Delay(config.HeartbeatMs, cancelTunnel.Token);
        }
    }

    static async Task SendHeartbeat()
    {
        string deviceKey = LoadDeviceKey();
        if (string.IsNullOrWhiteSpace(deviceKey))
        {
            Log("device_key non trouvé, skip heartbeat.");
            return;
        }

        using (var client = new HttpClient())
        {
            try
            {
                string url = $"{config.ServerProtocol}://{config.ServerHost}/api/devices/{deviceKey}/online";
                var content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json");
                var resp = await client.PostAsync(url, content);
                Log("Heartbeat POST : " + resp.StatusCode);
            }
            catch (Exception ex)
            {
                Log("Erreur heartbeat : " + (ex.Message ?? ""));
            }
        }
    }

    static string LoadDeviceKey()
    {
        try
        {
            if (File.Exists(InfoPath))
            {
                var json = JsonSerializer.Deserialize<JsonElement>(File.ReadAllText(InfoPath));
                if (json.TryGetProperty("device_key", out var devKey))
                    return devKey.GetString() ?? "";
            }
        }
        catch { }
        return ""; // jamais null
    }

    static void Log(string msg)
    {
        var line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + msg;
        Console.WriteLine(line);
        try { File.AppendAllText(LogPath, line + Environment.NewLine); } catch { }
    }

    // === Tunnel TCP proxy principal ===
    static async Task RunTunnelProxy(CancellationToken ct)
    {
        string deviceKey = LoadDeviceKey();
        if (string.IsNullOrWhiteSpace(deviceKey))
        {
            Log("device_key non trouvé, tunnel non démarré.");
            await Task.Delay(5000, ct);
            return;
        }
        Log($"[tunnel] Connexion à {config.ServerHost}:{config.ServerPort} ...");

        using (TcpClient proxy = new TcpClient())
        {
            await proxy.ConnectAsync(config.ServerHost, config.ServerPort, ct);
            Log("[tunnel] Connecté au proxy.");

            using (var stream = proxy.GetStream())
            {
                // 1. Handshake JSON {token, name}
                var hello = $"{{\"token\":\"{config.Token}\",\"name\":\"{deviceKey}\"}}\n";
                var helloBytes = System.Text.Encoding.UTF8.GetBytes(hello);
                Log("[debug] Handshake envoyé : " + hello.Replace("\n", "\\n"));
                await stream.WriteAsync(helloBytes, 0, helloBytes.Length, ct);

                Log("[tunnel] Handshake envoyé.");

                var buffer = new byte[65536];
                var mem = new MemoryStream();

                // 2. Main loop (lecture frames binaires)
                while (!ct.IsCancellationRequested)
                {
                    // Lecture pour au moins 9 bytes (header frame)
                    while (mem.Length < 9)
                    {
                        int n = await stream.ReadAsync(buffer, 0, buffer.Length, ct);
                        if (n == 0) throw new IOException("Socket fermée par le proxy");
                        mem.Write(buffer, 0, n);
                    }
                    mem.Position = 0;
                    var header = new byte[9];
                    mem.Read(header, 0, 9);
                    char frameType = (char)header[0];
                    int streamId = BitConverter.ToInt32(header, 1);     // BE → LE à la main
                    streamId = System.Net.IPAddress.NetworkToHostOrder(streamId);
                    int payloadLen = BitConverter.ToInt32(header, 5);
                    payloadLen = System.Net.IPAddress.NetworkToHostOrder(payloadLen);

                    // Lire le reste du payload si besoin
                    int bytesLeft = payloadLen;
                    var payload = new byte[payloadLen];
                    int offset = 0;
                    while (bytesLeft > 0)
                    {
                        int n = await stream.ReadAsync(payload, offset, bytesLeft, ct);
                        if (n == 0) throw new IOException("Socket fermée par le proxy (payload)");
                        offset += n;
                        bytesLeft -= n;
                    }
                    // Reste du buffer
                    long remaining = mem.Length - mem.Position;
                    if (remaining > 0)
                    {
                        var left = new byte[remaining];
                        mem.Read(left, 0, (int)remaining);
                        mem = new MemoryStream();
                        mem.Write(left, 0, left.Length);
                    }
                    else
                        mem = new MemoryStream();

                    // === Gestion des frames ===
                    if (frameType == 'N')
                    {
                        // Demande d'ouverture de flux local (ex: SSH)
                        int localPort = (payload.Length >= 2) ? (payload[0] << 8) + payload[1] : config.LocalPort;
                        Log($"[tunnel] New stream id={streamId}, port={localPort}");
                        _ = HandleLocalStreamAsync(stream, streamId, localPort, ct);
                    }
                    else if (frameType == 'D')
                    {
                        // Data vers le flux local
                        if (localStreams.TryGetValue(streamId, out var cli) && cli.Connected)
                        {
                            try
                            {
                                cli.GetStream().Write(payload, 0, payload.Length);
                            }
                            catch (Exception ex)
                            {
                                Log($"[tunnel] Write failed stream {streamId}: " + (ex.Message ?? ""));
                            }
                        }
                    }
                    else if (frameType == 'C')
                    {
                        // Close stream
                        if (localStreams.TryRemove(streamId, out var cli))
                        {
                            try { cli.Close(); } catch { }
                            Log($"[tunnel] Close stream id={streamId}");
                        }
                    }
                }
            }
        }
    }

    static async Task HandleLocalStreamAsync(NetworkStream proxyStream, int streamId, int port, CancellationToken ct)
    {
        TcpClient local = new TcpClient();
        try
        {
            await local.ConnectAsync("127.0.0.1", port, ct);
            Log($"[local] Connecté à localhost:{port} pour stream {streamId}");
            localStreams[streamId] = local;
            var buf = new byte[65536];
            var ns = local.GetStream();

            // Dès qu'on reçoit des données, on wrappe dans une frame D et renvoie au proxy
            while (!ct.IsCancellationRequested && local.Connected)
            {
                int n = await ns.ReadAsync(buf, 0, buf.Length, ct);
                if (n == 0) break;
                // Frame : 1 byte type, 4 bytes id, 4 bytes length, payload
                byte[] frame = new byte[9 + n];
                frame[0] = (byte)'D';
                var sid = BitConverter.GetBytes(System.Net.IPAddress.HostToNetworkOrder(streamId));
                var plen = BitConverter.GetBytes(System.Net.IPAddress.HostToNetworkOrder(n));
                Array.Copy(sid, 0, frame, 1, 4);
                Array.Copy(plen, 0, frame, 5, 4);
                Array.Copy(buf, 0, frame, 9, n);
                await proxyStream.WriteAsync(frame, 0, frame.Length, ct);
            }
        }
        catch (Exception ex)
        {
            Log($"[local] Erreur stream {streamId}: " + (ex.Message ?? ""));
        }
        finally
        {
            if (localStreams.TryRemove(streamId, out var oldCli))
            {
                try { oldCli.Close(); } catch { }
            }
            // Send frame C (close) au proxy
            byte[] closeFrame = new byte[9];
            closeFrame[0] = (byte)'C';
            var sid = BitConverter.GetBytes(System.Net.IPAddress.HostToNetworkOrder(streamId));
            Array.Copy(sid, 0, closeFrame, 1, 4);
            Array.Copy(new byte[4], 0, closeFrame, 5, 4); // length = 0
            try { await proxyStream.WriteAsync(closeFrame, 0, closeFrame.Length, ct); } catch { }
        }
    }
}
