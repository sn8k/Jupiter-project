# YGS-Agent for Windows — Developer/AI Codex Brief

## Purpose

YGS-Agent is a **background process (daemon/service)** allowing a Windows device to connect to the Meeting proxy infrastructure for secure, authenticated, multiplexed remote access (SSH, HTTP, VNC, etc.), with automated provisioning and reporting.

---

## Core Features

- **Initial provisioning wizard**: Accepts *either* a device serial (e.g., `V1-S01-00030`) or a full `device_key` (hex).
- **Serial resolution**: If a serial is provided, agent resolves it to a device_key via the API (`GET /api/devices/by-serial/{serial}`).
- **Token burn**: Agent "burns" (consumes) the enrollment token by POSTing to `/api/devices/{device_key}/flash-request` before any config is written.
- **Persistent config**: Writes `config.json` and `device_info.json` into `C:\ProgramData\YGS-Agent\`.
- **SSH key management**: Ensures a local Ed25519 SSH keypair exists (`C:\Users\USERNAME\.ssh\id_ed25519*`). If missing, generates using `ssh-keygen`.
- **Heartbeat**: Regular POST every 60s (default) to `/api/devices/{device_key}/online`.
- **Tunnel multiplexing**: Persistent TCP connection to the Meeting proxy (`meeting.ygsoft.fr:9001`), with custom binary protocol for multi-stream relays.
- **Full logging**: All errors, state changes, and fatal events are logged to `ygs-agent.log` *from the very first execution*, even if setup fails.

---

## Protocols and API

### REST API Endpoints Used

- `GET /api/devices/by-serial/{serial}` → resolve serial to device_key
- `POST /api/devices/{device_key}/flash-request` → burn enrollment token (may require token in header or body)
- `POST /api/devices/{device_key}/online` → heartbeat, signals device presence
- (Multiplexed tunnel, see below)

### Tunnel Handshake (TCP, binary)

- Agent connects to `meeting.ygsoft.fr:9001`
- Sends: `{"token":"<TOKEN>","name":"<DEVICE_KEY>"}\n` as UTF-8
- Receives and processes custom binary frames:
    - `N` (New stream): opens local TCP socket to requested port
    - `D` (Data): relays data to/from local stream
    - `C` (Close): closes local stream

See agent code for full protocol implementation.

---

## Code Conventions

- All code must be null-safe (`?? ""` for any potential null value)
- Any fatal error or exception is both **logged** and **displayed**
- `device_info.json` always contains a valid device_key, *never* just a serial
- The agent must never proceed if provisioning fails (API unreachable, invalid serial/token, etc.)

---

## File Locations

- `C:\ProgramData\YGS-Agent\config.json`
- `C:\ProgramData\YGS-Agent\device_info.json`
- `C:\ProgramData\YGS-Agent\ygs-agent.log`
- `C:\Users\<user>\.ssh\id_ed25519`, `id_ed25519.pub` (SSH keys)

---

## Project Goals for Future Devs/AI

- Add SSH public key upload to backend
- Add advanced status REST endpoints (for maintenance and control)
- Port to run as a real Windows Service (use [node-windows](https://github.com/coreybutler/node-windows) style or .NET native)
- Add optional config reload/watch and CLI flags
- Enable port mapping for additional service types (not just SSH)
- Full test coverage for error/failure scenarios
