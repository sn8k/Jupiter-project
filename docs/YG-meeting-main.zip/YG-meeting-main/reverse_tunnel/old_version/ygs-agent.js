#!/usr/bin/env node
/*
───────────────────────────────────────────────────────────────────────────────
  ygs-agent

  • Expected location & filename : /usr/local/bin/ygs-agent
  • Version                     : 1.2.1   (2025-06-10)
───────────────────────────────────────────────────────────────────────────────
  Lightweight TCP tunnel agent with:

   – Automatic server reconnection & periodic “port refresh”.
   – Zero-dependency dark-mode Web UI (default http://<device>:3000/).
   – Live status, last logs, and on-the-fly configuration editing.
   – Persistent JSON config (auto-created on first start).
───────────────────────────────────────────────────────────────────────────────*/

import net    from 'node:net';
import fs     from 'node:fs';
import http   from 'node:http';
import https  from 'node:https';
import url    from 'node:url';
import events from 'node:events';

/* ── 1 | persistent configuration ─────────────────────────────────────── */
const CFG_FILE = new URL('./config.json', import.meta.url).pathname;
const INFO_FILE = '/etc/meeting/device_info.json';
const DEFAULTS = {
  serverHost     : 'meeting.ygsoft.fr',
  serverPort     : 9001,
  serverProtocol : 'https',       // "https" or "http"
  token          : 'ChangeMe',
  refreshMs      : 4 * 60 * 1000,  // 4 min
  reconnectDelay : 5000,           // 5 s
  uiPort         : 3000,
  uiUser         : '',
  uiPass         : '',
  heartbeatMs    : 60 * 1000          // 1 min
};

function loadCfg() {
  try   { return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(CFG_FILE, 'utf8')) }; }
  catch { return { ...DEFAULTS }; }                /* first run → defaults */
}
let cfg = loadCfg();
function saveCfg() { fs.writeFileSync(CFG_FILE, JSON.stringify(cfg, null, 2)); }

function loadInfo() {
  try   { return JSON.parse(fs.readFileSync(INFO_FILE, 'utf8')); }
  catch { return null; }
}
const deviceInfo = loadInfo();
const deviceKey  = deviceInfo?.device_key || null;

/* ── 2 | runtime state & helpers ─────────────────────────────────────── */
let ctrlSock        = null;                        /* control/data socket */
const locals        = new Map();                   /* id → local socket   */
const logStream     = new events.EventEmitter();   /* push logs to UI     */
const logBuffer     = [];                          /* last 40 lines       */
const log = (...msg) => {
  const line = new Date().toISOString() + ' ' + msg.join(' ');
  console.log(line);
  logBuffer.push(line); if (logBuffer.length > 40) logBuffer.shift();
  logStream.emit('line', line);
};
if(deviceKey) log('[cfg] device_key', deviceKey);
const safeWrite = (sock, buf) => { if (sock && !sock.destroyed && sock.writable) sock.write(buf); };
const frame = (type, id, payload = Buffer.alloc(0)) => {
  const b = Buffer.alloc(9 + payload.length);
  b[0] = type.charCodeAt(0);
  b.writeUInt32BE(id, 1);
  b.writeUInt32BE(payload.length, 5);
  payload.copy(b, 9);
  return b;
};

/* ── 3 | agent ↔ server connection & multiplexing ────────────────────── */
let reconnectTimer = null;
const scheduleReconnect = ms => { clearTimeout(reconnectTimer); reconnectTimer = setTimeout(connect, ms); };

function connect() {
  ctrlSock = net.connect(cfg.serverPort, cfg.serverHost, () => {
    const hello = JSON.stringify({token: cfg.token, name: deviceKey||''}) + '\n';
    safeWrite(ctrlSock, Buffer.from(hello));

    log('[ygs] connected to', cfg.serverHost, cfg.serverPort, 'as', deviceKey||'?');
  });

  ctrlSock.on('error', err => {
    log('[err] ctrl', err.message);
    scheduleReconnect(cfg.reconnectDelay);
  });

  /* demultiplexer ------------------------------------------------------ */
  let buf = Buffer.alloc(0);
  ctrlSock.on('data', chunk => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 9) {
      const t   = String.fromCharCode(buf[0]),
            id  = buf.readUInt32BE(1),
            len = buf.readUInt32BE(5);
      if (buf.length < 9 + len) break;
      const payload = buf.subarray(9, 9 + len);
      buf = buf.subarray(9 + len);

      if (t === 'N') {                                   /* new stream */
        const lp = payload.readUInt16BE(0);
        const s  = net.connect(lp, '127.0.0.1');
        locals.set(id, s);
        log(`[==] stream ${id} → localhost:${lp}`);

        s.on('error', err => log('[err] stream', id, err.message));

        s.on('data', d => safeWrite(ctrlSock, frame('D', id, d)));
        s.on('close', () => { safeWrite(ctrlSock, frame('C', id)); locals.delete(id); });
      }
      else if (t === 'D')  locals.get(id)?.write(payload);
      else if (t === 'C') { locals.get(id)?.destroy(); locals.delete(id); }
    }
  });

  ctrlSock.on('close', () => {
    log('[ygs] disconnected');
    for (const s of locals.values()) s.destroy();
    locals.clear();
    scheduleReconnect(cfg.reconnectDelay);
  });
}

/* ── 4 | periodic “port refresh” ─────────────────────────────────────── */
let refreshTimer;
function resetRefreshTimer() {
  clearInterval(refreshTimer);
  refreshTimer = setInterval(() => {
    if (locals.size === 0 && ctrlSock && !ctrlSock.destroyed) {
      log('[ygs] refresh — no active streams, reconnecting');
      clearInterval(refreshTimer);           /* pause until next connect */
      ctrlSock.end();                        /* triggers reconnect flow  */
    }
  }, cfg.refreshMs);
}
resetRefreshTimer();

/* ── 5 | heartbeat to backend (universal HTTP/HTTPS) ────────────────── */
function sendHeartbeat() {
  if (!deviceKey) return;
  const payload = JSON.stringify({});
  const proto = (cfg.serverProtocol && cfg.serverProtocol.toLowerCase() === 'https') ? https : http;
  const port  = (cfg.serverProtocol && cfg.serverProtocol.toLowerCase() === 'https')
                  ? 443
                  : 80;

  const opts = {
    method: 'POST',
    hostname: cfg.serverHost,
    port: port,
    path: `/api/devices/${deviceKey}/online`,
    headers: {'Content-Type':'application/json','Content-Length': Buffer.byteLength(payload)}
  };

  const req = proto.request(opts, res => { res.resume(); });
  log('[hb] POST', opts.path, `(${cfg.serverProtocol||'https'}:${opts.port})`);
  req.on('error', e => log('[err] heartbeat', e.message));
  req.write(payload);
  req.end();
}
let hbTimer = setInterval(sendHeartbeat, cfg.heartbeatMs);
sendHeartbeat();

/* ── 6 | minimal dark-mode Web UI ────────────────────────────────────── */
const HTML = /*html*/`<!DOCTYPE html><meta charset=utf8>
<title>YGS Agent</title>
<style>
:root{color-scheme:dark;font-family:system-ui}
body{background:#111;color:#eee;margin:0;display:grid;place-content:center;height:100vh;text-align:center}
section{background:#1a1a1a;border:1px solid #444;padding:2rem 3rem;border-radius:12px;min-width:26rem}
h1{margin:0 0 .5em;font-size:2rem}label{display:block;margin:.6em 0 .2em}
input{width:100%;padding:.45em;border-radius:6px;border:1px solid #555;background:#222;color:#eee}
button{margin-top:1em;padding:.55em 1.4em;border:none;border-radius:6px;background:#0a84ff;color:#fff;font-weight:600}
pre{background:#0003;padding:.6em;border-radius:8px;max-height:9em;overflow:auto;font-size:.82em;text-align:left}
small{color:#999;font-size:.8em}
</style>
<section>
<h1>YGS Agent</h1><div id=stat>…</div><hr>
<form id=cfg>
<label>Server host</label><input name=serverHost>
<label>Server port</label><input type=number name=serverPort>
<label>Server protocol</label><input name=serverProtocol>
<label>Token</label><input name=token>
<label>Refresh ms</label><input type=number name=refreshMs>
<label>Reconnect ms</label><input type=number name=reconnectDelay>
<label>Heartbeat ms</label><input type=number name=heartbeatMs>
<label>UI user</label><input name=uiUser>
<label>UI pass</label><input type=password name=uiPass>
<button>Save</button></form><hr><pre id=log>(logs)</pre>
<small>Press Ctrl-C to quit</small>
<script>
const $=q=>document.querySelector(q);
function load(){fetch('/config').then(r=>r.json()).then(c=>{for(const k in c)$('[name='+k+']').value=c[k];});}
$('#cfg').onsubmit=e=>{
  e.preventDefault();
  const d=Object.fromEntries(new FormData(e.target));
  for(const k in d){ if(!isNaN(d[k])) d[k]=Number(d[k]); }
  fetch('/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)})
    .then(load);
};
load();
const es=new EventSource('/sse');
es.onmessage=e=>{
  const s=JSON.parse(e.data);
  $('#stat').innerHTML=\`<b>\${s.connected?'🟢 online':'🔴 offline'}<\/b> — \${s.serverHost}:\${s.serverPort}
     <br>streams: \${s.actives} — refresh in \${Math.round(s.nextRefresh/1000)}s — heartbeat \${Math.round(s.heartbeatMs/1000)}s\`;
  $('#log').textContent=s.logs.join('\\n');
};
</script>
</section>`;
const status = () => ({
  connected   : ctrlSock && !ctrlSock.destroyed,
  serverHost  : cfg.serverHost, serverPort: cfg.serverPort,
  actives     : locals.size,
  nextRefresh : cfg.refreshMs - (Date.now() % cfg.refreshMs),
  heartbeatMs : cfg.heartbeatMs,
  serverProtocol : cfg.serverProtocol || 'https',
  deviceKey   : deviceKey,
  logs        : logBuffer
});
http.createServer((req,res)=>{
  if(cfg.uiUser){
    const h=req.headers['authorization']||'';
    const b=h.startsWith('Basic ')?h.slice(6):'';
    const [u,p]=Buffer.from(b,'base64').toString().split(':');
    if(u!==cfg.uiUser||p!==cfg.uiPass){
      res.writeHead(401,{"WWW-Authenticate":"Basic realm=\"ygs-agent\""});
      return res.end('Auth required');
    }
  }
  const p=url.parse(req.url).pathname;
  if (p==='/'||p==='/index.html') return res.end(HTML);

  if (p==='/config' && req.method==='GET')
    return res.end(JSON.stringify(cfg));

  if (p==='/config' && req.method==='POST'){
    let body=''; req.on('data',d=>body+=d).on('end',()=>{
      try { Object.assign(cfg, JSON.parse(body)); saveCfg(); resetRefreshTimer(); log('[cfg] updated'); }
      catch { return res.writeHead(400).end(); }
      res.writeHead(204).end();
    }); return;
  }

  if (p==='/sse'){
    res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive'});
    const send = () => res.write('data:'+JSON.stringify(status())+'\n\n');
    send();
    const listener = () => send();
    logStream.on('line', listener);
    req.on('close', () => logStream.off('line', listener));
    return;
  }

  res.writeHead(404).end();
}).listen(cfg.uiPort, ()=>log('[ui] http://localhost:'+cfg.uiPort));

/* ── 6 | startup ─────────────────────────────────────────────────────── */
saveCfg();                                  /* create file if missing */
log('[ygs] agent started – Web UI on port', cfg.uiPort);
connect();
