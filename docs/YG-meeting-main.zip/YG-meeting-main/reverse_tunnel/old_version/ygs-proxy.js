#!usr/bin/env node
/*
-------------------------------------------------------------------------------
  ygs-proxy

  • Expected location & filename : /usr/local/bin/ygs-proxy
  • Version                     : 1.1.1   (2025-06-10)
-------------------------------------------------------------------------------
  Public TCP proxy that pairs with *ygs-agent*:

   – Control socket on port 9001 (token-based auth).
   – Random public port (9050-9130) allocated per local service; retries if
     port already in use.
   – Dark-mode Web UI on http://<server>:9500/  (add / delete mappings live).
   – Robust against late socket events: every write toward the agent now
     passes through `safeWrite()` to avoid “Cannot read properties of null”.
-------------------------------------------------------------------------------*/

import net    from 'node:net';
import http   from 'node:http';
import url    from 'node:url';
import events from 'node:events';

/* -- constants --------------------------------------------------------- */
const CTRL_PORT = 9001;
const PORT_MIN  = 9050, PORT_MAX = 9130;
const UI_PORT   = 9500;
const TOKEN     = 'ChangeMe';
const UI_USER   = process.env.YGS_USER || '';
const UI_PASS   = process.env.YGS_PASS || '';

/* -- runtime state & helpers ------------------------------------------- */
let agentSock = null;
let agentName = '';
let nextID    = 1;

const conns   = new Map();               /* streamID ? pub socket      */
const maps    = new Map();               /* pubPort  ? {localPort,srv,name} */
const logBus  = new events.EventEmitter();
const logBuf  = [];
const log = (...a)=>{const l=new Date().toISOString()+' '+a.join(' ');
  console.log(l); logBuf.push(l); if(logBuf.length>80) logBuf.shift();
  logBus.emit('line',l);};

const safeWrite = (sock, buf)=>{
  if(sock && !sock.destroyed && sock.writable) sock.write(buf);
};

const frame = (t,id,p=Buffer.alloc(0))=>{
  const b=Buffer.alloc(9+p.length);
  b[0]=t.charCodeAt(0); b.writeUInt32BE(id,1);
  b.writeUInt32BE(p.length,5); p.copy(b,9); return b;
};

const pickPort = (blocked=new Set())=>{
  const pool=[]; for(let p=PORT_MIN;p<=PORT_MAX;p++)
    if(!maps.has(p)&&!blocked.has(p)) pool.push(p);
  return pool.length ? pool[Math.floor(Math.random()*pool.length)] : 0;
};

/* -- mapping management ----------------------------------------------- */
function addService(localPort){
  if(!agentSock){ log('[warn] agent not connected'); return; }
  const tried=new Set();
  let pub=pickPort(tried);
  if(!pub){ log('[warn] no free port'); return; }

  const srv=net.createServer(sock=>{
    const id=nextID++;
    conns.set(id,sock);
    log(`[map] stream ${id} ext:${sock.remoteAddress}:${pub} ? local:${localPort}`);

    const pl=Buffer.alloc(2); pl.writeUInt16BE(localPort);
    safeWrite(agentSock, frame('N',id,pl));

    sock.on('data',d=>safeWrite(agentSock, frame('D',id,d)));

    sock.on('close',()=>{
      safeWrite(agentSock, frame('C',id));
      conns.delete(id);
    });
  })
  .on('error',err=>{
    if(err.code==='EADDRINUSE'){
      log(`[warn] port ${pub} busy ? retry`);
      tried.add(pub); pub=pickPort(tried);
      if(!pub){ log('[warn] pool exhausted'); return; }
      srv.listen(pub);
    } else log('[err] listener',err);
  })
  .on('listening',()=>{
    maps.set(pub,{localPort,server:srv,name:agentName});
    log(`[map] device ${agentName} public ${pub} ? local ${localPort} (ready)`);
  });

  srv.listen(pub);
}

function delService(pubPort){
  const o=maps.get(pubPort);
  if(!o){ log('[warn] unknown',pubPort); return; }
  o.server.close(()=>{ maps.delete(pubPort); log('[map] removed',pubPort);});
}

/* -- control socket (agent) ------------------------------------------- */
net.createServer(sock=>{
  log('[ygs] agent connected',sock.remoteAddress);
  sock.once('data',first=>{
    let hello;
    try { hello = JSON.parse(first.toString()); } catch { hello = {token:first.toString().trim(),name:''}; }
    if(hello.token!==TOKEN){ log('[auth] failed'); sock.destroy(); return; }
    agentName=hello.name||'';
    log('[ygs] agent authenticated',agentName);
    agentSock=sock;

    /* demultiplex ------------------------------------------------------ */
    let acc=Buffer.alloc(0);
    sock.on('data',chunk=>{
      acc=Buffer.concat([acc,chunk]);
      while(acc.length>=9){
        const t=String.fromCharCode(acc[0]), id=acc.readUInt32BE(1),
              len=acc.readUInt32BE(5);
        if(acc.length<9+len) break;
        const data=acc.subarray(9,9+len); acc=acc.subarray(9+len);
        if(t==='D') conns.get(id)?.write(data);
        else if(t==='C'){ conns.get(id)?.destroy(); conns.delete(id); }
      }
    });

    sock.on('close',()=>{
      log('[ygs] agent disconnected',agentName);
      agentSock=null;
      for(const c of conns.values()) c.destroy(); conns.clear();
      for(const {server} of maps.values()) server.close(); maps.clear();
    });

    /* expose defaults -------------------------------------------------- */
    [22,80,5900].forEach(addService);
  });
}).listen(CTRL_PORT,()=>log('[ygs] waiting agent on',CTRL_PORT));

/* -- Web UI  ---------------------------------------------------------- */
const PAGE=/*html*/`<!DOCTYPE html><meta charset=utf8><title>YGS Proxy</title>
<style>:root{color-scheme:dark;font-family:system-ui}body{margin:0;background:#111;
color:#eee;display:grid;place-content:center;height:100vh;text-align:center}
section{background:#1a1a1a;border:1px solid #444;padding:2rem 3rem;border-radius:12px;min-width:32rem}
h1{font-size:2rem;margin:.1em 0 .5em}table{width:100%;border-collapse:collapse;margin:.6em 0}
th,td{padding:.4em;border-bottom:1px solid #333;text-align:center;font-size:.9em}
button{padding:.35em .8em;border:none;border-radius:6px;background:#0a84ff;color:#fff;cursor:pointer}
input{width:6rem;padding:.35em;border-radius:6px;border:1px solid #555;background:#222;color:#eee;text-align:center}
pre{background:#0003;padding:.6em;border-radius:8px;max-height:8em;overflow:auto;font-size:.8em;text-align:left}
small{color:#999;font-size:.8em}</style>
<section><h1>YGS Proxy</h1><div id=stat>…</div>
<table id=tbl><tr><th>Public</th><th>Local</th><th></th></tr></table>
<form id=f><input name=local type=number placeholder="local port"><button>Add</button></form>
<pre id=log>(logs)</pre><small>UI : port 9500</small>
<script>
const $=q=>document.querySelector(q);
function refresh(){fetch('/state').then(r=>r.json()).then(s=>{
  $('#stat').innerHTML=\`<b>\${s.agent?'🟢':'🔴'} \${s.name||'agent'}</b> – streams: \${s.streams}\`;
  $('#tbl').innerHTML='<tr><th>Public</th><th>Local</th><th></th></tr>'+
    s.maps.map(m=>\`<tr><td>\${m.pub}</td><td>\${m.name?m.name+':':''}\${m.local}</td><td><button data-p="\${m.pub}">del</button></td></tr>\`).join('');
  $('#log').textContent=s.logs.join('\\n');
});}
refresh(); setInterval(refresh,2000);
$('#tbl').onclick=e=>{if(e.target.dataset.p)fetch('/del/'+e.target.dataset.p,{method:'POST'}).then(refresh);};
$('#f').onsubmit=e=>{e.preventDefault();const lp=$('[name=local]').value;
  fetch('/add/'+lp,{method:'POST'}).then(()=>{$('[name=local]').value='';refresh();});};
</script></section>`;

const state=()=>({
  agent:!!agentSock,
  name: agentName,
  streams:conns.size,
  maps:[...maps].map(([pub,{localPort,name}])=>({pub,local:localPort,name})),
  logs:logBuf
});

http.createServer((req,res)=>{
  if(UI_USER){
    const h=req.headers['authorization']||'';
    const b=h.startsWith('Basic ')?h.slice(6):'';
    const [u,p]=Buffer.from(b,'base64').toString().split(':');
    if(u!==UI_USER||p!==UI_PASS){
      res.writeHead(401,{"WWW-Authenticate":"Basic realm=\"ygs-proxy\""});
      return res.end('Auth required');
    }
  }
  const p=url.parse(req.url).pathname;
  if(p==='/'||p==='/index.html') return res.end(PAGE);
  if(p==='/state') return res.end(JSON.stringify(state()));
  if(p.startsWith('/add/')){ addService(Number(p.split('/').pop())); return res.end('ok'); }
  if(p.startsWith('/del/')){ delService(Number(p.split('/').pop())); return res.end('ok'); }
  res.writeHead(404).end();
}).listen(UI_PORT,()=>log('[ui] http://localhost:'+UI_PORT));
