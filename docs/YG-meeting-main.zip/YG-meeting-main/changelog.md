# Changelog


Version: 1.2.4 (2025-06-13)

## 2025-06-13
- Correction du champ `serial_prefix` dans Device Designer
- Meilleure compatibilite avec l'API lors de l'enregistrement des types
- Gestion d'erreurs lors de la creation, la mise a jour et le fork de device types
- Les messages d'erreur renvoyes par l'API sont desormais affiches dans Device Designer


Version: 1.2.6 (2025-06-13)
## 2025-06-13
- Ajout de l'endpoint POST /device-types/{id}/merge et confirmation de fusion dans device_designer.
- Documentation mise à jour (versions 1.1.6 et 3.4.8).


## 2025-06-13
- Lecture du `backend_api.log` pour afficher l'historique DeviceType dans Device Designer.
- Documentation mise à jour (versions 1.1.5 et 3.4.7).
- Aligné la balise `<h3>` de `device_designer.php` avec la version courante.


## 2025-06-13
- Prise en charge de l'upload d'icones pour les device types et envoi FormData depuis l'admin.




## 2025-06-13
- Ajout de la création automatique du fichier `builder_storage/published/index.json` dans `log_create.sh`.
- Documentation `builder_api.md` mise à jour avec l'endpoint `/api/builder/whoami`.
- Change index page redirection to /devices_frontend
- Replace index page with redirect to /admin and added version header
- Previous changes:
- Add DeviceTypeController and new API routes
- Update docs with device type endpoints
- Corrected future-dated headers and added placeholder examples in Device Designer
- Bump API index version
- Add Device Designer admin page
- Add logout and user session management
- Add DB-backed user login
- Fix admin paths to storage and log management
- Update data paths for storage
- Fix tab initialization and navigation scripts
- Improve database check interface
- Add API endpoints to save and regenerate server SSH key
- Implement advanced device key editing modal in admin page
- Extend builder header retrieval
- Add admin page to manage users
- Store server SSH keys under /var/meeting and update related scripts
- Fix admin page to load server key info correctly
- Display all devices and allow retrieving SSH key from ForceCommand
- Add ForceCommand routes in API index
- Compute fingerprint client-side for devices list
- Read server key from /var/meeting instead of config
- Remove `server_pubkey` and `server_pubkey_fingerprint` from config
- Add SHA256 fingerprint generation option in `regen_meeting_sshkey.sh`
- Alert on admin page when server key file is missing

## 2025-06-13 (cont.)
- Add `device_type_icon_dir` to config and ensure creation via `log_create.sh`
- Verify permissions for device type icon directory
- Bump script and config versions
- Update documentation for new server key metadata

## 2025-06-13 (package_job)
- Rewrote `tools/package_job.php` using `ZipArchive`/`PharData`
- Calculated SHA-256 with `hash_file()`
- Bumped script version to 1.2.1

## 2025-06-13 (docs)
- Documenté la page `device_designer` et le modèle `device_types`
- Ajouté les nouveaux endpoints dans `structure_globale.md`
- Mis à jour les versions et dates des documents

## 2025-06-13
- Device Designer auto-remplit le token de session et affiche la liste des device types via l'API
- Stockage du token Distrib Builder dans la session lors du login admin
- Documentation mise à jour (versions 1.1.3 et 3.4.4)

## 2025-06-13
- Ajout de l'édition et du fork dans Device Designer
- Confirmation par token pour la suppression des types
- Aide contextuelle via tooltips et messages d'alerte
- Documentation mise à jour (versions 1.1.4 et 3.4.5)

## 2025-06-13 (device_designer)
- Correction des boutons non réactifs via ajout de Bootstrap JS
- Mise à jour des versions et .gitignore

Version: 1.2.7 (2025-06-16)
## 2025-06-16
- Nettoyage et amélioration du fichier `.gitignore` (v1.0.5).

Version: 1.2.8 (2025-06-16)
## 2025-06-16
- Mise à jour du proxy (`reverse_tunnel/server/proxy.js` v2.0.1) avec gestion des paquets N, D et C.

Version: 1.2.9 (2025-06-17)
## 2025-06-17

- Correction de l'endpoint `request-tunnel-port` : paramètre `service` pris en charge.
- Mise à jour de `admin/db_check.php` pour ajouter la colonne `service` à `tunnel_ports`.

Version: 1.2.10 (2025-06-17)
## 2025-06-17
- `TunnelController` réserve désormais le port directement en base (plus de fichier `tunnel_requests`).
- Documentation mise à jour (`Encyclopedie.md`).

Version: 1.2.11 (2025-06-17)
## 2025-06-17
- Mise à jour du proxy (`reverse_tunnel/server/proxy.js` v2.0.2).
- Synchronisation des tunnels corrigée via l'API.

Version: 1.2.12 (2025-06-17)
## 2025-06-17
- Proxy (`reverse_tunnel/server/proxy.js` v2.0.3) : amélioration de `fetchAPI`
  pour accepter les certificats self‑signed et mieux gérer les erreurs.

Version: 1.2.13 (2025-06-17)
## 2025-06-17
- Proxy `reverse_tunnel/server/proxy.js` v2.0.4 : mode debug avec `YGS_DEBUG`.
- Interface web déplacée dans `admin/proxy_ui.html`.

Version: 1.2.14 (2025-06-17)
## 2025-06-17
- Proxy `reverse_tunnel/server/proxy.js` v2.0.5 : journaux debug améliorés et suivi des tunnels.

Version: 1.2.15 (2025-06-17)
## 2025-06-17
- Proxy `reverse_tunnel/server/proxy.js` v2.0.6 : chemin de l'interface corrigé et page PHP.

Version: 1.2.16 (2025-06-17)
## 2025-06-17
- Correction des dates UTC dans `TunnelController` pour que les tunnels créés
  apparaissent aussitôt via `/api/tunnels`.
- Documentation mise à jour (`Encyclopedie.md`).
- Mise à jour d'`AGENTS.md` avec un récapitulatif des modules Distrib Builder, Device Designer et LogCenter.

Version: 1.2.17 (2025-06-17)
## 2025-06-17
- `ygs-agent.js` v1.2.2 : récupération automatique de la clé SSH serveur et
  mise à jour périodique de `~/.ssh/known_hosts`.
- Nouvelle API `GET /api/ssh-hostkey` documentée.
- 1ere version fonctionnelle pour le tunnel !! ENFIN ! PUTAIN DE MERDE !!! 

Version: 1.2.18 (2025-06-17)
## 2025-06-17
- `ygs-agent.js` v1.2.3 : log de la récupération de clé et état inchangé.

Version: 1.2.19 (2025-06-17)
## 2025-06-17
- `ygs-agent.js` v1.2.4 : options CLI `--upload-key` et `--fetch-key`.
  Lecture de la clé locale et synchronisation périodique via `--interval`.


Version: 1.2.20 (2025-06-17)
## 2025-06-17
- Champ "Hostname" remplace par "SSH User" dans admin_ssh_keys.
- Payload JS mis a jour et export CSV adapte.

Version: 1.2.21 (2025-06-17)
## 2025-06-17
- `ygs-agent.js` v1.2.5 : génération automatique de la clé locale si absente.
- Affichage du numéro de version lors du démarrage de l'agent.

Version: 1.2.22 (2025-06-17)
## 2025-06-17
- Correction du bouton "Get from device" dans admin_ssh_keys (lecture via /api/devices/{device_key}/ssh-key).


Version: 1.2.23 (2025-06-17)
## 2025-06-17
- Bouton "Get from device" fonctionnel via endpoint forcecommand.
- Fallback lors de l'édition d'une clé si absente dans la table devices.

Version: 1.2.24 (2025-06-17)
## 2025-06-17
- Suppression de l'appel inexistant `/devices/{device_key}/ssh-key`.
- Lecture directe via `forcecommand/get_device_key`.

Version: 1.2.25 (2025-06-17)
## 2025-06-17
- Onglet Availability affiche IP LAN, IP publique, cluster et MAC.

Version: 1.2.26 (2025-06-17)
## 2025-06-17
- Tableau Availability renommé (Status/Since/IP LAN/MAC/Cluster) et suppression de "Event log".

Version: 1.2.27 (2025-06-17)
## 2025-06-17
Version: 1.2.32 (2025-06-17)
## 2025-06-17
- Le script device_setup.sh ignore les erreurs `apt update` et poursuit l'installation.
- install_ygs_agent.sh continue même si l'installation de nodejs échoue.
- README passe en version 1.0.12 et documente cette tolérance.

Version: 1.2.33 (2025-06-17)
## 2025-06-17
- install_ygs_agent.sh corrige les fins de ligne Windows et affiche un message plus simple.
- device_setup.sh affiche sa version, démarre le service après l'échange de clés et passe en v1.0.5.
- README passe en version 1.0.13 et note le démarrage automatique.

Version: 1.2.34 (2025-06-17)
## 2025-06-17
- device_setup.sh se relance automatiquement avec sudo si nécessaire et passe en v1.0.6.
- README passe en version 1.0.14 et précise ce comportement.

- Correction du blocage "Fetching availability…" (ordre des variables JS).



Version: 1.2.28 (2025-06-17)
## 2025-06-17
- Ajout du script interactif device_setup.sh pour l'onboarding des appareils.
- log_create.sh crée /var/log/meeting/device_setup.log.
- `ygs-agent` v1.2.9 : exécution unique avec `--upload-key` ou `--fetch-key`, puis arrêt automatique.

Version: 1.2.29 (2025-06-17)
## 2025-06-17
- device_setup.sh brûle un token et renomme le hostname après installation.
- log_create.sh crée un fichier /etc/meeting/device_info.json.

Version: 1.2.30 (2025-06-17)
## 2025-06-17
- device_setup.sh lance `ygs-agent --fetch-key` avant `--upload-key`.
- Mise à jour de README.md pour décrire cette étape.

Version: 1.2.31 (2025-06-17)
## 2025-06-17
- device_setup.sh détecte une installation existante et propose la réinstallation.
- Possibilité de réutiliser les informations présentes.
- Ajout du dépôt apt Meeting avant l'installation de l'agent.
- README mis à jour en version 1.0.11.





Version: 1.2.35 (2025-06-19)
## 2025-06-19
- Ajout d'un serveur NTP Node.js et script d'installation.
- Mise a jour de log_create.sh et config.php pour ntp_logfile.
- Documentation mise a jour.

Version: 1.2.36 (2025-06-20)
## 2025-06-20
- Ajout d'une suite de tests Jest et d'un workflow CI GitHub Actions.
- Mise à jour du README (v1.0.16) et de `.gitignore` (v1.0.6).

Version: 1.2.37 (2025-06-20)
## 2025-06-20
- Ajout du script `uninstall_ntp_server.sh` (v1.1.0) pour supprimer le serveur NTP.
- Documentation mise à jour (README v1.0.17).

Version: 1.2.38 (2025-06-20)
## 2025-06-20
- Ajout du script `uninstall_distrib_builder.sh` (v1.0.0) pour désinstaller Distrib Builder.
- Mise à jour du README (v1.0.18).

Version: 1.2.39 (2025-06-20)
## 2025-06-20
- Documentation Encyclopedie (v3.4.12) : ajout d'un paragraphe sur le serveur NTP (NTP_PORT, NTP_LOG et script d'installation).

Version: 1.2.40 (2025-06-20)
## 2025-06-20
- Mise à jour du README (v1.0.19) avec une section d'installation du serveur NTP.

Version: 1.2.41 (2025-06-20)
## 2025-06-20
- Ajout du guide `server_reinstall.md`.
- Liens actualisés dans README (v1.0.20) et structure_globale (v1.1.8).

Version: 1.2.42 (2025-06-20)
## 2025-06-20
- Workflow de tests mis à jour pour installer Node.js 22.

Version: 1.2.43 (2025-06-20)
## 2025-06-20
- `ygs-agent.js` v1.2.10 : lecture de `YGS_SERVER_HOST`.
- Configuration par défaut mise à jour (`config.json` v1.2.10).
- Documentation enrichie pour la variable d'environnement.

Version: 1.2.44 (2025-06-20)
## 2025-06-20
- Ajout de tests unitaires pour `/api/devices`, `/api/ssh-hostkey` et `ygs-proxy`.
- Mise à jour de `tests/package.json` en version 1.0.1.
- Couverture des tests en hausse.

Version: 1.2.45 (2025-06-20)
## 2025-06-20
- `api/index.php` v3.10.1 : support de l'option `DB_DSN` (SQLite pour les tests).
- `tests/package.json` passe en 1.0.2.
- Les tests utilisent une base SQLite temporaire pour éviter les erreurs de connexion.

Version: 1.2.46 (2025-06-20)
## 2025-06-20
- Correction des tests avec une base SQLite complète.
- `tests/package.json` passe en 1.0.3.

Version: 1.2.47 (2025-06-21)
## 2025-06-21
- `resident_tools/forceCommand.sh` v3.5.2 : suppression du mode SSH direct, utilisation de `request-tunnel-port` pour `ssh`.
- Option `--debug` pour l'affichage détaillé HTTP et mode standard par défaut.

Version: 1.2.48 (2025-06-21)
## 2025-06-21
- `resident_tools/forceCommand.sh` v3.5.3 : ajout de show_devices et commande showDevices.

Version: 1.2.49 (2025-06-21)
## 2025-06-21
- `resident_tools/forceCommand.sh` v3.5.4 : showDevices affiche uniquement les devices en ligne et mentionne les services actifs.

Version: 1.2.50 (2025-06-21)
## 2025-06-21
- `resident_tools/forceCommand.sh` v3.6.0 : prise en charge de `--config` et de la variable `FORCECOMMAND_CONFIG`.
- Nouveaux scripts `install_forcecommand.sh` et `uninstall_forcecommand.sh`.
- `tools/log_create.sh` v1.6.1 : création automatique de `/etc/meeting/forcecommand.json`.
- Documentation mise à jour (README v1.0.21, structure_globale v1.1.9).
\nVersion: 1.2.51 (2025-06-21)
## 2025-06-21
- Ajout de la documentation forceCommand (v1.0.0) et liens README/structure_globale.

Version: 1.2.52 (2025-06-21)
## 2025-06-21
- `resident_tools/forceCommand.sh` v3.7.0 : ajout de la commande relay avec demande du port.
- Documentation mise à jour (forcecommand v1.1.0, README v1.0.23, structure_globale v1.1.11).

Version: 1.2.53 (2025-06-21)
## 2025-06-21
- `install_forcecommand.sh` v1.1.0 : ajoute ForceCommand dans sshd_config et recharge sshd.
- `uninstall_forcecommand.sh` v1.1.0 : retire la directive et recharge sshd.
- `server_reinstall.md` v1.1.0 avec instructions d'installation.
- `forcecommand.md` v1.2.0 : guide d'installation rapide.

Version: 1.2.54 (2025-06-21)
## 2025-06-21
- `resident_tools/forceCommand.sh` v3.8.0 : connexion SSH automatique après ouverture du tunnel.
- Documentation mise à jour (forcecommand v1.3.0).

Version: 1.2.55 (2025-06-21)
## 2025-06-21
- `resident_tools/forceCommand.sh` v3.9.0 : mise à jour automatique de la clé hôte et options SSH dédiées.
- Documentation mise à jour (forcecommand v1.4.0).

Version: 1.2.56 (2025-06-21)
## 2025-06-21
- `resident_tools/forceCommand.sh` v3.10.0 : chargement dynamique de `log_path` et utilisation variable.

Version: 1.2.57 (2025-06-21)
## 2025-06-21
- `resident_tools/forceCommand.sh` v3.10.1 : gestion d'un `forcecommand.json` sans section `services` et suppression du clear.
- Documentation mise à jour (forcecommand v1.4.1).

Version: 1.2.58 (2025-06-21)
## 2025-06-21
- `resident_tools/forceCommand.sh` v3.10.2 : commandes par défaut quand `services` est absent.
- Documentation mise à jour (forcecommand v1.4.2).

Version: 1.2.59 (2025-06-22)
## 2025-06-22
- `resident_tools/forceCommand.sh` v3.10.3 : commandes par défaut toujours affichées et utilisables.
- Documentation mise à jour (forcecommand v1.4.3).

Version: 1.2.60 (2025-06-22)
## 2025-06-22
- `resident_tools/forceCommand.sh` v3.10.4 : support complet de l'option `--debug` et secours sur l'hôte d'`api_url`.
- Documentation mise à jour (forcecommand v1.4.4).

Version: 1.2.61 (2025-06-22)
## 2025-06-22
- `resident_tools/forceCommand.sh` v3.10.5 : débogage plus verbeux avec configuration affichée et URL de clé hôte.
- Documentation mise à jour (forcecommand v1.4.5).

Version: 1.2.63 (2025-06-23)
Version: 1.2.64 (2025-06-23)
## 2025-06-23
- Synchronisation automatique des clés SSH entre `devices` et `device_keys`.
- `get_device_key` utilise désormais `devices.ssh_public_key` en secours.
- `db_check.php` v3.3.3 : migration des clés existantes.
- Correction d'une accolade surnuméraire bloquant `get_device_key`.

## 2025-06-23
- `device_setup.sh` v1.0.7 : installation automatique de `curl` et `jq`.
- `install_ygs_agent.sh` v1.0.3 : vérification d'`openssh-client` et `curl`.
- `ygs-agent` est installé en `.mjs` pour le support ES modules.

Version: 1.2.66 (2025-06-23)
## 2025-06-23
- `install_ygs_agent.sh` v1.0.4 : ignore les erreurs apt lors de l'installation des dépendances.
- `install_ygs_agent.sh` v1.0.5 : vérifie la présence de Node.js ≥ 20 et avertit si absent.
- `ygs-agent` v1.2.11 : compatibilité avec les versions plus anciennes de Node.js.


Version: 1.2.67 (2025-06-23)
## 2025-06-23
- Ajout du script `ygs-ntpclient` (v1.0.0) et de ses installateurs.
- Documentation mise a jour (README v1.0.27, Encyclopedie v3.4.15, structure_globale v1.1.12).
- `device_setup.sh` v1.0.8 : déclare la clé publique avant l'installation de `ygs-agent` et génère `config.json` après validation du token. README mis à jour.
Version: 1.2.68 (2025-06-23)
- `device_setup.sh` v1.0.9 : ajoute la clé publique Meeting à `authorized_keys`.
- `log_create.sh` v1.6.2 : création automatique d'`authorized_keys`.
- `README.md` v1.0.27 : documentation du nouveau comportement.
Version: 1.2.69 (2025-06-23)
- `device_setup.sh` v1.0.10 : messages colorés, bannière ludique, confirmation de réinstallation,
  publication de la clé avant l'installation et envoi de clé temporairement désactivé.
- `README.md` v1.0.28 : description mise à jour.
Version: 1.2.70 (2025-06-23)
- `device_setup.sh` v1.0.11 : bannière YGSoft et permissions renforcées sur `authorized_keys`.
- `README.md` v1.0.29 : mention de la bannière YGSoft.

Version: 1.2.71 (2025-06-24)
## 2025-06-24
- Ajout du champ `local_port` dans `tunnel_ports` et mise à jour de `db_check.php`.
- Controllers mis à jour pour initialiser ce champ.
- `proxy.js` utilise désormais `local_port` et `/api/tunnels` le renvoie.
- Documentation mise à jour (Encyclopedie v3.4.16).

Version: 1.2.72 (2025-06-24)
- Creation de la table `meeting_users` dans `db_check.php`.
- Support des modifications de colonnes pour cette nouvelle table.

Version: 1.2.73 (2025-06-24)
- `api/controllers/UserController.php` v1.0.0 : gestion REST des utilisateurs (GET/POST/PUT).
- `api/index.php` v3.10.2 : routage des endpoints `/api/users`.
- `Encyclopedie.md` v3.4.17 : documentation des nouveaux endpoints users.

Version: 1.2.74 (2025-06-24)
- `db_check.php` v3.3.6 : colonne `ssh_pubkey` et `authorized` pour `builder_users`.
- `user_manager.php` v1.2.0 : formulaire enrichi et gestion du statut utilisateur.

Version: 1.2.75 (2025-06-24)
- `user_manager.php` v1.2.1 : bouton Upload SSH Key et titre "Users Administration".

Version: 1.2.76 (2025-06-24)
- `api/config.php` v1.7.0 : ajout `ssh_authorized_keys_token` et `user_keys_sync_logfile`.
- `api/controllers/UserController.php` v1.1.0 : endpoint `authorized-keys`.
- `api/index.php` v3.10.3 : routage de `authorized-keys`.
- `resident_tools/ygs-UserKeysSync.sh` v1.0.0 : synchro des cles SSH utilisateurs.
- `tools/log_create.sh` v1.6.3 : prise en charge du log `user_keys_sync_logfile`.
- `Encyclopedie.md` v3.4.18 : documentation mise a jour.

Version: 1.2.77 (2025-06-24)
- `api/config.php` v1.7.1 : correction des chemins de log.
- `resident_tools/ygs-UserKeysSync.sh` v1.1.0 : prise en charge du log Meeting et configuration complete.
- `docs/ssh_keys_walkthrough.md` v1.0.0 : tutoriel pas a pas pour l'utilisation des cles SSH.
- `Encyclopedie.md` v3.4.19 : lien vers le tutoriel SSH.

Version: 1.2.78 (2025-06-24)
- `resident_tools/ygs-UserKeysSync.sh` v1.2.0 : amelioration des logs d'erreur et URL par defaut locale.
- `docs/ssh_keys_walkthrough.md` v1.1.0 : precision sur `API_URL`.
- `Encyclopedie.md` v3.4.20 : ajout mention script de synchronisation.

Version: 1.2.79 (2025-06-24)
- `resident_tools/ygs-UserKeysSync.sh` v1.2.1 : corrige l'erreur "unbound variable" sans argument.
- `docs/ssh_keys_walkthrough.md` v1.2.0 : ajout d'un exemple de synchronisation immediate.

Version: 1.2.80 (2025-06-24)
- `api/index.php` v3.10.4 : prise en charge correcte de `/api/users/authorized-keys`.
- `docs/Encyclopedie.md` v3.4.21 : mention de cette route et version minimale.

Version: 1.2.81 (2025-06-24)
- `api/config.php` v1.8.0 : suppression du token `ssh_authorized_keys_token` et ajout `user_key_sync_script`.
- `api/controllers/UserController.php` v1.2.0 : endpoint autorisé uniquement depuis localhost, synchronisation auto.
- `admin/user_manager.php` v1.3.0 : déclenche la synchronisation après modification d'utilisateur.
- `resident_tools/ygs-UserKeysSync.sh` v1.3.0 : fonctionnement sans token et verbosité accrue.
- `docs/ssh_keys_walkthrough.md` v1.3.0 : mise à jour des instructions sans token.
- `docs/Encyclopedie.md` v3.4.22 : documentation révisée sur `authorized-keys`.

Version: 1.2.82 (2025-06-24)
- `resident_tools/ygs-UserKeysSync.sh` v1.3.1 : log de l'URL utilisée et message explicite en cas de 403.
- `docs/ssh_keys_walkthrough.md` v1.3.1 : note sur l'erreur 403 si l'URL n'est pas locale.
- `docs/Encyclopedie.md` v3.4.23 : précision sur la réponse 403 de l'endpoint.

Version: 1.2.83 (2025-06-24)
- `api/controllers/UserController.php` v1.3.0 : lecture de la table `builder_users` et génération auto du token.
- `docs/Encyclopedie.md` v3.4.24 : exemples mis à jour avec le champ password.

Version: 1.2.84 (2025-06-24)
- `resident_tools/ygs-UserKeysSync.sh` v1.4.0 : ajoute les nouvelles clés sans écraser le fichier existant.
- `docs/ssh_keys_walkthrough.md` v1.4.0 : précision sur la conservation des clés présentes.
- `docs/Encyclopedie.md` v3.4.25 : mention du comportement d'ajout et mise à jour de la version.


Version: 1.2.85 (2025-06-24)
- README.md v1.0.30 : ajout d'une section sur Pageant.
- docs/Encyclopedie.md v3.4.26 : details de `meeting_users` et workflow d'authentification.
- AGENTS.md v2.3 : mention de la nouvelle doc sur l'authentification.

Version: 1.2.86 (2025-06-24)
- ygscreen/backend/api.js v1.1.0 : upload via multer, conversion et gestion des playlists.
- ygscreen/backend/ffmpeg_worker.js v1.1.0 : fonction de conversion ffmpeg.
- ygscreen/backend/config.json v1.0.1 : ajout du chemin tmp et numero de version.
- tools/log_create.sh v1.6.4 : creation du dossier ygscreen.
- Nouvelle route GET `/api/player/playlist/:device_key` et media/clear-cache.

Version: 1.2.87 (2025-06-24)
- ygscreen/frontend/upload.php v1.1.0 : envoi du fichier via cURL.
- ygscreen/frontend/playlist.php v1.1.0 : lecture de la playlist depuis l'API.
- ygscreen/frontend/clear_cache.php v1.1.0 : appel de l'endpoint clear-cache.
- ygscreen/frontend/index.php v1.1.0 : chargement des devices via `/api/devices` et rafraîchissement automatique de la playlist.

Version: 1.2.88 (2025-06-24)
- ygscreen/devices/ygs-player.js v1.1.0 : agent Node pour synchro playlist, telechargement et lecture mpv.
- ygscreen/devices/player_config.json v1.0.0 : configuration par defaut du player.
- tools/setup-files/install_ygs_player.sh v1.0.0 : installe le player et le service systemd.
- tools/setup-files/uninstall_ygs_player.sh v1.0.0 : desinstalle le player.
- ygscreen/AGENTS.md : correction du chemin pour ygs-player.js.
- ygscreen/SPECS.md : mise a jour de la reference de l'agent node.


Version: 1.2.89 (2025-06-24)
- admin/global_settings.php v2.2.0 : ajout des champs `ntp_logfile`, `user_keys_sync_logfile` et `device_type_icon_dir`. Les onglets utilisent maintenant Bootstrap.
- `api/config.php` v1.9.0 : ajout du chemin `ygscreen_storage_root`.
- `tools/log_create.sh` v1.6.5 : creation automatique du dossier YGScreen via la configuration.


Version: 1.2.90 (2025-06-25)
- tools/setup-files/install_ygscreen_backend.sh v1.0.0 : déploiement du backend Node et service systemd.
- tools/setup-files/uninstall_ygscreen_backend.sh v1.0.0 : suppression du backend et du service.
- tools/log_create.sh v1.6.6 : création du dossier de logs pour ygscreen backend.
- AGENTS.md v2.4 : YGScreen module & endpoints.
- docs/Encyclopedie.md v3.4.28 : workflow digital signage.
- ygscreen/README.md v1.0.1 : ajout du workflow complet.
- ygscreen/SPECS.md v1.0.1 : version initiale et endpoints.
- ygs-agent.js v1.2.13 : reconnexion automatique après coupure du proxy.

Version: 1.2.91 (2025-06-25)
- ygscreen/backend/package.json v1.0.0 : liste les dépendances et script de démarrage.
- ygscreen/README.md v1.0.2 : installation du backend via npm.

Version: 1.2.92 (2025-06-25)
- README.md v1.0.32 : présentation de YGScreen.
- docs/Encyclopedie.md v3.4.29 : détail des paramètres des endpoints player.

Version: 1.2.93 (2025-06-25)
- ygscreen/devices/ygs-player.js v1.2.0 : récupération automatique du device_key
  et de l'URL Meeting depuis les fichiers système.
- ygscreen/devices/setup_ygsplayer.sh v1.0.0 : installation simplifiée des
  dépendances et du service ygs-player.

Version: 1.2.94 (2025-06-25)
- ygscreen/backend/api.js v1.2.0 : création automatique de la playlist par défaut et copie des médias imposés.
- ygscreen/backend/config.json v1.0.2 : ajout du chemin imposed_media_dir.
- docs/Encyclopedie.md v3.4.30 : description de la playlist générée par défaut.

Version: 1.2.95 (2025-06-25)
- api/config.php v1.9.1 : ajout du chemin ygscreen_logfile.
- tools/log_create.sh v1.6.7 : prise en compte de ygscreen_logfile via la configuration.
- ygscreen/backend/config.json v1.0.3 : ajout du chemin log_file.
- ygscreen/backend/api.js v1.3.0 : journalisation des opérations et message de démarrage.
- docs/Encyclopedie.md v3.4.31 : ajout du paramètre ygscreen_logfile.

Version: 1.2.96 (2025-06-25)
- tools/setup-files/install_ygscreen_backend.sh v1.0.1 : arrêt du service existant et redémarrage automatique.

Version: 1.2.97 (2025-06-25)
- ygscreen/backend/ffmpeg_worker.js v1.1.1 : force l'option `-f mp4` pour la conversion sans extension et évite l'erreur 500 à l'upload.

Version: 1.2.98 (2025-06-25)
- tools/setup-files/install_ygscreen_backend.sh v1.0.2 : installation complète du backend et du frontend.
- tools/setup-files/uninstall_ygscreen_backend.sh v1.0.1 : suppression du frontend.
- ygscreen/README.md v1.0.3 : mise à jour de la version.

Version: 1.2.99 (2025-06-25)
- tools/setup-files/install_ygscreen_backend.sh v1.0.3 : installe automatiquement Node.js et ffmpeg.
- ygscreen/README.md v1.0.4 : mention de l'installateur auto-dépendances.

Version: 1.2.100 (2025-06-25)
- ygscreen/backend/package.json v1.0.1 : mise à jour de multer pour compatibilité.
- tools/setup-files/install_ygscreen_backend.sh v1.0.4 : exécute `npm install --omit=dev`.

Version: 1.2.101 (2025-06-25)
- ygscreen/backend/api.js v1.3.1 : logs détaillés et appel convert avec logger.
- ygscreen/backend/ffmpeg_worker.js v1.1.2 : enregistre la commande ffmpeg et les erreurs.
- ygscreen/backend/config.json v1.0.4 : incrément de version.
- tools/setup-files/install_ygscreen_backend.sh v1.0.5 : supprime l’ancienne installation avant copie.
- ygscreen/README.md v1.0.5 : mention du fichier de log.
- docs/Encyclopedie.md v3.4.33 : description enrichie du paramètre ygscreen_logfile.

Version: 1.2.102 (2025-06-25)
- tools/setup-files/install_ygscreen_backend.sh v1.0.6 : sécurise la suppression des dossiers d'installation.
- tools/setup-files/uninstall_ygscreen_backend.sh v1.0.2 : mêmes vérifications de chemin.
- ygscreen/README.md v1.0.6 : mise à jour de la version.

Version: 1.2.103 (2025-07-21)
## 2025-07-21
- reverse_tunnel/YGS-agent_win/Program.cs v0.3.5 : envoi automatique de la clé SSH (UploadSshKeyAsync).
- reverse_tunnel/YGS-agent_win/README.md : documentation mise à jour (upload automatique).
- README.md v1.0.33 : incrément de version générale.

