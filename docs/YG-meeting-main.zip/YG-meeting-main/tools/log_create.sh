#!/usr/bin/env bash
# File: tools/log_create.sh


# Version: 1.6.7 (2025-06-25)



# Description: Vérifie et crée l'ensemble des dossiers de logs et de stockage
#   nécessaires à l'exécution de Meeting. Les chemins sont récupérés depuis
#   api/config.php. Les droits sont ajustés pour l'utilisateur web.

set -euo pipefail

if ! command -v php >/dev/null; then
  echo "Erreur : PHP CLI introuvable." >&2
  exit 1
fi

DATA_ROOT="${MEETING_DATA_ROOT:-/var/meeting}"

WEB_USER=${WEB_USER:-www-data}
CONFIG_FILE="$(dirname "$0")/../api/config.php"
LOG_FILE="$DATA_ROOT/api/logs/log_create.log"

sudo mkdir -p "$DATA_ROOT"
sudo chown "$WEB_USER":"$WEB_USER" "$DATA_ROOT"
sudo chmod 775 "$DATA_ROOT"

sudo mkdir -p "$(dirname "$LOG_FILE")"
sudo touch "$LOG_FILE"
sudo chown "$WEB_USER":"$WEB_USER" "$LOG_FILE"
sudo chmod 664 "$LOG_FILE"

# Redirect stdout and stderr to console and log file
exec > >(tee -a "$LOG_FILE") 2>&1

echo "=== log_create.sh $(date '+%Y-%m-%d %H:%M:%S') ==="
echo "Web user: $WEB_USER"
echo "Config file: $CONFIG_FILE"
echo "Log file: $LOG_FILE"
echo "Data root: $DATA_ROOT"

if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "Fichier de configuration introuvable: $CONFIG_FILE" >&2
  exit 1
fi

readarray -t DIRS < <(php -r "\$c = include '$CONFIG_FILE'; \$d = [\$c['tunnel_requests_dir'], \$c['tunnel_status_dir'], dirname(\$c['tunnel_logfile']), dirname(\$c['status_logfile']), dirname(\$c['ssh_keys_logfile']), dirname(\$c['backend_logfile']), dirname(\$c['device_logfile']), dirname(\$c['device_note_logfile']), dirname(\$c['metrics_logfile']), dirname(\$c['tunnel_debug_logfile']), dirname(\$c['builder_logfile']), dirname(\$c['ntp_logfile']), dirname(\$c['ygscreen_logfile']), \$c['flash_storage_root'], \$c['storage_path'], \$c['device_keys_root'], \$c['builder_storage_root'], \$c['builder_storage_root'].'/published', isset(\$c['device_type_icon_dir']) ? \$c['device_type_icon_dir'] : null, isset(\$c['ygscreen_storage_root']) ? \$c['ygscreen_storage_root'] : null, isset(\$c['ygscreen_storage_root']) ? \$c['ygscreen_storage_root'].'/tmp' : null]; echo implode(PHP_EOL, array_unique(array_filter(\$d)));")
echo "Directories to process: ${#DIRS[@]}"


readarray -t LOGFILES < <(php -r "\$c = include '$CONFIG_FILE'; \$f = [\$c['tunnel_logfile'], \$c['status_logfile'], \$c['ssh_keys_logfile'], \$c['backend_logfile'], \$c['device_logfile'], \$c['device_note_logfile'], \$c['metrics_logfile'], \$c['tunnel_debug_logfile'], \$c['builder_logfile'], \$c['ntp_logfile'], \$c['user_keys_sync_logfile'], \$c['ygscreen_logfile']]; echo implode(PHP_EOL, array_unique(\$f));")
echo "Log files to process: ${#LOGFILES[@]}"

echo "[Directories]"
for dir in "${DIRS[@]}"; do
  echo "Processing directory: $dir"
  sudo mkdir -p "$dir"
  sudo chown -R "$WEB_USER":"$WEB_USER" "$dir"
  sudo chmod -R 775 "$dir"
  echo "  ✓ $dir"
done

echo "[Log files]"
for file in "${LOGFILES[@]}"; do
  echo "Processing log file: $file"
  sudo mkdir -p "$(dirname "$file")"
  sudo touch "$file"
  sudo chown "$WEB_USER":"$WEB_USER" "$file"
  sudo chmod 664 "$file"
  echo "  ✓ $file"
done

# Create published index file if it doesn't exist
PUBLISHED_INDEX=$(php -r "\$c = include '$CONFIG_FILE'; echo \$c['builder_storage_root'].'/published/index.json';")
if [[ ! -f "$PUBLISHED_INDEX" ]]; then
  sudo mkdir -p "$(dirname "$PUBLISHED_INDEX")"
  sudo touch "$PUBLISHED_INDEX"
  sudo chown "$WEB_USER":"$WEB_USER" "$PUBLISHED_INDEX"
  sudo chmod 664 "$PUBLISHED_INDEX"
  echo "Created $PUBLISHED_INDEX"
fi

# Also ensure local repository storage has an index file
LOCAL_PUBLISHED_INDEX="$(dirname "$0")/../builder_storage/published/index.json"
if [[ ! -f "$LOCAL_PUBLISHED_INDEX" ]]; then
  mkdir -p "$(dirname "$LOCAL_PUBLISHED_INDEX")"
  touch "$LOCAL_PUBLISHED_INDEX"
  echo "Created $LOCAL_PUBLISHED_INDEX"
fi

# Ensure server public key file exists
SERVER_PUBKEY_FILE="$DATA_ROOT/meeting_id_rsa.pub"
if [[ ! -f "$SERVER_PUBKEY_FILE" ]]; then
  sudo touch "$SERVER_PUBKEY_FILE"
  sudo chown "$WEB_USER":"$WEB_USER" "$SERVER_PUBKEY_FILE"
  sudo chmod 644 "$SERVER_PUBKEY_FILE"
  echo "Created $SERVER_PUBKEY_FILE"
fi
SERVER_FP_FILE="$DATA_ROOT/meeting_id_rsa.pub.sha256"
if [[ ! -f "$SERVER_FP_FILE" ]]; then
  sudo touch "$SERVER_FP_FILE"
  sudo chown "$WEB_USER":"$WEB_USER" "$SERVER_FP_FILE"
  sudo chmod 644 "$SERVER_FP_FILE"
  echo "Created $SERVER_FP_FILE"
fi

# Ensure permissions on the entire base path
sudo chown -R "$WEB_USER":"$WEB_USER" "$DATA_ROOT"
sudo find "$DATA_ROOT" -type d -exec chmod 775 {} +
sudo find "$DATA_ROOT" -type f -exec chmod 664 {} +

echo "Permissions verified for $DATA_ROOT"


# Device setup log file
SETUP_LOG_FILE="/var/log/meeting/device_setup.log"
sudo mkdir -p "$(dirname "$SETUP_LOG_FILE")"
sudo touch "$SETUP_LOG_FILE"
sudo chown "$WEB_USER":"$WEB_USER" "$SETUP_LOG_FILE"
sudo chmod 664 "$SETUP_LOG_FILE"
echo "Created $SETUP_LOG_FILE"

# Device info placeholder
INFO_FILE="/etc/meeting/device_info.json"
sudo mkdir -p "$(dirname "$INFO_FILE")"
if [[ ! -f "$INFO_FILE" ]]; then
  sudo touch "$INFO_FILE"
  echo '{}' | sudo tee "$INFO_FILE" >/dev/null
fi
sudo chown "$WEB_USER":"$WEB_USER" "$INFO_FILE"
sudo chmod 664 "$INFO_FILE"
echo "Created $INFO_FILE"

# Forcecommand configuration example
FORCECOMMAND_CFG="/etc/meeting/forcecommand.json"
sudo mkdir -p "$(dirname "$FORCECOMMAND_CFG")"
if [[ ! -f "$FORCECOMMAND_CFG" ]]; then
  sudo touch "$FORCECOMMAND_CFG"
  echo '{"server_url":"meeting.local","api_url":"http://localhost/api","log_path":"/var/log/meeting/forcecommand.log"}' | sudo tee "$FORCECOMMAND_CFG" >/dev/null
fi
sudo chown "$WEB_USER":"$WEB_USER" "$FORCECOMMAND_CFG"
sudo chmod 664 "$FORCECOMMAND_CFG"
echo "Created $FORCECOMMAND_CFG"

# Ensure authorized_keys file for device user
# AUTHORIZED_KEYS="/home/device/.ssh/authorized_keys"
# sudo mkdir -p "$(dirname "$AUTHORIZED_KEYS")"
# sudo touch "$AUTHORIZED_KEYS"
# sudo chown device:device "$AUTHORIZED_KEYS"
# sudo chmod 600 "$AUTHORIZED_KEYS"
# echo "Created $AUTHORIZED_KEYS"

