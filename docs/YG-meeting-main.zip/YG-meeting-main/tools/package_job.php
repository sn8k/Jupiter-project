<?php
// File: tools/package_job.php
// Version: 1.2.1
// Date: 2025-06-13
// Author: Meeting Server Team
// Description: Background packaging job for BuilderController.

if ($argc < 5) {
    fwrite(STDERR, "Usage: php package_job.php <job_id> <dir> <archive> <format>\n");
    exit(1);
}

$jobId   = $argv[1];
$dir     = $argv[2];
$archive = $argv[3];
$format  = $argv[4];
$status  = dirname(__DIR__)."/builder_storage/{$jobId}.status";

file_put_contents($status, json_encode(['state' => 'running', 'progress' => 0]));

try {
    if ($format === 'tar.gz') {
        $tarPath = preg_replace('/\.gz$/', '', $archive);
        $phar = new PharData($tarPath);
        $phar->buildFromDirectory($dir);
        $phar->compress(Phar::GZ);
        unset($phar);
        if (file_exists($tarPath)) {
            unlink($tarPath);
        }
    } else {
        $zip = new ZipArchive();
        if ($zip->open($archive, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Unable to create archive');
        }
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
        foreach ($files as $file) {
            $local = substr($file->getPathname(), strlen($dir) + 1);
            $zip->addFile($file->getPathname(), $local);
        }
        $zip->close();
    }

    $sha = hash_file('sha256', $archive) ?: null;
    file_put_contents($status, json_encode([
        'state'    => 'done',
        'progress' => 100,
        'archive'  => $archive,
        'sha256'   => $sha
    ]));
} catch (Throwable $e) {
    file_put_contents($status, json_encode([
        'state'    => 'error',
        'progress' => 100,
        'code'     => -1,
        'sha256'   => null,
        'error'    => $e->getMessage()
    ]));
}
?>
