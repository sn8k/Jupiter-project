#!/usr/bin/env bash
# File: tools/device_setup.sh
# Version: 1.0.14 (2025-06-24)
# Description: Setup avancé pour Meeting device, robustifié et auto-heal.
#   - Correction hostname/sudo, nettoyage total authorized_keys,
#   - Redémarrage ygs-agent systématique post-install.

if [[ $EUID -ne 0 ]]; then
  echo "[INFO] Relance du script avec sudo..."
  exec sudo "$0" "$@"
fi

set -euo pipefail

# Some colorful helpers
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m'

fun_banner() {
  echo -e "${BLUE}\\n    __   ______ ____         __ _${NC}"
  echo -e "${BLUE}    \\ \ / / ___/ ___|  ___  / _| |_${NC}"
  echo -e "${BLUE}     \\ V / |  _\\___ \\ / _ \\| |_| __|${NC}"
  echo -e "${BLUE}      | || |_| |___) | (_) |  _| |_${NC}"
  echo -e "${BLUE}      |_| \\____|____/ \\___/|_|  \\__|${NC}"
  echo
}

install_deps() {
  echo "[INFO] Vérification des dépendances (curl, jq)..."
  if ! command -v curl >/dev/null || ! command -v jq >/dev/null; then
    apt-get update -y
    apt-get install -y curl jq
  fi
}

install_deps
fun_banner

# Generate SSH key and declare it to the server
ensure_local_key() {
  local key="/home/device/.ssh/id_ed25519"
  if [[ ! -f "$key" ]]; then
    echo "[INFO] Génération de la paire de clés SSH..."
    mkdir -p "$(dirname "$key")"
    ssh-keygen -t ed25519 -N '' -f "$key" -C "$device_key" >/dev/null
  fi
}

# declare public key to Meeting server
publish_key() {
  ensure_local_key
  local pub="/home/device/.ssh/id_ed25519.pub"
  if [[ -f "$pub" ]]; then
    local key_data
    key_data=$(cat "$pub")
    echo "[INFO] Déclaration de la clé publique sur le serveur..."
    curl -fs -X PUT "$API_BASE/devices/$device_key/ssh-key" \
      -H 'Content-Type: application/json' \
      -d "{\"pubkey\":\"$key_data\"}" >/dev/null \
      && echo "[OK] Clé déclarée" || echo "[WARN] Échec de publication de la clé"
  fi
}

# copy default config for ygs-agent
prepare_config() {
  local cfg="/usr/local/bin/config.json"
  if [[ ! -f "$cfg" ]]; then
    mkdir -p "$(dirname "$cfg")"
    cp "$(dirname "$0")/../reverse_tunnel/devices/config.json" "$cfg" 2>/dev/null || true
  fi
}

# fetch Meeting server public key and add it to authorized_keys (force cleaning)
add_server_key() {
  local ak="/home/device/.ssh/authorized_keys"
  mkdir -p "$(dirname "$ak")"
  local key_raw key_clean
  key_raw=$(curl -fs "$API_BASE/ssh-hostkey" | head -n 1 || true)
  if [[ -n "$key_raw" ]]; then
    # Supprime le hostname du début de la ligne si présent (force overwrite)
    key_clean=$(echo "$key_raw" | awk '{$1=""; print substr($0,2)}' | sed 's/^ //')
    # Supprime et recrée authorized_keys systématiquement (backup possible)
    if [[ -f "$ak" ]]; then
      mv "$ak" "${ak}.bak.$(date +%s)" || true
    fi
    echo "$key_clean" > "$ak"
    chown device:device "$ak" 2>/dev/null || true
    chmod 600 "$ak" 2>/dev/null || true
    echo "[OK] Clé serveur nettoyée et écrite dans authorized_keys"
  else
    echo "[WARN] Clé serveur introuvable"
  fi
}

API_BASE="${MEETING_API_URL:-https://meeting.ygsoft.fr/api}"
LOG_FILE="/var/log/meeting/device_setup.log"

sudo mkdir -p "$(dirname "$LOG_FILE")"
sudo touch "$LOG_FILE"
sudo chmod 664 "$LOG_FILE"
exec > >(tee -a "$LOG_FILE") 2>&1

echo -e "${GREEN}=== Device setup v1.0.14 - $(date '+%Y-%m-%d %H:%M:%S') ===${NC}"

INFO_FILE="/etc/meeting/device_info.json"
reflash=false
reuse_existing=false
existing_key=""
existing_serial=""
existing_token=""

# Check if file exists and is populated (contains non-empty key/token/serial)
if [[ -f "$INFO_FILE" ]]; then
  existing_key=$(jq -r '.device_key // empty' "$INFO_FILE" 2>/dev/null || true)
  existing_serial=$(jq -r '.product_serial // empty' "$INFO_FILE" 2>/dev/null || true)
  existing_token=$(jq -r '.token_code // empty' "$INFO_FILE" 2>/dev/null || true)
  if [[ -n "$existing_key" && -n "$existing_serial" && -n "$existing_token" ]]; then
    host_current=$(hostname)
    read -rp "Le device semble déjà configuré (hostname $host_current). Voulez-vous réinstaller ? [y/N] " ans
    if [[ "$ans" =~ ^[Yy]$ ]]; then
      reflash=true
      read -rp "Réutiliser les informations existantes ? [y/N] " ans2
      if [[ "$ans2" =~ ^[Yy]$ ]]; then
        reuse_existing=true
        device_key="$existing_key"
        serial="$existing_serial"
        token="$existing_token"
        echo "[INFO] Réutilisation des informations présentes dans $INFO_FILE"
      fi
    else
      echo "Abandon."
      exit 0
    fi
  else
    # Fichier présent mais incomplet/vide, ignorer
    echo "[WARN] Fichier $INFO_FILE incomplet ou vide, installation normale."
  fi
fi

if ! $reuse_existing; then
  device_key=""
  serial=""
  token=""
  while true; do
    read -rp "Numéro de série du device: " serial
    if [[ -z "$serial" ]]; then
      read -rp "Numéro de série absent. Entrez la deviceKey: " device_key
      break
    fi
    echo "[INFO] Vérification du numéro de série..."
    json=$(curl -fs "$API_BASE/devices?limit=1000" || true)
    device_key=$(echo "$json" | jq -r --arg sn "$serial" '.devices[] | select(.product_serial==$sn) | .device_key' | head -n1)
    if [[ -z "$device_key" ]]; then
      echo "[WARN] Numéro de série introuvable. Vérifiez et réessayez."
    else
      echo "[OK] device_key trouvé: $device_key"
      break
    fi
  done
fi

if [[ -z "$device_key" ]]; then
  echo "[ERROR] Aucune deviceKey renseignée." >&2
  exit 1
fi

# Vérification token et autorisation
info=$(curl -fs "$API_BASE/devices/$device_key" || true)
server_serial=$(echo "$info" | jq -r '.product_serial')
server_token=$(echo "$info" | jq -r '.token_code')
authorized=$(echo "$info" | jq -r '.authorized')
if [[ -n "$serial" && "$server_serial" != "$serial" ]]; then
  echo "[ERROR] Le numéro de série ne correspond pas." >&2
  exit 1
fi

if ! $reuse_existing; then
  while true; do
    read -rp "Token associé: " token
    if [[ "$token" != "$server_token" ]]; then
      echo "[WARN] Token incorrect. Vérifiez puis recommencez."
    else
      break
    fi
  done
fi

if [[ "$authorized" != "true" ]]; then
  echo "[ERROR] Device non autorisé." >&2
  exit 1
fi

echo "[INFO] Consommation d'un token..."
if curl -fs -X POST "$API_BASE/devices/$device_key/flash-request" >/dev/null; then
  echo "[OK] Token brûlé."
else
  echo "[WARN] Impossible de brûler le token."
fi

echo "[INFO] Enregistrement des informations locales..."
sudo mkdir -p /etc/meeting
sudo tee /etc/meeting/device_info.json >/dev/null <<JSON
{
  "device_key": "$device_key",
  "token_code": "$token",
  "product_serial": "$serial"
}
JSON

# Préparation config et publication des clés
prepare_config
add_server_key
publish_key
# Installation de ygs-agent (sans démarrer le service)
echo "deb [trusted=yes] https://meeting.ygsoft.fr/apt stable main" | sudo tee /etc/apt/sources.list.d/meeting.list
if ! sudo apt update; then
  echo "[WARN] apt update a échoué, poursuite du script"
fi
"$(dirname "$0")/setup-files/install_ygs_agent.sh"

# [TEMP] Désactivation temporaire de la récupération de la clé Meeting
echo "[INFO] (Ignoré) Téléchargement de la clé publique Meeting désactivé temporairement."
# for i in {1..10}; do
#   /usr/local/bin/ygs-agent --fetch-key
#   if [[ -s "/home/device/.ssh/device_key_remote.pub" ]]; then
#     echo "[OK] Clé Meeting récupérée."
#     break
#   fi
#   sleep 5
# done

# Envoi de la clé publique locale
echo "[INFO] Envoi de la clé publique device..."
# TODO: réactiver l'upload automatique lors d'une prochaine mise à jour
# /usr/local/bin/ygs-agent --upload-key

new_hostname="${device_key:0:15}"
if sudo hostnamectl set-hostname "$new_hostname"; then
  echo "[OK] Hostname mis à jour en $new_hostname"
  # Correction /etc/hosts pour le nouveau hostname (sudo-friendly)
  if ! grep -qE "127\.0\.1\.1\s+$new_hostname" /etc/hosts; then
    sudo sed -i "s/^\(127\.0\.1\.1\s\+\).*/\1$new_hostname/" /etc/hosts || \
      echo "127.0.1.1   $new_hostname" | sudo tee -a /etc/hosts >/dev/null
    echo "[OK] /etc/hosts corrigé pour le hostname $new_hostname"
  fi
else
  echo "[WARN] Impossible de changer le hostname"
fi

echo "[INFO] Redémarrage du service ygs-agent…"
sudo systemctl restart ygs-agent
echo "[INFO] Setup terminé."
