#!/usr/bin/env bash
# File: tools/setup_environment.sh
# Version: 1.2.0
# Description: Installe PHP et Node.js puis configure uniquement le service proxy.
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Veuillez exécuter ce script en tant que root." >&2
  exit 1
fi

install_packages() {
  echo "[1/3] Installation des paquets système..."
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y
  apt-get install -y php php-cli php-mysql php-curl php-xml curl jq
  if ! command -v node >/dev/null 2>&1; then
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    apt-get install -y nodejs
  fi
}

install_proxy() {
  echo "[2/3] Installation du proxy..."
  tools/setup-files/install_proxy.sh
}

finish_message() {
  echo "[3/3] Setup terminé. Pensez à ajuster api/config.php et /usr/local/bin/config.json."
}

install_packages
install_proxy

