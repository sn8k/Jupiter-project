#!/bin/bash
# File: ./tools/update_branch.sh
# Version: 1.3.0 (2025-06-11)
# Description: Déploiement d’une branche GitHub directement dans /var/www/meeting-backend/
# Log: ./github_deploy.log

LOGFILE="./github_deploy.log"
REPO_URL="git@github.com:sn8k/YG-meeting.git"
GH_REPO="sn8k/YG-meeting"
DEPLOY_DIR="/var/www/meeting-backend"
TMP_CLONE="/tmp/ygs_git_clone_$$"
COLOR_OK="\033[1;32m"
COLOR_ERR="\033[1;31m"
COLOR_INFO="\033[1;36m"
COLOR_RESET="\033[0m"

log() { echo -e "[$(date '+%F %T')] $*" | tee -a "$LOGFILE"; }

echo -e "${COLOR_INFO}==== YG-meeting Branch Deployment Script (Direct Deploy) ====${COLOR_RESET}"
log "Script lancé."

# Dépendances
for pkg in git curl jq; do
    if ! command -v $pkg &>/dev/null; then
        log "$pkg absent. Installation..."
        sudo apt-get update && sudo apt-get install -y $pkg
    else
        log "$pkg déjà installé."
    fi
done
if ! command -v gh &>/dev/null; then
    log "gh CLI absent. Installation..."
    type lsb_release &>/dev/null || sudo apt-get install -y lsb-release
    sudo apt-get install -y curl
    if [ "$(lsb_release -is 2>/dev/null)" == "Ubuntu" ] || [ "$(lsb_release -is 2>/dev/null)" == "Debian" ]; then
        curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | \
            sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
        sudo chmod go+r /usr/share/keyrings/githubcli-archive-keyring.gpg
        echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | \
            sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
        sudo apt update
        sudo apt install gh -y
    else
        log "${COLOR_ERR}Distrib non supportée. Installe gh manuellement !${COLOR_RESET}"
        exit 10
    fi
else
    log "gh CLI déjà installé."
fi

# Auth
if ! gh auth status &>/dev/null; then
    log "Configuration de l'authentification gh (ouvre ton navigateur)..."
    gh auth login --hostname github.com --web
    if [ $? -ne 0 ]; then
        log "${COLOR_ERR}Erreur d'authentification gh !${COLOR_RESET}"
        exit 11
    fi
else
    log "Authentification gh OK."
fi

# Liste des branches
log "Récupération des branches via GitHub API..."
BRANCHES=$(gh api "repos/$GH_REPO/branches" | jq -r '.[].name')
if [ -z "$BRANCHES" ]; then
    log "${COLOR_ERR}Aucune branche trouvée ! Vérifie ton accès GitHub.${COLOR_RESET}"
    exit 12
fi

declare -A branch_map
i=1
echo -e "${COLOR_INFO}Branches disponibles sur GitHub :${COLOR_RESET}"
for branch in $BRANCHES; do
    echo "  [$i] $branch"
    branch_map[$i]=$branch
    ((i++))
done

read -p "Numéro de la branche à déployer ? " CHOICE
BRANCH_CHOSEN="${branch_map[$CHOICE]}"
if [ -z "$BRANCH_CHOSEN" ]; then
    log "${COLOR_ERR}Branche invalide. Annulation.${COLOR_RESET}"
    exit 13
fi
log "Branche choisie : $BRANCH_CHOSEN"

# Clone dans TMP
log "Clonage temporaire dans $TMP_CLONE ..."
rm -rf "$TMP_CLONE"
git clone --branch "$BRANCH_CHOSEN" "$REPO_URL" "$TMP_CLONE" | tee -a "$LOGFILE"
if [ $? -ne 0 ]; then
    log "${COLOR_ERR}Clonage échoué. Vérifie la clé SSH ou tes droits.${COLOR_RESET}"
    exit 14
fi

# Backup de l’ancien DEPLOY_DIR
BACKUP_DIR="${DEPLOY_DIR}_backup_$(date '+%Y%m%d_%H%M%S')"
log "Backup de $DEPLOY_DIR dans $BACKUP_DIR ..."
sudo rsync -a --exclude '.git' --delete "$DEPLOY_DIR/" "$BACKUP_DIR/"

# Déploiement (écrase tout sauf .git)
log "Déploiement du contenu de la branche $BRANCH_CHOSEN dans $DEPLOY_DIR ..."
sudo rsync -a --delete --exclude='.git' "$TMP_CLONE/" "$DEPLOY_DIR/"

# Nettoyage
rm -rf "$TMP_CLONE"

log "${COLOR_OK}Déploiement de la branche $BRANCH_CHOSEN terminé avec succès dans $DEPLOY_DIR.${COLOR_RESET}"
echo -e "${COLOR_OK}Terminé ! Voir $LOGFILE pour les détails.${COLOR_RESET}"

exit 0
