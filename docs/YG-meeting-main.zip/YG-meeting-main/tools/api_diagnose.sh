#!/usr/bin/env bash
set -euo pipefail

BASE_URL="http://localhost"
VARS_FILE=""
OUTPUT="diagnostic_report.json"

usage() {
  echo "Usage: $0 [--base-url URL] [--vars vars.json] [--output file.json]"
  exit 0
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --base-url)
      BASE_URL="$2"
      shift 2
      ;;
    --vars)
      VARS_FILE="$2"
      shift 2
      ;;
    --output)
      OUTPUT="$2"
      shift 2
      ;;
    -h|--help)
      usage
      ;;
    *)
      echo "Unknown option: $1"
      usage
      ;;
  esac
done

declare -A VARS
if [[ -n "$VARS_FILE" ]]; then
  while IFS= read -r key; do
    value=$(jq -r --arg k "$key" '.[$k]' "$VARS_FILE")
    VARS["$key"]="$value"
  done < <(jq -r 'keys[]' "$VARS_FILE")
fi

mapfile -t ENDPOINTS < <(grep -E '^(GET|POST|PUT|DELETE) /api/' docs/Encyclopedie.md | awk '{print $1 " " $2}')

RESULTS=()

for ep in "${ENDPOINTS[@]}"; do
  method="${ep%% *}"
  path="${ep#* }"
  resolved="$path"
  for var in "${!VARS[@]}"; do
    resolved="${resolved//\{$var\}/${VARS[$var]}}"
  done
  if [[ "$resolved" =~ \{.*\} ]]; then
    result=$(jq -n --arg endpoint "$path" --arg method "$method" --arg reason "missing variable" '{endpoint:$endpoint, method:$method, status:"skipped", reason:$reason}')
    RESULTS+=("$result")
    continue
  fi
  url="${BASE_URL%/}$resolved"
  response=$(curl -s -w "\n%{http_code} %{time_total}" -X "$method" "$url")
  body=$(echo "$response" | head -n -1)
  status_line=$(echo "$response" | tail -n 1)
  status_code=$(echo "$status_line" | awk '{print $1}')
  time_ms=$(echo "$status_line" | awk '{printf "%d", $2*1000}')
  body_trunc=$(echo "$body" | head -c 200)
  result=$(jq -n --arg endpoint "$path" --arg method "$method" --arg resolved_url "$url" --arg status_code "$status_code" --arg time_ms "$time_ms" --arg body "$body_trunc" '{endpoint:$endpoint, method:$method, resolved_url:$resolved_url, status_code:($status_code|tonumber), response_time_ms:($time_ms|tonumber), body:$body}')
  RESULTS+=("$result")

done

printf '%s\n' "${RESULTS[@]}" | jq -s --arg base_url "$BASE_URL" '{base_url:$base_url, results:.}' > "$OUTPUT"

echo "Report written to $OUTPUT"
