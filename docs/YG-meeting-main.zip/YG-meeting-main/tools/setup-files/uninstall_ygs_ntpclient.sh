#!/bin/bash
# File: uninstall_ygs_ntpclient.sh
# Version: 1.0.0 (2025-06-23)
# Description: Supprime ygs-ntpclient et son service systemd.

set -e

DEST_BIN="/usr/local/bin/ygs-ntpclient"
DEST_MJS="/usr/local/bin/ygs-ntpclient.mjs"
SERVICE_FILE="/etc/systemd/system/ygs-ntpclient.service"

if [[ $EUID -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl stop ygs-ntpclient 2>/dev/null || true
  systemctl disable ygs-ntpclient 2>/dev/null || true
fi

rm -f "$DEST_BIN" "$DEST_MJS" "$SERVICE_FILE"

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl daemon-reload
fi

echo "[OK] ygs-ntpclient desinstalle"
