#!/bin/bash
# File: install_ygs_agent.sh
# Version: 1.0.5 (2025-06-23)
# Description: Installe l'outil ygs-agent et son service systemd.
# Usage: sudo ./install_ygs_agent.sh

set -e

BIN_SRC="$(dirname "$0")/../../reverse_tunnel/devices/ygs-agent.js"
CFG_SRC="$(dirname "$0")/../../reverse_tunnel/devices/config.json"
DEST_BIN="/usr/local/bin/ygs-agent"
DEST_MJS="/usr/local/bin/ygs-agent.mjs"
DEST_CFG="/usr/local/bin/config.json"
SERVICE_FILE="/etc/systemd/system/ygs-agent.service"

if [[ $EUID -ne 0 ]]; then
  echo "Veuillez exécuter ce script en root." >&2
  exit 1
fi

ensure_deps() {
  echo "[INFO] Installation des dépendances (curl, openssh-client)…"
  apt-get update -y || echo "[WARN] apt-get update échoué, poursuite"
  apt-get install -y curl openssh-client || echo "[WARN] apt-get install échoué, poursuite"
}

ensure_node() {
  if ! command -v node >/dev/null 2>&1; then
    echo "Installation de Node.js…"
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash - || echo "[WARN] échec setup NodeSource"
    apt-get install -y nodejs || echo "[WARN] installation nodejs échouée, poursuite"
  fi
  if command -v node >/dev/null 2>&1; then
    MAJOR=$(node -v | sed 's/v//' | cut -d. -f1)
    if [[ $MAJOR -lt 20 ]]; then
      echo "[WARN] Node.js <20 détecté. Mise à niveau…"
      curl -fsSL https://deb.nodesource.com/setup_22.x | bash - || echo "[WARN] échec setup NodeSource"
      apt-get install -y nodejs || echo "[WARN] installation nodejs échouée, poursuite"
    fi
  else
    echo "[WARN] Node.js toujours absent, ygs-agent risque de ne pas fonctionner"
  fi
}

install_files() {
  install -m 755 "$BIN_SRC" "$DEST_MJS"
  # Assure LF line endings to éviter l'erreur 'node\r'
  sed -i 's/\r$//' "$DEST_MJS"
  cat > "$DEST_BIN" <<EOF
#!/usr/bin/env bash
node "$DEST_MJS" "$@"
EOF
  chmod 755 "$DEST_BIN"
  if [[ ! -f "$DEST_CFG" ]]; then
    cp "$CFG_SRC" "$DEST_CFG"
  fi
}

create_service() {
  cat > "$SERVICE_FILE" <<SERVICE
[Unit]
Description=YGS agent
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=$DEST_BIN
Environment=YGS_TOKEN=ChangeMe
Restart=on-failure

[Install]
WantedBy=multi-user.target
SERVICE
  systemctl daemon-reload
  if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
    systemctl enable ygs-agent
  else
    echo "[WARN] systemd non disponible, service non installé"
  fi
}

ensure_deps
ensure_node
install_files
create_service

echo "Installation terminée. Lancez : systemctl start ygs-agent"

