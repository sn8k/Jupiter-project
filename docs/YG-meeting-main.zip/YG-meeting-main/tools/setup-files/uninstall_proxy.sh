#!/bin/bash
# File: /usr/local/bin/uninstall_proxy.sh
# Version: 1.0.0
# Author: Meeting DevOps
# Description: Supprime le binaire ygs-proxy et désinstalle le service systemd
#   associé.

set -e

BINARY_PATH="/usr/local/bin/ygs-proxy"
SERVICE_FILE="/etc/systemd/system/ygs-proxy.service"

if [[ "$EUID" -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl stop ygs-proxy 2>/dev/null || true
  systemctl disable ygs-proxy 2>/dev/null || true
fi
rm -f "$BINARY_PATH"
rm -f "$SERVICE_FILE"

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl daemon-reload
fi

echo "[OK] ygs-proxy désinstallé"
