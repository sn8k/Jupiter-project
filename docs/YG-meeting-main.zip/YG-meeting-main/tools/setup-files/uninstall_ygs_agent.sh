#!/bin/bash
# File: uninstall_ygs_agent.sh
# Version: 1.0.1 (2025-06-23)
# Description: Supprime ygs-agent et son service systemd.
# Usage: sudo ./uninstall_ygs_agent.sh

set -e

DEST_BIN="/usr/local/bin/ygs-agent"
DEST_MJS="/usr/local/bin/ygs-agent.mjs"
DEST_CFG="/usr/local/bin/config.json"
SERVICE_FILE="/etc/systemd/system/ygs-agent.service"

if [[ $EUID -ne 0 ]]; then
  echo "Veuillez exécuter ce script en root." >&2
  exit 1
fi

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl stop ygs-agent 2>/dev/null || true
  systemctl disable ygs-agent 2>/dev/null || true
fi
rm -f "$SERVICE_FILE"
rm -f "$DEST_BIN" "$DEST_MJS" "$DEST_CFG"
if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl daemon-reload
fi

echo "ygs-agent désinstallé."

