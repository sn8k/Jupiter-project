#!/bin/bash
# File: tools/setup-files/regen_meeting_sshkey.sh
# Version: 1.3.0
# Author: YGSoft Meeting Automation Team
# Description: (Re)génère la clé SSH 'meeting', copie la pubkey sur le webserver, corrige les droits. Log, interactive, robuste.
# Usage: regen_meeting_sshkey.sh

################################################################################
#                                  CONFIG                                      #
################################################################################
MEETING_USER="meeting"
SSH_DIR="/home/$MEETING_USER/.ssh"
DATA_ROOT="${MEETING_DATA_ROOT:-/var/meeting}"
INSTALL_DIR="$DATA_ROOT"
KEY_FILE="$SSH_DIR/id_rsa_meeting"
PUB_FILE="$SSH_DIR/id_rsa_meeting.pub"
WEB_PUB_FILE="$INSTALL_DIR/meeting_id_rsa.pub"
FINGERPRINT_FILE="$INSTALL_DIR/meeting_id_rsa.pub.sha256"
DATE_STR=$(date +%Y%m%d_%H%M%S)
LOGFILE="../logs/regen_meeting_sshkey.log"
SCRIPT_PATH="$(dirname "$0")/regen_meeting_sshkey.sh"

################################################################################
#                             LOGGING                                          #
################################################################################
debug_log() {
    mkdir -p "$(dirname "$LOGFILE")"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [DEBUG] $*" >> "$LOGFILE"
}
debug_log "==== Script démarré ===="

################################################################################
#                         PATH MANAGEMENT                                      #
################################################################################
# Ajout temporaire à PATH pour la session courante si pas déjà dedans
case ":$PATH:" in
    *:/usr/local/bin:*) ;;
    *) export PATH="$PATH:/usr/local/bin"
       debug_log "Ajout de /usr/local/bin dans PATH pour la session." ;;
esac

################################################################################
#                         SUDO/CHECK USER                                      #
################################################################################
if [[ "$EUID" == 0 ]]; then
    debug_log "Script lancé en root (sudo)."
    # On autorise le lancement root ET user normal, rien à faire (robuste dans les deux cas)
else
    debug_log "Script lancé en utilisateur normal ($USER)."
fi

################################################################################
#                        SELF-INSTALL                                          #
################################################################################
if [[ "$0" != "$SCRIPT_PATH" ]]; then
    debug_log "Script lancé hors de $SCRIPT_PATH. Copie automatique au bon endroit."
    cp "$0" "$SCRIPT_PATH"
    chmod +x "$SCRIPT_PATH"
    echo -e "Le script a été copié dans $SCRIPT_PATH\nRelance recommandée via : regen_meeting_sshkey.sh"
    debug_log "Script copié à $SCRIPT_PATH et rendu exécutable."
    exit 0
fi

################################################################################
#                      FONCTIONS PRINCIPALES                                   #
################################################################################
backup_keys() {
    if [[ -f "$KEY_FILE" || -f "$PUB_FILE" ]]; then
        debug_log "Backup ancienne clé SSH meeting si existante."
        mv -v "$KEY_FILE" "$KEY_FILE.bak.$DATE_STR" 2>>"$LOGFILE" || true
        mv -v "$PUB_FILE" "$PUB_FILE.bak.$DATE_STR" 2>>"$LOGFILE" || true
    fi
}

gen_new_key() {
    debug_log "Génération nouvelle clé SSH meeting (user=$MEETING_USER)."
    sudo -u "$MEETING_USER" ssh-keygen -t rsa -b 4096 -N "" -f "$KEY_FILE"
}

ensure_install_dir() {
    if [[ ! -d "$INSTALL_DIR" ]]; then
        debug_log "Création du dossier $INSTALL_DIR."
        mkdir -p "$INSTALL_DIR"
        chown "$MEETING_USER":"$MEETING_USER" "$INSTALL_DIR"
        chmod 755 "$INSTALL_DIR"
    fi
}

copy_pubkey() {
    debug_log "Copie clé publique vers $WEB_PUB_FILE."
    cp -f "$PUB_FILE" "$WEB_PUB_FILE"
    chown "$MEETING_USER":"$MEETING_USER" "$WEB_PUB_FILE"
    chmod 644 "$WEB_PUB_FILE"
}

secure_perms() {
    debug_log "Correction permissions/droits."
    chown -R "$MEETING_USER":"$MEETING_USER" "$SSH_DIR"
    chmod 700 "$SSH_DIR"
    chmod 600 "$KEY_FILE"
    chmod 644 "$PUB_FILE"
}

generate_fingerprint() {
    if [[ ! -f "$PUB_FILE" ]]; then
        echo "Public key missing: $PUB_FILE"
        return 1
    fi
    fp=$(ssh-keygen -lf "$PUB_FILE" -E sha256 | awk '{print $2}')
    echo "$fp" > "$FINGERPRINT_FILE"
    chown "$MEETING_USER":"$MEETING_USER" "$FINGERPRINT_FILE"
    chmod 644 "$FINGERPRINT_FILE"
    debug_log "Fingerprint generated: $fp"
    echo "Fingerprint saved to $FINGERPRINT_FILE"
}

################################################################################
#                    INTERACTIVE MENU                                          #
################################################################################
print_menu() {
    clear
    echo "╔═══════════════════════════════════════════════════════╗"
    echo "║   REGEN MEETING SSH KEY - MANAGEMENT UTILITY         ║"
    echo "╠═══════════════════════════════════════════════════════╣"
    echo "║  1. (Re)générer la clé SSH meeting                   ║"
    echo "║  2. Sauvegarder la clé actuelle                     ║"
    echo "║  3. Copier la clé publique vers $INSTALL_DIR            ║"
    echo "║  4. Corriger les permissions                        ║"
    echo "║  5. Voir le log                                     ║"
    echo "║  6. Générer le fingerprint SHA256                  ║"
    echo "║  7. Quitter                                         ║"
    echo "╚═══════════════════════════════════════════════════════╝"
}

show_log() {
    echo -e "\n--- Dernières lignes du log ---"
    tail -n 40 "$LOGFILE"
    echo -e "\n(Appuyez sur Entrée pour continuer...)"
    read
}

interactive_main() {
    while true; do
        print_menu
        echo
        read -p "Sélectionnez une option [1-7]: " choice
        case "$choice" in
            1)
                backup_keys
                gen_new_key
                ensure_install_dir
                copy_pubkey
                secure_perms
                echo -e "\n\033[32m✅ Clé SSH meeting régénérée et déployée avec succès.\033[0m"
                debug_log "Clé SSH meeting régénérée via menu."
                sleep 2
                ;;
            2)
                backup_keys
                echo -e "\n\033[36mBackup terminé.\033[0m"
                sleep 1
                ;;
            3)
                ensure_install_dir
                copy_pubkey
                echo -e "\n\033[36mCopie de la clé publique effectuée.\033[0m"
                sleep 1
                ;;
            4)
                secure_perms
                echo -e "\n\033[36mPermissions corrigées.\033[0m"
                sleep 1
                ;;
            5)
                show_log
                ;;
            6)
                generate_fingerprint
                sleep 1
                ;;
            7)
                echo "Bye!"
                debug_log "Fin du script, exit par menu."
                exit 0
                ;;
            *)
                echo "Option inconnue."; sleep 1;;
        esac
    done
}

################################################################################
#                ENTRÉE SCRIPT CLI/NON-INTERACTIF                              #
################################################################################

if [[ "$1" == "--interactive" || "$1" == "-i" || -z "$1" ]]; then
    interactive_main
    exit 0
fi

case "$1" in
    regen|generate|gen|all)
        backup_keys
        gen_new_key
        ensure_install_dir
        copy_pubkey
        secure_perms
        echo -e "\n\033[32m✅ Clé SSH meeting régénérée et déployée avec succès.\033[0m"
        debug_log "Clé SSH meeting régénérée via mode direct."
        ;;
    backup)
        backup_keys
        echo -e "\n\033[36mBackup terminé.\033[0m"
        ;;
    copy)
        ensure_install_dir
        copy_pubkey
        echo -e "\n\033[36mCopie de la clé publique effectuée.\033[0m"
        ;;
    perms|secure)
        secure_perms
        echo -e "\n\033[36mPermissions corrigées.\033[0m"
        ;;
    fingerprint|sha256)
        generate_fingerprint
        ;;
    log)
        show_log
        ;;
    *)
        echo "Usage: regen_meeting_sshkey.sh [regen|backup|copy|perms|fingerprint|log|--interactive]"
        debug_log "Appel sans action reconnue."
        ;;
esac

exit 0
