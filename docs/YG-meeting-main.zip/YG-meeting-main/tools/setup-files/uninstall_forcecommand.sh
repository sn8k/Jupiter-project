#!/bin/bash
# File: /usr/local/bin/uninstall_forcecommand.sh
# Version: 1.1.0 (2025-06-21)
# Description: Supprime le script forceCommand.sh.
# Usage: sudo ./uninstall_forcecommand.sh

set -e

DEST_BIN="/usr/local/bin/forcecommand.sh"
DEST_CFG="/etc/meeting/forcecommand.json"

if [[ "$EUID" -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

rm -f "$DEST_BIN"

SSHD_CONFIG="/etc/ssh/sshd_config"
LINE="ForceCommand /usr/local/bin/forcecommand.sh"
if grep -q "^${LINE}$" "$SSHD_CONFIG"; then
  sed -i "\|^${LINE}$|d" "$SSHD_CONFIG"
fi

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl reload sshd
else
  service ssh reload 2>/dev/null || true
fi

echo "[OK] forcecommand supprimé (config conservée: $DEST_CFG)."
