#!/bin/bash
# File: install_ygs_ntpclient.sh
# Version: 1.0.0 (2025-06-23)
# Description: Installe ygs-ntpclient et cree le service systemd associe.

set -e

SRC="$(dirname "$0")/../../reverse_tunnel/devices/ygs-ntpclient.js"
DEST_BIN="/usr/local/bin/ygs-ntpclient"
DEST_MJS="/usr/local/bin/ygs-ntpclient.mjs"
SERVICE_FILE="/etc/systemd/system/ygs-ntpclient.service"

if [[ $EUID -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

if ! command -v node >/dev/null; then
  echo "[ERROR] Node.js n'est pas installe." >&2
  exit 1
fi

install -m 755 "$SRC" "$DEST_MJS"
sed -i 's/\r$//' "$DEST_MJS"
cat > "$DEST_BIN" <<WRAP
#!/usr/bin/env bash
node "$DEST_MJS" "$@"
WRAP
chmod 755 "$DEST_BIN"

cat > "$SERVICE_FILE" <<SERVICE
[Unit]
Description=Meeting NTP client
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=$DEST_BIN
Restart=always
Environment=NTP_SERVER=127.0.0.1
Environment=NTP_INTERVAL_MS=600000

[Install]
WantedBy=multi-user.target
SERVICE

echo "[OK] Fichiers installes"
if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl daemon-reload
  systemctl enable --now ygs-ntpclient
  echo "[OK] Service ygs-ntpclient demarre et active"
else
  echo "[WARN] systemd non disponible, service non installe"
fi
