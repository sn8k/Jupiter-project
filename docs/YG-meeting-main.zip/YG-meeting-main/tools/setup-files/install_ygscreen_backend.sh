#!/bin/bash
# File: install_ygscreen_backend.sh
# Version: 1.2.0 (2025-06-25)
# Description: Setup YGScreen backend (Node.js) et service systemd, sans déplacer ni supprimer de fichiers.

set -euo pipefail

# ==============================
# --------- CONFIG -------------
# ==============================
BACKEND_DIR="/var/www/meeting-backend/ygscreen/backend"
BIN_WRAPPER="/usr/local/bin/ygscreen-backend"
SERVICE_FILE="/etc/systemd/system/ygscreen-backend.service"
API_MAIN="api.js"   # A adapter si ton entrypoint Node diffère

# ============== CHECKS ================
if [[ $EUID -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

if [[ ! -d "$BACKEND_DIR" ]]; then
  echo "[ERROR] Backend introuvable : $BACKEND_DIR"
  exit 1
fi
if [[ ! -f "$BACKEND_DIR/$API_MAIN" ]]; then
  echo "[ERROR] Fichier principal backend absent : $BACKEND_DIR/$API_MAIN"
  exit 1
fi

echo "[OK] Backend présent : $BACKEND_DIR"

# ============== DEPS ==================
if ! command -v node >/dev/null 2>&1; then
  echo "[INFO] Installation de Node.js…"
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash - || echo "[WARN] setup NodeSource échoué"
  apt-get install -y nodejs || echo "[WARN] installation nodejs échouée"
fi
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "[INFO] Installation de ffmpeg…"
  apt-get update -y
  apt-get install -y ffmpeg || echo "[WARN] installation ffmpeg échouée"
fi

# ============= NPM ====================
cd "$BACKEND_DIR"
if [[ ! -f package.json ]]; then
  echo "[WARN] Aucun package.json, initialisation npm"
  npm init -y >/dev/null
fi
echo "[INFO] Installation des dépendances NPM (prod only)…"
npm install --omit=dev >/dev/null

# =========== WRAPPER ==================
echo "[INFO] Création du wrapper exécutable ($BIN_WRAPPER)..."
cat > "$BIN_WRAPPER" <<WRAP
#!/usr/bin/env bash
node "$BACKEND_DIR/$API_MAIN" "\$@"
WRAP
chmod 755 "$BIN_WRAPPER"

# =========== SYSTEMD ==================
echo "[INFO] Installation du service systemd ($SERVICE_FILE)..."
cat > "$SERVICE_FILE" <<SERVICE
[Unit]
Description=YGScreen backend
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=$BIN_WRAPPER
WorkingDirectory=$BACKEND_DIR
Restart=always
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
SERVICE

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  echo "[INFO] Activation et démarrage du service ygscreen-backend..."
  systemctl daemon-reload
  systemctl enable ygscreen-backend
  systemctl restart ygscreen-backend || systemctl start ygscreen-backend
else
  echo "[WARN] systemd non disponible, service non installé"
fi

echo "[OK] ygscreen-backend prêt et lancé (dossier : $BACKEND_DIR)"
