#!/bin/bash
# File: install_ntp_server.sh
# Version: 1.0.0 (2025-06-19)
# Description: Installe le serveur NTP Node.js pour Meeting et cree le service systemd correspondant.

set -e

SRC="$(dirname "$0")/../../reverse_tunnel/server/ntp-server.js"
BIN="/usr/local/bin/ntp-server"
SERVICE_FILE="/etc/systemd/system/ntp-server.service"

if [[ $EUID -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

if ! command -v node >/dev/null; then
  echo "[ERROR] Node.js n'est pas installe." >&2
  exit 1
fi

install -m 755 "$SRC" "$BIN"
echo "[OK] Binaire installe : $BIN"

cat > "$SERVICE_FILE" <<SERVICE
[Unit]
Description=Meeting NTP server
After=network.target

[Service]
ExecStart=$BIN
Restart=on-failure

[Install]
WantedBy=multi-user.target
SERVICE

echo "[OK] Service systemd cree : $SERVICE_FILE"

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl daemon-reload
  systemctl enable --now ntp-server
  echo "[OK] Service ntp-server demarre et active"
else
  echo "[WARN] systemd non disponible, service non installe"
fi
