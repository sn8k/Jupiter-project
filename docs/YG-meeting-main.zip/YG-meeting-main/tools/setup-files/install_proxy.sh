#!/bin/bash
# File: /usr/local/bin/install_proxy.sh
# Version: 1.0.0
# Author: Meeting DevOps
# Description: Installe le proxy YGS (proxy.js) comme binaire system-wide
#   et crée le service systemd correspondant.

set -e

PROXY_SRC="$(dirname "$0")/../../reverse_tunnel/server/proxy.js"
BINARY_PATH="/usr/local/bin/ygs-proxy"
SERVICE_FILE="/etc/systemd/system/ygs-proxy.service"

if [[ "$EUID" -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

if ! command -v node >/dev/null; then
  echo "[ERROR] Node.js n'est pas installé." >&2
  exit 1
fi

install -m 755 "$PROXY_SRC" "$BINARY_PATH"
echo "[OK] Binaire installé : $BINARY_PATH"

cat > "$SERVICE_FILE" <<SERVICE
[Unit]
Description=YGS proxy
After=network.target

[Service]
ExecStart=$BINARY_PATH
Restart=on-failure

[Install]
WantedBy=multi-user.target
SERVICE

echo "[OK] Service systemd créé : $SERVICE_FILE"

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl daemon-reload
  systemctl enable --now ygs-proxy
  echo "[OK] Service ygs-proxy démarré et activé"
else
  echo "[WARN] systemd non disponible, service non installé"
fi
