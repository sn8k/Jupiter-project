#!/bin/bash
# File: uninstall_ygscreen_backend.sh
# Version: 1.0.2 (2025-06-25)
# Description: Supprime le backend YGScreen et son service systemd.

set -e

DEST_DIR="/usr/local/share/ygscreen-backend"
FRONTEND_DIR="/var/www/meeting-backend/ygscreen"
BIN_WRAPPER="/usr/local/bin/ygscreen-backend"
SERVICE_FILE="/etc/systemd/system/ygscreen-backend.service"

if [[ $EUID -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl stop ygscreen-backend 2>/dev/null || true
  systemctl disable ygscreen-backend 2>/dev/null || true
fi

if [[ -d "$DEST_DIR" && "$DEST_DIR" != "/" ]]; then
  rm -rf "$DEST_DIR"
fi
if [[ -d "$FRONTEND_DIR" && "$FRONTEND_DIR" != "/" ]]; then
  rm -rf "$FRONTEND_DIR"
fi
rm -f "$BIN_WRAPPER" "$SERVICE_FILE"

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl daemon-reload
fi

echo "[OK] ygscreen-backend desinstalle"
