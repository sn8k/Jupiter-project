#!/bin/bash
# File: install_ygs_player.sh
# Version: 1.0.0 (2025-06-24)
# Description: Installe ygs-player et son service systemd.

set -e

SRC="$(dirname "$0")/../../ygscreen/devices/ygs-player.js"
CFG_SRC="$(dirname "$0")/../../ygscreen/devices/player_config.json"
DEST_BIN="/usr/local/bin/ygs-player"
DEST_MJS="/usr/local/bin/ygs-player.mjs"
DEST_CFG="/usr/local/bin/player_config.json"
SERVICE_FILE="/etc/systemd/system/ygs-player.service"

if [[ $EUID -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

if ! command -v node >/dev/null; then
  echo "[ERROR] Node.js n'est pas installe." >&2
  exit 1
fi

install -m 755 "$SRC" "$DEST_MJS"
sed -i 's/\r$//' "$DEST_MJS"
cat > "$DEST_BIN" <<WRAP
#!/usr/bin/env bash
node "$DEST_MJS" "\$@"
WRAP
chmod 755 "$DEST_BIN"

if [[ ! -f "$DEST_CFG" ]]; then
  cp "$CFG_SRC" "$DEST_CFG"
fi

cat > "$SERVICE_FILE" <<SERVICE
[Unit]
Description=YGScreen player
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=$DEST_BIN
Restart=always

[Install]
WantedBy=multi-user.target
SERVICE

systemctl daemon-reload
if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl enable --now ygs-player
else
  echo "[WARN] systemd non disponible, service non installe"
fi

echo "[OK] ygs-player installe"
