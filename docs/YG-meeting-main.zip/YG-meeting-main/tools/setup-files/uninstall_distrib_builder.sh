#!/bin/bash
# File: tools/setup-files/uninstall_distrib_builder.sh
# Version: 1.0.0 (2025-06-20)
# Description: Supprime Distrib Builder (frontend et dossiers) et retire le service eventuel.

set -e

ROOT_DIR="$(dirname "$0")/../.."
SERVICE_NAME="distrib-builder"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
CONFIG_FILE="$ROOT_DIR/api/config.php"

if [[ $EUID -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl stop "$SERVICE_NAME" 2>/dev/null || true
  systemctl disable "$SERVICE_NAME" 2>/dev/null || true
fi
rm -f "$SERVICE_FILE"

# Suppression de la build frontend
rm -rf "$ROOT_DIR/distrib-builder-frontend/dist"

# Lecture des chemins via config.php
STORAGE_ROOT=$(php -r "echo (include '$CONFIG_FILE')['builder_storage_root'];")
LOG_FILE=$(php -r "echo (include '$CONFIG_FILE')['builder_logfile'];")

rm -rf "$ROOT_DIR/builder_storage"
rm -rf "$STORAGE_ROOT"
rm -f "$LOG_FILE"

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl daemon-reload
fi

echo "[OK] Distrib Builder désinstallé"
