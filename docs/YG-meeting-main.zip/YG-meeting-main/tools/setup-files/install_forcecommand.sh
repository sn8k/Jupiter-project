#!/bin/bash
# File: /usr/local/bin/install_forcecommand.sh
# Version: 1.1.0 (2025-06-21)
# Description: Installe forceCommand.sh et copie la configuration exemple.
# Usage: sudo ./install_forcecommand.sh

set -e

SRC_SCRIPT="$(dirname "$0")/../../resident_tools/forceCommand.sh"
CFG_SRC="$(dirname "$0")/../../resident_tools/forcecommand.example.json"
DEST_BIN="/usr/local/bin/forcecommand.sh"
DEST_CFG="/etc/meeting/forcecommand.json"

if [[ "$EUID" -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

install -m 755 "$SRC_SCRIPT" "$DEST_BIN"
mkdir -p "$(dirname "$DEST_CFG")"
if [[ -f "$CFG_SRC" && ! -f "$DEST_CFG" ]]; then
  cp "$CFG_SRC" "$DEST_CFG"
fi

SSHD_CONFIG="/etc/ssh/sshd_config"
LINE="ForceCommand /usr/local/bin/forcecommand.sh"
if ! grep -q "^${LINE}$" "$SSHD_CONFIG"; then
  echo "$LINE" >> "$SSHD_CONFIG"
fi

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl reload sshd
else
  service ssh reload 2>/dev/null || true
fi

echo "[OK] forcecommand installé."
