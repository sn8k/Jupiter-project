#!/bin/bash
# File: uninstall_ygs_player.sh
# Version: 1.0.0 (2025-06-24)
# Description: Supprime ygs-player et son service systemd.

set -e

DEST_BIN="/usr/local/bin/ygs-player"
DEST_MJS="/usr/local/bin/ygs-player.mjs"
DEST_CFG="/usr/local/bin/player_config.json"
SERVICE_FILE="/etc/systemd/system/ygs-player.service"

if [[ $EUID -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl stop ygs-player 2>/dev/null || true
  systemctl disable ygs-player 2>/dev/null || true
fi

rm -f "$DEST_BIN" "$DEST_MJS" "$DEST_CFG" "$SERVICE_FILE"

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl daemon-reload
fi

echo "[OK] ygs-player desinstalle"
