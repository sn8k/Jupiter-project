#!/usr/bin/env bash
# File: tools/setup-files/install_distrib_builder.sh
# Version: 1.0.0
# Description: Installe le module Distrib Builder (frontend + dossiers).
#   - Installe Node.js si nécessaire
#   - Installe les dépendances npm
#   - Génère la build de production
#   - Crée les dossiers via log_create.sh

set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Veuillez exécuter ce script en tant que root." >&2
  exit 1
fi

ROOT_DIR="$(dirname "$0")/../.."

ensure_node() {
  if ! command -v node >/dev/null 2>&1; then
    echo "[1/3] Installation de Node.js…"
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    apt-get install -y nodejs
  fi
}

install_frontend() {
  echo "[2/3] Installation du frontend…"
  cd "$ROOT_DIR/distrib-builder-frontend"
  npm install
  npm run build
}

prepare_storage() {
  echo "[3/3] Création des dossiers de stockage…"
  "$ROOT_DIR/tools/log_create.sh"
}

ensure_node
install_frontend
prepare_storage

echo "Distrib Builder installé."
