#!/bin/bash
# File: uninstall_ntp_server.sh
# Version: 1.1.0 (2025-06-20)
# Description: Supprime ntp-server et son service systemd.

set -e

BIN="/usr/local/bin/ntp-server"
SERVICE_FILE="/etc/systemd/system/ntp-server.service"

if [[ $EUID -ne 0 ]]; then
  echo "[INFO] Relancement avec sudo..."
  exec sudo -E "$0" "$@"
fi

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl stop ntp-server 2>/dev/null || true
  systemctl disable ntp-server 2>/dev/null || true
fi

rm -f "$BIN" "$SERVICE_FILE"

if command -v systemctl >/dev/null && systemctl list-units >/dev/null 2>&1; then
  systemctl daemon-reload
fi

echo "[OK] ntp-server désinstallé"
