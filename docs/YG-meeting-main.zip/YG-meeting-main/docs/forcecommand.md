# Utilitaire forceCommand

Version: 1.4.5 (2025-06-22)

Ce script bash offre une interface interactive pour ouvrir des tunnels vers vos appareils via l'API Meeting. Il se lance automatiquement lors d'une connexion SSH vers le serveur Meeting.

## Exemple rapide

```bash
ssh user@meeting.example.com
```
Une fois connecté, saisissez par exemple :
```bash
ssh ABC123
```
Ou pour un relais HTTP :
```bash
http ABC123
```
Pour relayer un port arbitraire :
```bash
relay ABC123 8080
```
Si le port est omis, le script le demandera.
Le script attend que l'API crée le tunnel puis affiche la commande ou l'URL à utiliser. Pour une commande `ssh`, la connexion est lancée automatiquement à réception du port. En cas d'échec, un message d'erreur s'affiche.

## Options

- `--config <fichier>` : spécifie un fichier de configuration différent (peut aussi être fourni via la variable `FORCECOMMAND_CONFIG`).
- `--debug` : affiche toutes les requêtes HTTP et les réponses de l'API.

Les commandes `help`, `showDevices` et `getOut` sont disponibles pour obtenir la liste des services, afficher les appareils en ligne ou revenir à un shell normal.

Le fichier d'exemple de configuration se trouve dans `resident_tools/forcecommand.example.json`.

## Installation

Pour que `forcecommand.sh` se lance automatiquement à chaque connexion SSH, exécutez :

```bash
sudo tools/setup-files/install_forcecommand.sh
```

Le script copie le binaire, crée la configuration par défaut et ajoute dans `/etc/ssh/sshd_config` :

```
ForceCommand /usr/local/bin/forcecommand.sh
```

Le service `sshd` est ensuite rechargé. Pour revenir au comportement standard :

```bash
sudo tools/setup-files/uninstall_forcecommand.sh
```

## Gestion automatique de la clé SSH

Depuis la version 3.9.0, `forceCommand.sh` récupère la clé publique du serveur
via l'endpoint `GET /api/ssh-hostkey` et la sauvegarde dans
`~/.ssh/meeting_known_hosts`. Lors des connexions, l'option
`UserKnownHostsFile` est utilisée avec `StrictHostKeyChecking=accept-new` pour
éviter toute invite interactive. Le fichier est mis à jour si la clé change.

Depuis la version 3.10.1, le champ `services` dans `forcecommand.json` est optionnel ;
le script ignore simplement la liste si elle est absente.
Depuis la version 3.10.3, si cette section manque, une liste par défaut de
commandes (`ssh`, `http`, `relay`, `vnc`, `scp`) est automatiquement proposée.
Depuis la version 3.10.3, ces commandes apparaissent toujours dans le menu et fonctionnent avec n'importe quelle deviceKey.
Depuis la version 3.10.4, l'option `--debug` affiche les réponses de l'API pour toutes les commandes et le script utilise l'hôte d'`api_url` si `server_url` n'est pas résolu.
Depuis la version 3.10.5, le mode débogage indique la configuration chargée et l'URL de récupération de la clé hôte.
