# Réinstallation complète du backend

Version: 1.1.0 (2025-06-21)

Ce guide détaille la procédure pour repartir d\'une installation propre du backend Meeting, des services Node.js et des scripts systemd associés.

## 1. Sauvegarder l\'ancien environnement

- Exportez la base de données MySQL :

```bash
mysqldump -u root -p devices_db > ~/devices_db_backup.sql
```

- Copiez éventuellement les journaux et le dossier `storage` :

```bash
sudo cp -r /var/meeting/api/logs ~/logs_backup
sudo cp -r /var/meeting/storage ~/storage_backup
```

## 2. Arrêter et supprimer les services existants

```bash
sudo systemctl stop ygs-proxy.service
sudo systemctl stop ntp-server.service
sudo systemctl disable ygs-proxy.service
sudo systemctl disable ntp-server.service
sudo /usr/local/bin/uninstall_proxy.sh
sudo /usr/local/bin/uninstall_ntp_server.sh
sudo /usr/local/bin/uninstall_forcecommand.sh
```

Si un agent tournait également sur la machine, exécutez :

```bash
sudo systemctl stop ygs-agent.service
sudo systemctl disable ygs-agent.service
sudo /usr/local/bin/uninstall_ygs_agent.sh
```

## 3. Mettre à jour le dépôt

```bash
cd /var/www/meeting
git fetch --all
git reset --hard origin/main
```

## 4. Réinstaller l\'environnement de base

```bash
sudo tools/setup_environment.sh
```

Ce script installe PHP et Node.js puis déploie le service `ygs-proxy`.

## 5. Mettre à jour la base de données et les dossiers

```bash
php admin/db_check.php
sudo tools/log_create.sh
```

## 6. Installer les services complémentaires

```bash
sudo tools/setup-files/install_ntp_server.sh
# Si l\'agent doit tourner sur ce serveur :
sudo tools/setup-files/install_ygs_agent.sh
sudo tools/setup-files/install_forcecommand.sh
```

Référez‑vous à chaque script d\'installation pour les options `--remove` ou `--uninstall`.

## 7. Relancer l\'application

Après ces étapes, le backend et les services Node.js sont fonctionnels. Importez votre sauvegarde SQL si nécessaire :

```bash
mysql -u root -p devices_db < ~/devices_db_backup.sql
```

Vérifiez enfin que les services sont actifs :

```bash
systemctl status ygs-proxy.service
systemctl status ntp-server.service
```
