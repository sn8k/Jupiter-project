# Documentation globale du dépôt YG-meeting


Version: 1.1.12 (2025-06-23)


Ce document décrit succinctement chaque répertoire et fichier principal du projet YG-meeting.

## Contenu racine

- **AGENTS.md** : philosophie du projet et rôles des contributeurs.
- **README.md** : guide d'installation rapide et informations générales.
- **index.php** : point d'entrée web minimal.
- **LICENSE** : conditions de licence YG Proprietary.

## Répertoires principaux

- **/api** : backend PHP avec les contrôleurs REST, la configuration et les helpers de journalisation.
- **/admin** : interface d'administration (PHP) et scripts associés comme `db_check.php` pour la base.
- **/distrib-builder-frontend** : application React/Vite pour préparer et publier des distributions logicielles.
- **/builder_storage** : espace de stockage utilisé par Distrib Builder pour conserver les archives publiées.
- **/reverse_tunnel** : code Node.js des agents, du proxy et du serveur NTP et du client ygs-ntpclient assurant la synchronisation horaire.
- **/devices_frontend** : pages PHP destinées aux appareils pour afficher disponibilité et détails.
- **/docs** : documentation du projet, dont l'Encyclopédie de l'API.
- **/tools** : scripts de maintenance (`log_create.sh`, `setup_environment.sh`, etc.).
- **/resident_tools** : utilitaires à déployer sur les machines hôtes (forceCommand, synchronisation de clés SSH). `forceCommand.sh` peut aussi lire un fichier via `--config` ou la variable `FORCECOMMAND_CONFIG`. La commande `relay <devicekey> <port>` permet de relayer n'importe quel port (le script demande le port s'il est omis).
- Les journaux du backend se trouvent dans `$MEETING_DATA_ROOT/api/logs/` (par défaut `/var/meeting/api/logs/`).
- Le stockage principal est situé dans `$MEETING_DATA_ROOT/storage`.
- **/medias_library** : bibliothèque par défaut d'images et de médias à afficher sur les appareils.

## Fichiers clés

- `admin/db_check.php` : vérifie et met à jour la structure de la base MySQL.
- `tools/log_create.sh` : crée l'arborescence de journaux et ajuste les droits.
- `admin/device_designer.php` : interface web pour gérer les device types (liste, création, édition et fork, suppression avec confirmation par token) et lancer Distrib Builder et consulter l'historique des actions DeviceType depuis `backend_api.log`.
- Table MySQL `device_types` : définit les modèles d'appareils (nom, préfixe, plateforme, services par défaut).

## Documentation complémentaire

Consultez également :

- `docs/Encyclopedie.md` pour l'ensemble des endpoints REST et des workflows.
- `docs/builder_api.md` pour l'API du module Distrib Builder.
- `docs/server_reinstall.md` pour réinstaller complètement le backend et les services.
- `docs/forcecommand.md` pour l'utilisation détaillée de forceCommand.

## Principaux contrôleurs et endpoints

Le dossier `/api/controllers` regroupe l'ensemble des classes PHP qui
implémentent l'API REST. Ci-dessous un aperçu des fonctions publiques et de
leurs endpoints associés :

### DeviceController
- `GET /api/devices` → `listDevices()`
- `POST /api/devices/generate-and-register` → `generateAndRegisterDevice()`
- `POST /api/devices/{device_key}/service` → `startDeviceService()`
- `GET /api/devices/{device_key}` → `getDevice()`

### TunnelController
- `POST /api/devices/{device_key}/authorize-tunnel` → `authorizeTunnel()`
- `GET /api/devices/{device_key}/pending-tunnel` → `getPendingTunnel()`
- `POST /api/devices/{device_key}/tunnel-status` → `setTunnelStatus()`

### DeviceLogsController
- `GET /api/devices/{device_key}/logs` → `deviceLogs()`
- `DELETE /api/devices/{device_key}/logs` → `purgeLogs()`

### ForceCommandController
- `POST /api/forcecommand/register` → `registerDeviceKey()`
- `GET /api/forcecommand/device-key` → `getDeviceKey()`
- `POST /api/forcecommand/request-port` → `requestTunnelPort()`

### FlashController
- `POST /api/flash/request/{device_key}` → `flashRequest()`
- `POST /api/flash/upload` → `uploadDistributionFile()`

### SshKeysController
- `GET /api/sshkeys/{device_key}` → `getSshKey()`
- `POST /api/sshkeys/{device_key}` → `setDeviceSshKey()`

### DeviceTypeController
- `GET /api/device-types` → `listTypes()`
- `POST /api/device-types` → `createType()`
- `PUT /api/device-types/{id}` → `updateType()`
- `POST /api/device-types/{id}/fork` → `forkType()`
- `POST /api/device-types/{id}/merge` → `mergeType()`
- `DELETE /api/device-types/{id}` → `deleteType()`

### Autres contrôleurs
`StatusController`, `DeviceAvailabilityController`, `DeviceRelationController`
et `MetricsController` fournissent respectivement les endpoints de présence, de
suivi d'activité, de relations entre appareils et de collecte de métriques.
Consultez `docs/Encyclopedie.md` pour le détail complet des paramètres et des
réponses attendues.

