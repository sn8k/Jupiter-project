# Installing MySQL and creating the Meeting database

These commands target a Debian/Ubuntu environment.
Adjust package manager commands for other distributions.

## 1. Install packages
```bash
sudo apt update
sudo apt install -y mysql-server
```

Run the secure installation script if desired:
```bash
sudo mysql_secure_installation
```

## 2. Create database and user
Connect as root in the MySQL shell:
```bash
sudo mysql -u root
```
Then execute:
```sql
CREATE DATABASE devices_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'meeting_db'@'localhost' IDENTIFIED BY '2cmorh2x';
GRANT ALL PRIVILEGES ON devices_db.* TO 'meeting_db'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```
You can change database name, user or password if required. Update the values in `api/config.php` accordingly or set the equivalent environment variables.

## 3. Initialize the schema
Place the project in your web directory (e.g. `webroot/`) and run:
```bash
php admin/db_check.php
```
This script creates the needed tables (`devices`, `device_keys`, `flash_logs`, `connection_logs`, `tunnel_ports`).

After that the API can connect using the credentials defined above.
