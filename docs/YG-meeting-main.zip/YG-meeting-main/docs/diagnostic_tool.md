# API Diagnostic Utility

This repository includes a helper script to automatically test the REST API and generate a report.

## Usage

1. Ensure `curl` and `jq` are available on your system.

2. Run the diagnostic script from the repository root:

```bash
bash tools/api_diagnose.sh --base-url http://your-server/api --vars variables.json
```

- `--base-url`: base URL of the API (default `http://localhost`)
- `--vars`: optional JSON file with values for path placeholders (e.g. `{"device_key": "ABC123"}`)
- `--output`: report filename (defaults to `diagnostic_report.json`)

3. The script parses `docs/Encyclopedie.md` to discover endpoints, calls each one, and writes a JSON report summarizing responses.

The generated report can be shared for debugging purposes.
