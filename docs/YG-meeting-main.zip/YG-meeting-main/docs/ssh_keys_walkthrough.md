# Utilisation des cles SSH utilisateurs

Version: 1.4.0 (2025-06-24)

Ce guide explique comment configurer l'authentification SSH sans mot de passe avec Meeting.

## 1. Generer une cle
```bash
ssh-keygen -t ed25519 -C "mon@example.com"
```
Le fichier `id_ed25519.pub` contient la cle publique.

## 2. Importer la cle dans Meeting
- Rendez-vous sur la page `admin/user_manager.php`.
- Ajoutez ou modifiez un utilisateur et collez le contenu de `id_ed25519.pub` dans le champ prevu, ou utilisez le bouton *Upload SSH Key*.
- Cochez la case *authorized* pour activer l'accès.

## 3. Synchroniser les cles sur le serveur
- Installez le script:
```bash
sudo bash resident_tools/ygs-UserKeysSync.sh --install
```
- Si besoin, ajustez `API_URL` dans `/etc/ygs-userkeysync.conf` pour pointer vers votre serveur (par defaut `http://localhost/api/users/authorized-keys`).
- Si le log affiche `Acces interdit (403)`, verifiez que `API_URL` pointe bien vers `localhost`.
- Le cron mettra a jour `/home/meeting/.ssh/authorized_keys` toutes les dix minutes.
- Les clés existantes ne sont pas écrasées : seules les nouvelles clés sont ajoutées si elles ne sont pas déjà présentes.
- Consultez le log `user_keys_sync.log` pour verifier la synchronisation.
- Pour tester immediatement, lancez:
```bash
sudo ygs-UserKeysSync.sh --sync
```

## 4. Connexion
Assurez-vous que votre cle privee est chargee par `ssh-agent` puis connectez-vous simplement :
```bash
ssh <login>@meeting.ygsoft.fr
```
