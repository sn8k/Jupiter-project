# Distrib Builder API

Version: 1.3.5
Date: 2025-06-13

Cette documentation décrit les endpoints REST pour le workflow "Distrib Builder" permettant de créer et de publier des distributions firmware.

Toutes les requêtes doivent inclure l'en-tête `Authorization: Bearer <token>` pour être authentifiées.

## Liste et suggestions
- `GET /api/builder/whoami` : identifie l'utilisateur actuellement authentifié.
- `GET /api/builder/device-types` : liste des types d'appareils.
- `GET /api/builder/distributions?type=rpi4` : liste des distributions d'un type.
- `POST /api/builder/suggest-version` : propose la prochaine version.

## Création et édition
- `POST /api/builder/start` : crée un brouillon de build et retourne les URLs d'upload et de manifest.
- `POST /api/builder/upload-file` : envoie un fichier lié à un build. Les fichiers doivent avoir une extension autorisée et ne pas dépasser la taille configurée.
- `GET /api/builder/manifest?build_id=xxx` : récupère le manifest courant.
- `POST /api/builder/manifest` : met à jour le manifest.

## Packaging et publication
- `POST /api/builder/package` : lance la création de l'archive en tâche de fond (tar.gz ou zip).
- `GET /api/builder/package-status?job_id=xxx` : retourne l'avancement du packaging et le SHA-256 de l'archive une fois terminée.
- `GET /api/builder/download/{job_id}` : télécharge l'archive générée.
- `POST /api/builder/commit` : publie la distribution générée.
- La distribution est ensuite enregistrée sous `published/<type>/<distribution>/<version>`.

## Historique et maintenance
- `GET /api/builder/history` : liste l'historique des builds publiés.
- `POST /api/builder/rollback` : restaure une version publiée.
- `POST /api/builder/duplicate` : crée une copie d'une distribution.

Ces endpoints sont pensés pour être appelés par un frontend moderne. Les réponses sont toujours au format JSON et indiquent `success` ou `error` ainsi que des informations de suivi de job lorsque nécessaire.
