#!/bin/bash
set -euo pipefail
# File: /usr/local/bin/ygs-UserKeysSync.sh
# Version: 1.4.2
# Date: 2025-06-24
# Author: Meeting DevOps
# Description: Synchronise les cles SSH des utilisateurs autorises via l'API Meeting.
#   - Recupere GET /api/users/authorized-keys
#   - Ajoute les cles dans /home/meeting/.ssh/authorized_keys (sans effacer les anciennes)
#   - Convertit automatiquement les cles SSH2 en format OpenSSH si besoin
#   - Logs DEBUG détaillés
#   - Options --install / --remove pour cron systemd.

BIN_PATH="/usr/local/bin/ygs-UserKeysSync.sh"
CONFIG_FILE="/etc/ygs-userkeysync.conf"
LOGFILE="/var/meeting/api/logs/user_keys_sync.log"
CRON_FILE="/etc/cron.d/ygs-userkeysync"
DEFAULT_API_URL="http://localhost/api/users/authorized-keys"
AUTHORIZED_KEYS="/home/meeting/.ssh/authorized_keys"

log_msg() {
    mkdir -p "$(dirname "$LOGFILE")"
    local line="[$(date '+%Y-%m-%d %H:%M:%S')] $*"
    echo "$line" | tee -a "$LOGFILE"
}

API_URL="$DEFAULT_API_URL"
[ -f "$CONFIG_FILE" ] && source "$CONFIG_FILE"
TMP_KEYS="/tmp/user_authorized_keys.$$"
log_msg "[CONFIG] API_URL=$API_URL"

sync_keys() {
    log_msg "[DEBUG] Lancement sync_keys()"
    log_msg "Appel API $API_URL"
    http_code=$(curl -s -w "%{http_code}" -o "$TMP_KEYS" "$API_URL" || echo "000")
    log_msg "[DEBUG] curl http_code=$http_code"
    if [[ "$http_code" != "200" ]]; then
        if [[ "$http_code" == "403" ]]; then
            log_msg "Acces interdit (403) - verifiez API_URL=$API_URL"
        else
            log_msg "Erreur curl (code $http_code)"
        fi
        rm -f "$TMP_KEYS"
        return 1
    fi
    if [[ ! -s "$TMP_KEYS" ]]; then
        log_msg "Aucune cle recuperee"
        rm -f "$TMP_KEYS"
        return 1
    fi

    # Log le contenu TMP_KEYS
    log_msg "[DEBUG] Contenu du TMP_KEYS récupéré :"
    while IFS= read -r l || [ -n "$l" ]; do log_msg "[DEBUG][API] $l"; done < "$TMP_KEYS"

    # Backup
    cp -f "$AUTHORIZED_KEYS" "$AUTHORIZED_KEYS.bak.$(date +%Y%m%d_%H%M%S)" 2>/dev/null || true
    touch "$AUTHORIZED_KEYS"
    chmod 600 "$AUTHORIZED_KEYS"
    chown meeting:meeting "$AUTHORIZED_KEYS"

    new=0
    buffer=""
    in_ssh2=0
    while IFS= read -r line || [ -n "$line" ]; do
        # Début d'un bloc SSH2
        if [[ "$line" =~ ^----\ BEGIN\ SSH2\ PUBLIC\ KEY\ ---- ]]; then
            buffer="$line"$'\n'
            in_ssh2=1
            log_msg "[DEBUG] Bloc SSH2 détecté (début)"
            continue
        fi

        if [[ "$in_ssh2" == "1" ]]; then
            buffer+="$line"$'\n'
            if [[ "$line" =~ ^----\ END\ SSH2\ PUBLIC\ KEY\ ---- ]]; then
                log_msg "[DEBUG] Bloc SSH2 détecté (fin), tentative conversion"
                openssh_key=$(echo "$buffer" | ssh-keygen -i -m SSH2 -f - 2>/dev/null | head -n1)
                if [[ -n "$openssh_key" ]]; then
                    if ! grep -Fxq "$openssh_key" "$AUTHORIZED_KEYS"; then
                        echo "$openssh_key" >> "$AUTHORIZED_KEYS"
                        log_msg "[DEBUG] Ajout clé convertie : $openssh_key"
                        new=$((new+1))
                    else
                        log_msg "[DEBUG] Clé déjà présente (convertie) : $openssh_key"
                    fi
                else
                    log_msg "[WARN] Impossible d'ajouter/convertir clé SSH2 (bloc ignoré)"
                fi
                buffer=""
                in_ssh2=0
            fi
            continue
        fi

        # Ligne normale (clé OpenSSH ou autre)
        line="$(echo "$line" | xargs)"
        [[ -z "$line" ]] && continue
        if ! grep -Fxq "$line" "$AUTHORIZED_KEYS"; then
            echo "$line" >> "$AUTHORIZED_KEYS"
            log_msg "[DEBUG] Ajout clé brute : $line"
            new=$((new+1))
        else
            log_msg "[DEBUG] Clé déjà présente (brute) : $line"
        fi
    done < "$TMP_KEYS"

    rm -f "$TMP_KEYS"
    total=$(grep -c '^' "$AUTHORIZED_KEYS" || true)
    if [[ $new -gt 0 ]]; then
        log_msg "Ajout de $new nouvelle(s) cle(s) (total $total)"
    else
        log_msg "Aucune nouvelle cle (total $total)"
    fi
}

install_sync() {
    echo "[INSTALL] Installation ygs-UserKeysSync"
    mkdir -p "$(dirname "$BIN_PATH")" "$(dirname "$LOGFILE")"
    # Écrase/replace l'ancien script si présent
    cp -f "$0" "$BIN_PATH" && chmod +x "$BIN_PATH"
    touch "$LOGFILE" && chmod 644 "$LOGFILE"
    if [[ ! -f "$CONFIG_FILE" ]]; then
        cat <<EOF > "$CONFIG_FILE"
API_URL="$DEFAULT_API_URL"
LOGFILE="$LOGFILE"
AUTHORIZED_KEYS="$AUTHORIZED_KEYS"
EOF
    fi
    # Force cron à écraser l'ancienne entrée
    echo "*/10 * * * * root $BIN_PATH --sync >> $LOGFILE 2>&1" > "$CRON_FILE"
    chmod 644 "$CRON_FILE"
    echo "[INSTALL] Cron installe/reinstallé dans $CRON_FILE"
    echo "[INSTALL] ygs-UserKeysSync installé à $BIN_PATH (remplacement auto si déjà existant)"
}

remove_sync() {
    echo "[REMOVE] Desinstallation ygs-UserKeysSync"
    rm -f "$BIN_PATH" "$CRON_FILE" "$CONFIG_FILE"
    rm -f "$LOGFILE"
    echo "[REMOVE] Fichiers supprimes"
}

action="${1:-}"
case "$action" in
    --install) install_sync ;;
    --remove)  remove_sync ;;
    --sync|"") sync_keys ;;
    *) echo "Usage: $0 [--install|--remove|--sync]" ; exit 1 ;;
esac

exit 0
