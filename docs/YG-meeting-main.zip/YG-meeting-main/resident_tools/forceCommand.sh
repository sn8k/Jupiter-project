#!/bin/bash
# File: /usr/local/bin/forcecommand.sh
# Config: /etc/meeting/forcecommand.json
# Version: 3.12.0
# Date: 2025-06-24
# Author: Meeting Server Team
# Description: Meeting Server - All tunnels passwordless, CLI UX couleur.

################################################################################
BIN_TARGET="/usr/local/bin/forcecommand.sh"
if [[ ! -e "$BIN_TARGET" ]]; then
  cp "$0" "$BIN_TARGET" && chmod +x "$BIN_TARGET"
fi
TARGET_PATH="/usr/local/bin"
if ! echo "$PATH" | grep -q "$TARGET_PATH"; then
  export PATH="$TARGET_PATH:$PATH"
fi

DEBUG_MODE=0
CONFIG="/etc/meeting/forcecommand.json"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --debug) DEBUG_MODE=1; shift ;;
    --config) CONFIG="$2"; shift 2 ;;
    --config=*) CONFIG="${1#*=}"; shift ;;
    *) shift ;;
  esac
done

if [[ -n "${FORCECOMMAND_CONFIG:-}" ]]; then
  CONFIG="$FORCECOMMAND_CONFIG"
fi

LOG=$(jq -r '.log_path // "/var/log/meeting/forcecommand.log"' "$CONFIG")

function debug_print() {
  if [[ $DEBUG_MODE -eq 1 ]]; then
    echo -e "\033[0;37m[DEBUG] $1\033[0m"
  fi
}

function log_cmd() {
  local devicekey="$1" service="$2" result="$3"
  if ! echo "$(date '+%Y-%m-%d %H:%M:%S') | $USER | $service | $devicekey | $result" >> "$LOG" 2>/dev/null; then
    echo -e "\033[0;90m[Log] Can't write to $LOG\033[0m" >&2
  fi
}

SERVER_URL=$(jq -r '.server_url' "$CONFIG")
API=$(jq -r '.api_url' "$CONFIG")
SCRIPT_VERSION="3.12.0"
debug_print "Using config $CONFIG"
debug_print "SERVER_URL=$SERVER_URL"
debug_print "API=$API"
if ! getent hosts "$SERVER_URL" >/dev/null 2>&1; then
  SERVER_URL=$(echo "$API" | awk -F[/:] '{print $4}')
fi
MIN_KEYLEN=$(jq -r '.min_devicekey_length // 6' "$CONFIG")
BOX_WIDTH=$(jq -r '.box_width // 30' "$CONFIG")
DEFAULT_USER=$(jq -r '.default_user // "device"' "$CONFIG")
DEFAULT_PATH=$(jq -r '.default_path // "/path"' "$CONFIG")

DEFAULT_SERVICES=(ssh http relay vnc scp)
DEFAULT_USAGE=(
  "ssh <devicekey>"
  "http <devicekey>"
  "relay <devicekey> <port>"
  "vnc <devicekey>"
  "scp <devicekey>"
)
DEFAULT_DESCRIPTIONS=(
  "connect to remote device ssh"
  "open HTTP relay"
  "relay custom port"
  "Relay VNC port"
  "file transfer via scp"
)

KNOWN_HOSTS_FILE="$HOME/.ssh/meeting_known_hosts"
hostkey=$(curl -s "$API/ssh-hostkey")
debug_print "Fetching host key from $API/ssh-hostkey"
if [[ -n "$hostkey" ]]; then
  mkdir -p "$(dirname "$KNOWN_HOSTS_FILE")"
  if [[ -f "$KNOWN_HOSTS_FILE" ]]; then
    if ! grep -qxF "$hostkey" "$KNOWN_HOSTS_FILE" >/dev/null 2>&1; then
      ssh-keygen -R "$SERVER_URL" -f "$KNOWN_HOSTS_FILE" >/dev/null 2>&1 || true
      echo "$hostkey" >> "$KNOWN_HOSTS_FILE"
    fi
  else
    echo "$hostkey" > "$KNOWN_HOSTS_FILE"
  fi
fi

SSH_KEY_CONFIG=$(jq -r '.ssh_private_key // empty' "$CONFIG")
if [[ -n "$SSH_KEY_CONFIG" && -f "$SSH_KEY_CONFIG" ]]; then
  SSH_KEYFILE="$SSH_KEY_CONFIG"
elif [[ -f "$HOME/.ssh/id_rsa_meeting" ]]; then
  SSH_KEYFILE="$HOME/.ssh/id_rsa_meeting"
elif [[ -f "$HOME/.ssh/id_ed25519_meeting" ]]; then
  SSH_KEYFILE="$HOME/.ssh/id_ed25519_meeting"
else
  SSH_KEYFILE=""
fi

SSH_OPTIONS="-o UserKnownHostsFile=$KNOWN_HOSTS_FILE -o StrictHostKeyChecking=accept-new"
if [[ -n "$SSH_KEYFILE" ]]; then
  SSH_OPTIONS="$SSH_OPTIONS -i $SSH_KEYFILE"
  debug_print "Using SSH private key: $SSH_KEYFILE"
fi

C_RST="\033[0m"
C_BOLD="\033[1m"
C_GREY="\033[0;37m"
C_GREEN="\033[1;32m"
C_RED="\033[1;31m"
C_YELLOW="\033[1;33m"
C_CYAN="\033[1;36m"
C_BLUE="\033[1;34m"

function color_status() {
  case "$1" in
    Available) echo -e "${C_GREEN}$1${C_RST}" ;;
    Disconnected) echo -e "${C_RED}$1${C_RST}" ;;
    *) echo -e "${C_YELLOW}${1:-Unknown}${C_RST}" ;;
  esac
}
function banner() {
  echo -e "${C_BLUE}╔════════════════════════════════════════════════════════════════╗"
  echo -e "║  ${C_BOLD}Meeting Device Tunnel Terminal (forceCommand)${C_RST}${C_BLUE}  ║"
  echo -e "║         Version ${SCRIPT_VERSION}$(printf "%*s" $((54-${#SCRIPT_VERSION})) "")║"
  echo -e "╚════════════════════════════════════════════════════════════════╝${C_RST}\n"
}
function get_services_with_desc() {
  if jq -e '.services and (.services|length>0)' "$CONFIG" >/dev/null 2>&1; then
    jq -r --arg boxw "$((BOX_WIDTH-4))" '
      (.services // [])[] | select(.visible==true) | .name + " <devicekey>" + (if .description then " - " + .description else "" end)
    ' "$CONFIG"
  else
    for i in "${!DEFAULT_SERVICES[@]}"; do
      echo "${DEFAULT_USAGE[$i]} - ${DEFAULT_DESCRIPTIONS[$i]}"
    done
  fi
}
function is_valid_service() {
  local cmd="$1"
  if jq -e --arg name "$cmd" '(.services // [])[] | select(.name==$name) and .visible==true' "$CONFIG" >/dev/null 2>&1; then
    return 0
  fi
  for s in "${DEFAULT_SERVICES[@]}"; do [[ "$s" == "$cmd" ]] && return 0; done
  return 1
}
function show_box() {
  local box_content="Available services:"; local cmds=()
  while read -r cmd; do cmds+=("$cmd"); done < <(get_services_with_desc)
  local minwidth=$BOX_WIDTH; local maxlen=${#box_content}
  for c in "${cmds[@]}"; do [[ ${#c} -gt $maxlen ]] && maxlen=${#c}; done
  [[ $maxlen -lt $minwidth ]] && maxlen=$minwidth; local width=$((maxlen + 2))
  echo -ne "${C_CYAN}╔"; for ((i=0; i<width; i++)); do echo -n "═"; done; echo -e "╗${C_RST}"
  printf "${C_CYAN}║${C_RST} %-${maxlen}s ${C_CYAN}║${C_RST}\n" "$box_content"
  printf "${C_CYAN}║${C_RST} %-${maxlen}s ${C_CYAN}║${C_RST}\n" ""
  for c in "${cmds[@]}"; do
    printf "${C_CYAN}║${C_RST} %-${maxlen}s ${C_CYAN}║${C_RST}\n" "$c"
  done
  echo -ne "${C_CYAN}╚"; for ((i=0; i<width; i++)); do echo -n "═"; done; echo -e "╝${C_RST}"
}
function show_devices() {
  echo -e "${C_BOLD}Available devices:${C_RST}"
  local tunnels_json; tunnels_json=$(curl -s "$API/tunnels")
  declare -A tunnel_map
  if echo "$tunnels_json" | jq . >/dev/null 2>&1; then
    while read -r dkey svc; do
      tunnel_map["$dkey"]+="$svc, "
    done < <(echo "$tunnels_json" | jq -r '.tunnels[] | "\(.device_key) \(.service)"')
  fi
  local list_json; list_json=$(curl -s "$API/devices?limit=1000")
  echo "$list_json" | jq -r '.devices[]?.device_key' | while read -r dev; do
    [[ -z "$dev" ]] && continue
    local status_json status; status_json=$(curl -s "$API/devices/$dev/availability")
    status=$(echo "$status_json" | jq -r '.status')
    if [[ "$status" == "Available" ]]; then
      local services="${tunnel_map[$dev]}"
      [[ -n "$services" ]] && services=${services%, } || services="--"
      echo " $dev ($services)"
    fi
  done
}
function show_help() {
  echo -e "${C_BOLD}Available commands:${C_RST}"
  get_services_with_desc
  echo; echo -e "${C_BOLD}Debug/hidden commands:${C_RST}"
  echo -e " showDevices     -- List all registered devicekeys"
  echo -e " help            -- Show this help"
  echo -e " getOut          -- Return to meeting shell (keep ssh session open)"
}

wait_for_port_open() {
  local host="$1" port="$2" timeout="${3:-20}" elapsed=0
  while ((elapsed < timeout)); do
    (echo > /dev/tcp/$host/$port) >/dev/null 2>&1 && return 0
    sleep 1; ((elapsed++))
  done
  return 1
}

################################################################################
# Main loop
################################################################################
while true; do
  banner
  show_box
  echo -ne "${C_YELLOW}${C_BOLD}ssh>${C_RST} "
  read -r line
  cmd=$(awk '{print $1}' <<<"$line")
  arg=$(awk '{print $2}' <<<"$line" | tr '[:lower:]' '[:upper:]')
  arg2=$(awk '{print $3}' <<<"$line")

  # HIDDEN: updateServer
  if [[ "$cmd" == "updateServer" ]]; then
    echo -e "${C_CYAN}${C_BOLD}This will update the backend (meeting-backend) and related services!${C_RST}"
    echo -ne "${C_YELLOW}Continue? [y/N] ${C_RST}"
    read -r confirm
    if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
      echo -e "${C_GREY}Update cancelled.${C_RST}"; continue
    fi

    (
      set -e
      cd /var/www/meeting-backend || exit 1

      echo -e "${C_CYAN}Updating branch...${C_RST}"
      ./tools/update_branch.sh

      echo -e "${C_CYAN}Updating backend logs (root required)...${C_RST}"
      sudo ./tools/log_create.sh

      echo -e "${C_CYAN}Database check...${C_RST}"
      php ./admin/db_check.php

      echo -e "${C_CYAN}Updating forcecommand...${C_RST}"
      ./tools/setup-files/install_forcecommand.sh

      echo -e "${C_CYAN}Stopping ygs-proxy...${C_RST}"
      sudo systemctl stop ygs-proxy

      echo -e "${C_CYAN}Updating ygs-proxy...${C_RST}"
      ./tools/setup-files/install_proxy.sh

      echo -e "${C_CYAN}Updating NTP server...${C_RST}"
      ./tools/setup-files/install_ntp_server.sh

      echo -e "${C_GREEN}✔ All backend updates completed!${C_RST}"
    )
    echo -e "${C_YELLOW}Restarting forceCommand...${C_RST}"
    exec "$BIN_TARGET"
    exit 0
  fi

  if [[ "$cmd" == "help" ]]; then show_help; continue; fi
  if [[ "$cmd" == "showDevices" ]]; then show_devices; echo -e "${C_GREY}(Press Enter to continue)${C_RST}"; read -r _; continue; fi
  if [[ "$cmd" == "getOut" ]]; then echo -e "${C_YELLOW}Returning to shell... (SSH session remains open)${C_RST}"; exec /bin/bash --login; break; fi
  if ! is_valid_service "$cmd"; then echo -e "${C_RED}Unknown command. Type 'help' for assistance.${C_RST}"; echo -e "${C_GREY}(Press Enter to continue)${C_RST}"; read -r _; continue; fi
  if [[ ! "$arg" =~ ^[A-F0-9]{$MIN_KEYLEN,32}$ ]]; then echo -e "${C_RED}Invalid device key. Must be at least $MIN_KEYLEN hex digits.${C_RST}"; echo -e "${C_GREY}(Press Enter to continue)${C_RST}"; read -r _; continue; fi

  resp=$(curl -s -H "Accept: application/json" "$API/devices?prefix=$arg")
  debug_print "$resp"
  match=$(jq -r '.devices[0].device_key // empty' <<<"$resp")
  if [[ -z "$match" ]]; then echo -e "${C_RED}Unknown device key.${C_RST}"; log_cmd "$arg" "$cmd" "Unknown device key"; echo -e "${C_GREY}(Press Enter to continue)${C_RST}"; read -r _; continue; fi
  authorized=$(jq -r '.devices[0].authorized' <<<"$resp")
  if [[ "$authorized" != "1" && "$authorized" != "true" ]]; then echo -e "${C_RED}Device is not authorized.${C_RST}"; log_cmd "$match" "$cmd" "Not authorized"; echo -e "${C_GREY}(Press Enter to continue)${C_RST}"; read -r _; continue; fi

  # SSH
  if [[ "$cmd" == "ssh" ]]; then
    max_wait=20; wait_time=0; tunnel_ready=0; poll_interval=2; upnp_msg_shown=0
    echo -ne "${C_GREY}Requesting ssh tunnel, please wait"
    while [[ $wait_time -lt $max_wait ]]; do
      portresp=$(curl -s -H "Accept: application/json" -X POST "$API/devices/$match/request-tunnel-port" -d "{\"service\":\"ssh\"}")
      debug_print "$portresp"
      if echo "$portresp" | jq . >/dev/null 2>&1; then
        port=$(jq -r '.port // empty' <<<"$portresp")
        error_msg=$(jq -r '.error // empty' <<<"$portresp")
        upnp_msg=$(jq -r '.upnp // empty' <<<"$portresp")
      else
        port=""; error_msg="Unexpected API response"; upnp_msg=""
      fi
      if [[ -n "$error_msg" && "$error_msg" != "null" ]]; then echo -e "\n${C_RED}Error: $error_msg${C_RST}"; log_cmd "$match" "$cmd" "$error_msg"; tunnel_ready=0; break; fi
      if [[ -n "$port" && "$port" != "null" ]]; then
        echo -ne "${C_GREY}Waiting for port $port to open..."
        if wait_for_port_open "$SERVER_URL" "$port" 20; then
          echo -e " ${C_GREEN}OK${C_RST}"
          tunnel_ready=1
        else
          echo -e " ${C_RED}Port $port is not open after wait.${C_RST}"
          log_cmd "$match" "$cmd" "Tunnel not ready after wait"
          break
        fi
        break
      fi
      if [[ -n "$upnp_msg" && "$upnp_msg" != "null" && $upnp_msg_shown -eq 0 ]]; then echo -e "\n${C_YELLOW}[UPnP] $upnp_msg${C_RST}"; upnp_msg_shown=1; fi
      echo -ne "."; sleep $poll_interval; wait_time=$((wait_time+poll_interval))
    done
    echo ""
    if [[ $tunnel_ready -eq 1 ]]; then
      SSH_CONNECT_CMD="ssh $SSH_OPTIONS -p $port $DEFAULT_USER@$SERVER_URL"
      echo -e "${C_GREEN}✔ SSH tunnel ready! Connecting with:\n${C_CYAN}$SSH_CONNECT_CMD${C_RST}"
      log_cmd "$match" "$cmd" "$SSH_CONNECT_CMD"
      eval "$SSH_CONNECT_CMD"
      if [[ $? -ne 0 ]]; then echo -e "${C_RED}SSH connection failed.${C_RST}"; fi
    else
      echo -e "${C_RED}Error: ssh tunnel is not available after $max_wait seconds.${C_RST}"; log_cmd "$match" "$cmd" "Tunnel not available"
    fi
    continue
  fi

  # HTTP
  if [[ "$cmd" == "http" ]]; then
    max_wait=20; wait_time=0; tunnel_ready=0; poll_interval=2; upnp_msg_shown=0
    echo -ne "${C_GREY}Requesting http tunnel, please wait"
    while [[ $wait_time -lt $max_wait ]]; do
      portresp=$(curl -s -H "Accept: application/json" -X POST "$API/devices/$match/service" -d "{\"service\":\"http\"}")
      debug_print "$portresp"
      if echo "$portresp" | jq . >/dev/null 2>&1; then
        port=$(jq -r '.port // empty' <<<"$portresp")
        error_msg=$(jq -r '.error // empty' <<<"$portresp")
        upnp_msg=$(jq -r '.upnp // empty' <<<"$portresp")
      else
        port=""; error_msg="Unexpected API response"; upnp_msg=""
      fi
      if [[ -n "$error_msg" && "$error_msg" != "null" ]]; then
        echo -e "\n${C_RED}Error: $error_msg${C_RST}"; log_cmd "$match" "$cmd" "$error_msg"; tunnel_ready=0; break
      fi
      if [[ -n "$port" && "$port" != "null" ]]; then
        echo -ne "${C_GREY}Waiting for port $port to open..."
        if wait_for_port_open "$SERVER_URL" "$port" 20; then
          echo -e " ${C_GREEN}OK${C_RST}"
          tunnel_ready=1
        else
          echo -e " ${C_RED}Port $port is not open after wait.${C_RST}"
          log_cmd "$match" "$cmd" "Tunnel not ready after wait"
          break
        fi
        break
      fi
      if [[ -n "$upnp_msg" && "$upnp_msg" != "null" && $upnp_msg_shown -eq 0 ]]; then echo -e "\n${C_YELLOW}[UPnP] $upnp_msg${C_RST}"; upnp_msg_shown=1; fi
      echo -ne "."; sleep $poll_interval; wait_time=$((wait_time+poll_interval))
    done
    echo ""
    if [[ $tunnel_ready -eq 1 ]]; then
      proto="http"
      OUT_URL="$proto://$SERVER_URL:$port"
      echo -e "${C_GREEN}✔ HTTP tunnel ready! Go to: ${C_YELLOW}$OUT_URL${C_RST}"
      log_cmd "$match" "$cmd" "$OUT_URL"
    else
      echo -e "${C_RED}Error: http tunnel is not available after $max_wait seconds.${C_RST}"; log_cmd "$match" "$cmd" "Tunnel not available"
    fi
    echo -e "${C_GREY}(Press Enter to continue)${C_RST}"; read -r _; continue
  fi

  # VNC
  if [[ "$cmd" == "vnc" ]]; then
    max_wait=20; wait_time=0; tunnel_ready=0; poll_interval=2; upnp_msg_shown=0
    echo -ne "${C_GREY}Requesting vnc tunnel, please wait"
    while [[ $wait_time -lt $max_wait ]]; do
      portresp=$(curl -s -H "Accept: application/json" -X POST "$API/devices/$match/service" -d "{\"service\":\"vnc\"}")
      debug_print "$portresp"
      if echo "$portresp" | jq . >/dev/null 2>&1; then
        port=$(jq -r '.port // empty' <<<"$portresp")
        error_msg=$(jq -r '.error // empty' <<<"$portresp")
        upnp_msg=$(jq -r '.upnp // empty' <<<"$portresp")
      else
        port=""; error_msg="Unexpected API response"; upnp_msg=""
      fi
      if [[ -n "$error_msg" && "$error_msg" != "null" ]]; then echo -e "\n${C_RED}Error: $error_msg${C_RST}"; log_cmd "$match" "$cmd" "$error_msg"; tunnel_ready=0; break; fi
      if [[ -n "$port" && "$port" != "null" ]]; then
        echo -ne "${C_GREY}Waiting for port $port to open..."
        if wait_for_port_open "$SERVER_URL" "$port" 20; then
          echo -e " ${C_GREEN}OK${C_RST}"
          tunnel_ready=1
        else
          echo -e " ${C_RED}Port $port is not open after wait.${C_RST}"
          log_cmd "$match" "$cmd" "Tunnel not ready after wait"
          break
        fi
        break
      fi
      if [[ -n "$upnp_msg" && "$upnp_msg" != "null" && $upnp_msg_shown -eq 0 ]]; then echo -e "\n${C_YELLOW}[UPnP] $upnp_msg${C_RST}"; upnp_msg_shown=1; fi
      echo -ne "."; sleep $poll_interval; wait_time=$((wait_time+poll_interval))
    done
    echo ""
    if [[ $tunnel_ready -eq 1 ]]; then
      OUT_URL="vnc://$SERVER_URL:$port"
      echo -e "${C_GREEN}✔ VNC tunnel ready! Connect to: ${C_YELLOW}$OUT_URL${C_RST}"
      log_cmd "$match" "$cmd" "$OUT_URL"
    else
      echo -e "${C_RED}Error: vnc tunnel is not available after $max_wait seconds.${C_RST}"; log_cmd "$match" "$cmd" "Tunnel not available"
    fi
    echo -e "${C_GREY}(Press Enter to continue)${C_RST}"; read -r _; continue
  fi

  # SCP
  if [[ "$cmd" == "scp" ]]; then
    max_wait=20; wait_time=0; tunnel_ready=0; poll_interval=2; upnp_msg_shown=0
    echo -ne "${C_GREY}Requesting scp tunnel, please wait"
    while [[ $wait_time -lt $max_wait ]]; do
      portresp=$(curl -s -H "Accept: application/json" -X POST "$API/devices/$match/service" -d "{\"service\":\"scp\"}")
      debug_print "$portresp"
      if echo "$portresp" | jq . >/dev/null 2>&1; then
        port=$(jq -r '.port // empty' <<<"$portresp")
        error_msg=$(jq -r '.error // empty' <<<"$portresp")
        upnp_msg=$(jq -r '.upnp // empty' <<<"$portresp")
      else
        port=""; error_msg="Unexpected API response"; upnp_msg=""
      fi
      if [[ -n "$error_msg" && "$error_msg" != "null" ]]; then echo -e "\n${C_RED}Error: $error_msg${C_RST}"; log_cmd "$match" "$cmd" "$error_msg"; tunnel_ready=0; break; fi
      if [[ -n "$port" && "$port" != "null" ]]; then
        echo -ne "${C_GREY}Waiting for port $port to open..."
        if wait_for_port_open "$SERVER_URL" "$port" 20; then
          echo -e " ${C_GREEN}OK${C_RST}"
          tunnel_ready=1
        else
          echo -e " ${C_RED}Port $port is not open after wait.${C_RST}"
          log_cmd "$match" "$cmd" "Tunnel not ready after wait"
          break
        fi
        break
      fi
      if [[ -n "$upnp_msg" && "$upnp_msg" != "null" && $upnp_msg_shown -eq 0 ]]; then echo -e "\n${C_YELLOW}[UPnP] $upnp_msg${C_RST}"; upnp_msg_shown=1; fi
      echo -ne "."; sleep $poll_interval; wait_time=$((wait_time+poll_interval))
    done
    echo ""
    if [[ $tunnel_ready -eq 1 ]]; then
      SCP_CMD="scp $SSH_OPTIONS -P $port $DEFAULT_USER@$SERVER_URL:$DEFAULT_PATH ."
      WINSCP_SESSION="$DEFAULT_USER@$SERVER_URL:$port"
      echo -e "${C_GREEN}✔ SCP tunnel ready! Use: ${C_CYAN}$SCP_CMD${C_RST}"
      echo -e "${C_GREEN}✔ WinSCP session:\n${C_YELLOW}$WINSCP_SESSION${C_RST}"
      log_cmd "$match" "$cmd" "$SCP_CMD | $WINSCP_SESSION"
    else
      echo -e "${C_RED}Error: scp tunnel is not available after $max_wait seconds.${C_RST}"; log_cmd "$match" "$cmd" "Tunnel not available"
    fi
    echo -e "${C_GREY}(Press Enter to continue)${C_RST}"; read -r _; continue
  fi

  # RELAY
  if [[ "$cmd" == "relay" ]]; then
    port_param="$arg2"
    if [[ -z "$port_param" ]]; then echo -ne "${C_YELLOW}Port to relay? ${C_RST}"; read -r port_param; fi
    if [[ ! "$port_param" =~ ^[0-9]+$ ]]; then echo -e "${C_RED}Invalid port number.${C_RST}"; echo -e "${C_GREY}(Press Enter to continue)${C_RST}"; read -r _; continue; fi
    max_wait=20; wait_time=0; tunnel_ready=0; poll_interval=2
    echo -ne "${C_GREY}Requesting relay tunnel on port $port_param, please wait"
    while [[ $wait_time -lt $max_wait ]]; do
      portresp=$(curl -s -H "Accept: application/json" -X POST "$API/devices/$match/service" -d "{\"service\":\"relay\",\"port\":$port_param}")
      debug_print "$portresp"
      if echo "$portresp" | jq . >/dev/null 2>&1; then
        url=$(jq -r '.url // empty' <<<"$portresp")
        error_msg=$(jq -r '.error // empty' <<<"$portresp")
        port=$(jq -r '.port // empty' <<<"$portresp")
      else
        url=""; error_msg="Unexpected API response"; port=""
      fi
      if [[ -n "$error_msg" && "$error_msg" != "null" ]]; then echo -e "\n${C_RED}Error: $error_msg${C_RST}"; log_cmd "$match" "$cmd" "$error_msg"; tunnel_ready=0; break; fi
      if [[ -n "$port" && "$port" != "null" ]]; then
        echo -ne "${C_GREY}Waiting for port $port to open..."
        if wait_for_port_open "$SERVER_URL" "$port" 20; then
          echo -e " ${C_GREEN}OK${C_RST}"
          tunnel_ready=1
          url="$SERVER_URL:$port"
        else
          echo -e " ${C_RED}Port $port is not open after wait.${C_RST}"
          log_cmd "$match" "$cmd" "Tunnel not ready after wait"
          break
        fi
        break
      fi
      echo -ne "."; sleep $poll_interval; wait_time=$((wait_time+poll_interval))
    done
    echo ""
    if [[ $tunnel_ready -eq 1 ]]; then
      echo -e "${C_GREEN}✔ Relay tunnel ready! Use: ${C_YELLOW}http://$url${C_RST}"
      log_cmd "$match" "$cmd" "http://$url"
    else
      echo -e "${C_RED}Error: relay tunnel is not available after $max_wait seconds.${C_RST}"; log_cmd "$match" "$cmd" "Tunnel not available"
    fi
    echo -e "${C_GREY}(Press Enter to continue)${C_RST}"; read -r _; continue
  fi

done

exit 0
