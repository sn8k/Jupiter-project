#!/bin/bash
# File: /usr/local/bin/ygs-KeysSync.sh
# Version: 1.3.0
# Date: 2025-05-25
# Author: Meeting DevOps
# Description: Synchronisation interactive (ou service) des clés SSH devices via API Meeting.
#   - Sync auto des clés vers /home/meeting/.ssh/authorized_keys
#   - Menu CLI complet (install/remove/sync/show/backup/restore/config/quit)
#   - Loglevel configurable, logs horodatés, sudo auto
#   - Ajout automatique de la règle sudoers pour www-data (API trigger)
#
# CHANGELOG:
# 1.3.0 (2025-05-25): Ajout de la gestion automatique des droits sudoers www-data pour appel API, amélioration install/remove.
# 1.2.0 (2025-05-25): Version avec install/remove interactif, robustesse production, logs, sudo auto, etc.
################################################################################

# ==== RELANCE EN SUDO SI NÉCESSAIRE ====
if [[ "$EUID" -ne 0 ]]; then
    echo "[INFO] Relaunching as root (sudo)..."
    exec sudo -E "$0" "$@"
    exit 1
fi

################################################################################
# === CONFIGURATION ===
BIN_PATH="/usr/local/bin/ygs-KeysSync.sh"
CONFIG_FILE="/etc/ygs-keyssync.conf"
LOGFILE="/var/log/ygs-keyssync.log"
LOGLEVEL_FILE="/etc/ygs-keyssync.loglevel"
SUDOERS_FILE="/etc/sudoers.d/ygs-keyssync"

DEFAULT_API_URL="https://meeting.ygsoft.fr/api/devices?authorized=1"
AUTHORIZED_KEYS="/home/meeting/.ssh/authorized_keys"

API_URL="${API_URL:-$DEFAULT_API_URL}"
[[ -f "$CONFIG_FILE" ]] && source "$CONFIG_FILE"
[[ -f "$LOGLEVEL_FILE" ]] && LOGLEVEL=$(cat "$LOGLEVEL_FILE") || LOGLEVEL="info"
LOGLEVEL="${LOGLEVEL:-info}"

TMP_KEYS="/tmp/authorized_keys.tmp.$$"

################################################################################
# === LOGGING (loglevel : error, warning, info, debug) ===
log_msg() {
    local lvl="$1"; shift
    local msg="$*"
    local levels=(error warning info debug)
    local log_index=0; for i in "${!levels[@]}"; do [[ "${levels[$i]}" = "$LOGLEVEL" ]] && log_index=$i; done
    local msg_index=0; for i in "${!levels[@]}"; do [[ "${levels[$i]}" = "$lvl" ]] && msg_index=$i; done
    [[ $msg_index -le $log_index ]] || return 0
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [$lvl] $msg" >> "$LOGFILE"
}

set_loglevel() {
    local value="$1"
    case "$value" in
        info|warning|error|debug)
            LOGLEVEL="$value"
            echo "$value" > "$LOGLEVEL_FILE"
            log_msg "info" "Loglevel set to $value"
            ;;
        *)
            echo "Usage: setLogLevel <info|warning|error|debug>"
            ;;
    esac
}

################################################################################
# === INSTALLATION & DESINSTALLATION ===

install_keyssync() {
    echo "[INSTALL] Installation de ygs-KeysSync.sh..."
    # Copie le script dans /usr/local/bin si ce n'est pas déjà fait
    if [[ "$0" != "$BIN_PATH" ]]; then
        cp "$0" "$BIN_PATH"
        chmod +x "$BIN_PATH"
        echo "[INSTALL] Script copié dans $BIN_PATH"
    fi

    # Crée le fichier config si absent
    if [[ ! -f "$CONFIG_FILE" ]]; then
        echo "API_URL=\"$DEFAULT_API_URL\"" > "$CONFIG_FILE"
        echo "[INSTALL] Fichier de configuration créé : $CONFIG_FILE"
    else
        echo "[INSTALL] $CONFIG_FILE déjà présent."
    fi

    # Crée log et loglevel
    touch "$LOGFILE"
    chmod 644 "$LOGFILE"
    if [[ ! -f "$LOGLEVEL_FILE" ]]; then
        echo "info" > "$LOGLEVEL_FILE"
    fi

    # Permissions
    chown root:root "$BIN_PATH" "$LOGFILE" "$CONFIG_FILE" "$LOGLEVEL_FILE" 2>/dev/null || true

    # Vérifie le répertoire .ssh et le fichier authorized_keys
    su - meeting -c "mkdir -p $(dirname "$AUTHORIZED_KEYS")"
    if [[ ! -f "$AUTHORIZED_KEYS" ]]; then
        su - meeting -c "touch $AUTHORIZED_KEYS"
        chown meeting:meeting "$AUTHORIZED_KEYS"
        chmod 600 "$AUTHORIZED_KEYS"
    fi

    # Ajout sudoers pour www-data (pour appel API depuis PHP)
    SUDOERS_LINE="www-data ALL=(ALL) NOPASSWD: $BIN_PATH"
    if ! grep -qF "$SUDOERS_LINE" "$SUDOERS_FILE" 2>/dev/null; then
        echo "$SUDOERS_LINE" > "$SUDOERS_FILE"
        chmod 440 "$SUDOERS_FILE"
        echo "[INSTALL] Droits sudo ajoutés pour www-data dans $SUDOERS_FILE"
    else
        echo "[INSTALL] Droits sudo déjà présents ($SUDOERS_FILE)"
    fi

    # Ajout cron (optionnel)
    echo "Voulez-vous planifier une synchronisation automatique ? (y/n)"
    read -r rep
    if [[ "$rep" =~ ^[yY]$ ]]; then
        cronjob="*/15 * * * * root $BIN_PATH sync > /dev/null 2>&1"
        if ! grep -qF "$BIN_PATH sync" /etc/crontab; then
            echo "$cronjob" >> /etc/crontab
            echo "[INSTALL] Cron ajouté : $cronjob"
        else
            echo "[INSTALL] Cron déjà présent."
        fi
    fi
    read -n1 -rsp $'\nPress any key...'
}

remove_keyssync() {
    echo "[REMOVE] Suppression de ygs-KeysSync.sh et fichiers associés."
    # Supprime le binaire
    rm -f "$BIN_PATH"
    # Supprime la config, log, loglevel
    rm -f "$CONFIG_FILE" "$LOGLEVEL_FILE" "$LOGFILE"
    # Supprime les backups authorized_keys
    rm -f /home/meeting/.ssh/authorized_keys.bak.*
    # Supprime le cron éventuel
    sed -i "\|$BIN_PATH sync|d" /etc/crontab
    # Supprime sudoers
    rm -f "$SUDOERS_FILE"
    echo "[REMOVE] Suppression terminée."
    read -n1 -rsp $'\nPress any key...'
}

################################################################################
# === ACTIONS DE BASE ===

sync_keys() {
    log_msg "info" "Lancement de la synchronisation des clés SSH via $API_URL"
    curl -sf "$API_URL" | \
        jq -r '.devices[] | select(.ssh_public_key != null and .ssh_public_key != "") | .ssh_public_key' > "$TMP_KEYS"

    if [[ ! -s "$TMP_KEYS" ]]; then
        log_msg "error" "Pas de clé publique récupérée via l'API ($API_URL)"
        rm -f "$TMP_KEYS"
        echo "[ERROR] Pas de clé publique récupérée."
        return 1
    fi

    cp -f "$AUTHORIZED_KEYS" "$AUTHORIZED_KEYS.bak.$(date +%Y%m%d_%H%M%S)" 2>/dev/null || true
    mv "$TMP_KEYS" "$AUTHORIZED_KEYS"
    chown meeting:meeting "$AUTHORIZED_KEYS"
    chmod 600 "$AUTHORIZED_KEYS"
    n=$(wc -l < "$AUTHORIZED_KEYS")
    log_msg "info" "Fichier $AUTHORIZED_KEYS synchronisé avec $n clés publiques."
    echo "[OK] Fichier $AUTHORIZED_KEYS synchronisé avec $n clés publiques."
    return 0
}

show_keys() {
    if [[ -f "$AUTHORIZED_KEYS" ]]; then
        echo "===== Clés publiques dans $AUTHORIZED_KEYS : ====="
        cat "$AUTHORIZED_KEYS"
        n=$(wc -l < "$AUTHORIZED_KEYS")
        echo "===== Total : $n clés ====="
    else
        echo "[INFO] Aucun fichier $AUTHORIZED_KEYS trouvé."
    fi
    read -n1 -rsp $'\nPress any key...'
}

backup_keys() {
    local backup="$AUTHORIZED_KEYS.bak.$(date +%Y%m%d_%H%M%S)"
    cp -f "$AUTHORIZED_KEYS" "$backup" && \
        log_msg "info" "Backup vers $backup" && \
        echo "[OK] Backup dans $backup" || \
        (log_msg "error" "Backup échoué" && echo "[ERROR] Backup échoué")
    read -n1 -rsp $'\nPress any key...'
}

restore_keys() {
    local lastbak
    lastbak=$(ls -1t "$AUTHORIZED_KEYS.bak."* 2>/dev/null | head -n1)
    if [[ -z "$lastbak" ]]; then
        echo "[ERROR] Aucune sauvegarde trouvée."
        log_msg "error" "Aucune sauvegarde à restaurer"
        return 1
    fi
    cp -f "$lastbak" "$AUTHORIZED_KEYS" && \
        chown meeting:meeting "$AUTHORIZED_KEYS" && chmod 600 "$AUTHORIZED_KEYS" && \
        log_msg "info" "Restauration depuis $lastbak" && \
        echo "[OK] Restauré depuis $lastbak"
    read -n1 -rsp $'\nPress any key...'
}

show_config() {
    echo "===== CONFIGURATION ACTUELLE ====="
    echo "API_URL         : $API_URL"
    echo "AUTHORIZED_KEYS : $AUTHORIZED_KEYS"
    echo "LOGFILE         : $LOGFILE"
    echo "LOGLEVEL        : $LOGLEVEL"
    echo "CONFIG_FILE     : $CONFIG_FILE"
    echo "SUDOERS_FILE    : $SUDOERS_FILE"
    read -n1 -rsp $'\nPress any key...'
}

################################################################################
# === MENU INTERACTIF ===
draw_menu() {
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║                YGS-KEYSSYNC MENU                             ║"
    echo "╠════════════════════════════════════════════════════════════════╣"
    echo "║  install     : Installer/Réinstaller ygs-KeysSync             ║"
    echo "║  remove      : Désinstaller complètement ygs-KeysSync         ║"
    echo "║  sync        : Synchroniser les clés (API → authorized_keys)  ║"
    echo "║  show        : Afficher toutes les clés actuelles             ║"
    echo "║  backup      : Backup du fichier authorized_keys              ║"
    echo "║  restore     : Restaurer le dernier backup                    ║"
    echo "║  config      : Afficher la configuration                      ║"
    echo "║  setLogLevel <val> : Définir le loglevel (info/warning/...)   ║"
    echo "║  quit        : Quitter le menu                                ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
}

cli_menu() {
    while true; do
        clear
        echo -e "\n🟦  \033[1mYGS-KEYSSYNC\033[0m  (Meeting SSH Keys Sync Utility)\n"
        draw_menu
        echo
        echo -ne "\033[1;36mygs-keyssync > \033[0m"
        read -r cmd args
        case "$(echo "$cmd" | tr '[:upper:]' '[:lower:]')" in
            install)     install_keyssync ;;
            remove)      remove_keyssync ;;
            sync)        sync_keys ;;
            show)        show_keys ;;
            backup)      backup_keys ;;
            restore)     restore_keys ;;
            config)      show_config ;;
            setloglevel) set_loglevel "$args" ;;
            quit|exit)   echo -e "\nBye!"; exit 0 ;;
            *)           echo "Commande inconnue : $cmd"; sleep 1 ;;
        esac
    done
}

################################################################################
# === ENTRYPOINT ===
if [[ $# -gt 0 ]]; then
    case "$1" in
        install)     install_keyssync; exit 0 ;;
        remove)      remove_keyssync; exit 0 ;;
        sync)        sync_keys; exit $? ;;
        show)        show_keys; exit 0 ;;
        backup)      backup_keys; exit 0 ;;
        restore)     restore_keys; exit 0 ;;
        config)      show_config; exit 0 ;;
        setloglevel) set_loglevel "$2"; exit 0 ;;
        *)           echo "Commande inconnue : $1"; exit 1 ;;
    esac
fi

cli_menu

exit 0
