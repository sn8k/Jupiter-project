const { spawn } = require('child_process');
const net = require('net');
const path = require('path');
let proc;

beforeAll(done => {
  proc = spawn('node', ['reverse_tunnel/server/proxy.js'], {
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, YGS_DEBUG: '0' }
  });
  setTimeout(done, 1000);
});

afterAll(() => {
  proc.kill();
});

test('proxy accepts agent handshake', done => {
  const sock = net.createConnection({ port: 9001 }, () => {
    sock.write(JSON.stringify({ token: 'bXlfZnVja2luX3Rva2VuX2J5X3lncw==', name: 'testdev' }));
  });
  setTimeout(() => {
    expect(sock.destroyed).toBe(false);
    sock.end();
    done();
  }, 300);
});
