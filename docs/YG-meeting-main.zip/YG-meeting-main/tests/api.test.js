const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
let server;
const dataRoot = path.join(__dirname, 'tmp_data');
const dbPath = path.join(dataRoot, 'test.sqlite');

beforeAll(done => {
  if (!fs.existsSync(dataRoot)) fs.mkdirSync(dataRoot, { recursive: true });
  const hostKey = 'testhost ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFakeHostKeyExample\n';
  fs.writeFileSync(path.join(dataRoot, 'meeting_id_rsa.pub'), hostKey);
  if (fs.existsSync(dbPath)) fs.unlinkSync(dbPath);
  execSync(
    `sqlite3 ${dbPath} "CREATE TABLE devices (
      device_key TEXT PRIMARY KEY,
      token_code TEXT,
      token_count INTEGER,
      registered_at TEXT,
      authorized INTEGER,
      ap_ssid TEXT,
      ap_password TEXT,
      http_pw_low TEXT,
      http_pw_medium TEXT,
      http_pw_high TEXT,
      note TEXT,
      product_serial TEXT,
      device_type TEXT,
      bundles TEXT,
      ghost_candidate_url TEXT,
      parent_device_key TEXT,
      ip_address TEXT,
      distribution TEXT,
      ssh_public_key TEXT,
      ssh_user TEXT
    );
    INSERT INTO devices(device_key, token_code, token_count, registered_at, authorized)
    VALUES ('DEV1','tok',0,'2025-01-01',1);"`
  );
  server = spawn('php', ['-S', '127.0.0.1:8000'], {
    cwd: path.join(__dirname, '..'),
    env: {
      ...process.env,
      MEETING_SECRETS_PATH: path.join(__dirname, '..', 'config.secrets.php'),
      MEETING_DATA_ROOT: dataRoot,
      DB_DSN: 'sqlite:' + dbPath,
      DB_USER: '',
      DB_PASS: ''
    }
  });
  setTimeout(done, 1000);
});

afterAll(() => {
  server.kill();
  fs.rmSync(dataRoot, { recursive: true, force: true });
});

test('API index responds with JSON', async () => {
  const res = await fetch('http://127.0.0.1:8000/api');
  expect(res.headers.get('content-type')).toMatch(/application\/json/);
  const data = await res.json();
  expect(typeof data).toBe('object');
});

test('GET /api/devices returns list', async () => {
  const res = await fetch('http://127.0.0.1:8000/api/devices');
  expect(res.status).toBe(200);
  const body = await res.json();
  expect(Array.isArray(body.devices)).toBe(true);
});

test('GET /api/ssh-hostkey returns host key', async () => {
  const res = await fetch('http://127.0.0.1:8000/api/ssh-hostkey');
  const text = await res.text();
  expect(text).toMatch(/ssh-ed25519/);
});
