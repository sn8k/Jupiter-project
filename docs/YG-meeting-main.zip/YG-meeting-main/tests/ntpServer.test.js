const { spawn } = require('child_process');
const dgram = require('dgram');
const os = require('os');
const path = require('path');
const fs = require('fs');

const port = 10500;
const logFile = path.join(os.tmpdir(), 'ntp_test.log');
let proc;

beforeAll(done => {
  proc = spawn('node', ['reverse_tunnel/server/ntp-server.js'], {
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, NTP_PORT: String(port), NTP_LOG: logFile }
  });
  setTimeout(done, 500);
});

afterAll(() => {
  proc.kill();
  if (fs.existsSync(logFile)) fs.unlinkSync(logFile);
});

test('NTP server responds to UDP request', done => {
  const client = dgram.createSocket('udp4');
  client.once('message', msg => {
    expect(msg.length).toBe(48);
    client.close();
    done();
  });
  client.send(Buffer.alloc(48), port, '127.0.0.1');
});
