<?php
/**
 * MetricsController.php
 * Location: api/controllers/MetricsController.php
 * Version: 1.2.0
 * 
 * MetricsController - handles system metrics API endpoints, including advanced Linux metrics and DB checks.
 * 
 * Changelog:
 *   - v1.2.0 (2025-05-31): Centralisation config (logfile + DB params) via config.php.
 *   - v1.1.0 (2025-05-25): Ajout temperature CPU, users connectés, réseau, infos PHP process, stats BDD, fallback Windows, robustesse accrue.
 *   - v1.0.0 (2025-05-25): Création initiale.
 */
require_once __DIR__ . '/../log_helpers.php';

class MetricsController
{
    // Statique : on charge la config au tout début, dispo partout
    private static $config = null;
    private static $logFile = null;

    // Init config et logFile au premier appel
    private static function initConfig()
    {
        if (self::$config !== null) return;
        $configFile = __DIR__ . '/../config.php';
        self::$config = is_file($configFile) ? require($configFile) : [];
        self::$logFile = self::$config['metrics_logfile'] ?? (__DIR__ . '/../logs/metrics_api.log');
        ensure_log_directory(self::$logFile);
    }

    /**
     * getMetrics()
     * Returns advanced system metrics as JSON.
     * 
     * Endpoint: GET /api/metrics?action=get
     */
    public static function getMetrics()
    {
        self::initConfig();
        self::log("Received getMetrics request");

        try {
            $os = strtolower(PHP_OS);

            // -- CPU Load
            $cpuLoad = function_exists('sys_getloadavg') ? sys_getloadavg() : [null, null, null];

            // -- Memory (Linux/Unix)
            $memory = [
                'total_mb' => null,
                'free_mb'  => null,
                'used_mb'  => null
            ];
            if ($os === "linux" || $os === "darwin") {
                $meminfo = @file_get_contents("/proc/meminfo");
                if ($meminfo) {
                    preg_match('/MemTotal:\s+(\d+)/', $meminfo, $matchesTotal);
                    preg_match('/MemAvailable:\s+(\d+)/', $meminfo, $matchesFree);
                    $memory['total_mb'] = isset($matchesTotal[1]) ? intval($matchesTotal[1] / 1024) : null;
                    $memory['free_mb']  = isset($matchesFree[1]) ? intval($matchesFree[1] / 1024) : null;
                    $memory['used_mb']  = ($memory['total_mb'] !== null && $memory['free_mb'] !== null)
                        ? $memory['total_mb'] - $memory['free_mb'] : null;
                }
            } else { // Windows
                $totalMem = @shell_exec("wmic computersystem get TotalPhysicalMemory");
                $freeMem = @shell_exec("wmic OS get FreePhysicalMemory");
                $memory['total_mb'] = $totalMem ? intval(trim(preg_replace('/[^\d]/', '', $totalMem))/1048576) : null;
                $memory['free_mb'] = $freeMem ? intval(trim(preg_replace('/[^\d]/', '', $freeMem))/1024) : null;
                $memory['used_mb'] = ($memory['total_mb'] !== null && $memory['free_mb'] !== null)
                    ? $memory['total_mb'] - $memory['free_mb'] : null;
            }

            // -- Disk
            $diskFree = @disk_free_space("/");
            $diskTotal = @disk_total_space("/");
            $disk = [
                "total_bytes" => $diskTotal !== false ? floatval($diskTotal) : null,
                "free_bytes"  => $diskFree !== false ? floatval($diskFree) : null,
                "used_bytes"  => ($diskTotal !== false && $diskFree !== false) ? floatval($diskTotal) - floatval($diskFree) : null
            ];

            // -- Uptime
            $uptime = null;
            if ($os === "linux" || $os === "darwin") {
                $uptime = @shell_exec("awk '{print int($1)}' /proc/uptime");
            } else {
                $uptime = null;
            }
            $uptime = $uptime !== false ? intval($uptime) : null;

            // -- Temperature (Linux/RPi)
            $tempC = null;
            if ($os === "linux" && file_exists("/sys/class/thermal/thermal_zone0/temp")) {
                $tempRaw = @file_get_contents("/sys/class/thermal/thermal_zone0/temp");
                $tempC = $tempRaw !== false ? round(intval($tempRaw)/1000,1) : null;
            }

            // -- Users logged in (Linux)
            $users = null;
            if ($os === "linux" || $os === "darwin") {
                $users = @shell_exec("who | wc -l");
                $users = $users !== false ? intval($users) : null;
            }

            // -- Network usage (Linux, interface principale)
            $network = null;
            if ($os === "linux") {
                $iface = self::getPrimaryInterface();
                if ($iface) {
                    $rxPath = "/sys/class/net/$iface/statistics/rx_bytes";
                    $txPath = "/sys/class/net/$iface/statistics/tx_bytes";
                    $rx = file_exists($rxPath) ? @file_get_contents($rxPath) : null;
                    $tx = file_exists($txPath) ? @file_get_contents($txPath) : null;
                    $network = [
                        "interface" => $iface,
                        "rx_bytes" => $rx !== false ? intval($rx) : null,
                        "tx_bytes" => $tx !== false ? intval($tx) : null
                    ];
                }
            }

            // -- PHP process
            $php_proc = [
                "memory_usage_bytes" => memory_get_usage(),
                "peak_memory_bytes" => memory_get_peak_usage(),
                "threads" => function_exists('posix_getpid') ? count(@glob("/proc/".getmypid()."/task/*")) : null,
            ];

            // -- PHP version
            $phpVersion = phpversion();

            // -- DB Metrics
            $db_metrics = self::getDbMetrics();

            $metrics = [
                "cpu" => [
                    "loadavg_1min" => isset($cpuLoad[0]) ? floatval($cpuLoad[0]) : null,
                    "loadavg_5min" => isset($cpuLoad[1]) ? floatval($cpuLoad[1]) : null,
                    "loadavg_15min" => isset($cpuLoad[2]) ? floatval($cpuLoad[2]) : null,
                ],
                "memory" => $memory,
                "disk" => $disk,
                "uptime_sec" => $uptime,
                "temperature_c" => $tempC,
                "users_logged_in" => $users,
                "network" => $network,
                "php_process" => $php_proc,
                "php_version" => $phpVersion,
                "db_metrics" => $db_metrics,
                "timestamp" => date('c')
            ];

            header('Content-Type: application/json');
            http_response_code(200);
            echo json_encode([
                "success" => true,
                "metrics" => $metrics
            ]);
            self::log("getMetrics success");
        } catch (Exception $e) {
            self::log("getMetrics error: " . $e->getMessage());
            header('Content-Type: application/json');
            http_response_code(500);
            echo json_encode([
                "success" => false,
                "error" => "Could not fetch system metrics"
            ]);
        }
    }

    /**
     * getMetricsLogs()
     * Returns the last N lines of metrics API log.
     * 
     * Endpoint: GET /api/metrics?action=logs[&lines=N]
     */
    public static function getMetricsLogs($lines = 100)
    {
        self::initConfig();
        self::log("Received getMetricsLogs request (lines=$lines)");

        try {
            if (!file_exists(self::$logFile)) {
                throw new Exception("Metrics log file not found.");
            }

            $logContent = self::tailFile(self::$logFile, $lines);

            header('Content-Type: application/json');
            http_response_code(200);
            if (!is_array($logContent)) $logContent = explode("\n", (string)$logContent);
            echo json_encode([
                "success" => true,
                "log" => $logContent
            ]);
            self::log("getMetricsLogs success");
        } catch (Exception $e) {
            self::log("getMetricsLogs error: " . $e->getMessage());
            header('Content-Type: application/json');
            http_response_code(500);
            echo json_encode([
                "success" => false,
                "error" => "Could not fetch metrics logs"
            ]);
        }
    }

    /**
     * getDbMetrics()
     * Returns DB stats (MySQL/MariaDB).
     */
    private static function getDbMetrics()
    {
        self::initConfig();
        $c = self::$config;
        if (
            !isset($c['db_host']) ||
            !isset($c['db_user']) ||
            !isset($c['db_pass']) ||
            !isset($c['db_name'])
        ) return null;

        $mysqli = @new mysqli(
            $c['db_host'],
            $c['db_user'],
            $c['db_pass'],
            $c['db_name']
        );
        if ($mysqli->connect_errno) {
            return ["connected"=>false, "error"=>$mysqli->connect_error];
        }
        // Stats de base
        $numTables = null;
        $dbSizeMB = null;
        $numConnections = null;
        // Tables
        $res = $mysqli->query("SHOW TABLES");
        if ($res) {
            $numTables = $res->num_rows;
            $res->free();
        }
        // Taille DB
        $dbName = $mysqli->real_escape_string($c['db_name']);
        $res = $mysqli->query("SELECT SUM(data_length+index_length)/1024/1024 as size_mb FROM information_schema.tables WHERE table_schema='$dbName'");
        if ($res) {
            $row = $res->fetch_assoc();
            $dbSizeMB = round(floatval($row['size_mb']), 2);
            $res->free();
        }
        // Connexions actives
        $res = $mysqli->query("SHOW STATUS WHERE `variable_name` = 'Threads_connected'");
        if ($res) {
            $row = $res->fetch_assoc();
            $numConnections = intval($row['Value']);
            $res->free();
        }
        $mysqli->close();
        return [
            "connected" => true,
            "num_tables" => $numTables,
            "db_size_mb" => $dbSizeMB,
            "active_connections" => $numConnections
        ];
    }

    /**
     * getPrimaryInterface()
     * Devine l'interface réseau principale (Linux uniquement).
     */
    private static function getPrimaryInterface()
    {
        $data = @file("/proc/net/route");
        if (!$data) return null;
        foreach ($data as $line) {
            $parts = explode("\t", $line);
            if (isset($parts[1]) && trim($parts[1]) === "00000000" && trim($parts[0]) !== "Iface") {
                return trim($parts[0]);
            }
        }
        return null;
    }

    /**
     * tailFile()
     * Returns the last $lines lines from a file.
     */
    private static function tailFile($filepath, $lines = 100)
    {
        $buffer = [];
        $f = fopen($filepath, "r");
        if ($f === false) return [];
        fseek($f, 0, SEEK_END);
        $pos = ftell($f);
        $line = '';
        $cnt = 0;
        while ($pos > 0 && $cnt < $lines) {
            $pos--;
            fseek($f, $pos, SEEK_SET);
            $char = fgetc($f);
            if ($char === "\n" && $line !== '') {
                array_unshift($buffer, strrev($line));
                $line = '';
                $cnt++;
            } else {
                $line .= $char;
            }
        }
        if ($line !== '') {
            array_unshift($buffer, strrev($line));
        }
        fclose($f);
        return $buffer;
    }

    /**
     * log()
     * Appends a log entry to the metrics_api.log file.
     */
    private static function log($msg)
    {
        self::initConfig();
        $line = "[" . date('Y-m-d H:i:s') . "] " . $msg . "\n";
        file_put_contents(self::$logFile, $line, FILE_APPEND);
    }
}
