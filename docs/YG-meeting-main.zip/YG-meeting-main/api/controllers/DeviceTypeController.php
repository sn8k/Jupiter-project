<?php
// File: api/controllers/DeviceTypeController.php
// Version: 1.1.0

// Date: 2025-06-14

// Author: Meeting Server Team
// Description: CRUD controller for device types (list, create, update, fork, soft delete)

require_once __DIR__ . '/../log_helpers.php';

class DeviceTypeController {
    private PDO $pdo;
    private string $logfile;
    private array $config;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->config = require __DIR__ . '/../config.php';
        $this->logfile = $this->config['backend_logfile'] ?? __DIR__ . '/../logs/backend_api.log';
    }

    private function log(string $action, array $data = []): void {
        $line = sprintf("[%s] DeviceType %s %s\n", date('Y-m-d H:i:s'), $action, json_encode($data));
        write_log($this->logfile, $line);
    }

    private function handleIconUpload(): ?string {
        if (isset($_FILES['icon']) && $_FILES['icon']['error'] === UPLOAD_ERR_OK) {
            $dir = $this->config['device_type_icon_dir'] ?? __DIR__ . '/../device_type_icons';
            if (!is_dir($dir)) {
                mkdir($dir, 0775, true);
            }
            $ext = strtolower(pathinfo($_FILES['icon']['name'], PATHINFO_EXTENSION));
            $name = uniqid('icon_', true) . ($ext ? '.' . $ext : '');
            $dest = rtrim($dir, '/') . '/' . $name;
            if (move_uploaded_file($_FILES['icon']['tmp_name'], $dest)) {
                return $name;
            }
        }
        return null;
    }

    private function parsePutFormData(): void {
        if ($_SERVER['REQUEST_METHOD'] !== 'PUT') { return; }
        $type = $_SERVER['CONTENT_TYPE'] ?? '';
        if (strpos($type, 'multipart/form-data') === false) {
            parse_str(file_get_contents('php://input'), $_POST);
            return;
        }
        $data = file_get_contents('php://input');
        $boundary = substr($data, 0, strpos($data, "\r\n"));
        $parts = array_slice(explode($boundary, $data), 1);
        foreach ($parts as $part) {
            if ($part == "--\r\n") break;
            $part = ltrim($part, "\r\n");
            [$raw, $body] = explode("\r\n\r\n", $part, 2);
            $body = substr($body, 0, -2);
            $headers = [];
            foreach (explode("\r\n", $raw) as $h) {
                if (strpos($h, ':') !== false) {
                    [$hn, $hv] = explode(':', $h, 2);
                    $headers[strtolower(trim($hn))] = trim($hv);
                }
            }
            if (!isset($headers['content-disposition'])) continue;
            if (preg_match('/name="([^"]+)"/', $headers['content-disposition'], $n)) {
                $name = $n[1];
                if (preg_match('/filename="([^"]*)"/', $headers['content-disposition'], $f)) {
                    $filename = $f[1];
                    $tmp = tempnam(sys_get_temp_dir(), 'php');
                    file_put_contents($tmp, $body);
                    $_FILES[$name] = [
                        'name' => $filename,
                        'type' => $headers['content-type'] ?? 'application/octet-stream',
                        'tmp_name' => $tmp,
                        'error' => UPLOAD_ERR_OK,
                        'size' => strlen($body)
                    ];
                } else {
                    $_POST[$name] = $body;
                }
            }
        }
    }

    // GET /api/device-types
    public function listTypes(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->query("SELECT * FROM device_types WHERE status <> 'deleted'");
        echo json_encode(['device_types' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    // POST /api/device-types
    public function createType(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $data = $_POST;
        $icon = $this->handleIconUpload();
        if ($icon) { $data['icon_path'] = $icon; }
        if (!$data || empty($data['name']) || empty($data['serial_prefix'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing name or serial_prefix']);
            return;
        }
        $fields = ['name','serial_prefix','platform','services_default','description','icon_path','tags','default_distribution','parent_id'];
        $vals = [];
        $ph = [];
        foreach ($fields as $f) {
            $vals[] = $data[$f] ?? null;
            $ph[] = '?';
        }
        $sql = 'INSERT INTO device_types (' . implode(',', $fields) . ') VALUES (' . implode(',', $ph) . ')';
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($vals);
            $id = $this->pdo->lastInsertId();
            $this->log('CREATE', ['id' => $id]);
            echo json_encode(['success' => true, 'id' => $id]);
        } catch (PDOException $e) {
            $this->log('CREATE_FAIL', ['error' => $e->getMessage()]);
            http_response_code(409);
            $msg = ($e->errorInfo[1] ?? 0) === 1062
                ? 'Duplicate serial_prefix'
                : 'Database error';
            echo json_encode(['error' => $msg]);
        }
    }

    // PUT /api/device-types/{id}
    public function updateType(int $id): void {
        header('Content-Type: application/json; charset=UTF-8');
        $this->parsePutFormData();
        $data = $_POST;
        $icon = $this->handleIconUpload();
        if ($icon) { $data['icon_path'] = $icon; }
        if (!$data) { http_response_code(400); echo json_encode(['error' => 'Invalid body']); return; }
        $fields = ['name','serial_prefix','platform','services_default','description','icon_path','tags','default_distribution','parent_id','status'];
        $set = [];
        $vals = [];
        foreach ($fields as $f) {
            if (array_key_exists($f, $data)) {
                $set[] = "$f = ?";
                $vals[] = $data[$f];
            }
        }
        if (!$set) { http_response_code(400); echo json_encode(['error' => 'Nothing to update']); return; }
        $vals[] = $id;
        $sql = 'UPDATE device_types SET ' . implode(',', $set) . ' WHERE id = ?';
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($vals);
            $this->log('UPDATE', ['id' => $id]);
            echo json_encode(['success' => true]);
        } catch (PDOException $e) {
            $this->log('UPDATE_FAIL', ['id' => $id, 'error' => $e->getMessage()]);
            http_response_code(409);
            $msg = ($e->errorInfo[1] ?? 0) === 1062
                ? 'Duplicate serial_prefix'
                : 'Database error';
            echo json_encode(['error' => $msg]);
        }
    }

    // POST /api/device-types/{id}/fork
    public function forkType(int $id): void {
        header('Content-Type: application/json; charset=UTF-8');
        $data = $_POST;
        $icon = $this->handleIconUpload();
        if ($icon) { $data['icon_path'] = $icon; }
        if (!$data || empty($data['name']) || empty($data['serial_prefix'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing name or serial_prefix']);
            return;
        }
        $stmt = $this->pdo->prepare('SELECT name,serial_prefix,platform,services_default,description,icon_path,tags,default_distribution,parent_id FROM device_types WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) { http_response_code(404); echo json_encode(['error' => 'Not found']); return; }
        if ($icon) { $row['icon_path'] = $icon; }
        $row['name'] = $data['name'];
        $row['serial_prefix'] = $data['serial_prefix'];
        $row['parent_id'] = $data['parent_id'] ?? $id;
        $fields = array_keys($row);
        $place = array_fill(0, count($fields), '?');
        try {
            $stmt = $this->pdo->prepare('INSERT INTO device_types (' . implode(',', $fields) . ') VALUES (' . implode(',', $place) . ')');
            $stmt->execute(array_values($row));
            $newId = $this->pdo->lastInsertId();
            $this->log('FORK', ['id' => $id, 'new_id' => $newId]);
            echo json_encode(['success' => true, 'id' => $newId]);
        } catch (PDOException $e) {
            $this->log('FORK_FAIL', ['id' => $id, 'error' => $e->getMessage()]);
            http_response_code(409);
            $msg = ($e->errorInfo[1] ?? 0) === 1062 ? 'Duplicate serial_prefix' : 'Database error';
            echo json_encode(['error' => $msg]);
        }
    }

    // POST /api/device-types/{id}/merge
    public function mergeType(int $id): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare('SELECT * FROM device_types WHERE id = ?');
        $stmt->execute([$id]);
        $fork = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$fork) { http_response_code(404); echo json_encode(['error' => 'Not found']); return; }
        if (empty($fork['parent_id'])) { http_response_code(400); echo json_encode(['error' => 'No parent']); return; }
        $parentId = (int)$fork['parent_id'];
        $fields = ['name','serial_prefix','platform','services_default','description','icon_path','tags','default_distribution','status'];
        $set = [];
        $vals = [];
        foreach ($fields as $f) {
            $set[] = "$f = ?";
            $vals[] = $fork[$f];
        }
        $vals[] = $parentId;
        $sql = 'UPDATE device_types SET ' . implode(',', $set) . ' WHERE id = ?';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($vals);
        $stmt = $this->pdo->prepare("UPDATE device_types SET status = 'merged' WHERE id = ?");
        $stmt->execute([$id]);
        $this->log('MERGE', ['fork_id' => $id, 'parent_id' => $parentId]);
        echo json_encode(['success' => true]);
    }

    // DELETE /api/device-types/{id}
    public function deleteType(int $id): void {
        header('Content-Type: application/json; charset=UTF-8');
        try {
            $stmt = $this->pdo->prepare("UPDATE device_types SET status = 'deleted' WHERE id = ?");
            $stmt->execute([$id]);
            $this->log('DELETE', ['id' => $id]);
            echo json_encode(['success' => true]);
        } catch (PDOException $e) {
            $this->log('DELETE_FAIL', ['id' => $id, 'error' => $e->getMessage()]);
            http_response_code(500);
            echo json_encode(['error' => 'Database error']);
        }
    }
}
?>
