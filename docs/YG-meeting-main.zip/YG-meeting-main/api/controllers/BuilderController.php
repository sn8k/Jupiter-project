<?php
// File: api/controllers/BuilderController.php

// Version: 1.5.2
// Date: 2025-06-13

// Author: Meeting Server Team
// Description: Controller for distribution builder workflow (drafts, packaging, commit).

class BuilderController {
    private $storageRoot;
    private $logFile;
    private $apiToken;
    private $allowedExts;
    private $maxUploadSize;
    private $pdo;
    private $currentUser;

    public function __construct() {
        $configFile = __DIR__ . '/../config.php';
        $config = is_file($configFile) ? require $configFile : [];
        $this->storageRoot = $config['builder_storage_root'] ?? dirname(__DIR__,1) . '/builder_storage';
        $this->logFile     = $config['builder_logfile'] ?? __DIR__ . '/../logs/builder_api.log';
        $this->apiToken    = $config['builder_api_token'] ?? (getenv('BUILDER_API_TOKEN') ?: 'REPLACE_ME');
        $this->allowedExts = $config['builder_allowed_extensions'] ?? ['tar.gz','zip','json','txt','png'];
        $this->maxUploadSize = $config['builder_max_upload_size'] ?? 10*1024*1024;
        $this->currentUser = null;
        $dsn = "mysql:host={$config['db_host']};dbname={$config['db_name']};charset={$config['db_charset']}";
        try {
            $this->pdo = new PDO($dsn, $config['db_user'], $config['db_pass'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]);
        } catch (PDOException $e) {
            $this->pdo = null;
        }
        if (!is_dir($this->storageRoot)) {
            mkdir($this->storageRoot, 0777, true);
        }
    }

    // Vérifie le header Authorization (Bearer <token>)
    public function requireAuth() {
        $header = $_SERVER['HTTP_AUTHORIZATION']
            ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
            ?? '';
        if (!$header && function_exists('getallheaders')) {
            $h = getallheaders();
            $header = $h['Authorization'] ?? $h['authorization'] ?? '';
        }
        if (stripos($header, 'Bearer ') === 0) {
            $token = substr($header, 7);
        } else {
            $token = $header;
        }
        if ($this->pdo) {
            $stmt = $this->pdo->prepare('SELECT username FROM builder_users WHERE token = ?');
            $stmt->execute([$token]);
            $user = $stmt->fetchColumn();
            if ($user) {
                $this->currentUser = $user;
                return;
            }
        }
        if ($token === $this->apiToken) {
            $this->currentUser = 'admin';
            return;
        }
        http_response_code(401);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }

    // GET /api/builder/whoami
    public function whoami() {
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(['user' => $this->currentUser]);
    }

    // GET /api/builder/device-types
    public function listDeviceTypes() {
        header('Content-Type: application/json; charset=UTF-8');
        $q = $_GET['q'] ?? '';
        $types = [];
        $storage = $this->storageRoot;
        if (is_dir($storage)) {
            foreach (scandir($storage) as $d) {
                if ($d === '.' || $d === '..') continue;
                if (!is_dir("$storage/$d")) continue;
                if ($q && stripos($d, $q) === false) continue;
                $types[] = [ 'name' => $d, 'desc' => ucfirst($d), 'icon' => '📦' ];
            }
        }
        echo json_encode(['device_types' => $types]);
    }

    // GET /api/builder/distributions?type=x
    public function listDistributions() {
        header('Content-Type: application/json; charset=UTF-8');
        $type = $_GET['type'] ?? '';
        $list = [];
        $base = "$this->storageRoot/$type";
        if ($type && is_dir($base)) {
            foreach (scandir($base) as $d) {
                if ($d === '.' || $d === '..') continue;
                $verFile = "$base/$d/latest_version";
                $last = is_file($verFile) ? trim(file_get_contents($verFile)) : '';
                $list[] = [ 'name' => $d, 'last_version' => $last ];
            }
        }
        echo json_encode(['distributions' => $list]);
    }

    // POST /api/builder/suggest-version
    public function suggestVersion() {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $type = $body['device_type'] ?? '';
        $dist = $body['distribution'] ?? '';
        $path = "$this->storageRoot/$type/$dist";
        $version = '1.0.0';
        if (is_dir($path)) {
            $vers = [];
            foreach (scandir($path) as $d) {
                if (preg_match('/^v?(\d+\.\d+\.\d+)/', $d, $m)) {
                    $vers[] = $m[1];
                }
            }
            if ($vers) {
                usort($vers, 'version_compare');
                $last = end($vers);
                $parts = explode('.', $last);
                $parts[2] = (int)$parts[2] + 1;
                $version = implode('.', $parts);
            }
        }
        echo json_encode(['suggested_version' => $version]);
    }

    private function writeLog($msg) {
        $dir = dirname($this->logFile);
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        file_put_contents($this->logFile, "[$_SERVER[REQUEST_METHOD]] $msg\n", FILE_APPEND);
    }

    private function loadIndex() {
        $file = $this->storageRoot . '/published/index.json';
        if (!is_file($file)) return [];
        return json_decode(file_get_contents($file), true) ?: [];
    }

    private function saveIndex($index) {
        $file = $this->storageRoot . '/published/index.json';
        $dir = dirname($file);
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        file_put_contents($file, json_encode($index, JSON_PRETTY_PRINT));
    }

    // POST /api/builder/start
    public function startBuild() {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $buildId = 'tmp_' . substr(bin2hex(random_bytes(4)),0,8);
        $path = "$this->storageRoot/$buildId";
        mkdir($path, 0777, true);
        file_put_contents("$path/manifest.json", json_encode($body, JSON_PRETTY_PRINT));
        echo json_encode([
            'build_id' => $buildId,
            'upload_url' => "/api/builder/upload-file?build_id=$buildId",
            'manifest_url' => "/api/builder/manifest?build_id=$buildId"
        ]);
    }

    // POST /api/builder/upload-file
    public function uploadFile() {
        header('Content-Type: application/json; charset=UTF-8');
        $buildId = $_POST['build_id'] ?? '';
        if (!$buildId || !isset($_FILES['file'])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing parameters']);
            return;
        }
        $type = $_POST['type'] ?? 'asset';
        $path = "$this->storageRoot/$buildId";
        if (!is_dir($path)) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Unknown build']);
            return;
        }
        $name = basename($_FILES['file']['name']);
        $name = preg_replace('/[^a-zA-Z0-9._-]/', '_', $name);
        $size = $_FILES['file']['size'] ?? 0;
        $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if ($ext === 'gz' && substr($name, -7) === '.tar.gz') {
            $ext = 'tar.gz';
        }
        if ($size > $this->maxUploadSize) {
            http_response_code(400);
            $this->writeLog("rejected $name for $buildId: file too large");
            echo json_encode(['success' => false, 'error' => 'File exceeds maximum allowed size']);
            return;
        }
        if (!in_array($ext, $this->allowedExts)) {
            http_response_code(400);
            $this->writeLog("rejected $name for $buildId: invalid extension");
            echo json_encode(['success' => false, 'error' => 'Invalid file extension']);
            return;
        }
        move_uploaded_file($_FILES['file']['tmp_name'], "$path/$name");
        $this->writeLog("uploaded $name to $buildId");
        echo json_encode(['success' => true, 'filename' => $name, 'filetype' => $type, 'path' => "$path/$name"]);
    }

    // GET /api/builder/manifest
    public function getManifest() {
        header('Content-Type: application/json; charset=UTF-8');
        $buildId = $_GET['build_id'] ?? '';
        $path = "$this->storageRoot/$buildId/manifest.json";
        if (!is_file($path)) {
            http_response_code(404);
            echo json_encode(['error' => 'Unknown build']);
            return;
        }
        $manifest = json_decode(file_get_contents($path), true);
        $files = [];
        $dir = dirname($path);
        foreach (scandir($dir) as $f) {
            if ($f === 'manifest.json') continue;
            if ($f === '.' || $f === '..') continue;
            $files[] = [ 'name' => $f, 'type' => 'asset', 'checksum' => sha1_file("$dir/$f") ];
        }
        $manifest['files'] = $files;
        echo json_encode(['manifest' => $manifest, 'valid' => true, 'missing' => []]);
    }

    // POST /api/builder/manifest
    public function updateManifest() {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $buildId = $body['build_id'] ?? '';
        if (!$buildId || !isset($body['manifest'])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Missing params']);
            return;
        }
        $path = "$this->storageRoot/$buildId/manifest.json";
        if (!is_file($path)) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Unknown build']);
            return;
        }
        file_put_contents($path, json_encode($body['manifest'], JSON_PRETTY_PRINT));
        echo json_encode(['success' => true, 'valid' => true, 'missing' => []]);
    }

    // POST /api/builder/package
    public function packageBuild() {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $buildId = $body['build_id'] ?? '';
        $format = $body['format'] ?? 'tar.gz';
        $dir = "$this->storageRoot/$buildId";
        if (!is_dir($dir)) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Unknown build']);
            return;
        }
        $jobId = 'job_' . substr(bin2hex(random_bytes(4)), 0, 8);
        $archive = "$this->storageRoot/$jobId.$format";
        $statusFile = "$this->storageRoot/$jobId.status";
        file_put_contents($statusFile, json_encode(['state' => 'queued', 'progress' => 0]));

        $script = escapeshellarg(__DIR__ . '/../../tools/package_job.php');
        $cmd = 'php ' . $script . ' ' .
            escapeshellarg($jobId) . ' ' .
            escapeshellarg($dir) . ' ' .
            escapeshellarg($archive) . ' ' .
            escapeshellarg($format);

        proc_open($cmd . ' > /dev/null 2>&1 &', [], $pipes);

        echo json_encode([
            'success'    => true,
            'job_id'     => $jobId,
            'status_url' => "/api/builder/package-status?job_id=$jobId"
        ]);
    }

    // GET /api/builder/package-status
    public function packageStatus() {
        header('Content-Type: application/json; charset=UTF-8');
        $jobId = $_GET['job_id'] ?? '';
        $statusFile = "$this->storageRoot/$jobId.status";
        if (!is_file($statusFile)) {
            http_response_code(404);
            echo json_encode(['error' => 'Unknown job']);
            return;
        }
        $stat = json_decode(file_get_contents($statusFile), true);
        $download = isset($stat['archive']) ? "/api/builder/download/$jobId" : null;
        echo json_encode([
            'state'        => $stat['state'],
            'progress'     => $stat['progress'],
            'download_url' => $download,
            'sha256'       => $stat['sha256'] ?? null,
            'log'          => []
        ]);
    }

    // POST /api/builder/commit
    public function commit() {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $jobId = $body['job_id'] ?? '';
        $statusFile = "$this->storageRoot/$jobId.status";
        if (!is_file($statusFile)) {
            http_response_code(404);
            echo json_encode(['success'=>false,'error'=>'Unknown job']);
            return;
        }
        $stat = json_decode(file_get_contents($statusFile), true);
        $archive = $stat['archive'] ?? null;
        if (!$archive || !is_file($archive)) {
            http_response_code(400);
            echo json_encode(['success'=>false,'error'=>'No archive']);
            return;
        }
        $notes = $body['notes'] ?? '';

        // extract manifest metadata from archive (.tar.gz or .zip)
        $ext = strtolower(pathinfo($archive, PATHINFO_EXTENSION));
        if ($ext === 'zip') {
            $cmd = 'unzip -p ' . escapeshellarg($archive) . ' manifest.json 2>/dev/null';
        } else {
            $cmd = 'tar -O -xzf ' . escapeshellarg($archive) . ' ./manifest.json 2>/dev/null';
        }
        $manifestRaw = shell_exec($cmd);
        $manifest = json_decode($manifestRaw, true) ?: [];
        $type = $manifest['type'] ?? ($manifest['device_type'] ?? 'unknown');
        $dist = $manifest['distribution'] ?? 'default';
        $version = $manifest['version'] ?? 'v1.0.0';

        $targetDir = $this->storageRoot . '/published/' . $type . '/' . $dist . '/' . $version;
        mkdir($targetDir, 0777, true);
        rename($archive, "$targetDir/".basename($archive));
        file_put_contents("$targetDir/notes.txt", $notes);
        if (!empty($manifestRaw)) {
            file_put_contents("$targetDir/manifest.json", $manifestRaw);
        }
        file_put_contents($this->storageRoot . "/published/$type/$dist/latest_version", $version);

        $index = $this->loadIndex();
        $index[] = [
            'device_type'  => $type,
            'distribution' => $dist,
            'version'      => $version,
            'date'         => date('c'),
            'notes'        => $notes
        ];
        $this->saveIndex($index);

        echo json_encode(['success'=>true,'path'=>$targetDir,'published_url'=>"/api/flash".basename($targetDir)]);
    }

    // GET /api/builder/download/{job_id}
    public function download($jobId) {
        $statusFile = "$this->storageRoot/$jobId.status";
        if (!is_file($statusFile)) {
            http_response_code(404);
            echo json_encode(['error' => 'Unknown job']);
            return;
        }
        $stat = json_decode(file_get_contents($statusFile), true);
        $archive = $stat['archive'] ?? null;
        if (!$archive || !is_file($archive)) {
            http_response_code(404);
            echo json_encode(['error' => 'Archive not found']);
            return;
        }

        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($archive) . '"');
        readfile($archive);
    }

    // GET /api/builder/history
    public function history() {
        header('Content-Type: application/json; charset=UTF-8');
        $type = $_GET['type'] ?? null;
        $dist = $_GET['distribution'] ?? null;
        $index = $this->loadIndex();
        $out = [];
        foreach ($index as $entry) {
            if ($type && $entry['device_type'] !== $type) continue;
            if ($dist && $entry['distribution'] !== $dist) continue;
            $out[] = $entry;
        }
        echo json_encode(['history' => $out]);
    }

    // POST /api/builder/rollback
    public function rollback() {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $type = $body['device_type'] ?? '';
        $dist = $body['distribution'] ?? '';
        $version = $body['version'] ?? '';
        if (!$type || !$dist || !$version) {
            http_response_code(400);
            echo json_encode(['success'=>false,'error'=>'Missing parameters']);
            return;
        }
        $latestFile = $this->storageRoot . "/published/$type/$dist/latest_version";
        if (!is_file($latestFile)) {
            http_response_code(404);
            echo json_encode(['success'=>false,'error'=>'Unknown distribution']);
            return;
        }
        file_put_contents($latestFile, $version);
        echo json_encode(['success'=>true]);
    }

    // POST /api/builder/duplicate
    public function duplicate() {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $type = $body['device_type'] ?? '';
        $dist = $body['distribution'] ?? '';
        $version = $body['version'] ?? '';
        $new = $body['new_version'] ?? '';
        $src = $this->storageRoot . "/published/$type/$dist/$version";
        $dst = $this->storageRoot . "/published/$type/$dist/$new";
        if (!$type || !$dist || !$version || !$new) {
            http_response_code(400);
            echo json_encode(['success'=>false,'error'=>'Missing parameters']);
            return;
        }
        if (!is_dir($src)) {
            http_response_code(404);
            echo json_encode(['success'=>false,'error'=>'Source not found']);
            return;
        }
        if (is_dir($dst)) {
            http_response_code(400);
            echo json_encode(['success'=>false,'error'=>'Target exists']);
            return;
        }
        mkdir($dst, 0777, true);
        foreach (scandir($src) as $f) {
            if ($f === '.' || $f === '..') continue;
            copy("$src/$f", "$dst/$f");
        }
        file_put_contents($this->storageRoot . "/published/$type/$dist/latest_version", $new);
        $index = $this->loadIndex();
        $index[] = [
            'device_type'  => $type,
            'distribution' => $dist,
            'version'      => $new,
            'date'         => date('c'),
            'notes'        => $body['notes'] ?? 'Duplicated from ' . $version
        ];
        $this->saveIndex($index);
        echo json_encode(['success'=>true]);
    }
}
?>
