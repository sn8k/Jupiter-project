<?php
// File: api/controllers/UserController.php
// Version: 1.3.0
// Date: 2025-06-24
// Author: Meeting Server Team
// Description: Basic REST controller for meeting users management

class UserController {
    private PDO $pdo;
    private string $syncScript;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $cfg = require __DIR__ . '/../config.php';
        $this->syncScript = $cfg['user_key_sync_script'] ?? dirname(__DIR__, 2) . '/resident_tools/ygs-UserKeysSync.sh';
    }

    public function listUsers(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->query('SELECT id, username, role, token, ssh_pubkey, authorized, created_at FROM builder_users ORDER BY id ASC');
        $rows = $stmt->fetchAll();
        echo json_encode(['users' => $rows]);
    }

    public function getUser(int $id): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare('SELECT id, username, role, token, ssh_pubkey, authorized, created_at FROM builder_users WHERE id = ?');
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        if (!$user) {
            http_response_code(404);
            echo json_encode(['error' => 'User not found']);
            return;
        }
        echo json_encode($user);
    }

    public function createUser(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $username   = trim($data['username'] ?? '');
        $role       = $data['role'] ?? 'user';
        $ssh_pubkey = $data['ssh_pubkey'] ?? null;
        $authorized = isset($data['authorized']) ? (int)$data['authorized'] : 0;
        if ($username === '') {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid username']);
            return;
        }
        $token = bin2hex(random_bytes(16));
        $stmt = $this->pdo->prepare('INSERT INTO builder_users (username, password, role, token, ssh_pubkey, authorized) VALUES (?, ?, ?, ?, ?, ?)');
        $hash = password_hash($data['password'] ?? '', PASSWORD_DEFAULT);
        try {
            $stmt->execute([$username, $hash, $role, $token, $ssh_pubkey, $authorized]);
        } catch (PDOException $e) {
            http_response_code(400);
            echo json_encode(['error' => 'User creation failed']);
            return;
        }
        exec('sudo ' . escapeshellarg($this->syncScript) . ' --sync > /dev/null 2>&1 &');
        echo json_encode(['success' => true, 'id' => $this->pdo->lastInsertId(), 'token' => $token]);
    }

    public function updateUser(int $id): void {
        header('Content-Type: application/json; charset=UTF-8');
        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $fields = [];
        $params = [];
        if (isset($data['username'])) { $fields[] = 'username = ?'; $params[] = $data['username']; }
        if (isset($data['password'])) { $fields[] = 'password = ?'; $params[] = password_hash($data['password'], PASSWORD_DEFAULT); }
        if (isset($data['role'])) { $fields[] = 'role = ?'; $params[] = $data['role']; }
        if (array_key_exists('ssh_pubkey', $data)) { $fields[] = 'ssh_pubkey = ?'; $params[] = $data['ssh_pubkey']; }
        if (isset($data['authorized'])) { $fields[] = 'authorized = ?'; $params[] = (int)$data['authorized']; }
        if (!$fields) {
            http_response_code(400);
            echo json_encode(['error' => 'No fields to update']);
            return;
        }
        $params[] = $id;
        $sql = 'UPDATE builder_users SET ' . implode(', ', $fields) . ' WHERE id = ?';
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        exec('sudo ' . escapeshellarg($this->syncScript) . ' --sync > /dev/null 2>&1 &');
        echo json_encode(['success' => true]);
    }

    /**
     * GET /api/users/authorized-keys
     * Retourne la liste des clés SSH autorisées pour les comptes utilisateurs.
     * Accessible uniquement depuis localhost.
     */
    public function getAuthorizedKeys(): void {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        if ($ip !== '127.0.0.1' && $ip !== '::1') {
            http_response_code(403);
            echo json_encode(['error' => 'Forbidden']);
            return;
        }
        header('Content-Type: text/plain; charset=UTF-8');
        $stmt = $this->pdo->query(
            "SELECT ssh_pubkey FROM builder_users WHERE authorized = 1 AND ssh_pubkey IS NOT NULL AND ssh_pubkey != ''"
        );
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            echo trim($row['ssh_pubkey']) . "\n";
        }
    }
}

?>
