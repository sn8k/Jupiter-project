<?php
// File: api/controllers/DeviceController.php
// Version: 3.4.0
// Date: 2025-05-31
// Author: Meeting Server Team
// Description: REST controller for devices management, tunnels dynamiques, logging avancé, tunnel_requests/tunnel_status robustes.
require_once __DIR__ . '/../log_helpers.php';
//
// CHANGELOG:
// - 3.4.0 (2025-05-31): Centralisation via config.php : storage_path, logs, tunnel dirs, debug logs, timeout, key sync script. Version complète clé en main.
// - 3.3.0 (2025-05-31): PATCH CRITIQUE : logs/erreurs détaillées sur création fichiers tunnel_requests/tunnel_status, log debug tunnel rotatif, anti path traversal, sécurité des noms fichiers.

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class DeviceController {
    private PDO $pdo;
    private $config;
    private $logfile;
    private $storagePath;
    private $keySyncScript;
    private $tunnelRequestsDir;
    private $tunnelStatusDir;
    private $tunnelTimeout;
    private $tunnelDebugLog;
    private $noteLogfile;

    public function __construct(PDO $pdo, $config = null) {
        $this->pdo = $pdo;
        $this->config = $config ?: (require __DIR__ . '/../config.php');
        $this->logfile = $this->config['device_logfile'] ?? (__DIR__ . '/../logs/device_service.log');
        $this->noteLogfile = $this->config['device_note_logfile'] ?? (__DIR__ . '/../logs/device_notes.log');
        ensure_log_directory($this->logfile);
        ensure_log_directory($this->noteLogfile);
        $this->storagePath = $this->config['storage_path'] ?? $this->config['flash_storage_root'] ?? dirname(__DIR__, 1) . '/storage';
        $this->keySyncScript = $this->config['key_sync_script'] ?? dirname(__DIR__, 1) . '/../resident_tools/ygs-KeysSync.sh';
        $this->tunnelRequestsDir = $this->config['tunnel_requests_dir'] ?? __DIR__ . '/../tunnel_requests';
        $this->tunnelStatusDir   = $this->config['tunnel_status_dir']   ?? __DIR__ . '/../tunnel_status';
        $this->tunnelTimeout = isset($this->config['tunnel_timeout']) ? (int)$this->config['tunnel_timeout'] : 30;
        $this->tunnelDebugLog = $this->config['tunnel_debug_logfile'] ?? dirname(__DIR__, 1) . '/../tmp/tunnel_debug.log';
        ensure_log_directory($this->tunnelDebugLog);
        if (!is_dir($this->tunnelRequestsDir)) mkdir($this->tunnelRequestsDir, 0775, true);
        if (!is_dir($this->tunnelStatusDir)) mkdir($this->tunnelStatusDir, 0775, true);
    }

    // Log tunnel debug
    private function tunnelDebug($msg, $level = "DEBUG") {
        $line = "[" . date('Y-m-d H:i:s') . "] [$level] $msg\n";
        if (file_exists($this->tunnelDebugLog) && filesize($this->tunnelDebugLog) > 1024 * 1024) {
            @rename($this->tunnelDebugLog, $this->tunnelDebugLog . '.' . time());
        }
        error_log($line, 3, $this->tunnelDebugLog);
    }

    private function getAllDeviceTypes(): array {
        $types = [];
        if (!is_dir($this->storagePath)) return [];
        foreach (scandir($this->storagePath) as $d) {
            if ($d === '.' || $d === '..') continue;
            if (is_dir($this->storagePath . '/' . $d)) $types[] = $d;
        }
        return $types;
    }

    private function getDistributionsForType(string $type): array {
        $dists = [];
        $typePath = $this->storagePath . '/' . $type;
        if (!is_dir($typePath)) return [];
        foreach (scandir($typePath) as $d) {
            if ($d === '.' || $d === '..') continue;
            if (is_dir($typePath . '/' . $d)) $dists[] = $d;
        }
        return $dists;
    }

    private function getDistribJsonPath($device_type, $distribution) {
        return $this->storagePath . '/' . $device_type . '/' . $distribution . '/distrib.json';
    }

    private function extractFieldsFromDevicekey(string $devicekey): array {
        $dk = strtoupper($devicekey);
        return [
            'ap_ssid'        => 'yg-device-' . strtolower(substr($dk, 0, 6)),
            'ap_password'    => strtoupper(substr($dk, -8)),
            'http_pw_low'    => strtoupper(substr($dk, 12, 4)),
            'http_pw_medium' => strtoupper(substr($dk, 8, 4)),
            'http_pw_high'   => strtoupper(substr($dk, 6, 6)),
        ];
    }

    private function getNextProductSerial(): string {
        $prefix = "V1-S01-";
        $stmt = $this->pdo->query("SELECT product_serial FROM devices WHERE product_serial IS NOT NULL AND product_serial != '' ORDER BY product_serial ASC");
        $existing = [];
        while ($row = $stmt->fetch()) {
            $existing[] = $row['product_serial'];
        }
        for ($i = 1; $i <= 99999; ++$i) {
            $sn = $prefix . str_pad($i, 5, "0", STR_PAD_LEFT);
            if (!in_array($sn, $existing)) {
                return $sn;
            }
        }
        throw new Exception("No available serial numbers");
    }

    private function logService($device_key, $service, $remoteIp, $result) {
        $line = sprintf(
            "[%s] IP:%s Device:%s Service:%s => %s\n",
            date('Y-m-d H:i:s'),
            $remoteIp,
            $device_key,
            $service,
            $result
        );
        error_log($line, 3, $this->logfile);
    }

    private function triggerKeySync() {
        $cmd = 'sudo ' . $this->keySyncScript . ' --auto > /dev/null 2>&1 &';
        exec($cmd);
    }

    // ENDPOINT: /service (tunnel dynamique)
    public function startDeviceService(string $device_key, $body = null): void {
        header('Content-Type: application/json; charset=UTF-8');
        $remoteIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $debugId = uniqid();

        if ($body === null) {
            $raw = file_get_contents('php://input');
            $body = json_decode($raw, true);
            if (!is_array($body)) $body = [];
        }
        $service = $body['service'] ?? null;
        $this->tunnelDebug("[$debugId] API startDeviceService request: device_key=$device_key, service=$service, remoteIp=$remoteIp, body=" . json_encode($body), "INFO");

        if (!$service || !is_string($service)) {
            http_response_code(400);
            $msg = ['error' => 'Missing or invalid service'];
            echo json_encode($msg);
            $this->logService($device_key, $service, $remoteIp, 'invalid service param');
            $this->tunnelDebug("[$debugId] Invalid service param", "WARN");
            return;
        }
        $stmt = $this->pdo->prepare("SELECT * FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $device = $stmt->fetch();
        if (!$device) {
            http_response_code(404);
            $msg = ['error' => 'Device not found'];
            echo json_encode($msg);
            $this->logService($device_key, $service, $remoteIp, 'device not found');
            $this->tunnelDebug("[$debugId] Device not found", "WARN");
            return;
        }
        $timeout = isset($this->config['device_heartbeat_timeout']) ? (int)$this->config['device_heartbeat_timeout'] : 60;
        $stmt = $this->pdo->prepare("SELECT last_seen FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $row = $stmt->fetch();
        $now = new DateTime('now', new DateTimeZone('UTC'));
        $is_online = false;
        $delta = null;
        if ($row && $row['last_seen']) {
            $lastSeen = new DateTime($row['last_seen'], new DateTimeZone('UTC'));
            $delta = $now->getTimestamp() - $lastSeen->getTimestamp();
            $is_online = ($delta <= $timeout);
        }
        if (!$is_online) {
            http_response_code(503);
            $msg = ['error' => 'Device not available'];
            echo json_encode($msg);
            $this->logService($device_key, $service, $remoteIp, 'device offline');
            $this->tunnelDebug("[$debugId] Device not online (delta=$delta)", "WARN");
            return;
        }

        $supported = [
            'ssh'  => 22,
            'vnc'  => 5900,
            'http' => 80,
            'scp'  => 22,
        ];
        if (!array_key_exists($service, $supported)) {
            http_response_code(400);
            $msg = ['error' => 'Service not implemented'];
            echo json_encode($msg);
            $this->logService($device_key, $service, $remoteIp, 'service not implemented');
            $this->tunnelDebug("[$debugId] Service $service not implemented", "WARN");
            return;
        }
        $flag = "service_" . $service;
        if (!(bool)$device['authorized'] || !(isset($device[$flag]) && $device[$flag])) {
            http_response_code(403);
            $msg = ['error' => 'Service not authorized for this device'];
            echo json_encode($msg);
            $this->logService($device_key, $service, $remoteIp, 'service not authorized');
            $this->tunnelDebug("[$debugId] Service not authorized for device", "WARN");
            return;
        }

        // ---- LOGIQUE TUNNEL ----
        $safeKey = preg_replace('/[^A-Za-z0-9]/', '', strtoupper($device_key));
        $safeService = preg_replace('/[^a-z]/', '', strtolower($service));
        $tunnelReqId = uniqid($safeKey . "_" . $safeService . "_", true);
        $reqFile = "{$this->tunnelRequestsDir}/{$safeKey}_{$safeService}.json";
        $statusFile = "{$this->tunnelStatusDir}/{$safeKey}_{$safeService}.json";

        $this->tunnelDebug("[$debugId] tunnelReqId=$tunnelReqId, reqFile=$reqFile, statusFile=$statusFile", "INFO");

        // Clean ancienne requête
        if (file_exists($reqFile)) { @unlink($reqFile); $this->tunnelDebug("[$debugId] Ancien reqFile supprimé", "DEBUG"); }
        if (file_exists($statusFile)) { @unlink($statusFile); $this->tunnelDebug("[$debugId] Ancien statusFile supprimé", "DEBUG"); }

        $tunnelParams = [
            'tunnel_id'  => $tunnelReqId,
            'device_key' => $safeKey,
            'service'    => $safeService,
            'requested_at' => time(),
        ];

        $written = @file_put_contents($reqFile, json_encode($tunnelParams));
        if ($written === false) {
            $this->tunnelDebug("[$debugId] ERREUR: Impossible d’écrire $reqFile", "ERROR");
            http_response_code(500);
            $msg = ['error' => "Failed to write request file"];
            echo json_encode($msg);
            return;
        }
        $this->tunnelDebug("[$debugId] Fichier $reqFile écrit OK ($written octets)", "INFO");

        $waited = 0;
        $poll = 2;
        $tunnel_ok = false;
        $last_status = null;
        while ($waited < $this->tunnelTimeout) {
            clearstatcache();
            if (file_exists($statusFile)) {
                $statusRaw = file_get_contents($statusFile);
                $status = json_decode($statusRaw, true);
                $this->tunnelDebug("[$debugId] StatusFile détecté, content: $statusRaw", "INFO");
                if (is_array($status) && !empty($status['port'])) {
                    $tunnel_ok = true;
                    $last_status = $status;
                    break;
                } elseif (is_array($status) && !empty($status['error'])) {
                    http_response_code(503);
                    $msg = ['error' => $status['error']];
                    echo json_encode($msg);
                    $this->logService($device_key, $service, $remoteIp, 'tunnel device error');
                    $this->tunnelDebug("[$debugId] Tunnel status error: " . $status['error'], "WARN");
                    return;
                }
            }
            sleep($poll);
            $waited += $poll;
        }

        if (!$tunnel_ok) {
            http_response_code(504);
            $msg = ['error' => 'Tunnel not available (timeout)'];
            echo json_encode($msg);
            $this->logService($device_key, $service, $remoteIp, 'tunnel timeout');
            $this->tunnelDebug("[$debugId] Tunnel TIMEOUT after $waited s (no statusFile with port)", "ERROR");
            return;
        }

        $port = $last_status['port'];
        $url = $last_status['url'] ?? null;
        $upnp = $last_status['upnp'] ?? null;

        $result = [
            'port' => $port,
            'url'  => $url,
        ];
        if ($upnp) $result['upnp'] = $upnp;
        http_response_code(200);
        echo json_encode($result);
        $this->logService($device_key, $service, $remoteIp, "OK WAN port=$port url=$url");
        $this->tunnelDebug("[$debugId] OK: port=$port, url=$url, upnp=" . json_encode($upnp), "INFO");
    }

    public function getDeviceTypes(): void {
        header('Content-Type: application/json; charset=UTF-8');
        try {
            $types = $this->getAllDeviceTypes();
            echo json_encode(['device_types' => $types]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to list device types']);
        }
    }

    public function getDistributionsForDeviceType(string $device_type): void {
        header('Content-Type: application/json; charset=UTF-8');
        try {
            $basePath = $this->storagePath . '/' . $device_type;
            if (!is_dir($basePath)) {
                http_response_code(404);
                echo json_encode(['error' => 'Device type not found']);
                return;
            }
            $dists = $this->getDistributionsForType($device_type);
            echo json_encode(['distributions' => $dists]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to list distributions']);
        }
    }

    public function getDistribJson(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare("SELECT device_type, distribution FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $device = $stmt->fetch();
        if (!$device || !$device['device_type'] || !$device['distribution']) {
            http_response_code(404);
            echo json_encode(['error' => 'Device or distribution not found']);
            return;
        }
        $jsonPath = $this->getDistribJsonPath($device['device_type'], $device['distribution']);
        if (!file_exists($jsonPath)) {
            http_response_code(404);
            echo json_encode(['error' => 'distrib.json not found']);
            return;
        }
        $json = file_get_contents($jsonPath);
        header('Content-Type: application/json; charset=UTF-8');
        echo $json;
    }

    public function setDistribJson(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare("SELECT device_type, distribution FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $device = $stmt->fetch();
        if (!$device || !$device['device_type'] || !$device['distribution']) {
            http_response_code(404);
            echo json_encode(['error' => 'Device or distribution not found']);
            return;
        }
        $jsonPath = $this->getDistribJsonPath($device['device_type'], $device['distribution']);
        $body = file_get_contents('php://input');
        $jsonCheck = json_decode($body, true);
        if ($jsonCheck === null && trim($body) !== 'null') {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid JSON']);
            return;
        }
        if (!is_dir(dirname($jsonPath))) {
            mkdir(dirname($jsonPath), 0775, true);
        }
        file_put_contents($jsonPath, $body);
        echo json_encode(['success' => true]);
    }

    public function getDeviceServices(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare(
            "SELECT service_ssh, service_vnc, service_http, service_scp FROM devices WHERE device_key = ?"
        );
        $stmt->execute([$device_key]);
        $row = $stmt->fetch();
        if (!$row) {
            http_response_code(404);
            echo json_encode(['error' => 'Device not found']);
            return;
        }
        $services = [];
        if (!empty($row['service_ssh']))  $services[] = 'ssh';
        if (!empty($row['service_vnc']))  $services[] = 'vnc';
        if (!empty($row['service_http'])) $services[] = 'http';
        if (!empty($row['service_scp']))  $services[] = 'scp';
        echo json_encode(['services' => $services]);
    }

    public function distributionFiles(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare("SELECT device_type, distribution FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $device = $stmt->fetch();
        if (!$device) {
            http_response_code(404);
            echo json_encode(['error' => 'Device not found']);
            return;
        }
        $devicetype = $device['device_type'] ?? null;
        $distribution = $device['distribution'] ?? null;
        if (empty($devicetype)) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing devicetype']);
            return;
        }
        if (empty($distribution)) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing distribution']);
            return;
        }
        $basePath = $this->storagePath . '/';
        $distPath = $basePath . $devicetype . '/' . $distribution . '/';
        if (!is_dir($distPath)) {
            http_response_code(404);
            echo json_encode(['error' => 'Devicetype/distribution path not found', 'path' => $distPath]);
            return;
        }
        $files = [];
        $dh = opendir($distPath);
        if ($dh) {
            while (($file = readdir($dh)) !== false) {
                if ($file === '.' || $file === '..') continue;
                if (is_file($distPath . $file)) $files[] = $file;
            }
            closedir($dh);
        }
        echo json_encode([
            'devicetype'   => $devicetype,
            'distribution' => $distribution,
            'files'        => $files
        ]);
    }

    public function listDevices(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $limit  = isset($_GET['limit']) ? (int)$_GET['limit'] : 25;
        $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
        $limit = max(1, min($limit, 100));
        $offset = max(0, $offset);

        $prefix = isset($_GET['prefix']) ? strtoupper($_GET['prefix']) : null;
        $where = "";
        $params = [];
        if ($prefix) {
            $where = "WHERE UPPER(device_key) LIKE :prefix";
            $params[':prefix'] = $prefix . '%';
        }

        $sqlCount = "SELECT COUNT(*) AS total FROM devices $where";
        $countStmt = $this->pdo->prepare($sqlCount);
        $countStmt->execute($params);
        $total = (int)($countStmt->fetch()['total'] ?? 0);

        $sql = "
            SELECT device_key, token_code, token_count, registered_at, authorized, 
                    ap_ssid, ap_password, http_pw_low, http_pw_medium, http_pw_high, note,
                    product_serial, device_type, bundles, ghost_candidate_url, parent_device_key, ip_address, distribution,
                    ssh_public_key, ssh_user
            FROM devices
            $where
            ORDER BY registered_at DESC 
            LIMIT :limit OFFSET :offset
        ";
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $key => $val) {
            $stmt->bindValue($key, $val, PDO::PARAM_STR);
        }
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll();

        echo json_encode([
            'devices' => $rows,
            'total'   => $total,
            'limit'   => $limit,
            'offset'  => $offset
        ]);
    }

    public function generateDeviceKey(): void {
        header('Content-Type: application/json; charset=UTF-8');
        do {
            $devicekey = strtoupper(bin2hex(random_bytes(16)));
            $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM devices WHERE device_key = ?");
            $stmt->execute([$devicekey]);
        } while ($stmt->fetchColumn() > 0);
        $token_code = strtolower(bin2hex(random_bytes(3)));
        echo json_encode([
            'devicekey'  => $devicekey,
            'token_code' => $token_code
        ]);
    }

    public function generateAndRegisterDevice(): void {
        header('Content-Type: application/json; charset=UTF-8');
        do {
            $devicekey = strtoupper(bin2hex(random_bytes(16)));
            $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM devices WHERE device_key = ?");
            $stmt->execute([$devicekey]);
        } while ($stmt->fetchColumn() > 0);
        $token_code = strtolower(bin2hex(random_bytes(3)));
        $fields = $this->extractFieldsFromDevicekey($devicekey);
        $stmt = $this->pdo->prepare(
            "INSERT INTO devices 
                (device_key, token_code, authorized, token_count, service_ssh, service_vnc, service_http, service_scp, 
                 ap_ssid, ap_password, http_pw_low, http_pw_medium, http_pw_high)
             VALUES (?, ?, 0, 0, 0, 0, 0, 0, ?, ?, ?, ?, ?)"
        );
        $stmt->execute([
            $devicekey, $token_code,
            $fields['ap_ssid'], $fields['ap_password'], $fields['http_pw_low'], $fields['http_pw_medium'], $fields['http_pw_high']
        ]);
        echo json_encode([
            'devicekey'      => $devicekey,
            'token_code'     => $token_code,
            'ap_ssid'        => $fields['ap_ssid'],
            'ap_password'    => $fields['ap_password'],
            'http_pw_low'    => $fields['http_pw_low'],
            'http_pw_medium' => $fields['http_pw_medium'],
            'http_pw_high'   => $fields['http_pw_high'],
        ]);
        $this->triggerKeySync();
    }

    public function manualCreateDevice(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $bodyRaw = file_get_contents('php://input');
        $body = json_decode($bodyRaw, true);
        if (!is_array($body)) $body = [];
        $devicekey = strtoupper(trim($body['devicekey'] ?? ''));
        $token_code = strtolower(trim($body['token_code'] ?? ''));
        $device_type = $body['device_type'] ?? null;
        $distribution = $body['distribution'] ?? null;
        $product_serial = $body['product_serial'] ?? null;
        if (!preg_match('/^[A-F0-9]{6,32}$/', $devicekey)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid devicekey']);
            return;
        }
        if (empty($token_code) || !preg_match('/^[a-z0-9]{1,32}$/', $token_code)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid token_code']);
            return;
        }
        if (!$device_type || !$distribution) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing device_type or distribution']);
            return;
        }
        if (empty($product_serial)) {
            try {
                $product_serial = $this->getNextProductSerial();
            } catch (\Exception $e) {
                http_response_code(500);
                echo json_encode(['error' => 'Unable to allocate product serial']);
                return;
            }
        }
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM devices WHERE device_key = ?");
        $stmt->execute([$devicekey]);
        if ($stmt->fetchColumn() > 0) {
            http_response_code(409);
            echo json_encode(['error' => 'Devicekey already exists']);
            return;
        }
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM devices WHERE product_serial = ?");
        $stmt->execute([$product_serial]);
        if ($stmt->fetchColumn() > 0) {
            http_response_code(409);
            echo json_encode(['error' => 'Serial number already assigned']);
            return;
        }
        $fields = $this->extractFieldsFromDevicekey($devicekey);
        $stmt = $this->pdo->prepare(
            "INSERT INTO devices 
                (device_key, token_code, authorized, token_count, service_ssh, service_vnc, service_http, service_scp, 
                 ap_ssid, ap_password, http_pw_low, http_pw_medium, http_pw_high, device_type, distribution, product_serial)
             VALUES (?, ?, 0, 0, 0, 0, 0, 0, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->execute([
            $devicekey, $token_code,
            $fields['ap_ssid'], $fields['ap_password'], $fields['http_pw_low'], $fields['http_pw_medium'], $fields['http_pw_high'],
            $device_type, $distribution, $product_serial
        ]);
        echo json_encode([
            'devicekey'      => $devicekey,
            'token_code'     => $token_code,
            'ap_ssid'        => $fields['ap_ssid'],
            'ap_password'    => $fields['ap_password'],
            'http_pw_low'    => $fields['http_pw_low'],
            'http_pw_medium' => $fields['http_pw_medium'],
            'http_pw_high'   => $fields['http_pw_high'],
            'device_type'    => $device_type,
            'distribution'   => $distribution,
            'product_serial' => $product_serial,
        ]);
        $this->triggerKeySync();
    }

    public function deleteDevice(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare("DELETE FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true]);
            $this->triggerKeySync();
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Device not found']);
        }
    }

    public function getDevice(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare(
            "SELECT device_key, token_code, token_count, registered_at, authorized, 
                    ap_ssid, ap_password, http_pw_low, http_pw_medium, http_pw_high, note,
                    product_serial, device_type, bundles, ghost_candidate_url, parent_device_key, ip_address, distribution,
                    service_ssh, service_vnc, service_http, service_scp
             FROM devices WHERE device_key = ?"
        );
        $stmt->execute([$device_key]);
        $row = $stmt->fetch();
        if (!$row) {
            http_response_code(404);
            echo json_encode(['error' => 'Device not found']);
            return;
        }
        $device = [
            'device_key'    => $row['device_key'],
            'device_name'   => $row['device_key'],
            'product_serial'=> $row['product_serial'],
            'authorized'    => (bool)$row['authorized'],
            'device_type'   => $row['device_type'],
            'distribution'  => $row['distribution'],
            'token_code'    => $row['token_code'],
            'token_count'   => (int)$row['token_count'],
            'note'          => $row['note'],
            'ip_address'    => $row['ip_address'],
            'parent_device_key'   => $row['parent_device_key'],
            'bundles'       => $row['bundles'] ? json_decode($row['bundles'], true) : [],
            'ghost_candidate_url' => $row['ghost_candidate_url'],
            'ap_ssid'       => $row['ap_ssid'],
            'ap_password'   => $row['ap_password'],
            'http_pw_low'   => $row['http_pw_low'],
            'http_pw_medium'=> $row['http_pw_medium'],
            'http_pw_high'  => $row['http_pw_high']
        ];
        $services = [];
        if (!empty($row['service_ssh']))  $services[] = 'ssh';
        if (!empty($row['service_vnc']))  $services[] = 'vnc';
        if (!empty($row['service_http'])) $services[] = 'http';
        if (!empty($row['service_scp']))  $services[] = 'scp';
        $device['services'] = $services;
        echo json_encode($device);
    }

    public function updateDevice(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $bodyRaw = file_get_contents('php://input');
        $body = json_decode($bodyRaw, true);
        if (!is_array($body)) $body = [];
        $stmt = $this->pdo->prepare("SELECT * FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $device = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$device) {
            http_response_code(404);
            echo json_encode(['error' => 'Device not found']);
            return;
        }
        $updates = [];
        $params = [];
        $shouldSync = false;

        if (isset($body['services']) && is_array($body['services'])) {
            $srvmap = ['ssh'=>'service_ssh','vnc'=>'service_vnc','http'=>'service_http','scp'=>'service_scp'];
            foreach ($srvmap as $svc => $dbcol) {
                if (!array_key_exists($dbcol, $device)) {
                    error_log("PATCH Meeting/DeviceController: Colonne manquante $dbcol dans la table devices !");
                    continue;
                }
                $val = in_array($svc, $body['services'], true) ? 1 : 0;
                if ($device[$dbcol] != $val) {
                    $shouldSync = true;
                }
                $updates[] = "$dbcol = ?";
                $params[] = $val;
            }
            error_log(date('[Y-m-d H:i:s]') . " PATCH services for $device_key: " . json_encode($body['services']) . "\n", 3, $this->logfile);
        }

        if (!$updates) {
            http_response_code(400);
            echo json_encode(['error' => 'Nothing to update']);
            return;
        }
        $params[] = $device_key;
        $sql = "UPDATE devices SET ".implode(", ", $updates)." WHERE device_key = ?";
        $st = $this->pdo->prepare($sql);
        $ok = $st->execute($params);
        if ($ok) {
            echo json_encode(['success' => true]);
            if ($shouldSync) $this->triggerKeySync();
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Update failed']);
        }
    }

    public function getDeviceNote(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare("SELECT note FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $row = $stmt->fetch();
        if (!$row) {
            http_response_code(404);
            echo json_encode(['error' => 'Device not found']);
            return;
        }
        echo json_encode(['note' => $row['note'] ?? ""]);
    }

    public function setDeviceNote(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $bodyRaw = file_get_contents('php://input');
        $body = json_decode($bodyRaw, true);
        if (!is_array($body) || !isset($body['note'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing note', 'raw' => $bodyRaw]);
            return;
        }
        $note = trim((string)$body['note']);
        if (strlen($note) > 2000) {
            http_response_code(400);
            echo json_encode(['error' => 'Note too long (max 2000 chars)']);
            return;
        }
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        if ($stmt->fetchColumn() == 0) {
            http_response_code(404);
            echo json_encode(['error' => 'Device not found']);
            return;
        }
        $stmt = $this->pdo->prepare("UPDATE devices SET note = ? WHERE device_key = ?");
        $stmt->execute([$note, $device_key]);
        $logDir = dirname($this->noteLogfile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0775, true);
        }
        error_log(date('[Y-m-d H:i:s]') . " Note updated for device $device_key\n", 3, $this->noteLogfile);
        echo json_encode(['success' => true, 'note' => $note]);
    }
}
?>
