<?php
// File: api/controllers/DeviceAvailabilityController.php
// Version: 1.2.0
// Date: 2025-05-31
// Author: Meeting Server Team
// Description: REST controller for device availability status endpoint (uses config.php for heartbeat timeout)
//
// CHANGELOG:
// - 1.2.0 (2025-05-31): Timeout configurable via config.php ('device_heartbeat_timeout').
// - 1.1.0 (2025-05-26): Switched to using devices.last_seen for status; removed log dependency and Disconnected spam; code cleanup, production ready.
// - 1.0.2 (2025-05-24): Vérification config PDO en amont, doc update, clean headers.
// - 1.0.1 (2025-05-24): Fix DateTime(null) deprecation (use 'now'), code clarity, strict typing.
// - 1.0.0 (2025-05-23): Initial extraction of deviceAvailability endpoint from DeviceController.
//
class DeviceAvailabilityController {
    private PDO $pdo;
    private array $config;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        // Charge config.php pour obtenir device_heartbeat_timeout
        $configPath = dirname(__DIR__, 1) . '/config.php';
        $this->config = is_file($configPath) ? require($configPath) : [];
    }

    /**
     * GET /api/devices/{device_key}/availability
     * Check device status and last connection time.
     * @param string $device_key
     * @return void
     */
    public function deviceAvailability(string $device_key): void {
        $timeout = $this->config['device_heartbeat_timeout'] ?? 60; // seconds (default if not set)
        $now = new DateTime('now', new DateTimeZone('UTC'));

        // Fetch last_seen from devices
        $stmt = $this->pdo->prepare(
            "SELECT last_seen FROM devices WHERE device_key = ?"
        );
        $stmt->execute([$device_key]);
        $row = $stmt->fetch();

        $status = 'Unknown';
        $since = null;
        $uptime = 0;

        if ($row && $row['last_seen']) {
            try {
                $lastSeen = new DateTime($row['last_seen'], new DateTimeZone('UTC'));
                $since = $row['last_seen'];
                $delta = $now->getTimestamp() - $lastSeen->getTimestamp();
                if ($delta <= $timeout) {
                    $status = 'Available';
                    $uptime = $delta;
                } else {
                    $status = 'Disconnected';
                    $uptime = 0;
                }
            } catch (Exception $e) {
                $status = 'Unknown';
                $since = null;
                $uptime = 0;
            }
        }

        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'status'         => $status,
            'last_heartbeat' => $since,
            'since'          => $since,
            'uptime'         => $uptime
        ]);
    }
}
