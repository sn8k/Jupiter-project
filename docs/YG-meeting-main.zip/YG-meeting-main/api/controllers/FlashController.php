<?php
// File: api/controllers/FlashController.php
// Version: 1.2.0
// Date: 2025-05-31
// Author: Meeting Server Team
// Description: Contrôleur pour la gestion du flash des devices et la distribution de fichiers (listing, upload, création de device-type/distribution, download, suppression).
//
// CHANGELOG:
// - 1.2.0 (2025-05-31): Centralisation du chemin storageRoot via config.php (clé flash_storage_root), conformité projet full-config.
// - 1.1.2 (2025-05-25): Hook ygs-KeysSync.sh (sync) après modification du champ authorized (setAuthorization)
// - 1.1.1 (2025-05-24): Suppression du require config.php, compatibilité config centralisée, injection PDO only.
// - 1.1.0 (2025-05-23): Ajout endpoints gestion device/tokens/flash/distribution : flashRequest, setAuthorization, setTokens, setDistribution, setTokenCode.
// - 1.0.0 (2025-05-23): Version initiale.
//

class FlashController {
    private $pdo;
    private $storageRoot;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        // Chemin storage root centralisé via config.php
        $configPath = dirname(__DIR__, 1) . '/config.php';
        $config = is_file($configPath) ? require($configPath) : [];
        $this->storageRoot = $config['flash_storage_root'] ?? dirname(__DIR__, 1) . '/../storage';
    }

    // POST /api/devices/{device_key}/flash-request
    public function flashRequest($device_key) {
        header('Content-Type: application/json; charset=UTF-8');
        try {
            $this->pdo->beginTransaction();
            $stmt = $this->pdo->prepare("SELECT token_count FROM devices WHERE device_key = ? FOR UPDATE");
            $stmt->execute([$device_key]);
            $row = $stmt->fetch();
            if (!$row) {
                $this->pdo->rollBack();
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Unknown device']);
                return;
            }
            if ((int)$row['token_count'] < 1) {
                $this->pdo->rollBack();
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'No tokens available']);
                return;
            }
            $stmt = $this->pdo->prepare(
                "UPDATE devices SET token_count = token_count - 1 WHERE device_key = ?"
            );
            $stmt->execute([$device_key]);
            $stmt = $this->pdo->prepare(
                "INSERT INTO flash_logs (device_key, success) VALUES (?, 1)"
            );
            $stmt->execute([$device_key]);
            $this->pdo->commit();
            $stmt = $this->pdo->prepare("SELECT token_count FROM devices WHERE device_key = ?");
            $stmt->execute([$device_key]);
            $tokens_left = (int)$stmt->fetchColumn();
            echo json_encode(['success' => true, 'tokens_left' => $tokens_left]);
        } catch (Exception $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Server error']);
        }
    }

    // PUT /api/devices/{device_key}/authorize
    public function setAuthorization($device_key) {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        if (!isset($body['authorized'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing authorized flag']);
            return;
        }
        $stmt = $this->pdo->prepare("UPDATE devices SET authorized = ? WHERE device_key = ?");
        $stmt->execute([(int)$body['authorized'], $device_key]);
        echo json_encode(['success' => true, 'authorized' => (int)$body['authorized']]);

        // === Synchronisation immédiate des clés SSH après autorisation/ban d’un device ===
        exec('sudo ' . dirname(__DIR__, 2) . '/resident_tools/ygs-KeysSync.sh sync > /dev/null 2>&1 &');
    }

    // PUT /api/devices/{device_key}/tokens
    public function setTokens($device_key) {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        if (!isset($body['token_count']) || !is_int($body['token_count'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid token_count']);
            return;
        }
        $stmt = $this->pdo->prepare("UPDATE devices SET token_count = ? WHERE device_key = ?");
        $stmt->execute([$body['token_count'], $device_key]);
        echo json_encode(['success' => true, 'token_count' => $body['token_count']]);
    }

    // PUT /api/devices/{device_key}/distribution
    public function setDistribution($device_key) {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        if (!isset($body['distribution'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing distribution']);
            return;
        }
        $stmt = $this->pdo->prepare("UPDATE devices SET distribution = ? WHERE device_key = ?");
        $stmt->execute([$body['distribution'], $device_key]);
        echo json_encode(['success' => true, 'distribution' => $body['distribution']]);
    }

    // PUT /api/devices/{device_key}/token-code
    public function setTokenCode($device_key) {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        if (!isset($body['token_code'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing token_code']);
            return;
        }
        $stmt = $this->pdo->prepare("UPDATE devices SET token_code = ? WHERE device_key = ?");
        $stmt->execute([$body['token_code'], $device_key]);
        echo json_encode(['success' => true, 'token_code' => $body['token_code']]);
    }

    // GET /api/flash/{device_key}/distribution-files
    public function listDistributionFiles($device_key) {
        header('Content-Type: application/json; charset=UTF-8');

        // Récupère le type et la distrib pour ce device_key
        $stmt = $this->pdo->prepare("SELECT device_type, distribution FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $device = $stmt->fetch();

        if (!$device) {
            http_response_code(404);
            echo json_encode(['error' => 'Device not found']);
            return;
        }
        $devicetype = $device['device_type'] ?? null;
        $distribution = $device['distribution'] ?? null;

        if (empty($devicetype) || empty($distribution)) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing devicetype or distribution']);
            return;
        }

        $distPath = "{$this->storageRoot}/{$devicetype}/{$distribution}/";
        if (!is_dir($distPath)) {
            http_response_code(404);
            echo json_encode(['error' => 'Devicetype/distribution path not found', 'path' => $distPath]);
            return;
        }

        // Liste les fichiers
        $files = [];
        foreach (scandir($distPath) as $file) {
            if ($file === '.' || $file === '..') continue;
            if (is_file($distPath . $file)) $files[] = $file;
        }
        echo json_encode([
            'devicetype'   => $devicetype,
            'distribution' => $distribution,
            'files'        => $files
        ]);
    }

    // POST /api/flash/upload
    public function uploadDistributionFile() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
            return;
        }
        header('Content-Type: application/json; charset=UTF-8');

        $devicetype   = $_POST['devicetype'] ?? '';
        $distribution = $_POST['distribution'] ?? '';
        if (!$devicetype || !$distribution) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing devicetype or distribution']);
            return;
        }
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            http_response_code(400);
            echo json_encode(['error' => 'No file uploaded']);
            return;
        }

        $dir = "{$this->storageRoot}/{$devicetype}/{$distribution}/";
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        $filename = basename($_FILES['file']['name']);
        $dest = $dir . $filename;

        if (!move_uploaded_file($_FILES['file']['tmp_name'], $dest)) {
            http_response_code(500);
            echo json_encode(['error' => 'File upload failed']);
            return;
        }
        echo json_encode(['success' => true, 'file' => $filename]);
    }

    // POST /api/flash/create-type
    public function createDeviceType() {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $devicetype = trim($body['devicetype'] ?? '');
        if (!$devicetype || !preg_match('/^[\w\-]+$/', $devicetype)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid devicetype']);
            return;
        }
        $dir = "{$this->storageRoot}/{$devicetype}/";
        if (is_dir($dir)) {
            http_response_code(409);
            echo json_encode(['error' => 'Device type already exists']);
            return;
        }
        if (!mkdir($dir, 0775, true)) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to create device type directory']);
            return;
        }
        echo json_encode(['success' => true, 'devicetype' => $devicetype]);
    }

    // POST /api/flash/create-distribution
    public function createDistribution() {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $devicetype   = trim($body['devicetype'] ?? '');
        $distribution = trim($body['distribution'] ?? '');
        if (!$devicetype || !$distribution || !preg_match('/^[\w\-]+$/', $devicetype) || !preg_match('/^[\w\-]+$/', $distribution)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid devicetype or distribution']);
            return;
        }
        $dir = "{$this->storageRoot}/{$devicetype}/{$distribution}/";
        if (is_dir($dir)) {
            http_response_code(409);
            echo json_encode(['error' => 'Distribution already exists']);
            return;
        }
        if (!mkdir($dir, 0775, true)) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to create distribution directory']);
            return;
        }
        echo json_encode(['success' => true, 'devicetype' => $devicetype, 'distribution' => $distribution]);
    }

    // DELETE /api/flash/{device_type}/{distribution}/{filename}
    public function deleteDistributionFile($device_type, $distribution, $filename) {
        header('Content-Type: application/json; charset=UTF-8');
        $filepath = "{$this->storageRoot}/{$device_type}/{$distribution}/{$filename}";
        if (!is_file($filepath)) {
            http_response_code(404);
            echo json_encode(['error' => 'File not found']);
            return;
        }
        if (!unlink($filepath)) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to delete file']);
            return;
        }
        echo json_encode(['success' => true]);
    }

    // GET /api/flash/device-types
    public function listDeviceTypes() {
        header('Content-Type: application/json; charset=UTF-8');
        $list = [];
        foreach (scandir($this->storageRoot) as $dir) {
            if ($dir === '.' || $dir === '..' || !is_dir($this->storageRoot . '/' . $dir)) continue;
            $list[] = $dir;
        }
        echo json_encode(['device_types' => $list]);
    }

    // GET /api/flash/{device_type}/distributions
    public function listDistributions($device_type) {
        header('Content-Type: application/json; charset=UTF-8');
        $dir = "{$this->storageRoot}/{$device_type}/";
        $list = [];
        if (!is_dir($dir)) {
            http_response_code(404);
            echo json_encode(['error' => 'Device type not found']);
            return;
        }
        foreach (scandir($dir) as $dist) {
            if ($dist === '.' || $dist === '..' || !is_dir($dir . $dist)) continue;
            $list[] = $dist;
        }
        echo json_encode(['distributions' => $list]);
    }
}
?>
