<?php
// File: api/controllers/StatusController.php
// Version: 1.5.0
// Date: 2025-05-31
// Author: Meeting Server Team
// Description: Status reporting endpoints for Meeting devices (device online reporting, service declaration, IP update, anti-spam, log cleanup, keepalive support)
require_once __DIR__ . '/../log_helpers.php';
//
// CHANGELOG:
// - 1.5.0 (2025-05-31): Centralise logfile path & max_logs via config.php
// - 1.4.0 (2025-05-27): Corrige la mise à jour du champ last_seen à chaque heartbeat (REST/API), garantit la cohérence de présence, pas de spam "Connected" (anti-doublon), frontend/tunnel OK.
// - 1.3.0 (2025-05-26): Patch anti-spam: no longer logs consecutive identical "Connected" status (host+remote). Keeps only real state changes. Delta check removed.
// - 1.2.2 (2025-05-24): Standard log cleanup, IP/hostname robust update, anti-spam interval for "Connected" log entries (delta<35s), improved input parsing.
// - 1.2.1 (2025-05-24): Refactor for config compliance, more robust log purge, comment updates.
// - 1.2.0 (2025-05-23): Initial extraction from DeviceController, per-device log cleanup, proper JSON headers.
//
class StatusController {
    private PDO $pdo;
    private string $logfile;
    private int $max_logs;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $configPath = dirname(__DIR__, 1) . '/config.php';
        $config = is_file($configPath) ? require($configPath) : [];
        $this->logfile  = $config['status_logfile'] ?? (__DIR__ . '/../logs/status_api.log');
        ensure_log_directory($this->logfile);
        $this->max_logs = isset($config['status_max_logs']) ? (int)$config['status_max_logs'] : 25;
    }

    // POST /api/devices/{device_key}/online
    public function deviceOnline($device_key) {
        header('Content-Type: application/json; charset=UTF-8');
        $hostname = gethostname();
        $body = json_decode(file_get_contents('php://input'), true);

        // Retrieve the device's real IP if provided, fallback to REMOTE_ADDR
        $device_ip = null;
        if (isset($body['ip_address']) && filter_var($body['ip_address'], FILTER_VALIDATE_IP)) {
            $device_ip = $body['ip_address'];
        } else {
            $device_ip = $_SERVER['REMOTE_ADDR'] ?? '';
        }

        // Check device exists
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        if ($stmt->fetchColumn() == 0) {
            http_response_code(404);
            $this->log("NOT FOUND", $device_key, $device_ip, "device not found");
            echo json_encode(['ok' => false, 'error' => 'Device not found']);
            return;
        }

        // Update device IP address and last_seen (toujours, même si pas de nouveau log)
        $nowUTC = (new DateTime('now', new DateTimeZone('UTC')))->format('Y-m-d H:i:s');
        $stmt = $this->pdo->prepare("UPDATE devices SET ip_address = ?, last_seen = ? WHERE device_key = ?");
        $stmt->execute([$device_ip, $nowUTC, $device_key]);

        // Update services if provided
        if (isset($body['services']) && is_array($body['services'])) {
            $fields = ['ssh', 'vnc', 'http', 'scp'];
            foreach ($fields as $srv) {
                if (isset($body['services'][$srv])) {
                    $stmt = $this->pdo->prepare("UPDATE devices SET service_$srv = ? WHERE device_key = ?");
                    $stmt->execute([$body['services'][$srv] ? 1 : 0, $device_key]);
                }
            }
        }

        // Update note if provided
        if (isset($body['note'])) {
            $note = trim($body['note']);
            if (mb_strlen($note) <= 2000) {
                $stmt = $this->pdo->prepare("UPDATE devices SET note = ? WHERE device_key = ?");
                $stmt->execute([$note, $device_key]);
            }
        }

        // --- PATCH v1.4.0: anti-doublon strict sur event+host+remote, mais last_seen toujours à jour ---
        $stmt = $this->pdo->prepare(
            "SELECT timestamp, event, host, remote FROM connection_logs WHERE device_key = ? ORDER BY timestamp DESC LIMIT 1"
        );
        $stmt->execute([$device_key]);
        $last = $stmt->fetch();
        $write_connected = true;

        if ($last) {
            if (
                $last['event'] === 'Connected'
                && $last['host'] === $hostname
                && $last['remote'] === $device_ip
            ) {
                // Same status, same server, same IP: skip insert
                $write_connected = false;
            }
        }

        if ($write_connected) {
            $stmt = $this->pdo->prepare(
                "INSERT INTO connection_logs (device_key, event, host, remote, timestamp)
                VALUES (?, 'Connected', ?, ?, ?)"
            );
            $stmt->execute([$device_key, $hostname, $device_ip, $nowUTC]);
            $this->log("CONNECTED", $device_key, $device_ip, "device reported online");
        } else {
            $this->log("ALREADY_CONNECTED", $device_key, $device_ip, "device already marked online (no db insert)");
        }

        // Clean up logs (keep max_logs most recent)
        $this->cleanupLogs($device_key);

        echo json_encode(['ok' => true, 'ip_address' => $device_ip, 'last_seen' => $nowUTC]);
    }

    // GET /api/devices/{device_key}/last-seen
    public function deviceLastSeen($device_key) {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare("SELECT last_seen FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $row = $stmt->fetch();
        if (!$row) {
            http_response_code(404);
            echo json_encode(['error' => 'Device not found']);
            return;
        }
        echo json_encode(['device_key' => $device_key, 'last_seen' => $row['last_seen']]);
    }

    // Remove old logs (keep only max_logs most recent)
    private function cleanupLogs($device_key): void {
        // Select IDs to delete (all except max_logs most recent)
        $stmt = $this->pdo->prepare(
            "SELECT id FROM connection_logs WHERE device_key = ? ORDER BY timestamp DESC LIMIT 18446744073709551615 OFFSET ?"
        );
        $stmt->execute([$device_key, $this->max_logs]);
        $ids = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
        if ($ids && count($ids) > 0) {
            $in = implode(',', array_fill(0, count($ids), '?'));
            $params = $ids;
            $sql = "DELETE FROM connection_logs WHERE id IN ($in)";
            $del = $this->pdo->prepare($sql);
            $del->execute($params);
        }
    }

    private function log($result, $device_key, $ip, $details): void {
        $line = sprintf("[%s] DEVICE:%s IP:%s => %s | %s\n",
            date('Y-m-d H:i:s'), $device_key, $ip, $result, $details);
        error_log($line, 3, $this->logfile);
    }
}
