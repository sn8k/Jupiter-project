<?php
// File: api/controllers/TunnelController.php
// Version: 2.2.3
// Date: 2025-06-24
// Author: Meeting Server Team (AI powered)
// Description: REST controller for device tunnel management (reverse tunnel architecture only).
require_once __DIR__ . '/../log_helpers.php';
//
// CHANGELOG:
// 2.2.0 (2025-05-31): Centralise all config (paths, host, logs) via config.php
// 2.1.0 (2025-05-31): Corrige: crée une demande de tunnel (fichier tunnel_requests) si aucun tunnel actif trouvé (workflow reverse tunnel correct!)
// 2.0.0 (2025-05-31): Adapté pour la stack Reverse Tunnel Meeting, plus de fallback/connexion directe au device. Toute gestion des ports = synchronisée avec le Proxy Node.js et la BDD (tunnel_ports). Ajout endpoint pour liste des tunnels actifs. Logging enrichi et homogène. Endpoint tunnel-pending amélioré (workflow agent polling). Statut tunnel bien enregistré (création, suppression, erreurs, etc).

class TunnelController {
    private PDO $pdo;
    private array $config;
    private string $requestsDir;
    private string $statusDir;
    private string $logfile;
    private string $host;
    private string $scp_path;
    private int $port_min;
    private int $port_max;
    private int $reservation_duration;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $configPath = dirname(__DIR__, 1) . '/config.php';
        $this->config = is_file($configPath) ? require($configPath) : [];

        // Centralisation config (avec fallback)
        $this->requestsDir = $this->config['tunnel_requests_dir'] ?? __DIR__ . '/../tunnel_requests';
        $this->statusDir   = $this->config['tunnel_status_dir']   ?? __DIR__ . '/../tunnel_status';
        $this->logfile     = $this->config['tunnel_logfile']      ?? (__DIR__ . '/../logs/tunnel_api.log');
        ensure_log_directory($this->logfile);
        $this->host        = $this->config['tunnel_host']         ?? 'clusterTO83.meeting.ygsoft.fr';
        $this->scp_path    = $this->config['scp_default_path']    ?? '/path';

        $this->port_min             = $this->config['forcecommand_port_min']             ?? 9050;
        $this->port_max             = $this->config['forcecommand_port_max']             ?? 9130;
        $this->reservation_duration = $this->config['forcecommand_reservation_duration'] ?? 300;

        if (!is_dir($this->requestsDir)) mkdir($this->requestsDir, 0775, true);
        if (!is_dir($this->statusDir)) mkdir($this->statusDir, 0775, true);
    }

    /**
     * POST /api/devices/{device_key}/authorize-tunnel
     */
    public function authorizeTunnel(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare(
            "SELECT device_key, authorized, token_code, token_count, distribution, registered_at 
             FROM devices WHERE device_key = ?"
        );
        $stmt->execute([$device_key]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            http_response_code(404);
            echo json_encode(["ok" => false, "error" => "Device not found"]);
            return;
        }
        if (!(bool)$row['authorized']) {
            http_response_code(403);
            echo json_encode(["ok" => false, "error" => "Device not authorized"]);
            return;
        }
        if ((int)$row['token_count'] <= 0) {
            http_response_code(403);
            echo json_encode(["ok" => false, "error" => "No tokens left"]);
            return;
        }
        echo json_encode([
            "ok"            => true,
            "device_key"    => $row['device_key'],
            "authorized"    => (bool)$row['authorized'],
            "token_code"    => $row['token_code'],
            "token_count"   => (int)$row['token_count'],
            "distribution"  => $row['distribution'],
            "registered_at" => $row['registered_at']
        ]);
    }

    /**
     * POST /api/devices/{device_key}/service
     * Input JSON: { "service": "http" }
     * Si tunnel SQL existe -> retourne le port/URL.
     * Sinon -> crée la demande tunnel_requests, attend polling agent.
     */
    public function createTunnel(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        if (!is_array($body) || empty($body['service'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing service param']);
            $this->log("CREATE_FAIL", $device_key, "-", "Missing service param");
            return;
        }
        $service = strtolower(trim($body['service']));
        $local_port = 22;
        if ($service === 'http') {
            $local_port = 80;
        } elseif ($service === 'vnc') {
            $local_port = 5900;
        } elseif ($service === 'relay') {
            $local_port = isset($body['port']) ? intval($body['port']) : 0;
            if ($local_port <= 0) {
                http_response_code(400);
                echo json_encode(['error' => 'Missing relay port']);
                return;
            }
        }

        // Vérifie device en BDD
        $stmt = $this->pdo->prepare("SELECT * FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$row) {
            http_response_code(404);
            echo json_encode(['error' => 'Device not found']);
            $this->log("CREATE_FAIL", $device_key, $service, "Device not found");
            return;
        }
        if (!(bool)$row['authorized']) {
            http_response_code(403);
            echo json_encode(['error' => 'Device not authorized']);
            $this->log("CREATE_FAIL", $device_key, $service, "Device not authorized");
            return;
        }
        if (empty($row['token_code'])) {
            http_response_code(403);
            echo json_encode(['error' => 'Device missing token']);
            $this->log("CREATE_FAIL", $device_key, $service, "Missing token");
            return;
        }

        // Cherche le port actif pour ce device/service (cohérent avec le proxy Meeting)
        $stmt2 = $this->pdo->prepare(
            "SELECT port, local_port, expires_at FROM tunnel_ports
             WHERE device_key = ? AND service = ? AND (expires_at IS NULL OR expires_at > UTC_TIMESTAMP())
             ORDER BY expires_at DESC LIMIT 1"
        );
        $stmt2->execute([$device_key, $service]);
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);

        if ($row2) {
            $port = intval($row2['port']);
            $expires_at = $row2['expires_at'];
            $host = $this->host;
            $url = "";
            switch ($service) {
                case "http":
                    $proto = "http";
                    $url = "{$proto}://{$host}:{$port}";
                    break;
                case "vnc":
                    $url = "vnc://{$host}:{$port}";
                    break;
                case "scp":
                    $url = "scp -P {$port} device@{$host}:{$this->scp_path}";
                    break;
                case "ssh":
                    $url = "ssh -p {$port} device@{$host}";
                    break;
                default:
                    $url = "{$host}:{$port}";
            }
            $out = ['port' => $port, 'url' => $url];
            if ($expires_at) $out['expires_at'] = $expires_at;
            echo json_encode($out);
            $this->log("TUNNEL_OK", $device_key, $service, "Port $port / $url / expires_at: $expires_at");
            return;
        }

        // === Aucun tunnel actif : allocation dynamique du port via la BDD ===
        $stmt = $this->pdo->prepare("SELECT port FROM tunnel_ports WHERE expires_at > UTC_TIMESTAMP()");
        $stmt->execute();
        $used_ports = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'port');

        $range_ports = range($this->port_min, $this->port_max);
        shuffle($range_ports);

        $free_port = null;
        foreach ($range_ports as $port) {
            if (!in_array($port, $used_ports)) { $free_port = $port; break; }
        }
        if (!$free_port) {
            http_response_code(503);
            echo json_encode(['error' => 'No available port in range']);
            return;
        }

        $expires_at = gmdate('Y-m-d H:i:s', time() + $this->reservation_duration); // UTC

        $stmt = $this->pdo->prepare(
            "INSERT INTO tunnel_ports (device_key, service, port, local_port, expires_at)".
            " VALUES (:device_key, :service, :port, :local_port, :expires_at)".
            " ON DUPLICATE KEY UPDATE port = :upd_port, local_port = :upd_local_port, expires_at = :upd_expires_at"
        );
        try {
            $stmt->execute([
                'device_key'     => $device_key,
                'service'        => $service,
                'port'           => $free_port,
                'local_port'     => $local_port,
                'expires_at'     => $expires_at,
                'upd_port'       => $free_port,
                'upd_local_port' => $local_port,
                'upd_expires_at' => $expires_at
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'DB error: ' . $e->getMessage()]);
            return;
        }

        $host = $this->host;
        switch ($service) {
            case 'http':
                $proto = 'http';
                $url = "{$proto}://{$host}:{$free_port}";
                break;
            case 'vnc':
                $url = "vnc://{$host}:{$free_port}";
                break;
            case 'scp':
                $url = "scp -P {$free_port} device@{$host}:{$this->scp_path}";
                break;
            case 'ssh':
                $url = "ssh -p {$free_port} device@{$host}";
                break;
            default:
                $url = "{$host}:{$free_port}";
        }
        $out = ['port' => $free_port, 'url' => $url, 'expires_at' => $expires_at];
        echo json_encode($out);
        $this->log("TUNNEL_ASSIGNED", $device_key, $service, "Port $free_port / $url / expires_at: $expires_at");
        return;
    }

    /**
     * GET /api/tunnels
     * Retourne la liste des tunnels actifs.
     */
    public function listTunnels(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare(
            "SELECT device_key, service, port, local_port, expires_at FROM tunnel_ports
             WHERE expires_at IS NULL OR expires_at > UTC_TIMESTAMP()
             ORDER BY device_key, service"
        );
        $stmt->execute();
        $tunnels = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['tunnels' => $tunnels]);
    }

    /**
     * GET /api/devices/{device_key}/tunnel-pending
     * Polling par l’agent device.
     */
    public function getPendingTunnel(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $pattern = $this->requestsDir . '/' . $device_key . '_*.json';
        $matches = glob($pattern);
        if (!$matches || count($matches) === 0) {
            echo json_encode(['pending' => false]);
            return;
        }
        $reqfile = $matches[0];
        $data = json_decode(file_get_contents($reqfile), true);
        if (!is_array($data)) $data = [];
        echo json_encode(['pending' => true, 'request' => $data]);
        $this->log("PENDING_SENT", $device_key, basename($reqfile), json_encode($data));
    }

    /**
     * POST /api/devices/{device_key}/tunnel-status
     * L’agent device poste ici le statut du tunnel créé (OK, erreur, upnp…)
     */
    public function setTunnelStatus(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        if (!is_array($body)) $body = [];

        $service = $body['service'] ?? null;
        $port    = $body['port']    ?? null;
        $url     = $body['url']     ?? null;
        $upnp    = $body['upnp']    ?? null;
        $error   = $body['error']   ?? null;

        if (!$service) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing service param']);
            $this->log("STATUS_MISSING", $device_key, "-", "service not specified");
            return;
        }
        $statusData = [
            'device_key' => $device_key,
            'service'    => $service,
            'port'       => $port,
            'url'        => $url,
            'upnp'       => $upnp,
            'error'      => $error,
            'reported_at'=> time(),
        ];
        $statusFile = "{$this->statusDir}/{$device_key}_{$service}.json";
        file_put_contents($statusFile, json_encode($statusData));
        $this->log("STATUS_SET", $device_key, $service, json_encode($statusData));
        echo json_encode(['ok' => true, 'status' => $statusData]);
    }

    // Logging helper
    private function log($event, $device_key, $target, $msg): void {
        $line = sprintf("[%s] %s | DEVICE:%s | %s | %s\n",
            date('Y-m-d H:i:s'), $event, $device_key, $target, $msg
        );
        error_log($line, 3, $this->logfile);
    }
}
?>
