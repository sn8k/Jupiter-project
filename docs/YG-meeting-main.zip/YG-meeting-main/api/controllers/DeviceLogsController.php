<?php
// File: api/controllers/DeviceLogsController.php
// Version: 1.0.2
// Date: 2025-05-31
// Author: Meeting Server Team
// Description: REST controller dedicated to device connection logs (extraction from DeviceController v2.6.1)
//
// CHANGELOG:
// - 1.0.2 (2025-05-31): Vérification conformité config.php (rien à centraliser pour l’instant), update version/date.
// - 1.0.1 (2025-05-24): Standardisation header JSON, commentaire, sécurité retour.
// - 1.0.0 (2025-05-23): Initial extraction of deviceLogs (GET) and purgeLogs (POST) from DeviceController v2.6.1
//

class DeviceLogsController {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    /**
     * GET /api/devices/{device_key}/logs
     * Retrieve the connection logs for the specified device.
     * @param string $device_key
     * @return void
     */
    public function deviceLogs(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare(
            "SELECT timestamp, event, host, remote FROM connection_logs WHERE device_key = ? ORDER BY timestamp DESC"
        );
        $stmt->execute([$device_key]);
        $rows = $stmt->fetchAll();
        echo json_encode($rows);
    }

    /**
     * POST /api/devices/{device_key}/purge-logs
     * Purge all connection logs for the specified device.
     * @param string $device_key
     * @return void
     */
    public function purgeLogs(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare("DELETE FROM connection_logs WHERE device_key = ?");
        $stmt->execute([$device_key]);
        echo json_encode(['success' => true]);
    }
}
?>
