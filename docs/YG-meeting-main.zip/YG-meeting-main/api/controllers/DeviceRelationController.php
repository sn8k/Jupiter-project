<?php
// File: api/controllers/DeviceRelationController.php
// Version: 1.0.2
// Date: 2025-05-31
// Author: Meeting Server Team
// Description: REST controller for device relationships and attributes (parent, ghost, bundles, product_serial, device_type)
//
// CHANGELOG:
// - 1.0.2 (2025-05-31): Vérification conformité config.php, update version/date.
// - 1.0.1 (2025-05-24): Ajout du header JSON sur chaque réponse pour cohérence, commentaires mineurs.
// - 1.0.0 (2025-05-23): Initial creation. Extracted parent/ghost/bundles/product_serial/device_type endpoints from DeviceController.
//

class DeviceRelationController {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    // PUT /api/devices/{device_key}/parent
    public function setParentDevice(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $parent = $body['parent_device_key'] ?? null;
        $stmt = $this->pdo->prepare("UPDATE devices SET parent_device_key = ? WHERE device_key = ?");
        $stmt->execute([$parent, $device_key]);
        echo json_encode(['success' => true, 'parent_device_key' => $parent]);
    }

    // PUT /api/devices/{device_key}/ghost
    public function setGhostCandidate(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $ghost_url = $body['ghost_candidate_url'] ?? null;
        $stmt = $this->pdo->prepare("UPDATE devices SET ghost_candidate_url = ? WHERE device_key = ?");
        $stmt->execute([$ghost_url, $device_key]);
        echo json_encode(['success' => true, 'ghost_candidate_url' => $ghost_url]);
    }

    // PUT /api/devices/{device_key}/bundles
    public function setBundles(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $bundles = is_array($body['bundles'] ?? null) ? json_encode($body['bundles']) : ($body['bundles'] ?? null);
        $stmt = $this->pdo->prepare("UPDATE devices SET bundles = ? WHERE device_key = ?");
        $stmt->execute([$bundles, $device_key]);
        echo json_encode(['success' => true, 'bundles' => $bundles]);
    }

    // PUT /api/devices/{device_key}/product-serial
    public function setProductSerial(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $serial = $body['product_serial'] ?? null;
        $stmt = $this->pdo->prepare("UPDATE devices SET product_serial = ? WHERE device_key = ?");
        $stmt->execute([$serial, $device_key]);
        echo json_encode(['success' => true, 'product_serial' => $serial]);
    }

    // PUT /api/devices/{device_key}/device-type
    public function setDeviceType(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $type = $body['device_type'] ?? null;
        $stmt = $this->pdo->prepare("UPDATE devices SET device_type = ? WHERE device_key = ?");
        $stmt->execute([$type, $device_key]);
        echo json_encode(['success' => true, 'device_type' => $type]);
    }
}
?>
