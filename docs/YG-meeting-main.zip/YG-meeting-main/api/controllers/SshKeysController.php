<?php
// File: api/controllers/SshKeysController.php
// Version: 1.9.3
// Date: 2025-06-23
// Author: Meeting Server Team
// Description: SSH Keys API for dynamic device key management and admin panel integration (Meeting project)
require_once __DIR__ . '/../log_helpers.php';
//
// Changelog:
// - v1.6.2 (2025-06-11): Create keys_root directory if missing.
// - v1.6.1 (2025-06-11): Fix fetch caching for PPK, version bump.
// - v1.6.0 (2025-06-11): Ajout de l'endpoint getPrivatePpk pour téléchargement PPK.
// - v1.5.0 (2025-06-01): CRUD device complet pour admin UI, audit log, fingerprint SHA256, gestion status, support création device à la volée.
// - v1.4.0 (2025-05-31): Centralisation logfile et SSH_API_TOKEN via config.php
// - v1.3.1 (2025-05-25): Ajout d'un appel à ygs-KeysSync.sh après MAJ de clé SSH
// - v1.3.0 (2025-05-25): Retrait de toute logique legacy/table device_keys, toutes les opérations sont faites sur devices.ssh_public_key
// - v1.2.1 (2025-05-24): Version stable pour gestion centralisée des clés SSH par device

class SshKeysController {
    private PDO $pdo;
    private string $logfile;
    private string $ssh_api_token;
    private string $keys_root;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $configPath = dirname(__DIR__, 1) . '/config.php';
        $config = is_file($configPath) ? require($configPath) : [];
        $this->logfile = $config['ssh_keys_logfile'] ?? (__DIR__ . '/../logs/ssh_keys_api.log');
        ensure_log_directory($this->logfile);
        $this->ssh_api_token = $config['ssh_api_token'] ?? (getenv('SSH_API_TOKEN') ?: 'REPLACE_ME');
        $this->keys_root = $config['device_keys_root'] ?? (__DIR__ . '/../device_private_keys');
        if (!is_dir($this->keys_root)) {
            @mkdir($this->keys_root, 0700, true);
        }
    }

    /**
     * GET /api/ssh-keys
     * Liste toutes les clés SSH devices (pour UI admin)
     */
    public function getAllDeviceKeys(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->query("
            SELECT 
                device_key, 
                ssh_user, 
                ssh_public_key AS pubkey, 
                authorized, 
                revoked,
                registered_at AS added, 
                modified,
                last_seen,
                -- ssh_last_access AS last_ssh, // utilise last_seen pour cohérence
                last_seen AS last_ssh
            FROM devices
            WHERE ssh_public_key IS NOT NULL AND ssh_public_key != ''
            ORDER BY registered_at DESC
        ");
        $rows = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $dev) {
            $status = ($dev['revoked'] ?? 0) ? 'revoked' : (($dev['authorized'] ?? 0) ? 'authorized' : 'unknown');
            $fingerprint = $this->sshFingerprint($dev['pubkey']);
            $rows[] = [
                'device_key'  => $dev['device_key'],
                'ssh_user'    => $dev['ssh_user'] ?? '',
                'pubkey'      => $dev['pubkey'],
                'status'      => $status,
                'added'       => $dev['added'] ?? '',
                'modified'    => $dev['modified'] ?? '',
                'fingerprint' => $fingerprint,
                'last_ssh'    => $dev['last_ssh'] ?? '',
            ];
        }
        echo json_encode(['keys' => $rows]);
    }

    /**
     * GET /api/devices/{device_key}/ssh-key
     * Retourne la clé publique SSH d’un device (avec métadonnées)
     */
    public function getSshKey(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $stmt = $this->pdo->prepare("SELECT device_key, ssh_user, ssh_public_key AS pubkey, authorized, revoked, registered_at AS added, modified, last_seen AS last_ssh FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $dev = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$dev || !$dev['pubkey']) {
            http_response_code(404);
            echo json_encode(['error' => 'SSH key not found for this device']);
            return;
        }
        $status = ($dev['revoked'] ?? 0) ? 'revoked' : (($dev['authorized'] ?? 0) ? 'authorized' : 'unknown');
        $fingerprint = $this->sshFingerprint($dev['pubkey']);
        echo json_encode([
            'device_key'  => $dev['device_key'],
            'ssh_user'    => $dev['ssh_user'] ?? '',
            'pubkey'      => $dev['pubkey'],
            'status'      => $status,
            'added'       => $dev['added'] ?? '',
            'modified'    => $dev['modified'] ?? '',
            'fingerprint' => $fingerprint,
            'last_ssh'    => $dev['last_ssh'] ?? '',
        ]);
    }

    /**
     * PUT /api/devices/{device_key}/ssh-key
     * Ajout/Màj clé publique SSH, ssh_user et statut (admin/devices)
     * Payload attendu : { "pubkey": "...", "ssh_user": "...", "status": "authorized|revoked" }
     */
    public function setDeviceSshKey(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $body = json_decode(file_get_contents('php://input'), true);
        $pubkey = trim($body['pubkey'] ?? '');
        $ssh_user = trim($body['ssh_user'] ?? '');
        $status = $body['status'] ?? null;

        if (!$pubkey) {
            http_response_code(400);
            $this->log("MISSING KEY", $ip, $device_key, "No pubkey in payload");
            echo json_encode(['error' => 'Missing pubkey']);
            return;
        }
        if (!preg_match('/^(ssh-(rsa|ed25519)|ecdsa-sha2-nistp\d+) [A-Za-z0-9+\/=]+(\s.*)?$/', $pubkey)) {
            http_response_code(400);
            $this->log("INVALID FORMAT", $ip, $device_key, "Invalid key");
            echo json_encode(['error' => 'Invalid SSH public key format']);
            return;
        }
        // Vérifie que le device existe, sinon création rapide possible
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM devices WHERE device_key = ?");
        $stmt->execute([$device_key]);
        if ($stmt->fetchColumn() == 0) {
            // Création nouveau device minimal
            $ins = $this->pdo->prepare("INSERT INTO devices (device_key, ssh_user, ssh_public_key, authorized, revoked, registered_at, modified) VALUES (?, ?, ?, ?, ?, NOW(), NOW())");
            $auth = ($status == 'authorized') ? 1 : 0;
            $rev  = ($status == 'revoked') ? 1 : 0;
            $ins->execute([$device_key, $ssh_user, $pubkey, $auth, $rev]);
            $this->log("CREATED", $ip, $device_key, "New device, key saved");
        } else {
            // Update device
            $q = "UPDATE devices SET ssh_public_key = ?, ssh_user = ?, modified = NOW()";
            $vals = [$pubkey, $ssh_user];
            if ($status !== null) {
                $q .= ", authorized = ?, revoked = ?";
                $vals[] = ($status == 'authorized') ? 1 : 0;
                $vals[] = ($status == 'revoked') ? 1 : 0;
            }
            $q .= " WHERE device_key = ?";
            $vals[] = $device_key;
            $upd = $this->pdo->prepare($q);
            $upd->execute($vals);
            $this->log("UPDATED", $ip, $device_key, "Key/user/status updated");
        }
        // Màj table device_keys pour compatibilité ForceCommand
        $sync = $this->pdo->prepare(
            "INSERT INTO device_keys (device_key, pubkey, created_at) " .
            "VALUES (?, ?, NOW()) " .
            "ON DUPLICATE KEY UPDATE pubkey = VALUES(pubkey), created_at = NOW()"
        );
        $sync->execute([$device_key, $pubkey]);
        // Synchronisation immédiate
        exec('sudo ' . dirname(__DIR__, 2) . '/resident_tools/ygs-KeysSync.sh sync > /dev/null 2>&1 &');
        echo json_encode(['success' => true]);
    }

    /**
     * DELETE /api/devices/{device_key}/ssh-key
     * Suppression (soft delete) de la clé SSH d’un device
     */
    public function removeSshKey(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $stmt = $this->pdo->prepare("UPDATE devices SET ssh_public_key = NULL, revoked = 1, modified = NOW() WHERE device_key = ?");
        $stmt->execute([$device_key]);
        $del = $this->pdo->prepare("DELETE FROM device_keys WHERE device_key = ?");
        $del->execute([$device_key]);
        $this->log("DELETED", $ip, $device_key, "SSH key deleted (revoked)");
        exec('sudo ' . dirname(__DIR__, 2) . '/resident_tools/ygs-KeysSync.sh sync > /dev/null 2>&1 &');
        echo json_encode(['success' => true]);
    }

    /**
     * GET /api/devices/{device_key}/ssh-key-log
     * Retourne l’historique des opérations sur la clé SSH du device
     */
    public function getSshKeyLog(string $device_key): void {
        header('Content-Type: application/json; charset=UTF-8');
        $logfile = $this->logfile;
        $logs = [];
        if (file_exists($logfile)) {
            $lines = file($logfile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach (array_reverse($lines) as $line) {
                if (strpos($line, $device_key) !== false) {
                    if (preg_match('/^\[(.*?)\] IP:(.*?) USER:(.*?) => (.*?) \| (.*)$/', $line, $m)) {
                        $logs[] = [
                            'timestamp' => $m[1],
                            'event'     => $m[4],
                            'detail'    => $m[5],
                            'ip'        => $m[2]
                        ];
                    }
                }
            }
        }
        echo json_encode($logs);
    }

    /**
     * GET /api/devices/{device_key}/private-ppk
     * Génère un fichier PPK (PuTTY) protégé par mot de passe aléatoire
     * et le renvoie en téléchargement. Le mot de passe est retourné
     * dans l'en-tête HTTP X-PPK-Passphrase.
     */
    public function getPrivatePpk(string $device_key): void {
        $path = rtrim($this->keys_root, '/')."/".$device_key;
        if (!is_file($path)) {
            http_response_code(404);
            echo json_encode(['error' => 'Private key not found']);
            return;
        }
        $password = bin2hex(random_bytes(8));
        $passFile = tempnam(sys_get_temp_dir(), 'ppkpass');
        $outFile  = tempnam(sys_get_temp_dir(), 'ppk');
        file_put_contents($passFile, $password);
        $cmd = sprintf('puttygen %s -O private -o %s --new-passphrase %s 2>&1',
            escapeshellarg($path), escapeshellarg($outFile), escapeshellarg($passFile));
        exec($cmd, $out, $ret);
        if ($ret !== 0 || !file_exists($outFile)) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to generate PPK']);
            @unlink($passFile); @unlink($outFile);
            return;
        }
        $data = file_get_contents($outFile);
        @unlink($passFile); @unlink($outFile);
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.$device_key.'.ppk"');
        header('X-PPK-Passphrase: '.$password);
        echo $data;
    }

    /**
     * Utilitaire : Calcul fingerprint SHA256 d’une clé SSH publique
     */
    private function sshFingerprint($pubkey): string {
        if (!$pubkey) return '';
        $parts = explode(' ', trim($pubkey));
        if (count($parts) < 2) return '';
        $decoded = base64_decode($parts[1], true);
        if ($decoded === false) return '';
        return 'SHA256:' . rtrim(base64_encode(hash('sha256', $decoded, true)), '=');
    }

    // === API legacy compatible pour usage serveur SSH dynamique ===

    /**
     * GET /api/ssh-keys?user=USERNAME
     * Utilisé côté serveur SSH pour fournir dynamiquement les clés publiques autorisées
     */
    public function getAuthorizedKeys(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

        $token = $_SERVER['HTTP_X_MEETING_SSH_TOKEN'] ?? '';
        if ($token !== $this->ssh_api_token && $ip !== '127.0.0.1' && $ip !== '::1') {
            http_response_code(401);
            $this->log("FAILED AUTH", $ip, null, "Token/IP NOK");
            echo json_encode(['error' => 'Unauthorized']);
            return;
        }

        $username = $_GET['user'] ?? '';
        if (!$username) {
            http_response_code(400);
            $this->log("MISSING USER", $ip, null, "No username param");
            echo json_encode(['error' => 'Missing user parameter']);
            return;
        }

        $stmt = $this->pdo->prepare("
            SELECT ssh_public_key 
            FROM devices 
            WHERE ssh_user = ? 
              AND authorized = 1 
              AND ssh_public_key IS NOT NULL 
              AND ssh_public_key != ''
              AND (revoked IS NULL OR revoked = 0)
        ");
        $stmt->execute([$username]);
        $rows = $stmt->fetchAll(PDO::FETCH_COLUMN);

        if (!$rows) {
            http_response_code(404);
            $this->log("NO KEYS", $ip, $username, "0 keys");
            echo json_encode(['keys' => []]);
            return;
        }

        $this->log("OK", $ip, $username, count($rows) . " key(s)");
        echo json_encode(['keys' => $rows]);
    }

    /**
     * GET /api/ssh-keys/devices?user=USERNAME
     * Liste tous les devices d’un user avec une clé SSH (optionnel, admin/debug)
     */
    public function listUserDevicesWithKeys(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

        $token = $_SERVER['HTTP_X_MEETING_SSH_TOKEN'] ?? '';
        if ($token !== $this->ssh_api_token && $ip !== '127.0.0.1' && $ip !== '::1') {
            http_response_code(401);
            $this->log("FAILED AUTH", $ip, null, "Token/IP NOK");
            echo json_encode(['error' => 'Unauthorized']);
            return;
        }

        $username = $_GET['user'] ?? '';
        if (!$username) {
            http_response_code(400);
            $this->log("MISSING USER", $ip, null, "No username param");
            echo json_encode(['error' => 'Missing user parameter']);
            return;
        }

        $stmt = $this->pdo->prepare("
            SELECT device_key, ssh_public_key, authorized, revoked
            FROM devices 
            WHERE ssh_user = ?
              AND ssh_public_key IS NOT NULL 
              AND ssh_public_key != ''
        ");
        $stmt->execute([$username]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['devices' => $rows]);
    }

    /**
     * POST /api/ssh-keys/server
     * Sauvegarde la clé publique SSH serveur et met à jour fingerprint/date
     */
    public function saveServerPubKey(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $body = json_decode(file_get_contents('php://input'), true);
        $pubkey = trim($body['pubkey'] ?? '');
        if (!$pubkey) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing pubkey']);
            return;
        }
        if (!preg_match('/^(ssh-(rsa|ed25519)|ecdsa-sha2-nistp\d+) [A-Za-z0-9+\/=]+(\s.*)?$/', $pubkey)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid SSH public key']);
            return;
        }
        $fingerprint = $this->sshFingerprint($pubkey);
        $dataRoot = getenv('MEETING_DATA_ROOT') ?: '/var/meeting';
        file_put_contents("$dataRoot/meeting_id_rsa.pub", $pubkey . "\n");
        file_put_contents("$dataRoot/meeting_id_rsa.pub.sha256", $fingerprint . "\n");

        $configFile = dirname(__DIR__) . '/config.php';
        $config = require $configFile;
        $config['server_pubkey_date'] = date('Y-m-d H:i:s');
        $content = "<?php\n// Version auto-generated " . date('Y-m-d H:i:s') . "\nreturn " . var_export($config, true) . ";\n";
        file_put_contents($configFile, $content);

        echo json_encode(['success' => true, 'fingerprint' => $fingerprint, 'date' => $config['server_pubkey_date']]);
    }

    /**
     * GET /api/ssh-hostkey
     * Retourne la ou les clés publiques SSH du serveur (format ssh-keyscan)
     */
    public function getServerHostKeys(): void {
        header('Content-Type: text/plain; charset=UTF-8');
        $dataRoot = getenv('MEETING_DATA_ROOT') ?: '/var/meeting';
        $pubPath = "$dataRoot/meeting_id_rsa.pub";
        if (!is_file($pubPath)) {
            http_response_code(404);
            echo "# hostkey missing\n";
            return;
        }
        $cfg = require dirname(__DIR__) . '/config.php';
        $host = $cfg['tunnel_host'] ?? ($_SERVER['HTTP_HOST'] ?? 'meeting');
        $lines = array_filter(array_map('trim', file($pubPath, FILE_IGNORE_NEW_LINES)));
        foreach ($lines as $line) {
            if ($line === '') continue;
            if (preg_match('/^[\w.-]+\s+ssh/', $line)) {
                echo $line . "\n";
            } else {
                echo $host . ' ' . $line . "\n";
            }
        }
    }

    /**
     * POST /api/ssh-keys/server/regenerate
     * Regénère la clé serveur via script shell et met à jour la config
     */
    public function regenerateServerKey(): void {
        header('Content-Type: application/json; charset=UTF-8');
        $script = dirname(__DIR__, 2) . '/tools/setup-files/regen_meeting_sshkey.sh';
        exec('sudo ' . escapeshellarg($script) . ' regen > /dev/null 2>&1', $o, $ret);
        if ($ret !== 0) {
            http_response_code(500);
            echo json_encode(['error' => 'Generation failed']);
            return;
        }
        $dataRoot = getenv('MEETING_DATA_ROOT') ?: '/var/meeting';
        $pubPath = "$dataRoot/meeting_id_rsa.pub";
        if (is_file($pubPath)) {
            $pubkey = trim(file_get_contents($pubPath));
            $fingerprint = $this->sshFingerprint($pubkey);
            file_put_contents("$dataRoot/meeting_id_rsa.pub.sha256", $fingerprint . "\n");

            $configFile = dirname(__DIR__) . '/config.php';
            $config = require $configFile;
            $config['server_pubkey_date'] = date('Y-m-d H:i:s');
            $content = "<?php\n// Version auto-generated " . date('Y-m-d H:i:s') . "\nreturn " . var_export($config, true) . ";\n";
            file_put_contents($configFile, $content);

            echo json_encode(['success' => true, 'pubkey' => $pubkey, 'fingerprint' => $fingerprint, 'date' => $config['server_pubkey_date']]);
            return;
        }
        echo json_encode(['success' => true]);
    }

    // Logging interne
    private function log($result, $ip, $username, $details): void {
        $line = sprintf("[%s] IP:%s USER:%s => %s | %s\n",
            date('Y-m-d H:i:s'), $ip, $username, $result, $details);
        error_log($line, 3, $this->logfile);
    }
}
