<?php
// File: api/controllers/ForceCommandController.php
// Version: 2.1.4
// Date: 2025-06-24
// Author: Meeting Server Team
// Description: REST Controller API for ForceCommand/Meeting device SSH key registration, validation,
//              tunnel port management (reverse-tunnel-ready, heartbeat HTTP), and key removal.
//
// CHANGELOG:
// - 2.1.0 (2025-05-31): Centralisation via config.php (plage ports, délai heartbeat, durée réservation).
// - 2.0.0 (2025-05-31): Vérification présence device via last_seen (heartbeat HTTP). Plus de dépendance à la présence SSH ou à une connexion entrante. Robustesse reverse-tunnel prod.

class ForceCommandController {
    private $pdo;

    // Configurable params (remplacent les const)
    private $port_min;
    private $port_max;
    private $max_last_seen;
    private $reservation_duration;

    public function __construct($pdo) {
        $this->pdo = $pdo;

        // Chargement de la config
        $configPath = dirname(__DIR__, 1) . '/config.php';
        $config = is_file($configPath) ? require($configPath) : [];

        // Centralisation
        $this->port_min             = isset($config['forcecommand_port_min']) ? intval($config['forcecommand_port_min']) : 9050;
        $this->port_max             = isset($config['forcecommand_port_max']) ? intval($config['forcecommand_port_max']) : 9130;
        $this->max_last_seen        = isset($config['forcecommand_max_last_seen']) ? intval($config['forcecommand_max_last_seen']) : 120; // secondes
        $this->reservation_duration = isset($config['forcecommand_reservation_duration']) ? intval($config['forcecommand_reservation_duration']) : (5*60); // secondes
    }

    // POST /api/forcecommand/register_device_key
    public function registerDeviceKey() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (empty($input['device_key']) || empty($input['pubkey'])) {
            $this->json_response(['error' => 'Missing device_key or pubkey'], 400);
        }
        $device_key = $input['device_key'];
        $pubkey    = $input['pubkey'];

        $stmt = $this->pdo->prepare(
            "INSERT INTO device_keys (device_key, pubkey, created_at)
             VALUES (:device_key, :pubkey, NOW())
             ON DUPLICATE KEY UPDATE pubkey = :pubkey, created_at = NOW()"
        );
        try {
            $stmt->execute([
                'device_key' => $device_key,
                'pubkey'     => $pubkey
            ]);
            $this->json_response(['status' => 'ok']);
        } catch (PDOException $e) {
            $this->json_response(['error' => 'DB error: ' . $e->getMessage()], 500);
        }
    }

    // POST /api/forcecommand/validate_device_key
    public function validateDeviceKey() {
        $input = json_decode(file_get_contents('php://input'), true);
        if (empty($input['pubkey'])) {
            $this->json_response(['error' => 'Missing pubkey'], 400);
        }
        $pubkey = $input['pubkey'];

        $stmt = $this->pdo->prepare(
            "SELECT device_key FROM device_keys WHERE pubkey = :pubkey LIMIT 1"
        );
        $stmt->execute(['pubkey' => $pubkey]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && $row['device_key']) {
            $this->json_response(['status' => 'ok', 'device_key' => $row['device_key']]);
        } else {
            $this->json_response(['status' => 'invalid'], 401);
        }
    }

    // GET /api/forcecommand/get_device_key?device_key=XXX
    public function getDeviceKey() {
        if (empty($_GET['device_key'])) {
            $this->json_response(['error' => 'Missing device_key'], 400);
        }
        $device_key = $_GET['device_key'];

        $stmt = $this->pdo->prepare(
            "SELECT pubkey FROM device_keys WHERE device_key = :device_key LIMIT 1"
        );
        $stmt->execute(['device_key' => $device_key]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && $row['pubkey']) {
            header('Content-Type: text/plain');
            echo $row['pubkey'];
            exit;
        }

        // Fallback sur devices.ssh_public_key
        $stmt = $this->pdo->prepare(
            "SELECT ssh_public_key FROM devices WHERE device_key = :device_key LIMIT 1"
        );
        $stmt->execute(['device_key' => $device_key]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && $row['ssh_public_key']) {
            // Mise à jour device_keys pour cohérence future
            $sync = $this->pdo->prepare(
                "INSERT INTO device_keys (device_key, pubkey, created_at) " .
                "VALUES (:device_key, :pubkey, NOW()) " .
                "ON DUPLICATE KEY UPDATE pubkey = :pubkey, created_at = NOW()"
            );
            $sync->execute(['device_key' => $device_key, 'pubkey' => $row['ssh_public_key']]);
            header('Content-Type: text/plain');
            echo $row['ssh_public_key'];
            exit;
        }

        $this->json_response(['status' => 'not_found'], 404);
    }

    // POST /api/devices/{device_key}/request-tunnel-port
    public function requestTunnelPort($device_key = null) {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!is_array($input)) $input = [];
        // Récupération du device_key depuis route, GET, ou body JSON
        if (!$device_key) {
            $device_key = $_GET['device_key'] ?? $input['device_key'] ?? null;
        }
        $service = $_GET['service'] ?? $input['service'] ?? 'ssh';
        $local_port = 22;
        if ($service === 'http') {
            $local_port = 80;
        } elseif ($service === 'vnc') {
            $local_port = 5900;
        } elseif ($service === 'relay') {
            $local_port = intval($_GET['port'] ?? $input['port'] ?? 0);
            if ($local_port <= 0) {
                $this->json_response(['error' => 'Missing relay port'], 400);
            }
        }
        if (!$device_key) {
            $this->json_response(['error' => 'Missing device_key'], 400);
        }

        // ==== PRÉSENCE DEVICE via last_seen (reverse tunnel only) ====
        $stmt = $this->pdo->prepare("SELECT last_seen, authorized FROM devices WHERE device_key = :device_key LIMIT 1");
        $stmt->execute(['device_key' => $device_key]);
        $dev = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$dev) {
            $this->json_response(['error' => 'Unknown device_key'], 404);
        }
        if (!(bool)$dev['authorized']) {
            $this->json_response(['error' => 'Device not authorized'], 403);
        }
        $lastSeen = $dev['last_seen'];
        $is_online = false;
        if ($lastSeen) {
            $now = new DateTime('now', new DateTimeZone('UTC'));
            $dtLast = new DateTime($lastSeen, new DateTimeZone('UTC'));
            $delta = $now->getTimestamp() - $dtLast->getTimestamp();
            $is_online = ($delta <= $this->max_last_seen);
        }
        if (!$is_online) {
            $this->json_response(['error' => 'Device offline (no recent heartbeat)'], 503);
        }

        // Vérifie si le device a déjà un port réservé pour ce service
        $stmt = $this->pdo->prepare(
            "SELECT port FROM tunnel_ports WHERE device_key = :device_key AND service = :service AND expires_at > UTC_TIMESTAMP() LIMIT 1"
        );
        $stmt->execute(['device_key' => $device_key, 'service' => $service]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && isset($row['port'])) {
            $this->json_response(['status' => 'ok', 'port' => intval($row['port'])]);
        }

        // Cherche tous les ports utilisés (toujours actuels)
        $stmt = $this->pdo->prepare("SELECT port FROM tunnel_ports WHERE expires_at > UTC_TIMESTAMP()");
        $stmt->execute();
        $used_ports = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'port');

        // Prépare la liste complète, shuffle pour random
        $range_ports = range($this->port_min, $this->port_max);
        shuffle($range_ports);

        $free_port = null;
        foreach ($range_ports as $port) {
            if (!in_array($port, $used_ports)) {
                $free_port = $port;
                break;
            }
        }
        if (!$free_port) {
            $this->json_response(['error' => 'No available port in range'], 503);
        }

        // Réserve le port pour ce device (valide X secondes)
        $expires_at = gmdate('Y-m-d H:i:s', time() + $this->reservation_duration); // UTC

        // Correction bug PDO/duplicate params : utiliser des noms distincts pour chaque occurrence
        $stmt = $this->pdo->prepare(
            "INSERT INTO tunnel_ports (device_key, service, port, local_port, expires_at)
            VALUES (:device_key, :service, :port, :local_port, :expires_at)
            ON DUPLICATE KEY UPDATE port = :upd_port, local_port = :upd_local_port, expires_at = :upd_expires_at"
        );
        try {
            $stmt->execute([
                'device_key'     => $device_key,
                'service'        => $service,
                'port'           => $free_port,
                'local_port'     => $local_port,
                'expires_at'     => $expires_at,
                'upd_port'       => $free_port,
                'upd_local_port' => $local_port,
                'upd_expires_at' => $expires_at
            ]);
            $this->json_response(['status' => 'ok', 'port' => $free_port]);
        } catch (PDOException $e) {
            $this->json_response(['error' => 'DB error: ' . $e->getMessage()], 500);
        }
    }

    // DELETE /api/forcecommand/remove_device_key
    public function removeDeviceKey() {
        $input = json_decode(file_get_contents('php://input'), true);
        $device_key = $input['device_key'] ?? $_GET['device_key'] ?? null;
        if (!$device_key) {
            $this->json_response(['error' => 'Missing device_key'], 400);
        }
        $stmt = $this->pdo->prepare("DELETE FROM device_keys WHERE device_key = :device_key");
        try {
            $stmt->execute(['device_key' => $device_key]);
            $rowCount = $stmt->rowCount();
            if ($rowCount > 0) {
                $this->json_response(['status' => 'ok', 'deleted' => $rowCount]);
            } else {
                $this->json_response(['status' => 'not_found', 'deleted' => 0], 404);
            }
        } catch (PDOException $e) {
            $this->json_response(['error' => 'DB error: ' . $e->getMessage()], 500);
        }
    }

    // Utilitaire pour réponse JSON RESTful
    private function json_response($arr, $code = 200) {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode($arr);
        exit;
    }
}
?>
