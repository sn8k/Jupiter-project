<?php

// File: api/index.php
// Version: 3.10.5
// Date: 2025-06-24
// Author: Meeting Server Team
// Description: REST API entrypoint for Meeting project, Reverse Tunnel Ready (devices, tunnels, logs, etc.)
// CHANGELOG:
// 3.7.0 (2025-06-13): Add DeviceTypeController routing.
// 3.4.7 (2025-06-13): Auth check for /api/builder endpoints.
// 3.4.4 (2025-06-13): Gestion des erreurs fatales via register_shutdown_function.
// 3.4.3 (2025-06-12): Journalisation de chaque requête HTTP via backend_logfile.
// 3.4.2 (2025-06-11): Ensure keys root folder exists.
// 3.4.1 (2025-06-11): Minor fixes on PPK download tab.
// 3.4.0 (2025-06-11): Endpoint GET /api/devices/{device_key}/private-ppk pour génération de clé PPK.
// 3.3.0 (2025-06-01): Ajout des endpoints GET /api/ssh-keys (all device keys, admin), GET /api/devices/{device_key}/ssh-key-log (audit log), compatibilité avancée UI admin_ssh_keys.php
// 3.2.1 (2025-06-01): Exposition/restauration des endpoints GET/DELETE sur /api/devices/{device_key}/ssh-key (SshKeysController), refonte clean du routage multi-méthode.
// 3.2.0 (2025-05-31): Ajout/refonte routage endpoints reverse tunnel, endpoint global /api/tunnels, code maintenable et production-ready.

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// --- DB & config ---
$config = require __DIR__ . '/config.php';
require_once __DIR__ . '/log_helpers.php';
$backendLog = $config['backend_logfile'] ?? __DIR__ . '/logs/backend_api.log';
$reqLine = sprintf("[%s] %s %s FROM %s\n", date('Y-m-d H:i:s'), $_SERVER['REQUEST_METHOD'], $_SERVER['REQUEST_URI'] ?? '-', $_SERVER['REMOTE_ADDR'] ?? 'unknown');
write_log($backendLog, $reqLine);
set_error_handler(function($severity, $message, $file, $line) use ($backendLog) {
    $log = sprintf("[%s] PHP ERROR %s:%d %s\n", date('Y-m-d H:i:s'), $file, $line, $message);
    write_log($backendLog, $log);
});
set_exception_handler(function($e) use ($backendLog) {
    $log = sprintf("[%s] EXCEPTION %s:%d %s\n", date('Y-m-d H:i:s'), $e->getFile(), $e->getLine(), $e->getMessage());
    write_log($backendLog, $log);
});
register_shutdown_function(function() use ($backendLog) {
    $e = error_get_last();
    if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        $log = sprintf("[%s] FATAL %s:%d %s\n", date('Y-m-d H:i:s'), $e['file'], $e['line'], $e['message']);
        write_log($backendLog, $log);
    }
});
$dsn = getenv('DB_DSN');
$user = $config['db_user'];
$pass = $config['db_pass'];
if (!$dsn) {
    $dsn = "mysql:host={$config['db_host']};dbname={$config['db_name']};charset={$config['db_charset']}";
} elseif (str_starts_with($dsn, 'sqlite:')) {
    $user = null;
    $pass = null;
}
try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$segments = explode('/', $uri);

if ($uri === 'api' || $uri === 'api/') {
    echo json_encode(['status' => 'Meeting API ready', 'version' => '3.3.1']);
    exit;
}

if (array_shift($segments) !== 'api') {
    http_response_code(404);
    echo json_encode(['error' => 'Not Found']);
    exit;
}

$resource = array_shift($segments);
$key      = $segments[0] ?? null;
$action   = $segments[1] ?? null;

// ==================== TUNNEL REVERSE CONTROLLER ENDPOINTS ====================

if ($resource === 'tunnels' && $method === 'GET') {
    require_once __DIR__ . '/controllers/TunnelController.php';
    (new TunnelController($pdo))->listTunnels(); exit;
}

if ($resource === 'devices' && $key && $action === 'service' && $method === 'POST') {
    require_once __DIR__ . '/controllers/TunnelController.php';
    (new TunnelController($pdo))->createTunnel($key); exit;
}

if ($resource === 'devices' && $key && $action === 'authorize-tunnel' && $method === 'POST') {
    require_once __DIR__ . '/controllers/TunnelController.php';
    (new TunnelController($pdo))->authorizeTunnel($key); exit;
}

if ($resource === 'devices' && $key && $action === 'tunnel-pending' && $method === 'GET') {
    require_once __DIR__ . '/controllers/TunnelController.php';
    (new TunnelController($pdo))->getPendingTunnel($key); exit;
}

if ($resource === 'devices' && $key && $action === 'tunnel-status' && $method === 'POST') {
    require_once __DIR__ . '/controllers/TunnelController.php';
    (new TunnelController($pdo))->setTunnelStatus($key); exit;
}

// ==================== RESTE DES ENDPOINTS EXISTANTS ====================

if ($resource === 'devices' && $key && $action === 'online' && $method === 'POST') {
    require_once __DIR__ . '/controllers/StatusController.php';
    $ctrl = new StatusController($pdo);
    $ctrl->deviceOnline($key);
    exit;
}

// =========== FLASH NATIVE ROUTING ===========
if ($resource === 'flash') {
    require_once __DIR__ . '/controllers/FlashController.php';
    $ctrl = new FlashController($pdo);
    if ($method === 'GET' && $key && $action === 'distribution-files') {
        $ctrl->listDistributionFiles($key); exit;
    }
    if ($method === 'POST' && $key === 'upload') {
        $ctrl->uploadDistributionFile(); exit;
    }
    if ($method === 'POST' && $key === 'create-type') {
        $ctrl->createDeviceType(); exit;
    }
    if ($method === 'POST' && $key === 'create-distribution') {
        $ctrl->createDistribution(); exit;
    }
    if ($method === 'GET' && $key === 'device-types') {
        $ctrl->listDeviceTypes(); exit;
    }
    if ($method === 'GET' && $key && isset($segments[1]) && $segments[1] === 'distributions') {
        $ctrl->listDistributions($key); exit;
    }
    if ($method === 'DELETE' && $key && isset($segments[1]) && isset($segments[2])) {
        $ctrl->deleteDistributionFile($key, $segments[1], $segments[2]); exit;
    }
    http_response_code(404); echo json_encode(['error' => 'Unknown endpoint']); exit;
}

// =========== BUILDER ROUTING ===========
if ($resource === 'builder') {
    require_once __DIR__ . '/controllers/BuilderController.php';
    $b = new BuilderController();
    $b->requireAuth();
    if ($method === 'GET' && $key === 'whoami') { $b->whoami(); exit; }
    if ($method === 'GET' && $key === 'device-types') { $b->listDeviceTypes(); exit; }
    if ($method === 'GET' && $key === 'distributions') { $b->listDistributions(); exit; }
    if ($method === 'POST' && $key === 'suggest-version') { $b->suggestVersion(); exit; }
    if ($method === 'POST' && $key === 'start') { $b->startBuild(); exit; }
    if ($method === 'POST' && $key === 'upload-file') { $b->uploadFile(); exit; }
    if ($method === 'GET' && $key === 'manifest') { $b->getManifest(); exit; }
    if ($method === 'POST' && $key === 'manifest') { $b->updateManifest(); exit; }
    if ($method === 'POST' && $key === 'package') { $b->packageBuild(); exit; }
    if ($method === 'GET' && $key === 'package-status') { $b->packageStatus(); exit; }
    if ($method === 'GET' && $key === 'download' && isset($segments[1])) { $b->download($segments[1]); exit; }
    if ($method === 'POST' && $key === 'commit') { $b->commit(); exit; }
    if ($method === 'GET' && $key === 'history') { $b->history(); exit; }
    if ($method === 'POST' && $key === 'rollback') { $b->rollback(); exit; }
    if ($method === 'POST' && $key === 'duplicate') { $b->duplicate(); exit; }
    http_response_code(404); echo json_encode(['error' => 'Unknown endpoint']); exit;
} 

// =================== DEVICE TYPES ROUTING ===================
if ($resource === 'device-types') {
    require_once __DIR__ . '/controllers/DeviceTypeController.php';
    $dt = new DeviceTypeController($pdo);
    if ($method === 'GET' && !$key) { $dt->listTypes(); exit; }
    if ($method === 'POST' && !$key) { $dt->createType(); exit; }
    if ($method === 'PUT' && $key && !$action) { $dt->updateType((int)$key); exit; }
    if ($method === 'POST' && $key && $action === 'fork') { $dt->forkType((int)$key); exit; }
    if ($method === 'POST' && $key && $action === 'merge') { $dt->mergeType((int)$key); exit; }
    if ($method === 'DELETE' && $key && !$action) { $dt->deleteType((int)$key); exit; }
    http_response_code(404); echo json_encode(['error' => 'Unknown endpoint']); exit;
}

// =================== FORCECOMMAND ROUTING ===================
if ($resource === 'forcecommand') {
    require_once __DIR__ . '/controllers/ForceCommandController.php';
    $fc = new ForceCommandController($pdo);
    if ($method === 'GET' && $key === 'get_device_key') { $fc->getDeviceKey(); exit; }
    if ($method === 'POST' && $key === 'register_device_key') { $fc->registerDeviceKey(); exit; }
    if ($method === 'POST' && $key === 'validate_device_key') { $fc->validateDeviceKey(); exit; }
    if ($method === 'POST' && $key === 'request-port') { $fc->requestTunnelPort(); exit; }
    if ($method === 'DELETE' && $key === 'remove_device_key') { $fc->removeDeviceKey(); exit; }
    http_response_code(404); echo json_encode(['error' => 'Unknown endpoint']); exit;
}

// =================== DEVICE CONTROLLER CRUD + SPECIALS ===================
if ($resource === 'devices') {
    require_once __DIR__ . '/controllers/DeviceController.php';
    $ctrl = new DeviceController($pdo);

    if ($method === 'GET' && !$key) {
        $ctrl->listDevices(); exit;
    }
    if ($method === 'POST' && $key === 'manual-create') {
        $ctrl->manualCreateDevice(); exit;
    }
    if ($method === 'GET' && $key === 'generate-key') {
        $ctrl->generateDeviceKey(); exit;
    }
    if ($method === 'POST' && $key === 'generate-and-register') {
        $ctrl->generateAndRegisterDevice(); exit;
    }
    if ($method === 'DELETE' && $key && !$action) {
        $ctrl->deleteDevice($key); exit;
    }
    if ($method === 'GET' && $key && !$action) {
        $ctrl->getDevice($key); exit;
    }
    if ($method === 'PUT' && $key && !$action) {
        if (method_exists($ctrl, 'updateDevice')) $ctrl->updateDevice($key);
        else { http_response_code(501); echo json_encode(['error' => 'Not implemented']); }
        exit;
    }
    if ($method === 'GET' && $key && $action === 'note') {
        $ctrl->getDeviceNote($key); exit;
    }
    if ($method === 'PUT' && $key && $action === 'note') {
        $ctrl->setDeviceNote($key); exit;
    }
    if ($method === 'GET' && $key === 'device-types' && !isset($segments[1])) {
        $ctrl->getDeviceTypes(); exit;
    }
    if ($method === 'GET' && $key === 'device-types' && isset($segments[1]) && isset($segments[2]) && $segments[2] === 'distributions') {
        $ctrl->getDistributionsForDeviceType($segments[1]); exit;
    }
    if ($method === 'GET' && $key && $action === 'distrib-json') {
        $ctrl->getDistribJson($key); exit;
    }
    if ($method === 'PUT' && $key && $action === 'distrib-json') {
        $ctrl->setDistribJson($key); exit;
    }
    if ($method === 'GET' && $key && $action === 'service') {
        $ctrl->getDeviceServices($key); exit;
    }

    if ($key && $action === 'logs' && $method === 'GET') {
        require_once __DIR__ . '/controllers/DeviceLogsController.php';
        (new DeviceLogsController($pdo))->deviceLogs($key); exit;
    }
    if ($key && $action === 'purge-logs' && $method === 'POST') {
        require_once __DIR__ . '/controllers/DeviceLogsController.php';
        (new DeviceLogsController($pdo))->purgeLogs($key); exit;
    }

    if ($key && $action === 'availability' && $method === 'GET') {
        require_once __DIR__ . '/controllers/DeviceAvailabilityController.php';
        (new DeviceAvailabilityController($pdo))->deviceAvailability($key); exit;
    }

    if ($key && $action && $method === 'PUT' && in_array($action, ['parent', 'ghost', 'bundles', 'product-serial', 'device-type'])) {
        require_once __DIR__ . '/controllers/DeviceRelationController.php';
        $rel = new DeviceRelationController($pdo);
        switch ($action) {
            case 'parent':         $rel->setParentDevice($key); break;
            case 'ghost':          $rel->setGhostCandidate($key); break;
            case 'bundles':        $rel->setBundles($key); break;
            case 'product-serial': $rel->setProductSerial($key); break;
            case 'device-type':    $rel->setDeviceType($key); break;
            case 'distribution':   $ctrl->setDistribution($key); break;
        }
        exit;
    }

    if ($key && $action && in_array($action, ['flash-request', 'authorize', 'tokens', 'distribution', 'token-code'])) {
        require_once __DIR__ . '/controllers/FlashController.php';
        $f = new FlashController($pdo);
        switch ([$method, $action]) {
            case ['POST', 'flash-request']: $f->flashRequest($key); exit;
            case ['PUT',  'authorize']:     $f->setAuthorization($key); exit;
            case ['PUT',  'tokens']:        $f->setTokens($key); exit;
            case ['PUT',  'distribution']:  $f->setDistribution($key); exit;
            case ['PUT',  'token-code']:    $f->setTokenCode($key); exit;
        }
    }

    if ($method === 'POST' && $key && $action === 'request-tunnel-port') {
        require_once __DIR__ . '/controllers/ForceCommandController.php';
        (new ForceCommandController($pdo))->requestTunnelPort($key);
        exit;
    }

    // ========== Clé SSH (SshKeysController) ==========
    if ($key && $action === 'ssh-key') {
        require_once __DIR__ . '/controllers/SshKeysController.php';
        $ssh = new SshKeysController($pdo);
        switch ($method) {
            case 'PUT':
                $ssh->setDeviceSshKey($key);
                break;
            case 'GET':
                $ssh->getSshKey($key);
                break;
            case 'DELETE':
                $ssh->removeSshKey($key);
                break;
            default:
                http_response_code(405);
                echo json_encode(['error' => 'Method Not Allowed']);
                break;
        }
        exit;
    }

    // ========== AUDIT LOG SSH Key ==========
    if ($key && $action === 'ssh-key-log' && $method === 'GET') {
        require_once __DIR__ . '/controllers/SshKeysController.php';
        $ssh = new SshKeysController($pdo);
        $ssh->getSshKeyLog($key);
        exit;
    }

    if ($key && $action === 'private-ppk' && $method === 'GET') {
        require_once __DIR__ . '/controllers/SshKeysController.php';
        $ssh = new SshKeysController($pdo);
        $ssh->getPrivatePpk($key);
        exit;
    }

    http_response_code(404);
    echo json_encode(['error' => 'Unknown endpoint']);
    exit;
}

// =================== SSH-KEYS ENDPOINTS (routing centralisé, backward compatible & admin UI) ===================
if ($resource === 'ssh-keys') {
    require_once __DIR__ . '/controllers/SshKeysController.php';
    $ctrl = new SshKeysController($pdo);
    // == UI Admin: liste toutes les clés device ==
    if ($method === 'GET' && !$key) {
        $ctrl->getAllDeviceKeys(); exit;
    }
    if ($method === 'POST' && $key === 'server' && !$action) {
        $ctrl->saveServerPubKey(); exit;
    }
    if ($method === 'POST' && $key === 'server' && $action === 'regenerate') {
        $ctrl->regenerateServerKey(); exit;
    }
    if ($method === 'GET' && $key === 'devices') {
        $ctrl->listUserDevicesWithKeys(); exit;
    }
    // Legacy pour usage SSH serveur
    if ($method === 'GET' && isset($_GET['user'])) {
        $ctrl->getAuthorizedKeys(); exit;
    }
    http_response_code(404);
    echo json_encode(['error' => 'Unknown endpoint']); exit;
}

// =================== SSH HOSTKEY ===================
if ($resource === 'ssh-hostkey' && $method === 'GET') {
    require_once __DIR__ . '/controllers/SshKeysController.php';
    (new SshKeysController($pdo))->getServerHostKeys();
    exit;
}

// =================== STATUS ENDPOINTS ===================
if ($resource === 'status') {
    require_once __DIR__ . '/controllers/StatusController.php';
    $ctrl = new StatusController($pdo);
    if ($method === 'POST' && $key && $action === 'online') {
        $ctrl->deviceOnline($key); exit;
    }
    if ($method === 'GET' && $key && $action === 'last-seen') {
        $ctrl->deviceLastSeen($key); exit;
    }
    if ($method === 'GET' && $key === 'tunnel') {
        $ctrl->tunnelStatus(); exit;
    }
    http_response_code(404);
    echo json_encode(['error' => 'Unknown endpoint']); exit;
}

// =================== METRICS ENDPOINTS ===================
if ($resource === 'metrics') {
    require_once __DIR__ . '/controllers/MetricsController.php';
    $actionParam = $_GET['action'] ?? null;
    if ($method === 'GET' && ($actionParam === 'get' || !$actionParam)) {
        MetricsController::getMetrics(); exit;
    }
    if ($method === 'GET' && $actionParam === 'logs') {
        $lines = isset($_GET['lines']) ? intval($_GET['lines']) : 100;
        MetricsController::getMetricsLogs($lines); exit;
    }
    if ($method === 'GET' && $actionParam === 'prometheus' && method_exists('MetricsController', 'exportPrometheus')) {
        (new MetricsController())->exportPrometheus(); exit;
    }
    http_response_code(404);
    echo json_encode(['error' => 'Unknown metrics endpoint']); exit;
}

// =================== USERS ENDPOINTS ===================
if ($resource === 'users') {
    require_once __DIR__ . '/controllers/UserController.php';
    $u = new UserController($pdo);
    if ($method === 'GET' && $key === 'authorized-keys') { $u->getAuthorizedKeys(); exit; }
    if ($method === 'GET' && !$key) { $u->listUsers(); exit; }
    if ($method === 'POST' && !$key) { $u->createUser(); exit; }
    if ($method === 'GET' && $key && !$action) { $u->getUser((int)$key); exit; }
    if ($method === 'PUT' && $key && !$action) { $u->updateUser((int)$key); exit; }
    http_response_code(404);
    echo json_encode(['error' => 'Unknown endpoint']);
    exit;
}

// =========== DEFAULT: 404 NOT FOUND ===========
http_response_code(404);
echo json_encode(['error' => 'Not Found']);
exit;

?>
