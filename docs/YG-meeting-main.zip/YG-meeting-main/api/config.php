<?php
// File: api/config.php
// Version: 1.9.1
// Date: 2025-06-25
// Author: Meeting Server Team
// Description: Configuration centralisée pour Meeting API (aucun objet PDO, juste les paramètres !)

$dataRoot = getenv('MEETING_DATA_ROOT') ?: '/var/meeting';
$secretsPath = getenv('MEETING_SECRETS_PATH') ?: "$dataRoot/config.secrets.php";
$secrets = file_exists($secretsPath)
    ? require $secretsPath
    : [];

$config = [
    // === Connexion à la base de données MySQL/MariaDB ===
    // Hôte (adresse IP ou DNS) de la base de données
    'db_host'    => getenv('DB_HOST')    ?: '127.0.0.1',
    // Nom de la base de données utilisée par le projet
    'db_name'    => getenv('DB_NAME')    ?: 'meeting',
    // Nom d’utilisateur SQL utilisé pour la connexion
    'db_user'    => getenv('DB_USER')    ?: 'meeting',
    // Jeu de caractères pour la connexion PDO
    'db_charset' => getenv('DB_CHARSET') ?: 'utf8mb4',

    // === Authentification SSH API (clé pour authorized_keys, sécurité agent SSH) ===

    // === Administration : compte d’accès temporaire à l’interface admin Meeting ===
    // Nom d’utilisateur pour le panneau d’admin (temporaire)
    'admin_user' => getenv('ADMIN_USER') ?: 'sn8k',

    // === Timeout de heartbeat pour la disponibilité des devices (en secondes) ===
    // Durée maximale (en secondes) sans heartbeat avant qu’un device soit considéré "offline"
    'device_heartbeat_timeout' => getenv('DEVICE_HEARTBEAT_TIMEOUT') ?: 60,

    // === Répertoire et paramètres pour la stack reverse tunnel (TunnelController et forcecommand) ===
    // Dossier où sont déposés les fichiers de demande de tunnel
    'tunnel_requests_dir' => getenv('TUNNEL_REQUESTS_DIR') ?: $dataRoot . '/api/tunnel_requests',
    // Dossier où sont stockés les fichiers de statut de tunnel
    'tunnel_status_dir'   => getenv('TUNNEL_STATUS_DIR')   ?: $dataRoot . '/api/tunnel_status',
    // Fichier de log dédié à la gestion des tunnels reverse
    'tunnel_logfile'      => getenv('TUNNEL_LOGFILE')      ?: $dataRoot . '/api/logs/tunnel_api.log',
    // Nom d’hôte (FQDN ou IP) utilisé pour générer les URLs de tunnel (HTTP/VNC/SSH)
    'tunnel_host'         => getenv('TUNNEL_HOST')         ?: 'clusterTO83.meeting.ygsoft.fr',
    // Chemin cible par défaut pour les commandes SCP (tunnel scp)
    'scp_default_path'    => getenv('SCP_DEFAULT_PATH')    ?: '/path',

    // === Journaux (logs) pour les statuts devices ===
    // Fichier log pour les statuts devices (StatusController)
    'status_logfile'   => getenv('STATUS_LOGFILE')   ?: $dataRoot . '/api/logs/status_api.log',
    // Nombre maximum de logs "connection" conservés par device (purge au-delà)
    'status_max_logs'  => getenv('STATUS_MAX_LOGS')  ?: 25,

    // === Logs et token pour gestion des clés SSH (SshKeysController) ===
    // Fichier log dédié aux opérations sur les clés SSH devices
    'ssh_keys_logfile' => getenv('SSH_KEYS_LOGFILE') ?: $dataRoot . '/api/logs/ssh_keys_api.log',
    'user_keys_sync_logfile' => getenv('USER_KEYS_SYNC_LOGFILE') ?: $dataRoot . '/api/logs/user_keys_sync.log',
    // Script de synchronisation des cles SSH utilisateurs
    'user_key_sync_script' => getenv('USER_KEY_SYNC_SCRIPT') ?: dirname(__DIR__) . '/resident_tools/ygs-UserKeysSync.sh',
    // Répertoire contenant les clés privées des devices (lecture seule)
    'device_keys_root' => getenv('DEVICE_KEYS_ROOT') ?: $dataRoot . '/device_private_keys',

    // === Logs système et API pour les métriques systèmes (MetricsController) ===
    // Fichier de log général de l’API backend (toutes les requêtes)
    'backend_logfile' => getenv('BACKEND_LOGFILE') ?: $dataRoot . '/api/logs/backend_api.log',

    // === Paramètres pour la gestion des ports SSH reverse (ForceCommandController) ===
    // Premier port utilisable pour l’attribution de tunnels dynamiques
    'forcecommand_port_min'             => getenv('FORCECOMMAND_PORT_MIN') ?: 9050,
    // Dernier port utilisable pour l’attribution de tunnels dynamiques
    'forcecommand_port_max'             => getenv('FORCECOMMAND_PORT_MAX') ?: 9130,
    // Délai maximal (en secondes) entre deux heartbeats pour valider un device (forcecommand)
    'forcecommand_max_last_seen'        => getenv('FORCECOMMAND_MAX_LAST_SEEN') ?: 120,
    // Durée (en secondes) de réservation d’un port de tunnel (avant expiration)
    'forcecommand_reservation_duration' => getenv('FORCECOMMAND_RESERVATION_DURATION') ?: 300,

    // === Répertoire racine de stockage des firmwares/distributions binaires devices (FlashController, DeviceController) ===
    // Chemin absolu du dossier de stockage des fichiers de flash/distrib (firmwares, updates…)
    'flash_storage_root'    => getenv('FLASH_STORAGE_ROOT') ?: $dataRoot . '/storage',

    // === Paramètres DeviceController : logs, stockage, scripts, tunnels, debug ===
    // Fichier de log principal pour toutes les opérations de DeviceController
    'device_logfile'         => getenv('DEVICE_LOGFILE') ?: $dataRoot . '/api/logs/device_service.log',
    // Fichier de log pour la modification des notes device
    'device_note_logfile'    => getenv('DEVICE_NOTE_LOGFILE') ?: $dataRoot . '/api/logs/device_notes.log',
    // Chemin général du stockage (utilisé pour lister types/distributions/devices)
    'storage_path'           => getenv('STORAGE_PATH') ?: $dataRoot . '/storage',
    // Chemin du script de synchronisation des clés SSH (appelé automatiquement)
    'key_sync_script'        => getenv('KEY_SYNC_SCRIPT') ?: dirname(__DIR__) . '/resident_tools/ygs-KeysSync.sh',
    // Fichier de log pour debug détaillé des workflows tunnel
    'tunnel_debug_logfile'   => getenv('TUNNEL_DEBUG_LOGFILE') ?: $dataRoot . '/tmp/tunnel_debug.log',
    // Délai d’attente maximal (en secondes) pour l’établissement d’un tunnel dynamique device
    'tunnel_timeout'         => getenv('TUNNEL_TIMEOUT') ?: 30,

    // === Métadonnées de la clé publique SSH serveur ===
    // Date de génération de la clé publique serveur
    'server_pubkey_date' => getenv('SERVER_PUBKEY_DATE') ?: '2025-05-25 18:12:00',
    // Date du dernier déploiement (push) de la clé serveur sur les devices
    'server_key_last_deploy' => getenv('SERVER_KEY_LAST_DEPLOY') ?: '2025-05-27 13:55:41',

    // === Endpoints et logs pour MetricsController/Admin ===
    // Chemin relatif ou absolu vers l’API metrics (frontend admin)
    'metrics_api_url' => getenv('METRICS_API_URL') ?: '/api/metrics',
    // Chemin absolu du fichier log Metrics (utilisé si affichage côté PHP natif)
    'metrics_logfile' => getenv('METRICS_LOGFILE') ?: $dataRoot . '/api/logs/metrics_api.log',

    // === Distrib Builder ===
    // Dossier racine pour les builds temporaires et packages
    'builder_storage_root' => getenv('BUILDER_STORAGE_ROOT') ?: $dataRoot . '/builder_storage',
    // Dossier racine pour YGScreen (medias, playlists)
    'ygscreen_storage_root' => getenv('YGSCREEN_STORAGE_ROOT') ?: $dataRoot . '/ygscreen',
    // Fichier log pour les opérations du builder
    'builder_logfile'      => getenv('BUILDER_LOGFILE') ?: $dataRoot . '/api/logs/builder_api.log',
    // Fichier log pour le serveur NTP interne
    'ntp_logfile'          => getenv('NTP_LOGFILE') ?: $dataRoot . '/api/logs/ntp_server.log',
    // Fichier log du backend YGScreen
    'ygscreen_logfile'     => getenv('YGSCREEN_LOGFILE') ?: $dataRoot . '/api/logs/ygscreen_backend.log',
    // Extensions de fichier autorisées lors de l'upload
    'builder_allowed_extensions' => explode(',', getenv('BUILDER_ALLOWED_EXTENSIONS') ?: 'tar.gz,zip,json,txt,png'),
    // Taille maximum d'un fichier uploadé (en octets)
    'builder_max_upload_size'    => (int)(getenv('BUILDER_MAX_UPLOAD_SIZE') ?: 10*1024*1024),

    // Répertoire pour les icônes associées aux device types
    'device_type_icon_dir' => getenv('DEVICE_TYPE_ICON_DIR') ?: $dataRoot . '/device_type_icons',

];

return array_merge($config, $secrets);
