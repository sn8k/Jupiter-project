<?php
// File: api/log_helpers.php
// Version: 1.1.2
// Date: 2025-06-13
// Simple helper functions for log management
function ensure_log_directory(string $path): void {
    $dir = dirname($path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
}

/**
 * Append a line to a log file with optional rotation.
 * @param string $file Path to the log file.
 * @param string $line Log line to append (already terminated with \n).
 * @param int $maxBytes Maximum allowed size before rotation.
 */
function write_log(string $file, string $line, int $maxBytes = 1048576): void {
    ensure_log_directory($file);
    if (is_file($file) && filesize($file) >= $maxBytes) {
        @rename($file, $file . '.' . time());
    }
    error_log($line, 3, $file);
}
